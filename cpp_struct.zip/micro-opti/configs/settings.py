import os
from dotenv import load_dotenv

import logging
from core.utils.reporting import WriteRemoteRunLog

# Load environment variables to be stored in settings
load_dotenv()

VERSION = "v.0.1.0"
SQL_DIR = "sql/"
# fmt: off
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

INSTALLED_MODULES = ["core"]

CONFIG_PATH = os.path.join(BASE_DIR, "configs")

CONTEXT_BACKEND = "oxygen.conf.context.DefaultContextManager"
EXECUTOR_BACKEND = "oxygen.exec.executors.LocalExecutor"
READER_BACKEND = "core.utils.readers.SynapsePandasReader"

# Azure storage settings
STORAGE_BACKEND = "oxygen.files.storages.local.LocalStorage"
STORAGE_HOSTNAME = ""
AZURE_STORAGE_NAME = ""
ADLS_PATH = ""

AZURE_STORAGE_KEY = os.environ.get("AZURE_STORAGE_KEY", "your-default-key")
AZURE_STORAGE_CONTAINER = ""
STORAGE_ROOT = "./output/"
STORAGE_URL = ""

DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN", "your-default-token")
DATABRICKS_SERVER = os.getenv("DATABRICKS_SERVER", "your-databricks-server")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "your-databricks-http-path")
database = "hive_metastore"

SQL_CONNECTION = (
    "databricks://token:{token}@{host}:{port}/{database}?http_path={http_path}".format(
        token=DATABRICKS_TOKEN,
        host=DATABRICKS_SERVER,
        port=443,
        database=database,
        http_path=DATABRICKS_HTTP_PATH,
    )
)

AIRFLOW_IMAGE = ""
AIRFLOW_DAG_PREFIX = "assortment"
AIRFLOW_PRE_SCRIPT = "cd assortment"
AIRFLOW_BASE_URL = os.getenv("AIRFLOW_BASE_URL", "your-airflow-url")
AIRFLOW_API_TOKEN = os.environ.get("AIRFLOW_API_TOKEN", "your-default-token")
AIRFLOW_DEPLOY_DAGS = [
    # Add the DAGs we want deployed
    # "core.dags.TrainForecaster",
]
AIRFLOW_TEMPLATE = "core/utils/templates/dag.j2"
AIRFLOW_KUBERNETES_AFFINITY = {
    'nodeAffinity': {
        'requiredDuringSchedulingIgnoredDuringExecution': {
            'nodeSelectorTerms': [{
                'matchExpressions': [{
                    'key': 'agentpool',
                    'operator': 'In',
                    'values': ['airflowexec', ]
                }]
            }]
        }
    }
}

START_TASK = "oxygen.exec.task.BootstrapTask"

LOGGING = {
    "version": 1,
    "formatters": {
        "full": {
            "format": "[%(asctime)s][%(levelname)s][%(filename)s][%(module)s.%(funcName)s:%(lineno)d] %(message)s", # noqa
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
    },
    # "filters": {"write_run_log": {"()": WriteRemoteRunLog}},
    "filters": {"write_run_log": {"()": logging.Filter}},
    "handlers": {
        "default": {
            "class": "logging.StreamHandler",
            "formatter": "full",
            "level": os.getenv("LOG_LEVEL", "INFO"),
            "filters": ["write_run_log"],
        },
    },
    "loggers": {
        "assortment": {
            "handlers": ["default"],
            "level": "DEBUG",
            "propagate": True,
        },
        "core": {
            "handlers": ["default"],
            "level": "DEBUG",
            "propagate": True,
        },
        "oxygen": {
            "handlers": ["default"],
            "level": "DEBUG",
            "propagate": True,
        },
    }
}

AIRFLOW_EXTERNAL_TASK_SENSOR = {
    "timeout": 3600,
    "poke_interval": 300,
    "execution_date_fn": "get_last_dag_run_exec_dt"
}

PROMO_TO_DATAMART_DEPENDENCY_MAPPING = {
    "develop": "develop",
    "staging": "staging",
    "main": "master"
}

# Gurobi variables
GURO_PAR_ISVNAME = os.getenv("GURO_PAR_ISVNAME")
GURO_PAR_ISVAPPNAME = os.getenv("GURO_PAR_ISVAPPNAME")
GURO_PAR_ISVEXPIRATION = os.getenv("GURO_PAR_ISVEXPIRATION")
GURO_PAR_ISVKEY = os.getenv("GURO_PAR_ISVKEY")

# Snowflake variables
SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT")
SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER")
SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE")
SNOWFLAKE_ROLE = os.getenv("SNOWFLAKE_ROLE")
SNOWFLAKE_CONFIGMAPNAME = os.getenv("SNOWFLAKE_CONFIGMAPNAME")