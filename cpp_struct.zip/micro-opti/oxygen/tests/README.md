# How to run tests

We run our tests within a Docker container to allow us to test
spark functionality as well.

Build image from this folder:

```bash
docker build -t oxygen -f ./Dockerfile ../
```

Run tests:

```bash
docker run
    -v $(pwd):/app/
    -v $(pwd)/../oxygen:/src/oxygen
    oxygen
```
