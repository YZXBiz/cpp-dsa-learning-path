import unittest
from io import BytesIO
from unittest.mock import Mock, patch

from oxygen.conf.context import Context, context_manager


class ContextTestCase(unittest.TestCase):
    def test_context_singleton(self):
        """
        Test that context is a singleton, no matter
        if you instantiate it again or not, it still refer
        to the same object.
        """
        c1 = Context({"foo": 1})
        c2 = Context({"foo": 2})
        self.assertTrue(c1 is c2)

    def test_context_singleton_functions(self):
        """
        Test that imported lazily evaluated context gets updated properly
        if we use the load_context function, even though it was imported before.

        Test written from bugfix to confirm it solved the bug.
        """
        # Imported, but not evaluated
        from oxygen.conf.context import context

        def load_context():
            with patch("oxygen.conf.context.storage") as storage_mock:
                storage_mock.open.return_value = BytesIO(b"foo: 2")
                Context.create_context(
                    context_manager.load_config("some/dir/file.yaml")
                )

        # Create context
        load_context()

        # Prove that context was not evaluated at import
        # but instead only evaluated when used.
        self.assertEqual(context.foo, 2)

    @patch("oxygen.conf.context.storage")
    def test_load_context(self, storage_mock: Mock):
        """Test that we can load a context from file"""
        storage_mock.open.side_effect = [
            BytesIO(b"foo: a"),
            BytesIO(b"foo: b"),
        ]

        # Test that we can use load_context as expected.
        c1 = Context.create_context(
            context_manager.load_config("/some/dir/context.yaml")
        )
        self.assertEqual(c1.foo, "a")

        # Test that if we instantiate a new context,
        # it is using the Singleton pattern to reuse
        # the existing context. Both c1 and c2 point to
        # the same object.
        c2 = Context.create_context(
            context_manager.load_config("/some/dir/context.yaml")
        )
        self.assertEqual(c2.foo, "b")
        self.assertEqual(c1.foo, "b")

    def test_context_immutable(self):
        """
        Our context is immutable, that means
        that we cannot change its attributes after
        it has been loaded.
        """
        context = Context({"foo": 1})
        with self.assertRaises(TypeError):
            context.foo = 2  # Not allowed.

    def test_context_getattr_to_dict(self):
        """
        Test that even though Context do not have a
        to_dict() method, the getattr implementation
        redirects the call to the Box.to_dict() method.
        """
        self.assertTrue(
            Context({"foo": {"bar": 1}}).to_dict(),
            {"foo": {"bar": 1}},
        )
