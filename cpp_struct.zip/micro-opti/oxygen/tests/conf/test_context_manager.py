import datetime
from unittest import TestCase
from unittest.mock import Mock, patch

from oxygen.conf.context import DefaultContextManager


class DefaultContextManagerTestCase(TestCase):
    def setUp(self):
        self.context_manager = DefaultContextManager()

    @patch("oxygen.conf.context.datetime")
    @patch("oxygen.conf.context.uuid.uuid4")
    def test_get_run_meta(self, uuid4_mock: Mock, dt_mock: Mock):
        uuid4_mock.return_value = "1234-5678-9012"
        dt_mock.now.return_value = datetime.datetime(2020, 4, 2, 0, 0, 0)
        self.assertEqual(
            self.context_manager.get_run_meta(),
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                }
            },
        )

    def test_create_context(self):
        """Test that we can load a context from scratch"""
        load_mock = Mock()
        load_mock.return_value = {"foo": 1}
        meta_mock = Mock()
        meta_mock.return_value = {
            "meta": {
                "run_id": "1234-5678-9012",
                "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                "run_folder": "/runs/2020/04/02/1234-5678-9012/",
            }
        }
        self.context_manager.load_config = load_mock
        self.context_manager.get_run_meta = meta_mock
        self.assertEqual(
            self.context_manager.create_context(),
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
                "foo": 1,
            },
        )

    def test_create_context_preexisting_config(self):
        """
        Test that we can provide an existing config and we
        get that one back as context without loading from disk.
        """
        self.assertEqual(
            self.context_manager.create_context(
                {
                    "meta": {
                        "run_id": "1234-5678-9012",
                        "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                        "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                    },
                    "foo": 1,
                }
            ),
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
                "foo": 1,
            },
        )

    def test_create_context_preexisting_config_and_patch(self):
        """
        Test that we can provide an existing config and patches and
        they all get merged into a single dictionary.
        """
        self.assertEqual(
            self.context_manager.create_context(
                {
                    "meta": {
                        "run_id": "1234-5678-9012",
                        "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                        "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                    },
                    "foo": 1,
                },
                patches=[{"foo": 2}, {"foo": 3, "bar": 1}],
            ),
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
                "foo": 3,
                "bar": 1,
            },
        )
