from unittest import TestCase

import pandas as pd

from oxygen.files.readers.pandas import PandasReader
from oxygen.files.schemas import FloatColumn, IntegerColumn, Schema, StringColumn
from oxygen.files.validators.pandas import (
    MaxValueValidator,
    MinValueValidator,
    NotNullValidator,
    RangeValidator,
    RegexValidator,
    UniqueValidator,
    ValidationError,
)


class PandasValidatorsTestCase(TestCase):
    def setUp(self):
        self.reader = PandasReader()

    def test_not_null_validator(self):
        """
        Test that ValidationError is raised
        if value is None when using NotNullValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            name = StringColumn(validators=[NotNullValidator()])

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "name": ["Shoe", "Shirt", None],
                    }
                ),
                SampleSchema,
            )

    def test_not_null_validator_valid(self):
        """
        Test that no ValidationError is raised as we
        validate a valid dataframe when using NotNullValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            name = StringColumn(validators=[NotNullValidator()])

        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoe", "Shirt", "Pants"],
                }
            ),
            SampleSchema,
        )

    def test_unique_validator(self):
        """
        Test that ValidationError is raised if values
        are not unique when using UniqueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn(validators=[UniqueValidator()])
            name = StringColumn()

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 2],
                        "name": ["Shoe", "Shirt", "Pants"],
                    }
                ),
                SampleSchema,
            )

    def test_unique_validator_cross_cols(self):
        """
        Test that ValidationError is raised if values
        across multiple columns are not unique when
        using the UniqueValidator.
        """

        class SampleSchema(Schema):
            validators = [UniqueValidator(unique_cols=["product_id", "price"])]
            product_id = IntegerColumn()
            name = StringColumn()
            price = FloatColumn()

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 2],
                        "name": ["Shoe", "Shirt", "Shirt Expensive"],
                        "price": [10.0, 20.0, 20.0],
                    }
                ),
                SampleSchema,
            )

    def test_unique_validator_cross_cols_valid(self):
        """
        Test that ValidationError is NOT raised if values
        across columns are unique even though individual
        columns might not be unique.
        """

        class SampleSchema(Schema):
            validators = [UniqueValidator(unique_cols=["product_id", "price"])]
            product_id = IntegerColumn()
            name = StringColumn()
            price = FloatColumn()

        # No exception should be raised.
        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 2],
                    "name": ["Shoe", "Shirt", "Shirt Expensive"],
                    "price": [10.0, 20.0, 30.0],
                }
            ),
            SampleSchema,
        )

    def test_unique_validator_valid(self):
        """
        Test that ValidationError is NOT raised if values
        are unique when using UniqueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn(validators=[UniqueValidator()])
            name = StringColumn()

        # No exception should be raised.
        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoe", "Shirt", "Pants"],
                }
            ),
            SampleSchema,
        )

    def test_range_validator(self):
        """
        Test that ValidationError is raised if values
        are outside of range when using RangeValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[RangeValidator(start=0, end=10)])

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "price": [5, 10, 100],
                    }
                ),
                SampleSchema,
            )

    def test_range_validator_valid(self):
        """
        Test that ValidationError is NOT raised if values
        are within range when using RangeValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[RangeValidator(start=0, end=1000)])

        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "price": [5, 10, 100],
                }
            ),
            SampleSchema,
        )

    def test_min_value_validator(self):
        """
        Test that ValidationError is raised if values
        are outside of limit when using MinValueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[MinValueValidator(limit=10)])

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "price": [5, 10, 100],
                    }
                ),
                SampleSchema,
            )

    def test_min_value_validator_valid(self):
        """
        Test that ValidationError is NOT raised if values
        are within limit when using MinValueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[MinValueValidator(limit=10)])

        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "price": [10, 20, 100],
                }
            ),
            SampleSchema,
        )

    def test_max_value_validator(self):
        """
        Test that ValidationError is raised if values
        are outside of limit when using MaxValueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[MaxValueValidator(limit=10)])

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "price": [5, 10, 100],
                    }
                ),
                SampleSchema,
            )

    def test_max_value_validator_valid(self):
        """
        Test that ValidationError is NOT raised if values
        are within limit when using MaxValueValidator.
        """

        class SampleSchema(Schema):
            product_id = IntegerColumn()
            price = IntegerColumn(validators=[MaxValueValidator(limit=100)])

        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "price": [10, 20, 50],
                }
            ),
            SampleSchema,
        )

    def test_regex_validator(self):
        """
        Test that ValidationError is raised if values
        do not match regular expression when using RegexValidator.
        """

        class SampleSchema(Schema):
            user_id = IntegerColumn()
            email = StringColumn(
                validators=[
                    RegexValidator(
                        # Email validation pattern.
                        pattern=r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
                    )
                ]
            )

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "user_id": [1, 2, 3],
                        "email": [
                            "foo@bar.com",
                            "bar@foo.com",
                            "foo@bar",  # invalid
                        ],
                    }
                ),
                SampleSchema,
            )

    def test_regex_validator_not_str(self):
        """
        Test that AssertionError is raised if we attempt to use
        RegexValidator on a not-str field.
        """

        class SampleSchema(Schema):
            user_id = IntegerColumn()
            email = IntegerColumn(
                validators=[
                    RegexValidator(
                        # Email validation pattern.
                        pattern=r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
                    )
                ]
            )

        with self.assertRaises(TypeError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "user_id": [1, 2, 3],
                        "email": [1, 2, 3],
                    }
                ),
                SampleSchema,
            )

    def test_regex_validator_valid(self):
        """
        Test that ValidationError is NOT raised if values
        do match regular expression when using RegexValidator.
        """

        class SampleSchema(Schema):
            user_id = IntegerColumn()
            email = StringColumn(
                validators=[
                    RegexValidator(
                        # Email validation pattern.
                        pattern=r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
                    )
                ]
            )

        self.reader.validate(
            pd.DataFrame(
                {
                    "user_id": [1, 2],
                    "email": [
                        "foo@bar.com",
                        "bar@foo.com",
                    ],
                }
            ),
            SampleSchema,
        )
