import datetime
from unittest import TestCase
from unittest.mock import Mock, patch

import numpy as np
import pandas as pd

from oxygen.files.readers.bigquery import BigQueryReader
from oxygen.files.schemas import DateColumn, DateTimeColumn, IntegerColumn, Schema


class BigQueryReaderTestCase(TestCase):
    def setUp(self, *args, **kwargs):
        self.mock_client = Mock()
        self.patcher = patch(
            "oxygen.files.readers.bigquery.Client", return_value=self.mock_client
        )
        self.mock_client_cls = self.patcher.start()
        self.reader = BigQueryReader()

    def tearDown(self):
        self.patcher.stop()

    def test_read(self):
        """
        Test that read method can handle bq data_format and
        redirect to _read_bigquery submethod. We do not need to
        test other data formats (such as csv) since it's covered by
        the Oxygen testsuite.
        """
        self.reader._read_bigquery = Mock()
        self.reader.read("foo", data_format="bq")
        self.reader._read_bigquery.assert_called_once_with(table="foo", schema=None)

    @patch("oxygen.files.readers.bigquery.BigQueryReader.get_query_hash")
    @patch("oxygen.files.readers.bigquery.ExtractJobConfig")
    @patch("oxygen.files.readers.bigquery.QueryJobConfig")
    def test_read_bigquery(
        self,
        mock_query_config_cls: Mock,
        mock_extract_config_cls: Mock,
        mock_get_hash: Mock,
    ):
        """
        Test the main bigquery reader method
        and how it interacts with GCP SDK.

        Actual calls are mocked so there is no real interaction
        with BigQuery in this test, only the SDK methods.
        """
        # Setup mocks
        mock_query_config = Mock()
        mock_query_config_cls.return_value = mock_query_config
        mock_extract_config = Mock()
        mock_extract_config_cls.return_value = mock_extract_config
        mock_get_df = Mock()
        mock_get_df.return_value = pd.DataFrame({"foo": [1]})
        self.reader.get_df_from_tmp = mock_get_df
        mock_get_hash.return_value = "ad38ffc37"

        # Do actual call that we want to test.
        self.reader._read_bigquery("foo", sql="SELECT * FROM %(table)s", cache=False)

        # Assert that the client was instantiated.
        self.mock_client_cls.assert_called_once()
        # Assert that get_dataset was called.
        self.mock_client.get_dataset.assert_called_once_with("demo-project.etl_staging")
        # Assert that a query config was created
        mock_query_config_cls.assert_called_once()
        # Assert that an extract config was created
        mock_extract_config_cls.assert_called_once()
        # Assert that the query was done with the SQL passed in.
        self.mock_client.query.assert_called_once_with(
            "SELECT * FROM demo-project.foo",
            location="EU",
            job_config=mock_query_config,
        )
        # Assert that extract_table was called
        self.mock_client.extract_table.assert_called_once()
        # Assert that delete_table was called
        self.mock_client.delete_table.assert_called_once()
        # Assert that get_df_from_tmp was called
        mock_get_df.assert_called_once_with(suffix="tmp_results_ad38ffc37")

    @patch("oxygen.files.readers.bigquery.BigQueryReader.get_query_hash")
    @patch("oxygen.files.readers.bigquery.ExtractJobConfig")
    @patch("oxygen.files.readers.bigquery.QueryJobConfig")
    @patch("oxygen.files.readers.bigquery.Client")
    @patch("oxygen.files.readers.bigquery.storage")
    def test_read_bigquery_cache(
        self,
        mock_client_cls: Mock,
        mock_query_config_cls: Mock,
        mock_extract_config_cls: Mock,
        mock_get_hash: Mock,
        mock_storage: Mock,
    ):
        """
        Test the bigquery reader with caching.

        """
        # Setup mocks
        mock_query_config = Mock()
        mock_query_config_cls.return_value = mock_query_config
        mock_extract_config = Mock()
        mock_extract_config_cls.return_value = mock_extract_config
        mock_client = Mock()
        mock_client_cls.return_value = mock_client
        mock_get_df = Mock()
        mock_get_df.return_value = pd.DataFrame({"foo": [1]})
        self.reader.get_df_from_tmp = mock_get_df
        mock_get_hash.return_value = "ad38ffc37"
        mock_storage.list_files_by_prefix.return_value = [
            f"tmp/tmp_{self.reader.get_query_hash('')}_0000000"
        ]

        # Do actual call that we want to test.
        self.reader._read_bigquery("foo", sql="SELECT * FROM %(table)s", cache=True)

        # Assert that the client was NOT instantiated.
        mock_client_cls.assert_not_called()

    @patch("oxygen.files.readers.bigquery.datetime")
    def test_get_query_hash(self, mock_dt: Mock):
        """Test that method return md5 hash of query with date salt"""
        mock_dt.datetime.utcnow.return_value = datetime.datetime(2020, 1, 1)
        md5 = self.reader.get_query_hash("SELECT * FROM table WHERE 1")
        self.assertEqual(md5, "84d6f1ef9164e7509c2eedc5b16391d3")

    @patch("oxygen.files.readers.bigquery.storage")
    def test_get_df_from_tmp(self, mock_storage: Mock):
        """
        Test that get_df_from_tmp reads in files from dir and
        concatenate the data into a single dataframe.
        """
        # list_files_by_prefix returns 3 valid files (matching the prefix).
        mock_storage.list_files_by_prefix.return_value = [
            "foobar_a.csv",
            "foobar_b.csv",
            "foobar_c.csv",
        ]
        read_mock = Mock()
        # Mock data of successful reads.
        read_mock.side_effect = [
            pd.DataFrame({"foo": [1]}),
            pd.DataFrame({"foo": [2]}),
            pd.DataFrame({"foo": [3]}),
        ]
        self.reader.read = read_mock

        # Do actual call we want to test
        df = self.reader.get_df_from_tmp(suffix="foobar", tmp_dir="tmp/")

        # Assert list_files_by_prefix was called with correct path.
        mock_storage.list_files_by_prefix.assert_called_once_with("tmp/foobar")
        # Assert that even though 4 files were found, only 3 were
        # read in since only 3 matched the provided suffix.
        self.assertEqual(len(self.reader.read.call_args_list), 3)
        # Assert that the returned dataframe was the concat data
        # of the 3 separate dataframes that were read in.
        pd.testing.assert_frame_equal(df, pd.DataFrame({"foo": [1, 2, 3]}))

    def test_generate_sql(self):
        """Test that SELECT statement can be generated from schema"""

        class TestSchema(Schema):
            product_id = IntegerColumn()
            qty = IntegerColumn()

        sql = BigQueryReader.generate_sql(
            table="products", schema=TestSchema, where="1=1"
        )
        self.assertEqual(
            sql,
            "SELECT product_id, qty FROM demo-project.products WHERE 1=1",
        )

    def test_get_dtype_schema(self):
        """
        Test that get_dtype_schema return the column dtype mapping that
        is valid for Pandas.read_csv(). This also means that "datetime64[ns]"
        are treated as strings.
        """

        class TestSchema(Schema):
            product_id = IntegerColumn()
            created_at = DateTimeColumn()

        dtypes = self.reader.get_dtype_schema(schema=TestSchema)
        self.assertEqual(dtypes, {"product_id": np.int64, "created_at": str})

    def test_get_schema_map(self):
        """
        Test that the _get_schema_map method maps our Oxygen Schema
        to the correct BigQuery types.
        """

        class TestSchema(Schema):
            product_id = IntegerColumn()
            created_at = DateTimeColumn()
            created_on = DateColumn()

        mapping = self.reader._get_schema_map(TestSchema)
        self.assertEqual(
            mapping,
            [
                {"name": "product_id", "type": "INT64"},
                {"name": "created_at", "type": "DATETIME"},
                {"name": "created_on", "type": "DATE"},
            ],
        )
