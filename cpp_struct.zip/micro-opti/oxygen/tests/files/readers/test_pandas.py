import unittest
from unittest.mock import Mock, patch

import numpy as np
import pandas as pd

from oxygen.conf.context import Context, context_manager
from oxygen.files.readers.pandas import PandasReader
from oxygen.files.schemas import (
    BoolColumn,
    DateColumn,
    DateTimeColumn,
    IntegerColumn,
    PandasCategoryColumn,
    Schema,
    StringColumn,
)
from oxygen.files.validators.pandas import NotNullValidator, ValidationError


class PandasReaderTestCase(unittest.TestCase):
    def setUp(self):
        class FooSchema(Schema):
            product_id = IntegerColumn()
            name = StringColumn(validators=[NotNullValidator()])

        Context.create_context(config=context_manager.load_config("config.yaml"))
        self.reader = PandasReader()
        self.schema = FooSchema

    def test_to_schema(self):
        """
        Test if we can convert our schema to a reader specific schema
        """
        self.assertEqual(
            self.reader.to_schema(self.schema),
            {"product_id": np.int64, "name": object},
        )

    def test_validate(self):
        """
        Test that validation of valid DataFrame do
        NOT raise any ValidationError. No asserts needed.
        """
        self.reader.validate(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoe", "Shirt", "Pants"],
                }
            ),
            self.schema,
        )

    def test_validate_extra_col(self):
        """
        Test that ValidationError is raised if
        the DataFrame contain extra columns.
        """
        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "name": ["Shoe", "Shirt", "Pants"],
                        "foo": [1, 2, 3],
                    }
                ),
                self.schema,
            )

    def test_validate_missing_col(self):
        """
        Test that ValidationError is raised if
        the DataFrame has missing columns.
        """
        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                    }
                ),
                self.schema,
            )

    def test_validate_validator_not_null(self):
        """
        Test that ValidationError is raised from the
        NotNullValidator set on name column.
        """
        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, 3],
                        "name": ["Shoe", "Shirt", None],
                    }
                ),
                self.schema,
            )

    def test_validate_validator_not_null_schema_wide(self):
        """
        Test that ValidationError is raised from the
        NotNullValidator set on the schema class.
        """

        class FooSchema(Schema):
            validators = [NotNullValidator()]  # Testing this.
            product_id = IntegerColumn()
            name = StringColumn()

        schema = FooSchema

        with self.assertRaises(ValidationError):
            self.reader.validate(
                pd.DataFrame(
                    {
                        "product_id": [1, 2, None],
                        "name": ["Shoe", "Shirt", "Pants"],
                    }
                ),
                schema,
            )

    @patch("oxygen.files.readers.pandas.PandasReader._read_csv")
    def test_read(self, read_mock: Mock):
        """
        Test that read function route to correct read method based
        on file extension, and also executes clean and validate if
        schema is passed with the file path.
        """
        # Prepare mocks
        df_mock = Mock()
        read_mock.return_value = df_mock
        schema_mock = Mock()
        schema_mock.clean.return_value = df_mock
        self.reader.cast = Mock()
        self.reader.cast.return_value = df_mock
        self.reader.rename = Mock()
        self.reader.rename.return_value = df_mock

        # Run tests and asserts
        self.reader.read("path/to/file.csv", schema_mock)
        read_mock.assert_called_once_with("path/to/file.csv", root=False)
        self.reader.cast.assert_called_once_with(df_mock, schema_mock)
        self.reader.rename.assert_called_once_with(df_mock, schema_mock)
        schema_mock.clean.assert_called_once_with(df_mock)
        schema_mock.validate.assert_called_once_with(df_mock)

    @patch("oxygen.files.readers.pandas.PandasReader._read_csv")
    def test_read_no_schema(self, read_mock: Mock):
        """
        Test that read method reads file even though no schema
        is passed with the file path.
        """
        # Prepare mocks
        df_mock = Mock()
        read_mock.return_value = df_mock

        # Run tests and asserts
        df = self.reader.read("path/to/file.csv", None)
        self.assertEqual(df, df_mock)
        read_mock.assert_called_once_with("path/to/file.csv", root=False)

    @patch("oxygen.files.readers.pandas.PandasReader._read_csv")
    def test_read_invalid_extension(self, read_mock: Mock):
        """
        Test that ValueError is raised if try to read file
        that is not supported.
        """
        # Run tests and asserts
        with self.assertRaises(ValueError):
            self.reader.read("path/to/file.foobar", schema=None)

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_csv")
    def test_read_csv(self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock):
        """
        Test that when we are using a local storage, the read function
        do not attempt to copy the file to a tmp file and simply just
        reads it in from the default path.
        """
        storage_mock.is_remote = False
        self.reader._read_csv("path/to/file.csv", root=True)

        tmp_mock.assert_not_called()
        read_mock.assert_called_once_with(
            "/app/data/path/to/file.csv", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_csv")
    def test_read_csv_remote(self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock):
        """
        Test that when we are using a remote storage, the read function
        copies the remote file to a local tmp file before it attempts
        to read it.
        """
        tmp_mock.return_value.__enter__.return_value.name = "path/to/tmp-file.csv"
        storage_mock.is_remote = True
        self.reader._read_csv("path/to/file.csv", root=True)

        # First we copied the file to a temporary file,
        # then we used the temp file path to read in the csv file.
        tmp_mock.assert_called_once_with("/app/data/path/to/file.csv")
        read_mock.assert_called_once_with(
            "path/to/tmp-file.csv", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_excel")
    def test_read_xlsx(self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock):
        """
        Test that when we are using a local storage, the read function
        do not attempt to copy the file to a tmp file and simply just
        reads it in from the default path.
        """
        storage_mock.is_remote = False
        self.reader._read_xlsx("path/to/file.xlsx", root=True)

        tmp_mock.assert_not_called()
        read_mock.assert_called_once_with(
            "/app/data/path/to/file.xlsx", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_excel")
    def test_read_xlsx_remote(
        self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock
    ):
        """
        Test that when we are using a remote storage, the read function
        copies the remote file to a local tmp file before it attempts
        to read it.
        """
        tmp_mock.return_value.__enter__.return_value.name = "path/to/tmp-file.xlsx"
        storage_mock.is_remote = True
        self.reader._read_xlsx("path/to/file.xlsx", root=True)

        # First we copied the file to a temporary file,
        # then we used the temp file path to read in the csv file.
        tmp_mock.assert_called_once_with("/app/data/path/to/file.xlsx")
        read_mock.assert_called_once_with(
            "path/to/tmp-file.xlsx", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_parquet")
    def test_read_parquet(self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock):
        """
        Test that when we are using a local storage, the read function
        do not attempt to copy the file to a tmp file and simply just
        reads it in from the default path.
        """
        storage_mock.is_remote = False
        self.reader._read_parquet("path/to/file.parquet", root=True)

        tmp_mock.assert_not_called()
        read_mock.assert_called_once_with(
            "/app/data/path/to/file.parquet", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.PandasReader._copy_to_tmp")
    @patch("oxygen.files.readers.pandas.storage")
    @patch("oxygen.files.readers.pandas.pd.read_parquet")
    def test_read_parquet_remote(
        self, read_mock: Mock, storage_mock: Mock, tmp_mock: Mock
    ):
        """
        Test that when we are using a remote storage, the read function
        copies the remote file to a local tmp file before it attempts
        to read it.
        """
        tmp_mock.return_value.__enter__.return_value.name = "path/to/tmp-file.parquet"
        storage_mock.is_remote = True
        storage_mock.isdir.return_value = False
        read_mock.return_value = pd.DataFrame({"foo": [1]})
        self.reader._read_parquet("path/to/file.parquet", root=True)

        # First we copied the file to a temporary file,
        # then we used the temp file path to read in the csv file.
        tmp_mock.assert_called_once_with("/app/data/path/to/file.parquet")
        read_mock.assert_called_once_with(
            "path/to/tmp-file.parquet", dtype_backend="pyarrow"
        )

    @patch("oxygen.files.readers.pandas.create_engine")
    @patch("oxygen.files.readers.pandas.pd.read_sql")
    def test_read_sql(self, read_mock: Mock, create_engine_mock: Mock):
        """Test that we can read from database to dataframe using SQL"""

        class FooSchema(Schema):
            product_id = IntegerColumn()

        conn_mock = Mock()
        create_engine_mock.return_value = conn_mock
        self.reader._read_sql("foo", schema=FooSchema, where="product_id > 1")

        # Assert that a connection was created using the settings.SQL_CONNECTION
        create_engine_mock.assert_called_once_with(
            "postgresql://used:pw@localhost:5432/postgres"
        )

        # Assert that pandas.read_sql was used with the engine.
        read_mock.assert_called_once_with(
            "SELECT product_id FROM foo WHERE product_id > 1",
            conn_mock,
            dtype_backend="pyarrow",
        )

    @patch("oxygen.files.readers.pandas.PandasReader._write_csv")
    def test_write(self, write_mock: Mock):
        """
        Test that write function route to correct write method based
        on file extension, and also executes validate if schema is
        passed with the file path.
        """
        # Prepare mocks
        df_mock = Mock()
        schema_mock = Mock()
        schema_mock.clean.return_value = df_mock
        self.reader.cast = Mock()
        self.reader.cast.return_value = df_mock
        self.reader.rename = Mock()
        self.reader.rename.return_value = df_mock

        # Run tests and asserts
        self.reader.write("path/to/file.csv", df_mock, schema_mock)
        write_mock.assert_called_once_with("path/to/file.csv", df_mock, root=False)
        self.reader.cast.assert_called_once_with(df_mock, schema_mock)
        schema_mock.validate.assert_called_once_with(df_mock)

    @patch("oxygen.files.readers.pandas.PandasReader._write_csv")
    def test_write_no_schema(self, write_mock: Mock):
        """
        Test that write method write file even though no schema
        is passed with the file path.
        """
        # Prepare mocks
        df_mock = Mock()

        # Run tests and asserts
        self.reader.write("path/to/file.csv", df_mock, schema=None)
        write_mock.assert_called_once_with("path/to/file.csv", df_mock, root=False)

    @patch("oxygen.files.readers.pandas.PandasReader._write_csv")
    def test_write_invalid_extension(self, write_mock: Mock):
        """
        Test that ValueError is raised if try to write file
        that is not supported.
        """
        # Run tests and asserts
        with self.assertRaises(ValueError):
            self.reader.write("path/to/file.foobar", Mock(), None)

    @patch("oxygen.files.readers.pandas.storage")
    def test_write_csv(self, storage_mock: Mock):
        """
        Test that we can store file locally when is_remote is False
        using the normal pandas DataFrame method.
        """
        df_mock = Mock()
        storage_mock.is_remote = False
        self.reader._write_csv("path/to/file.csv", df_mock, root=True)
        df_mock.to_csv.assert_called_once_with("/app/data/path/to/file.csv")

    @patch("oxygen.files.readers.pandas.StringIO")
    @patch("oxygen.files.readers.pandas.storage")
    def test_write_csv_remote(self, storage_mock: Mock, io_mock: Mock):
        """
        Test that when we use a remote storage, we convert the dataframe
        to a io handler and then use the storage object to save the handler
        to the remote storage.
        """
        handler_mock = Mock()
        io_mock.return_value = handler_mock
        df_mock = Mock()

        storage_mock.is_remote = True
        self.reader._write_csv("path/to/file.csv", df_mock, root=True)

        # Test that handler reset its pointer to start.
        handler_mock.seek.assert_called_once_with(0)
        # Test that we store output of df to the io handler.
        df_mock.to_csv.assert_called_once_with(handler_mock)
        # Test that we store the handler using the storage object.
        storage_mock.touch.assert_called_once_with(
            "/app/data/path/to/file.csv", handler_mock
        )

    @patch("oxygen.files.readers.pandas.storage")
    def test_write_xlsx(self, storage_mock: Mock):
        """
        Test that we can store file locally when is_remote is False
        using the normal pandas DataFrame method.
        """
        df_mock = Mock()
        storage_mock.is_remote = False
        self.reader._write_xlsx("path/to/file.xlsx", df_mock, root=True)
        df_mock.to_excel.assert_called_once_with("/app/data/path/to/file.xlsx")

    @patch("oxygen.files.readers.pandas.BytesIO")
    @patch("oxygen.files.readers.pandas.pd.ExcelWriter")
    @patch("oxygen.files.readers.pandas.storage")
    def test_write_xlsx_remote(
        self, storage_mock: Mock, writer_mock: Mock, io_mock: Mock
    ):
        """
        Test that when we use a remote storage, we convert the dataframe
        to a io handler and then use the storage object to save the handler
        to the remote storage.
        """
        writer_instance_mock = Mock()
        writer_mock.return_value.__enter__.return_value = writer_instance_mock
        handler_mock = Mock()
        io_mock.return_value = handler_mock
        df_mock = Mock()

        storage_mock.is_remote = True
        self.reader._write_xlsx("path/to/file.xlsx", df_mock, root=True)

        # Test that handler reset its pointer to start.
        handler_mock.seek.assert_called_once_with(0)
        # Test that we store output of df to the io handler.
        df_mock.to_excel.assert_called_once_with(writer_instance_mock)
        # Test that we store the handler using the storage object.
        storage_mock.touch.assert_called_once_with(
            "/app/data/path/to/file.xlsx", handler_mock
        )

    @patch("oxygen.files.readers.pandas.storage")
    def test_write_parquet(self, storage_mock: Mock):
        """
        Test that we can store file locally when is_remote is False
        using the normal pandas DataFrame method.
        """
        df_mock = Mock()
        storage_mock.is_remote = False
        self.reader._write_parquet("path/to/file.parquet", df_mock, root=True)
        df_mock.to_parquet.assert_called_once_with("/app/data/path/to/file.parquet")

    @patch("oxygen.files.readers.pandas.BytesIO")
    @patch("oxygen.files.readers.pandas.pa")
    @patch("oxygen.files.readers.pandas.pq")
    @patch("oxygen.files.readers.pandas.storage")
    def test_write_parquet_remote(
        self, storage_mock: Mock, pq_mock: Mock, pa_mock: Mock, io_mock: Mock
    ):
        """
        Test that when we use a remote storage, we convert the dataframe
        to a io handler and then use the storage object to save the handler
        to the remote storage.
        """
        handler_mock = Mock()
        io_mock.return_value = handler_mock
        df_mock = Mock()
        table_mock = Mock()
        pa_mock.Table.from_pandas.return_value = table_mock

        storage_mock.is_remote = True
        self.reader._write_parquet("path/to/file.parquet", df_mock, root=True)

        # Test that we store output of df to the io handler.
        pa_mock.Table.from_pandas.assert_called_once_with(df_mock)
        pq_mock.write_table.assert_called_once_with(table_mock, handler_mock)
        # Test that handler reset its pointer to start.
        handler_mock.seek.assert_called_once_with(0)
        # Test that we store the handler using the storage object.
        storage_mock.touch.assert_called_once_with(
            "/app/data/path/to/file.parquet", handler_mock
        )

    @patch("oxygen.files.readers.pandas.create_engine")
    def test_write_sql(self, create_engine_mock: Mock):
        """Test that we can write dataframe to database using SQL"""
        conn_mock = Mock()
        create_engine_mock.return_value = conn_mock
        df = Mock()
        self.reader._write_sql("foo", df)

        # Assert that a connection was created using the settings.SQL_CONNECTION
        create_engine_mock.assert_called_once_with(
            "postgresql://used:pw@localhost:5432/postgres"
        )

        # Assert that pandas.DataFrame.to_sql was used with the engine.
        df.to_sql.assert_called_once_with("foo", conn_mock)

    def test_rename(self):
        """
        Test that the rename function rename according
        to mapping dictionary but leave all other columns
        intact.
        """
        schema_mock = Mock()
        schema_mock.get_mapping.return_value = {
            "ID": "product_id",
            "name": "name",
        }
        df = self.reader.rename(
            pd.DataFrame(
                {
                    "ID": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [0.1, 0.2, 0.3],
                }
            ),
            schema_mock,
        )

        pd.testing.assert_frame_equal(
            df,
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [0.1, 0.2, 0.3],
                }
            ),
        )

    def test_rename_already_renamed(self):
        """
        Test that the rename function does not fail when
        all columns have already been renamed.
        """
        schema_mock = Mock()
        schema_mock.get_mapping.return_value = {
            "ID": "product_id",
            "name": "name",
        }
        df = self.reader.rename(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [0.1, 0.2, 0.3],
                }
            ),
            schema_mock,
        )

        pd.testing.assert_frame_equal(
            df,
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [0.1, 0.2, 0.3],
                }
            ),
        )

    def test_cast(self):
        """
        Test that cast method casts the values into the
        dtypes that is defined within the schema but also
        filters out the columns to only keep the ones within
        the schema.
        """
        schema_mock = Mock()
        self.reader.to_schema = Mock()
        self.reader.to_schema.return_value = {
            "product_id": np.int64,
            "name": object,
            "price": np.float64,
        }

        df = self.reader.cast(
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [10, 10, 20],  # Integers
                    "other": [1, 1, 1],  # Extra col not in schema
                }
            ),
            schema_mock,
        )

        pd.testing.assert_frame_equal(
            df,
            pd.DataFrame(
                {
                    "product_id": [1, 2, 3],
                    "name": ["Shoes", "T-shirt", "Pants"],
                    "price": [10.0, 10.0, 20.0],  # Now floats
                }
            ),
        )

    def test_cast_date(self):
        """Test that casting date columns work as expected"""

        class FooSchema(Schema):
            today = DateColumn()
            now = DateTimeColumn()

        df = self.reader.cast(
            pd.DataFrame(
                {
                    "today": ["2020-03-20", "2020-03-21"],
                    "now": ["2020-03-20 23:29:00", "2020-03-21 23:29:00"],
                }
            ),
            FooSchema,
        )

        pd.testing.assert_frame_equal(
            df,
            pd.DataFrame(
                {
                    "today": [
                        np.datetime64("2020-03-20"),
                        np.datetime64("2020-03-21"),
                    ],
                    "now": [
                        np.datetime64("2020-03-20 23:29:00"),
                        np.datetime64("2020-03-21 23:29:00"),
                    ],
                }
            ),
        )

    def test_cast_bool(self):
        """Test that bool columns can be casted"""

        class FooSchema(Schema):
            is_good = BoolColumn()

        pd.testing.assert_frame_equal(
            self.reader.cast(
                pd.DataFrame({"is_good": [1, 0, 1, 0]}),
                FooSchema,
            ),
            pd.DataFrame({"is_good": [True, False, True, False]}),
        )

    def test_cast_pandas_category(self):
        """Test that PandasCategoryColumn can be casted"""

        class FooSchema(Schema):
            category = PandasCategoryColumn()

        df = self.reader.cast(
            pd.DataFrame({"category": ["shirts", "pants", "shirts"]}),
            FooSchema,
        )

        # Test that values were not modified.
        self.assertEqual(list(df.category.values), ["shirts", "pants", "shirts"])
        # Test that new dtype is Categorical.
        self.assertEqual(
            list(df.dtypes),
            [pd.CategoricalDtype(categories=["pants", "shirts"], ordered=False)],
        )

    def test_generate_sql(self):
        """
        Test that the generate_sql method generates a sql string
        based on the Schema
        """

        class FooSchema(Schema):
            product_id = IntegerColumn()

        sql = self.reader.generate_sql("foo", FooSchema)
        self.assertEqual(sql, "SELECT product_id FROM foo WHERE true")
