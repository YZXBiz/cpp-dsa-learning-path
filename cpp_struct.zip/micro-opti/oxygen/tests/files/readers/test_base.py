import unittest
from unittest.mock import Mock, patch

from oxygen.conf.context import Context, context_manager
from oxygen.files.readers.base import Reader


class BaseReaderTestCase(unittest.TestCase):
    def setUp(self):
        Context.create_context(context_manager.load_config("config.yaml"))
        self.reader = Reader()

    @patch("oxygen.files.readers.base.context")
    @patch("oxygen.files.readers.base.settings")
    def test_format_path(self, config_mock: Mock, context_mock: Mock):
        """
        Test that it formats the path into a full
        spark path with prepended spark endpoint.
        """
        context_mock.meta.run_folder = "runs/2019/10/31/someid/"
        config_mock.STORAGE_HOSTNAME = "wasbs://foo.com"
        config_mock.STORAGE_ROOT = "bar"
        path = self.reader.format_path("data.csv")
        self.assertEqual(path, "wasbs://foo.com/bar/runs/2019/10/31/someid/data.csv")

    @patch("oxygen.files.readers.base.context")
    @patch("oxygen.files.readers.base.settings")
    def test_format_path_absolute_paths(self, config_mock: Mock, context_mock: Mock):
        """
        Test that it still formats the correct path even
        though many sections of it is prefixed with / and
        appears to be absolute paths.
        """
        context_mock.meta.run_folder = "runs/2019/10/31/someid/"
        config_mock.STORAGE_HOSTNAME = "wasbs://foo/"
        config_mock.STORAGE_ROOT = "/bar"
        path = self.reader.format_path("/data.csv")
        self.assertEqual(path, "wasbs://foo/bar/runs/2019/10/31/someid/data.csv")

    @patch("oxygen.files.readers.base.context")
    @patch("oxygen.files.readers.base.settings")
    def test_format_path_missing_hostname(self, config_mock: Mock, context_mock: Mock):
        """
        Test that it can still format a local path if
        STORAGE_HOSTNAME is not set.
        """
        context_mock.meta.run_folder = "runs/2019/10/31/someid/"
        config_mock.STORAGE_HOSTNAME = None
        config_mock.STORAGE_ROOT = "/bar"
        path = self.reader.format_path("/data.csv")
        self.assertEqual(path, "/bar/runs/2019/10/31/someid/data.csv")

    @patch("oxygen.files.readers.base.settings")
    def test_format_path_from_root(self, config_mock: Mock):
        """
        Test that function called with root=True return a
        path relative to the STORAGE_ROOT without run_folder.
        """
        config_mock.STORAGE_HOSTNAME = None
        config_mock.STORAGE_ROOT = "/bar"
        path = self.reader.format_path("/data.csv", root=True)
        self.assertEqual(path, "/bar/data.csv")
