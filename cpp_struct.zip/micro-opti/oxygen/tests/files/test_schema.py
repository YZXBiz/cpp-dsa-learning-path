import unittest

import numpy as np

from oxygen.files.schemas import FloatColumn, IntegerColumn, Schema, StringColumn


class SchemaTestCase(unittest.TestCase):
    def setUp(self):
        class TestSchema(Schema):
            some_other_attr = 1  # Not a schema column.
            product_id = IntegerColumn()
            name = StringColumn(source="PRODUCT_TITLE")
            price = FloatColumn()

        self.schema = TestSchema

    def test_get_dtypes(self):
        """
        Test that we can get a dtype mapping between
        column attributes and their column dtype.
        """
        self.assertEqual(
            self.schema.get_dtypes(),
            {
                "product_id": np.int64,
                "name": str,
                "price": np.float64,
            },
        )

    def test_get_mapping(self):
        """
        Test that we can generate a mapping between source cols
        and attribute names.
        """
        self.assertEqual(
            self.schema.get_mapping(),
            {
                "product_id": "product_id",
                "PRODUCT_TITLE": "name",
                "price": "price",
            },
        )

    def test_get_columns(self):
        """
        Test that get_column method only fetch the attributes
        of the schema that is actually columns. In this case
        it ignores the `some_other_attr` attribute.
        """
        self.assertEqual(
            list(self.schema.get_columns().keys()), ["product_id", "name", "price"]
        )

    def test_get_columns_inherited(self):
        """
        Test that get_columns get inherited columns as well,
        this needs to be tested because some methods of getting
        attributes do not include inheritance.
        """

        class Foo(Schema):
            product_id = IntegerColumn()
            name = StringColumn()

        class Bar(Foo):
            price = FloatColumn()

        self.assertEqual(
            list(Bar.get_columns().keys()), ["price", "product_id", "name"]
        )

    def test_schema_fields(self):
        """Test that we can access string representation of field"""
        self.assertEqual(self.schema.fields.product_id, "product_id")
