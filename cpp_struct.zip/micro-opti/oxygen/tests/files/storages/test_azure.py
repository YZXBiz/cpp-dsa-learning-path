from io import BytesIO, StringIO
from unittest import TestCase
from unittest.mock import Mock, call, patch

from oxygen.files.storages.azure import AzureStorage


class AzureStorageTestCase(TestCase):
    def setUp(self):
        # Must mock the BlockBlobService since it will error out
        # if no credentials are provided when AzureStorage is initiated.
        with patch("oxygen.files.storages.azure.BlobServiceClient"):
            self.storage = AzureStorage()
            self.storage.client.return_value = Mock()
            self.storage.service_client.return_value = Mock()

    def test_abspath(self):
        """
        Test that abspath can convert a relative path to an
        absolute one based on STORAGE_ROOT config value.
        """
        self.assertEqual(
            self.storage.abspath("subdir/foo.csv"),
            "app/data/subdir/foo.csv",
            "Path should be prepended with STORAGE_ROOT.",
        )

    def test_abspath_absolute(self):
        """
        Test that abspath can convert a relative path to an
        absolute one based on STORAGE_ROOT config value even
        when the path appears to be absolute (start with /)
        """
        self.assertEqual(
            self.storage.abspath("/subdir/foo.csv"),
            "app/data/subdir/foo.csv",
            "Path should be prepended with STORAGE_ROOT.",
        )

    def test_relpath(self):
        """
        Test that relpath can convert an absolute path to
        a relative one based on the path relative to
        STORAGE_ROOT config value.
        """
        self.assertEqual(
            self.storage.relpath("app/data/subdir/foo.csv"),
            "subdir/foo.csv",
            "Path should have STORAGE_ROOT stripped away.",
        )

    @patch("oxygen.files.storages.azure.BytesIO")
    def test_open(self, bytesio_mock: Mock):
        """
        Test that open calls get_blob_to_stream and returns
        thea BytesIO object that was populated.
        """
        io_mock = Mock()
        stream_mock = Mock()
        bytesio_mock.return_value = io_mock
        self.storage.client.download_blob.return_value = stream_mock
        res = self.storage.open("/some/file/path/file.csv")

        self.storage.client.download_blob.assert_called_once_with(
            "app/data/some/file/path/file.csv",
            timeout=30,
        )
        stream_mock.download_to_stream.assert_called_once_with(io_mock)
        self.assertEqual(res, io_mock)

    @patch("oxygen.files.storages.azure.BlobClient")
    @patch("oxygen.files.storages.azure.generate_blob_sas")
    def test_url(self, generate_sas_mock: Mock, blob_client_mock: Mock):
        """
        Test that url function returns a full URL prepended with
        STORAGE_HOSTNAME and STORAGE_ROOT.
        """
        generate_sas_mock.return_value = "?sas_token=1"
        url_mock = Mock()
        url_mock.url = "https://account.com/some/path/file.csv"
        sas_url_mock = Mock()
        sas_url_mock.url = "https://account.com/some/path/file.csv?sas_token=1"
        blob_client_mock.from_blob_url.return_value = sas_url_mock
        self.storage.client.get_blob_client.return_value = url_mock

        url = self.storage.url("some/path/file.csv")
        blob_client_mock.from_blob_url.assert_called_once_with(
            "https://account.com/some/path/file.csv", credential="?sas_token=1"
        )
        self.assertEqual(url, "https://account.com/some/path/file.csv?sas_token=1")

    @patch("oxygen.files.storages.azure.StringIO")
    @patch("oxygen.files.storages.azure.AzureStorage.rm")
    @patch("oxygen.files.storages.azure.AzureStorage.touch")
    def test_mkdir(self, touch_mock: Mock, rm_mock: Mock, stringio_mock: Mock):
        """
        The Azure client has no build in method to create directories. We
        get around this by creating a file in our dir_path and then deleting it
        again, this will leave the directory in place.
        """
        io_mock = Mock()
        stringio_mock.return_value = io_mock
        self.storage.mkdir("/some/dir")

        # Test that a file in our dir was touched and removed.
        touch_mock.assert_called_once_with("app/data/some/dir/.empty", io_mock)
        rm_mock.assert_called_once_with("app/data/some/dir/.empty")

    def test_touch(self):
        """
        Test that touch function pass args to the Azure Client and
        that the path is formatted correctly into an absolute path.

        """
        content = BytesIO(b"content")
        self.storage.touch("/some/dir/file.csv", content)
        self.storage.client.upload_blob.assert_called_once_with(
            "app/data/some/dir/file.csv", content, overwrite=True, timeout=30
        )

    def test_touch_convert_to_bytes(self):
        """Test that str is convert into bytes before saving"""
        content = StringIO("content")
        self.storage.touch("/some/dir/file.csv", content)
        args, _ = self.storage.client.upload_blob.call_args

        # Test that stream is now a bytes object intead of a string.
        self.assertTrue(isinstance(args[1], BytesIO))

    @patch("oxygen.files.storages.azure.AzureStorage.isdir")
    def test_rm(self, mock_isdir: Mock):
        """
        Test that deleting a file call the Azure Client delete_blob
        with an absolute path to the file.
        """
        mock_isdir.return_value = False
        self.storage.rm("/some/dir/file.csv")
        self.storage.client.delete_blob.assert_called_once_with(
            "app/data/some/dir/file.csv", timeout=30
        )

    @patch("oxygen.files.storages.azure.AzureStorage.listdir")
    @patch("oxygen.files.storages.azure.AzureStorage.isdir")
    def test_rm_dir_error(self, mock_isdir: Mock, mock_listdir: Mock):
        """
        Test that an error is raised if function attempt to delete
        a directory that contain files.
        """
        mock_listdir.return_value = ([], ["file.csv"])
        mock_isdir.return_value = True

        with self.assertRaises(FileExistsError):
            self.storage.rm("/some/dir/")

        self.storage.client.delete_blob.assert_not_called()

    @patch("oxygen.files.storages.azure.AzureStorage.listdir")
    @patch("oxygen.files.storages.azure.AzureStorage.isdir")
    def test_rm_dir_recursive(self, mock_isdir: Mock, mock_listdir: Mock):
        """
        Test that if we attempt to delete a dir with files within it,
        it is allowed and executed if the `recursive` kwarg is set.
        """
        mock_listdir.return_value = ([], ["file.csv"])
        mock_isdir.return_value = True

        self.storage.rm("/some/dir/", recursive=True)

        self.storage.client.delete_blob.assert_called_once_with(
            "app/data/some/dir/", timeout=30
        )

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isfile(self, mock_exists: Mock):
        """Test that a valid file path correctly returns True"""
        mock_exists.return_value = True
        self.storage._list_all = Mock()
        self.storage._list_all.return_value = []
        self.assertTrue(self.storage.isfile("/dir/foo.csv"))
        self.storage._list_all.assert_called_once_with("/dir/foo.csv", num_results=1)

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isfile_missing(self, mock_exists: Mock):
        """
        Test that a valid file path correctly returns False
        if the file itself does not exists.
        """
        mock_exists.return_value = False
        self.assertFalse(self.storage.isfile("/dir/foo.csv"))

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isfile_directory(self, mock_exists: Mock):
        """
        Test that a directory path correctly returns False
        since a dir path is not a file.
        """
        mock_exists.return_value = True
        self.assertFalse(self.storage.isfile("/dir/"))

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isdir(self, mock_exists: Mock):
        """
        Test that a dir path identifies as isdir=True if the
        directory exists, and it is of content_length 0.
        """
        mock_exists.return_value = True
        self.storage._list_all = Mock()
        self.storage._list_all.return_value = ["path/to/file/"]
        self.assertTrue(self.storage.isdir("/dir/"))
        self.storage._list_all.assert_called_once_with("/dir/", num_results=1)

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isdir_missing(self, mock_exists: Mock):
        """Test that a missing directory returns False"""
        mock_exists.return_value = False
        self.assertFalse(self.storage.isdir("/foo/"))

    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_isdir_file(self, mock_exists: Mock):
        """Test that a file path does not count as a directory"""
        mock_exists.return_value = True
        self.storage._list_all = Mock()
        self.storage._list_all.return_value = []

        # File.csv is not a dir.
        self.assertFalse(self.storage.isdir("/dir/file.csv"))
        self.storage._list_all.assert_called_once_with("/dir/file.csv", num_results=1)

    def test_exists(self):
        """
        Test that exists route params to the Azure Client exists
        with absolute path
        """
        blob_client_mock = Mock()
        self.storage.client.get_blob_client.return_value = blob_client_mock
        self.storage.exists("foo/data.csv")
        self.storage.client.get_blob_client.assert_called_once_with(
            "app/data/foo/data.csv"
        )
        # We test if a blob exists by pulling its properties.
        blob_client_mock.get_blob_properties.assert_called_once()

    def test_listdir(self):
        """
        Test that listdir return a tuple of directories and files
        that exists within the path provided. It should not return
        nested files, only files/dir directly within the path.
        """
        self.storage._list_all = Mock()
        self.storage._list_all.return_value = [
            "app/data/foo/bar/file.csv",
            "app/data/foo/bar/file2.csv",
            "app/data/foo/bar/subdir/file3.csv",
        ]

        dirs, files = self.storage.listdir("/foo/bar")

        self.storage._list_all.assert_called_once_with("/foo/bar/")
        self.assertEqual(dirs, ["foo/bar/subdir"])
        self.assertEqual(files, ["foo/bar/file.csv", "foo/bar/file2.csv"])

    @patch("oxygen.files.storages.azure.AzureStorage.touch")
    @patch("oxygen.files.storages.azure.AzureStorage.open")
    @patch("oxygen.files.storages.azure.AzureStorage.isfile")
    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_cp_file(
        self,
        mock_exists: Mock,
        mock_isfile: Mock,
        mock_open: Mock,
        mock_touch: Mock,
    ):
        """Test copy a file to a file path destination"""
        mock_exists.side_effect = (True, False)
        mock_isfile.return_value = True
        mock_stream = Mock()
        mock_open.return_value.__enter__.return_value = mock_stream
        self.storage.cp("path/to/file.csv", "path/to/new/file.csv")
        mock_touch.assert_called_once_with("path/to/new/file.csv", mock_stream)

    @patch("oxygen.files.storages.azure.AzureStorage.touch")
    @patch("oxygen.files.storages.azure.AzureStorage.open")
    @patch("oxygen.files.storages.azure.AzureStorage.listdir")
    @patch("oxygen.files.storages.azure.AzureStorage.isdir")
    @patch("oxygen.files.storages.azure.AzureStorage.isfile")
    @patch("oxygen.files.storages.azure.AzureStorage.exists")
    def test_cp_dir(
        self,
        mock_exists: Mock,
        mock_isfile: Mock,
        mock_isdir: Mock,
        mock_listdir: Mock,
        mock_open: Mock,
        mock_touch: Mock,
    ):
        """Test that we can copy a dir.

        This is much more complex than copying a file since we now
        have to handle recursive files and directories.

        """
        mock_exists.side_effect = (True, False, True, False, True, False, True, False)
        mock_isfile.side_effect = (False, False, True, True)
        mock_isdir.side_effect = (True, True)
        mock_listdir.side_effect = ((["foo/"], ["file.csv"]), ([], ["foo/bar.txt"]))
        mock_stream = Mock()
        mock_open.return_value.__enter__.return_value = mock_stream
        self.storage.cp("data/", "data2/", recursive=True)
        mock_touch.assert_has_calls(
            [
                call("data2/file.csv", mock_stream),
                call("data2/foo/bar.txt", mock_stream),
            ],
            any_order=True,
        )
