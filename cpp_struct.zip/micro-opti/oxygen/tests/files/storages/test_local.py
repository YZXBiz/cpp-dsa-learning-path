import unittest
from io import BytesIO, StringIO
from unittest.mock import Mock, call, mock_open, patch

from oxygen.files.storages.local import LocalStorage


class LocalStorageTestCase(unittest.TestCase):
    def setUp(self):
        self.storage = LocalStorage()

    def test_abspath(self):
        """
        Test that abspath can convert a relative path to an
        absolute one based on STORAGE_ROOT config value.
        """
        self.assertEqual(
            self.storage.abspath("subdir/foo.csv"),
            "/app/data/subdir/foo.csv",
            "Path should be prepended with STORAGE_ROOT.",
        )

    def test_abspath_absolute(self):
        """
        Test that abspath can convert a relative path to an
        absolute one based on STORAGE_ROOT config value even
        when the path appears to be absolute (start with /)
        """
        self.assertEqual(
            self.storage.abspath("/subdir/foo.csv"),
            "/app/data/subdir/foo.csv",
            "Path should be prepended with STORAGE_ROOT.",
        )

    def test_relpath(self):
        """
        Test that relpath can convert an absolute path to
        a relative one based on the path relative to
        STORAGE_ROOT config value.
        """
        self.assertEqual(
            self.storage.relpath("/app/data/subdir/foo.csv"),
            "subdir/foo.csv",
            "Path should have STORAGE_ROOT stripped away.",
        )

    @patch("builtins.open", mock_open(read_data="foobar"))
    def test_open(self):
        """Test that storage.open returns contents of file."""
        with self.storage.open("/foo.csv") as stream:
            contents = stream.read()
        self.assertEqual(contents, "foobar")

    def test_touch_string(self):
        """Test that we can create a file from text contents"""
        mock = mock_open()
        io = StringIO("mycontents")
        with patch("builtins.open", mock):
            self.storage.touch("foo.csv", io)

        # Mode is automatically changed to w since its string.
        # Also path is prepended with our STORAGE_ROOT.
        mock.assert_called_with("/app/data/foo.csv", mode="w", encoding="utf-8")
        mock().write.assert_called_with("mycontents")

    def test_touch_bytes(self):
        """Test that we can create a file from bytes contents"""
        mock = mock_open()
        io = BytesIO(b"mycontents")
        with patch("builtins.open", mock):
            self.storage.touch("foo.csv", io)

        # Mode is automatically changed to wb since its bytes.
        # Also path is prepended with our STORAGE_ROOT.
        mock.assert_called_with("/app/data/foo.csv", mode="wb", encoding=None)
        mock().write.assert_called_with(b"mycontents")

    @patch("os.remove")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    def test_rm_file(self, mock_isfile: Mock, mock_exists: Mock, remove_mock: Mock):
        """Test that storage.rm can remove a single file"""
        mock_isfile.return_value = True
        mock_exists.return_value = True
        self.storage.rm("foo.csv")
        remove_mock.assert_called_once_with("/app/data/foo.csv")

    @patch("os.rmdir")
    @patch("oxygen.files.storages.local.LocalStorage.listdir")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    @patch("oxygen.files.storages.local.LocalStorage.isdir")
    def test_rm_dir(
        self,
        mock_isdir: Mock,
        mock_isfile: Mock,
        mock_exists: Mock,
        mock_listdir: Mock,
        remove_mock: Mock,
    ):
        """Test that storage.rm can remove an empty directory"""
        mock_listdir.return_value = ([], [])
        mock_isdir.return_value = True
        mock_isfile.return_value = False
        mock_exists.return_value = True
        self.storage.rm("/foo")
        remove_mock.assert_called_once_with("/app/data/foo")

    @patch("os.rmdir")
    @patch("oxygen.files.storages.local.LocalStorage.listdir")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    @patch("oxygen.files.storages.local.LocalStorage.isdir")
    def test_rm_dir_with_files(
        self,
        mock_isdir: Mock,
        mock_isfile: Mock,
        mock_exists: Mock,
        mock_listdir: Mock,
        remove_mock: Mock,
    ):
        """
        Test that storage.rm do not remove the directory and
        raises a FileExistsError if the directory contains
        subdirectories or files without using the recursive arg.
        """
        # Mock that the dir contains a file.
        mock_listdir.return_value = (["file.csv"], [])
        mock_isdir.return_value = True
        mock_isfile.return_value = False
        mock_exists.return_value = True
        with self.assertRaises(FileExistsError):
            self.storage.rm("/foo")

        remove_mock.assert_not_called()

    @patch("os.rmdir")
    @patch("oxygen.files.storages.local.LocalStorage.listdir")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    @patch("oxygen.files.storages.local.LocalStorage.isdir")
    def test_rm_dir_with_files_recursive(
        self,
        mock_isdir: Mock,
        mock_isfile: Mock,
        mock_exists: Mock,
        mock_listdir: Mock,
        remove_mock: Mock,
    ):
        """
        Test that storage.rm can delete folder with files
        within it if recursive=True is used
        """
        # Mock that the dir contains a file.
        mock_listdir.return_value = (["file.csv"], [])
        mock_isdir.return_value = True
        mock_isfile.return_value = False
        mock_exists.return_value = True
        self.storage.rm("/foo", recursive=True)
        remove_mock.assert_called_once_with("/app/data/foo")

    @patch("os.rmdir")
    @patch("os.remove")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    def test_rm_not_exist(self, mock_exists: Mock, mock_remove: Mock, mock_rmdir: Mock):
        """
        Test that storage.rm do nothing if the file
        or directory is already removed.
        """
        mock_exists.return_value = False
        self.storage.rm("/foo", recursive=True)
        mock_remove.assert_not_called()
        mock_rmdir.assert_not_called()

    @patch("os.mkdir")
    def test_mkdir(self, mock_mkdir: Mock):
        self.storage.mkdir("/foo")
        mock_mkdir.assert_called_once_with("/app/data/foo")

    @patch("os.mkdir")
    def test_mkdir_exception(self, mock_mkdir: Mock):
        """
        Test that if mkdir attempts to create a directory
        at a path that do not exist, an error is raised.
        storage.mkdir is then suppose to catch and reraise
        the exception with a custom message.
        """
        mock_mkdir.side_effect = FileNotFoundError
        with self.assertRaises(FileNotFoundError) as ctx:
            self.storage.mkdir("/a/b/c/d")

        self.assertEqual(
            str(ctx.exception),
            (
                "No such file or directory: '/app/data/a/b/c/d'. "
                "Use make_parents=True if you want to create missing parents."
            ),
        )

    @patch("os.makedirs")
    def test_mkdir_parents(self, mock_makedirs: Mock):
        """
        Test that make_parents=True invoke another function
        that allow creating recursive directories.
        """
        self.storage.mkdir("/a/b/c", make_parents=True)
        mock_makedirs.assert_called_once_with(
            "/app/data/a/b/c", exist_ok=True, mode=0o777
        )

    @patch("os.path.isdir")
    @patch("os.path.isfile")
    @patch("os.listdir")
    def test_listdir(self, mock_listdir: Mock, mock_isfile: Mock, mock_isdir: Mock):
        """
        Test that listdir return a tuple of directories and files where
        the path is relative instead of absolute (e.g. no /app/data/ prefix).
        """
        mock_listdir.return_value = ["foo", "bar", "data.csv"]
        mock_isfile.side_effect = [False, False, True]
        mock_isdir.side_effect = [True, True, False]
        dirs, files = self.storage.listdir("some/dir")
        self.assertEqual(
            (dirs, files), (["some/dir/foo", "some/dir/bar"], ["some/dir/data.csv"])
        )

    @patch("os.path.isfile")
    def test_isfile(self, mock_isfile: Mock):
        """
        Test that isfile is using os.path.isfile with
        an absolute path to the file.
        """
        self.storage.isfile("foo.csv")
        mock_isfile.assert_called_once_with("/app/data/foo.csv")

    @patch("os.path.isdir")
    def test_isdir(self, mock_isdir: Mock):
        """
        Test that isdir is using os.path.isdir with
        an absolute path to the directory.
        """
        self.storage.isdir("foo/bar/")
        mock_isdir.assert_called_once_with("/app/data/foo/bar/")

    @patch("os.path.exists")
    def test_exists(self, mock_exists: Mock):
        """
        Test that exists use os.path.exists with
        an absolute path to the file/dir.
        """
        self.storage.exists("/foo/data.csv")
        mock_exists.assert_called_once_with("/app/data/foo/data.csv")

    @patch("oxygen.files.storages.local.LocalStorage.touch")
    @patch("oxygen.files.storages.local.LocalStorage.open")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    def test_cp_file(
        self,
        mock_exists: Mock,
        mock_isfile: Mock,
        mock_open: Mock,
        mock_touch: Mock,
    ):
        """Test copy a file to a file path destination"""
        mock_exists.side_effect = (True, False)
        mock_isfile.return_value = True
        mock_stream = Mock()
        mock_open.return_value.__enter__.return_value = mock_stream
        self.storage.cp("path/to/file.csv", "path/to/new/file.csv")
        mock_touch.assert_called_once_with("path/to/new/file.csv", mock_stream)

    @patch("oxygen.files.storages.local.LocalStorage.touch")
    @patch("oxygen.files.storages.local.LocalStorage.open")
    @patch("oxygen.files.storages.local.LocalStorage.listdir")
    @patch("oxygen.files.storages.local.LocalStorage.isdir")
    @patch("oxygen.files.storages.local.LocalStorage.isfile")
    @patch("oxygen.files.storages.local.LocalStorage.exists")
    def test_cp_dir(
        self,
        mock_exists: Mock,
        mock_isfile: Mock,
        mock_isdir: Mock,
        mock_listdir: Mock,
        mock_open: Mock,
        mock_touch: Mock,
    ):
        """Test that we can copy a dir.

        This is much more complex than copying a file since we now
        have to handle recursive files and directories.

        """
        mock_exists.side_effect = (True, False, True, False, True, False, True, False)
        mock_isfile.side_effect = (False, False, True, True)
        mock_isdir.side_effect = (True, True)
        mock_listdir.side_effect = ((["foo/"], ["file.csv"]), ([], ["foo/bar.txt"]))
        mock_stream = Mock()
        mock_open.return_value.__enter__.return_value = mock_stream
        self.storage.cp("data/", "data2/", recursive=True)
        mock_touch.assert_has_calls(
            [
                call("data2/file.csv", mock_stream),
                call("data2/foo/bar.txt", mock_stream),
            ],
            any_order=True,
        )
