from io import BytesIO
from unittest import TestCase
from unittest.mock import Mock, patch

from oxygen.files.storages.google import GoogleStorage


class GoogleStorageTestCase(TestCase):
    def setUp(self):
        # Must mock the BlockBlobService since it will error out
        # if no credentials are provided when AzureStorage is initiated.
        with patch("oxygen.files.storages.google.storage.Client"):
            self.storage = GoogleStorage()
            self.storage._client = Mock()
            self.storage._bucket = Mock()

    def test_abspath(self):
        """Test that absolute paths are formatted correctly with STORAGE_ROOT"""
        self.assertEqual(self.storage.abspath("foo/bar.csv"), "app/data/foo/bar.csv")

    def test_abspath_already_abspath(self):
        """
        Test if abspath return a valid abspath if it gets a path that is
        already an abspath as an argument.
        """
        self.assertEqual(
            self.storage.abspath("app/data/foo/bar.csv"), "app/data/foo/bar.csv"
        )

    def test_relpath(self):
        """Test if relpath turn an abspath into relpath correctly"""
        self.assertEqual(self.storage.relpath("app/data/foo/bar.csv"), "foo/bar.csv")

    def test_relpath_already_relpath(self):
        """
        Test if relpath turn an path into relpath correctly even if the path
        is already a relpath.
        """
        self.assertEqual(self.storage.relpath("foo/bar.csv"), "foo/bar.csv")

    def test_open(self):
        """Test that open calls the Google SDK as expected"""
        # Setup mock.

        with patch("oxygen.files.storages.google.BytesIO") as handler_mock:
            mock_content = BytesIO(b"hello-world")
            mock_content.read()  # Set file pointer to end to emulate write.
            handler_mock.return_value = mock_content
            handler = self.storage.open("foo/bar.csv")

        # Test that blob was called with an absolute path.
        self.storage._bucket.blob.assert_called_once_with("app/data/foo/bar.csv")
        # Test that returned value can be read and has file pointer set to start
        # even though file pointer was set to end with above .read() call.
        self.assertEqual(handler.read(), b"hello-world")

    def test_touch(self):
        """Test that GCP SDK is called as expected to create a file"""
        # Setup mocks
        blob_mock = Mock()
        self.storage._bucket.blob.return_value = blob_mock

        # Do call that we are testing.
        content = BytesIO(b"hello")
        self.storage.touch("foo.csv", content)

        # Test that actual call uses absolute path with STORAGE_ROOT prepended.
        self.storage._bucket.blob.assert_called_once_with("app/data/foo.csv")
        # Test that the BytesIO content is forwarded to the GCP SDK.
        blob_mock.upload_from_file.assert_called_once_with(content)

    def test_touch_invalid_path(self):
        """Test that we cannot use `.touch()` to create directories.

        Assertions should raise AssertionError if path is a directory.

        """
        with self.assertRaises(AssertionError):
            self.storage.touch("foo/", BytesIO())

    def test_rm_file(self):
        """Test if `.rm()` calls GCP SDK correctly for a normal file."""
        isdir_mock = Mock()
        isdir_mock.return_value = False
        blob_mock = Mock()
        # Setup mocks
        self.storage.isdir = isdir_mock
        self.storage._bucket.blob.return_value = blob_mock

        # Actual call we test.
        self.storage.rm("foo.csv")

        # Assert that we call the GCP SDK with a full path and
        # that we also call the blob .delete() method as expected.
        self.storage._bucket.blob.assert_called_once_with("app/data/foo.csv")
        blob_mock.delete.assert_called_once()

    def test_rm_dir_with_files(self):
        """
        Test that FileExistsError is raised if we attempt to delete
        a dir with existing files in it when not using the recursive=True option.
        """
        isdir_mock = Mock()
        isdir_mock.return_value = True
        listdir_mock = Mock()
        listdir_mock.return_value = ([], ["foo/bar.csv"])
        blob_mock = Mock()
        # Setup mocks
        self.storage.isdir = isdir_mock
        self.storage._bucket.blob.return_value = blob_mock
        self.storage.listdir = listdir_mock

        # Actual call we test.
        with self.assertRaises(FileExistsError):
            self.storage.rm("foo/")

        # Since FileExistsError was raised, make sure that
        # the actual delete calls were not made to the blob.
        self.storage._bucket.blob.assert_not_called()
        blob_mock.delete.assert_not_called()

    def test_rm_dir_recursive_with_files(self):
        """
        Test that FileExistsError is raised if we attempt to delete
        a dir with existing files in it when not using the recursive=True option.
        """
        isdir_mock = Mock()
        isdir_mock.side_effect = lambda path: path.endswith("/")
        listdir_mock = Mock()
        listdir_mock.return_value = ([], ["foo/bar.csv"])
        blob_mock = Mock()
        # Setup mocks
        self.storage.isdir = isdir_mock
        self.storage._bucket.blob.return_value = blob_mock
        self.storage.listdir = listdir_mock

        # Actual call we test.
        self.storage.rm("foo/", recursive=True)

        # Even though the directory had files within it, the delete call
        # should be made since it was called with recursive=True.
        if self.storage.isdir("foo/"):
            self.storage._bucket.blob.assert_called_once_with("app/data/foo/bar.csv")
            blob_mock.delete.assert_called_once()

    def test_mkdir(self):
        # Setup mocks
        blob_mock = Mock()
        exists_mock = Mock()
        exists_mock.side_effect = [False, True]
        self.storage._bucket.blob.return_value = blob_mock
        self.storage.exists = exists_mock

        # Actual call we want to test.
        self.storage.mkdir("foo/")

        # Make sure that the dir was called as absolute path with STORAGE_ROOT
        # prepended to it, and that upload_from_file was called which is creating
        # an empty "directory" blob.
        self.storage._bucket.blob.assert_called_once_with("app/data/foo/")
        blob_mock.upload_from_file.assert_called_once()

    def test_mkdir_exists(self):
        """
        Test that mkdir is **not** creating a dir
        if path already exists.
        """
        # Setup mocks
        blob_mock = Mock()
        exists_mock = Mock()
        exists_mock.side_effect = [True, True]
        self.storage._bucket.blob.return_value = blob_mock
        self.storage.exists = exists_mock

        # Actual call we want to test.
        self.storage.mkdir("foo/")

        # Since path already exists, make sure that there
        # was no attempt to create the dir with the GCP SDK.
        self.storage._bucket.blob.assert_not_called()
        blob_mock.upload_from_file.assert_not_called()

    def test_listdir(self):
        """Test that listdir returns a tuple of dirs and files"""
        # Setting up mocks
        isdir_mock = Mock()
        isdir_mock.side_effect = [False, False, True]
        blob_a = Mock()
        blob_a.name = "app/data/foo/foo.csv"
        blob_b = Mock()
        blob_b.name = "app/data/foo/bar.csv"
        blob_c = Mock()
        blob_c.name = "app/data/foo/dir/"
        list_blobs_mock = Mock()
        list_blobs_mock.return_value = [blob_a, blob_b, blob_c]
        self.storage.isdir = isdir_mock
        self.storage._client.list_blobs = list_blobs_mock

        # The mocked file system contains 3 blobs, 2 files and 1 dir.
        # test and make suree that they are returned with relpaths
        # (without STORAGE_ROOT)
        dirs, files = self.storage.listdir("foo/")
        self.assertEqual(dirs, ["foo/dir/"])
        self.assertEqual(files, ["foo/foo.csv", "foo/bar.csv"])

    def test_is_in_root(self):
        """Test helper function _is_in_root used by listdir to filter files.

        The function should return True if the blob path is directly within a dir path.

        e.g
        "foo/bar.csv", "foo/" returns True
        "foo/bar/zup.csv", "foo/" returns False

        """
        # File is directly under /app/data/foo/, should return True
        self.assertTrue(
            self.storage._is_in_root("app/data/foo/bar.csv", "app/data/foo/")
        )
        # File is in subdir of /app/data/foo/, should return False
        self.assertFalse(
            self.storage._is_in_root("app/data/foo/bar/zup.csv", "app/data/foo/")
        )

    def test_isfile(self):
        """Test that we correctly identify if a path is a file or a dir"""
        blob_mock = Mock()
        blob_mock.exists.return_value = True
        self.storage._bucket.blob.return_value = blob_mock
        self.assertTrue(self.storage.isfile("foo/bar.csv"))
        self.assertFalse(self.storage.isfile("foo/bar/"))

    def test_isdir(self):
        """
        Test that a blob which has a name that is a prefix of other files
        is identified as a dir
        """
        blob_mock = Mock()
        blob_mock.exists.return_value = True
        self.storage._bucket.blob.return_value = blob_mock
        self.assertTrue(self.storage.isdir("foo/"))

        blob_mock.exists.return_value = False
        self.storage._bucket.blob.return_value = blob_mock
        list_blobs_mock = Mock()
        list_blobs_mock.return_value = [blob_mock]
        self.storage._client.list_blobs = list_blobs_mock
        self.assertTrue(self.storage.isdir("foo/"))

        list_blobs_mock.return_value = []
        self.storage._client.list_blobs = list_blobs_mock
        self.assertFalse(self.storage.isdir("foo/"))
        self.assertFalse(self.storage.isdir("foo/foo.csv"))

    def test_exists_file(self):
        """
        Test that a file use the Blob GCP SDK to identify
        if the blob exists or not.
        """
        blob_mock = Mock()
        blob_mock.exists.return_value = True
        self.storage._bucket.blob.return_value = blob_mock
        self.assertTrue(self.storage.exists("foo.csv"))
        self.storage._bucket.blob.assert_called_once_with("app/data/foo.csv")
        blob_mock.exists.assert_called_once()

    def test_exists_dir(self):
        """
        Test that a dir use the list_blob GCP SDK to identify
        if the dir exists or not.

        This is because dirs are not always blobs in GCS.
        (e.g. the blob is /foo/bar/zup.csv, there is no /foo/bar/ blob)

        """
        blob_mock = Mock()
        blob_mock.name = "app/data/foo/bar/zup.csv"
        list_blobs_mock = Mock()
        list_blobs_mock.return_value = [blob_mock]
        self.storage._client.list_blobs = list_blobs_mock
        self.assertTrue(self.storage.exists("foo/"))
        self.assertTrue(self.storage.exists("foo/bar/"))

        blob_mock.exists.return_value = False
        self.storage._bucket.blob.return_value = blob_mock
        self.assertTrue(self.storage.exists("bar/"))

        list_blobs_mock.return_value = []
        self.storage._client.list_blobs = list_blobs_mock
        self.assertFalse(self.storage.exists("bar/"))
