from io import BytesIO, StringIO
from unittest import TestCase
from unittest.mock import Mock, call, patch

from botocore.exceptions import ClientError

from oxygen.files.storages.s3 import S3Storage


class S3StorageTestCase(TestCase):
    """Test the S3Storage backend"""

    def setUp(self) -> None:
        self.storage = S3Storage()

    def test_get_relpath(self):
        """
        Test that we can convert an absolute path to a relative path.
        """
        # Test file path conversion to relpath.
        self.assertEqual(
            self.storage.relpath("app/data/path/to/file.csv"),
            "path/to/file.csv",
        )

        # Test that paths ending in / keep /
        self.assertEqual(
            self.storage.relpath("app/data/path/to/"),
            "path/to/",
        )

        # Test that paths not ending in / do not keep /
        self.assertEqual(
            self.storage.relpath("app/data/path/to"),
            "path/to",
        )

    def test_get_abspath(self):
        """
        Test that we can convert a relative path to an absolute path.
        """
        # Test file path conversion to relpath.
        self.assertEqual(
            self.storage.abspath("path/to/file.csv"),
            "app/data/path/to/file.csv",
        )

        # Test that paths ending in / keep /
        self.assertEqual(
            self.storage.abspath("path/to/"),
            "app/data/path/to/",
        )

        # Test that paths not ending in / do not keep /
        self.assertEqual(
            self.storage.abspath("path/to"),
            "app/data/path/to",
        )

    def test_touch(self):
        """
        Test that we can create a file on bucket.

        We are mocking the boto calls and assume that if boto is
        called correctly, a file is created.
        """
        with patch("oxygen.files.storages.s3.S3Storage.bucket") as bucket_mock:
            object_mock = Mock()
            bucket_mock.Object.return_value = object_mock

            self.storage.touch("path/to/file.csv", StringIO("hello,world"))

        bucket_mock.Object.assert_called_once_with("app/data/path/to/file.csv")
        object_mock.upload_fileobj.assert_called_once()

    def test_open_str(self):
        """
        Test that we can open a file as a StringIO stream.
        """
        with patch("oxygen.files.storages.s3.S3Storage.bucket") as bucket_mock:
            object_mock = Mock()
            bucket_mock.Object.return_value = object_mock

            handler = self.storage.open("path/to/file.csv")

        bucket_mock.Object.assert_called_once_with("app/data/path/to/file.csv")
        object_mock.download_fileobj.assert_called_once()
        self.assertTrue(isinstance(handler, StringIO))

    def test_open_bytes(self):
        """
        Test that we can open a file as a BytesIO stream.

        This is specified by the `mode="rb"` kwarg.
        """
        with patch("oxygen.files.storages.s3.S3Storage.bucket") as bucket_mock:
            object_mock = Mock()
            bucket_mock.Object.return_value = object_mock

            handler = self.storage.open("path/to/file.csv", mode="rb")

        bucket_mock.Object.assert_called_once_with("app/data/path/to/file.csv")
        object_mock.download_fileobj.assert_called_once()
        self.assertTrue(isinstance(handler, BytesIO))

    def test_cp_file(self):
        """
        Test that we can copy a file from a source to a destination.

        The `cp` method only leverage other storage methods and never actually
        interact with the boto SDK.
        """
        handler_mock = StringIO()
        open_mock = Mock()
        open_mock.return_value = handler_mock
        touch_mock = Mock()
        exists_mock = Mock()
        exists_mock.side_effect = [True, False]
        isfile_mock = Mock()
        isfile_mock.return_value = True
        isdir_mock = Mock()
        isdir_mock.return_value = False
        self.storage.exists = exists_mock
        self.storage.isfile = isfile_mock
        self.storage.isdir = isdir_mock
        self.storage.touch = touch_mock
        self.storage.open = open_mock

        self.storage.cp("path/to/source.txt", "path/to/dist.txt")

        # Assert that we opened the source file and wrote it to dist path.
        self.storage.open.assert_called_once_with("path/to/source.txt", mode="rb")
        self.storage.touch.assert_called_once_with("path/to/dist.txt", handler_mock)

    def test_cp_src_missing(self):
        """
        Test that an exception is raised if source do not exist.
        """
        exists_mock = Mock()
        exists_mock.return_value = False
        self.storage.exists = exists_mock

        with self.assertRaises(FileNotFoundError):
            self.storage.cp("path/to/source.txt", "path/to/dist.txt")

    def test_cp_file_exists(self):
        """
        Test that exception is raised if destination already exists,
        and the `overwrite=True` kwarg is not set.
        """
        exists_mock = Mock()
        exists_mock.side_effect = [True, True]
        self.storage.exists = exists_mock

        with self.assertRaises(FileExistsError):
            self.storage.cp("path/to/source.txt", "path/to/dist.txt")

    def test_cp_file_exists_overwrite(self):
        """
        Test that we can successfully copy files even if destination
        exists by defining the `overwrite=True` kwarg.
        """
        handler_mock = StringIO()
        open_mock = Mock()
        open_mock.return_value = handler_mock
        touch_mock = Mock()
        exists_mock = Mock()
        exists_mock.side_effect = [True, True]
        isfile_mock = Mock()
        isfile_mock.return_value = True
        isdir_mock = Mock()
        isdir_mock.return_value = False
        self.storage.exists = exists_mock
        self.storage.isfile = isfile_mock
        self.storage.isdir = isdir_mock
        self.storage.touch = touch_mock
        self.storage.open = open_mock

        self.storage.cp("path/to/source.txt", "path/to/dist.txt", overwrite=True)

        self.storage.open.assert_called_once_with("path/to/source.txt", mode="rb")
        self.storage.touch.assert_called_once_with("path/to/dist.txt", handler_mock)

    def test_rm_file(self):
        """
        Test that we can delete a single file.
        """
        isdir_mock = Mock()
        isdir_mock.return_value = False
        self.storage.isdir = isdir_mock

        with patch("oxygen.files.storages.s3.S3Storage.bucket") as bucket_mock:
            object_mock = Mock()
            bucket_mock.Object.return_value = object_mock
            self.storage.rm("path/to/file.csv")

        bucket_mock.Object.assert_called_once_with("app/data/path/to/file.csv")
        object_mock.delete.assert_called_once()

    def test_rm_dir(self):
        """
        Test that if target is a directory that contain files,
        an exception is raised since `recursive=True` is not set.
        """
        isdir_mock = Mock()
        isdir_mock.return_value = True
        listdir_mock = Mock()
        listdir_mock.return_value = ([], ["file.csv"])
        self.storage.isdir = isdir_mock
        self.storage.listdir = listdir_mock

        with self.assertRaises(FileExistsError):
            self.storage.rm("path/to/")

    def test_rm_dir_recursive(self):
        """
        Test that we can recursively remove a directory that contain
        children by setting the `recursive=True` kwarg.
        """
        isdir_mock = Mock()
        isdir_mock.side_effect = [True, False]
        listdir_mock = Mock()
        listdir_mock.return_value = ([], ["path/to/file.csv"])
        self.storage.isdir = isdir_mock
        self.storage.listdir = listdir_mock

        with patch("oxygen.files.storages.s3.S3Storage.bucket") as bucket_mock:
            file_object_mock = Mock()
            dir_object_mock = Mock()
            bucket_mock.Object.side_effect = [file_object_mock, dir_object_mock]
            self.storage.rm("path/to/", recursive=True)

        self.assertEqual(
            bucket_mock.Object.call_args_list,
            [
                call("app/data/path/to/file.csv"),
                call("app/data/path/to/"),
            ],
        )
        file_object_mock.delete.assert_called_once()
        dir_object_mock.delete.assert_called_once()

    def test_mkdir(self):
        """
        Test that we can create a new directory.

        The concept of a directory on S3/blobs is a bit confusing since
        "folders" isn't really a thing. In this case a folder is simply an
        empty blob that end with `/`.
        """
        exists_mock = Mock()
        exists_mock.side_effect = [False, True]
        self.storage.exists = exists_mock

        with patch("oxygen.files.storages.s3.S3Storage.connection") as conn_mock:
            self.storage.mkdir("path/to/")

        conn_mock.meta.client.put_object.assert_called_once_with(
            Bucket="demo", Key="app/data/path/to/"
        )

    def test_mkdir_missing_parent(self):
        """
        Test that an exception is raised if we try to create a directory
        in a folder that do not exists yet.
        """
        exists_mock = Mock()
        exists_mock.side_effect = [False, False]
        self.storage.exists = exists_mock

        with self.assertRaises(FileNotFoundError):
            self.storage.mkdir("path/to/")

    def test_mkdir_make_parents(self):
        """
        Test that we can create a directory in a folder that do not
        exists yet by setting the `make_parents=True` kwarg.
        """
        exists_mock = Mock()
        exists_mock.side_effect = [False, False]
        self.storage.exists = exists_mock

        with patch("oxygen.files.storages.s3.S3Storage.connection") as conn_mock:
            self.storage.mkdir("path/to/", make_parents=True)

        conn_mock.meta.client.put_object.assert_called_once_with(
            Bucket="demo", Key="app/data/path/to/"
        )

    def test_list_objects(self):
        """
        Test that we can successfully list files and directories.
        """
        with patch("oxygen.files.storages.s3.S3Storage.connection") as conn_mock:
            paginator_mock = Mock()
            paginator_mock.paginate.return_value = [
                {"CommonPrefixes": ({"Prefix": "app/data/path/to/subdir/"},)},
                {"Contents": ({"Key": "app/data/path/to/file.csv"},)},
            ]
            conn_mock.meta.client.get_paginator.return_value = paginator_mock

            dirs, files = self.storage._list_objects("path/to/")
            self.assertEqual(dirs, ["path/to/subdir/"])
            self.assertEqual(files, ["path/to/file.csv"])

    def test_exists_missing(self):
        """
        Test that `exists` return False when a `ClientError` is raised
        by the boto connection.
        """
        with patch("oxygen.files.storages.s3.S3Storage.connection") as conn_mock:
            conn_mock.meta.client.head_object.side_effect = ClientError({}, "bar")
            res = self.storage._exists("/path/to/dir")

        conn_mock.meta.client.head_object.assert_called_once_with(
            Bucket="demo", Key="app/data/path/to/dir"
        )
        self.assertEqual(res, False)

    def test_exists(self):
        """
        Test that `exists` return True if no `ClientError` is raised.
        """
        with patch("oxygen.files.storages.s3.S3Storage.connection") as conn_mock:
            res = self.storage._exists("/path/to/dir")

        conn_mock.meta.client.head_object.assert_called_once_with(
            Bucket="demo", Key="app/data/path/to/dir"
        )
        self.assertEqual(res, True)
