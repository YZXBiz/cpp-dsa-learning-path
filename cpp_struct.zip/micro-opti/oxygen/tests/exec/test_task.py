from unittest import TestCase
from unittest.mock import MagicMock

from oxygen.exec.dag import DAG
from oxygen.exec.executors.local import LocalExecutor
from oxygen.exec.task import Concurrent, Sequential, Task


class TaskTestCase(TestCase):
    def make_mock_tasks(self, number, prefix="DummyTask") -> list[MagicMock]:
        """
        Generate <number> Mock tasks.
        Args:
            number: The number of tasks to generate
            prefix: A prefix for the task names

        Returns:
            A list of <number> Mock tasks
        """
        mock_tasks = []
        for index in range(number):
            factory = MagicMock()
            factory.__name__ = "{}Factory{}".format(prefix, index)
            dummy_task = MagicMock(spec=Task)
            dummy_task.__name__ = "{}{}".format(prefix, index)
            dummy_task.run.return_value = True
            dummy_task._run.return_value = True
            factory.return_value = dummy_task
            factory.label = "{}{}".format(prefix.lower(), index)
            mock_tasks.append(factory)

        return mock_tasks

    def test_duplicate_tasks(self):
        """
        Test that if a Task is added to the REGISTRY
        with a label that already exists for another Task,
        a KeyError is raised.
        """

        class TaskA(Task):
            label = "task"

        with self.assertRaises(KeyError):

            class TaskB(Task):
                label = "task"

    def test_single_task(self):
        """Checks that dags with a single task is correct."""
        mock_tasks = self.make_mock_tasks(1)

        class SingleTaskDAG(DAG):
            ignore_inject_tasks = True
            tasks = [mock_tasks[0]]

        dag = SingleTaskDAG()
        self.assertTrue(Sequential(*dag.tasks).links)

    def test_sequential_dag_run(self):
        """Test the execution of a dag with sequential tasks.

        Make sure the dag runs without errors and that each
        task is called once.

        The DAG:
        +---+     +---+     +---+     +---+     +---+
        | 0 | --> | 4 | --> | 2 | --> | 1 | --> | 3 |
        +---+     +---+     +---+     +---+     +---+
        """

        mock_tasks = self.make_mock_tasks(6)

        class SampleSequentialDAG1(DAG):
            ignore_inject_tasks = True
            tasks = [
                mock_tasks[0],
                # Sequential is optional here.
                Sequential(
                    mock_tasks[4],
                    mock_tasks[2],
                    mock_tasks[1],
                    mock_tasks[3],
                ),
                mock_tasks[5],
            ]

        dag = SampleSequentialDAG1()
        LocalExecutor().run_dag(dag)

        for task in mock_tasks:
            task.assert_called_once()
            self.assertTrue(
                task.return_value._run.called or task.return_value.run.called
            )

    def test_parallel_dag_run(self):
        """Test the execution of a dag with parallel tasks

        Make sure the dag runs without errors and that each
        task is called once.

        The DAG:
                  +---+     +---+
          |-----> | 2 |     | 4 |------|
          |       +---+     +---+      v
        +---+                        +---+
        | 0 |           -->          | 5 |
        +---+                        +---+
          |       +---+      +---+     ^
          |---->  | 1 |      | 3 |-----|
                  +---+      +---+
        """

        mock_tasks = self.make_mock_tasks(6)

        class SampleParallelDAG3(DAG):
            ignore_inject_tasks = True
            tasks = [
                Sequential(
                    mock_tasks[0],
                    Concurrent(
                        mock_tasks[1],
                        mock_tasks[2],
                    ),
                    Concurrent(
                        mock_tasks[3],
                        mock_tasks[4],
                    ),
                    mock_tasks[5],
                )
            ]

        dag = SampleParallelDAG3()
        LocalExecutor().run_dag(dag)

        for task in mock_tasks:
            task.assert_called_once()

    def test_parallel_dag2_run(self):
        """Test the execution of a dag with parallel tasks

        Make sure the dag runs without any errors.

        The DAG:
                  +---+
                  | 4 | ------+
                  +---+       |
                              v
        +---+     +---+     +---+
        | 0 | --> | 1 | --> | 5 |
        +---+     +---+     +---+
                              ^
        +---+     +---+       |
        | 2 | --> | 3 | ------+
        +---+     +---+
        """

        mock_tasks = self.make_mock_tasks(6)

        class SampleParallelDAG5(DAG):
            ignore_inject_tasks = True
            tasks = [
                Concurrent(
                    Sequential(mock_tasks[0], mock_tasks[1]),
                    Sequential(mock_tasks[2], mock_tasks[3]),
                    mock_tasks[4],
                ),
                mock_tasks[5],
            ]

        dag = SampleParallelDAG5()
        LocalExecutor().run_dag(dag)
