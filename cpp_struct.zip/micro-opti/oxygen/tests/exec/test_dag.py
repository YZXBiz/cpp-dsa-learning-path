import unittest
from unittest.mock import MagicMock, Mock

from oxygen.exec.dag import DAG
from oxygen.exec.executors.local import LocalExecutor


class TaskTestCase(unittest.TestCase):
    def test_dag_run(self):
        """Test that we can run a dag and that it execute its tasks"""
        MockTaskType: MagicMock = MagicMock()
        MockTaskType.__name__ = "MockTaskType"
        MockTask = MagicMock()
        MockTask.__name__ = "MockTaskType"
        MockTask.run.return_value = True
        MockTaskType.return_value = MockTask

        class SampleDag(DAG):
            ignore_inject_tasks = True
            tasks = [MockTaskType]

        SampleDag.save_log = Mock()

        # Run our Dag
        LocalExecutor().run_dag(SampleDag())

        # Test that the class type got instantiated
        MockTaskType.assert_called_once()

        # Test that the instantiated instance call _run()
        MockTask._run.assert_called_once()

    def test_duplicate_dag_labels(self):
        """
        Test that if a DAG is added to the REGISTRY
        with a label that already exists for another DAG,
        a KeyError is raised.
        """

        class SampleDagA(DAG):
            label = "foo"
            tasks = []

        with self.assertRaises(KeyError):

            class SampleDagB(DAG):
                label = "foo"
                tasks = []
