import datetime
from unittest import TestCase
from unittest.mock import Mock, mock_open, patch

import yaml

from oxygen.commands.dag import _get_kwargs, _load_context, _slice_tasks
from oxygen.conf.context import context


class DagCommandTestCase(TestCase):
    def test_get_kwargs(self):
        """
        Test that _get_kwargs can split list of strings
        into dictionary of key value mapping.
        """
        self.assertEqual(
            _get_kwargs(["foo=1", "bar=1"]),
            {"foo": "1", "bar": "1"},
        )

    def test_get_kwargs_invalid(self):
        """
        Test that _get_kwargs raise errors if
        the array provided is not a key value mapping
        separated by `=`.
        """
        with self.assertRaises(ValueError):
            _get_kwargs(["foo:1"])

    def test_slice_tasks(self):
        """Test that we can slice a list of tasks by task label"""
        task_a, task_b, task_c = Mock(label="foo"), Mock(label="bar"), Mock()
        self.assertEqual(
            _slice_tasks("bar", [task_a, task_b, task_c]),
            [task_b, task_c],
        )

    @patch("oxygen.conf.context.context_manager.load_config")
    @patch("oxygen.conf.context.datetime")
    @patch("oxygen.conf.context.uuid.uuid4")
    def test_load_context(self, uuid4_mock: Mock, dt_mock: Mock, context_mock: Mock):
        """
        Test that we can load a brand new context without any patches.

        This is the default behavior of any new run.

        """
        dag = Mock()
        dag.context = None
        uuid4_mock.return_value = "1234-5678-9012"
        dt_mock.now.return_value = datetime.datetime(2020, 4, 2, 0, 0, 0)
        context_mock.return_value = {"foo": 1}

        _load_context(dag)
        self.assertEqual(
            context.to_dict(),
            {
                "foo": 1,
                "meta": {
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                    "run_id": "1234-5678-9012",
                },
            },
        )

    @patch("oxygen.commands.dag.context_manager.load_config")
    def test_load_context_previous(self, manager_mock: Mock):
        """
        Test loading a PREVIOUS context. It should only load
        the context from the file path provided, and not include
        the base config located at settings.CONFIG_PATH.
        """
        dag = Mock()
        dag.context = None
        manager_mock.return_value = {
            "meta": {
                "run_id": "0987-6543-2109",
                "created_at": datetime.datetime(2020, 1, 1, 0, 0, 0),
                "run_folder": "/runs/2020/01/01/0987-6543-2109/",
            },
            "foo": 2,
        }

        _load_context(dag, context="path/to/old/context.yaml")

        manager_mock.assert_called_once_with("path/to/old/context.yaml")
        self.assertEqual(
            context.to_dict(),
            {
                "foo": 2,
                "meta": {
                    "run_id": "0987-6543-2109",
                    "created_at": datetime.datetime(2020, 1, 1, 0, 0, 0),
                    "run_folder": "/runs/2020/01/01/0987-6543-2109/",
                },
            },
        )

    @patch("oxygen.conf.context.storage")
    @patch("oxygen.commands.dag.context_manager.load_config")
    def test_load_context_refreshcontext(self, manager_mock: Mock, storage_mock: Mock):
        """
        Test that if we use refreshcontext combined with
        passing in a path to an old context, we will
        read the meta data from the old context but refresh
        and use the new/default context for the rest of
        the parameters.
        """
        dag = Mock()
        dag.context = None
        manager_mock.side_effect = [
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
            },
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
                "foo": 1,
            },
            {
                "meta": {
                    "run_id": "2109-8765-4321",
                    "created_at": datetime.datetime(2020, 3, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/03/02/2109-8765-4321/",
                },
                "foo": 2,
            },
        ]

        _load_context(dag, refreshcontext=True, context="path/to/old/context.yml")

        # Assert that the final context contains the meta params
        # from the reused context, and the rest of the params
        # from the default config file.
        self.assertEqual(
            context.to_dict(),
            {
                "foo": 2,
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
            },
        )

        # Assert that a context.yaml file was stored with the new
        # refreshed context.
        storage_mock.touch.assert_called()
        args, _ = storage_mock.touch.call_args
        path, content = args
        self.assertEqual(path, "/runs/2020/04/02/1234-5678-9012/context.yaml")
        self.assertEqual(
            yaml.load(content.read(), Loader=yaml.SafeLoader), context.to_dict()
        )

    @patch("builtins.open")
    @patch("oxygen.conf.context.storage")
    @patch("oxygen.commands.dag.context_manager.load_config")
    def test_load_context_patch(
        self, manager_mock: Mock, storage_mock: Mock, open_mock: Mock
    ):
        dag = Mock()
        dag.context = None
        manager_mock.side_effect = [
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
            },
            {
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
                "foo": 1,
            },
            {
                "meta": {
                    "run_id": "0987-6543-2109",
                    "created_at": datetime.datetime(2020, 1, 1, 0, 0, 0),
                    "run_folder": "/runs/2020/01/01/0987-6543-2109/",
                },
                "foo": 2,
            },
        ]

        open_mock.side_effect = [
            mock_open(
                read_data=(
                    """
                bar: 2
                """
                )
            ).return_value,
            mock_open(
                read_data=(
                    """
                foo: 5
                """
                )
            ).return_value,
        ]
        _load_context(
            dag,
            refreshcontext=True,
            context="path/to/old/context.yml",
            patch=["path/to/patch_a.yml", "path/to/patch_b.yml"],
        )

        # Assert that the final context contains the meta params
        # from the reused context, and the rest of the params
        # from the default config file.
        self.assertEqual(
            context.to_dict(),
            {
                "foo": 5,
                "bar": 2,
                "meta": {
                    "run_id": "1234-5678-9012",
                    "created_at": datetime.datetime(2020, 4, 2, 0, 0, 0),
                    "run_folder": "/runs/2020/04/02/1234-5678-9012/",
                },
            },
        )

        # Assert that a context.yaml file was stored with the new
        # refreshed context.
        storage_mock.touch.assert_called()
        args, _ = storage_mock.touch.call_args
        path, content = args
        self.assertEqual(path, "/runs/2020/04/02/1234-5678-9012/context.yaml")
        self.assertEqual(
            yaml.load(content.read(), Loader=yaml.SafeLoader), context.to_dict()
        )
