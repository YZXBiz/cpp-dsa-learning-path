import os
from datetime import datetime
from posixpath import dirname
from unittest import TestCase
from unittest.mock import Mock, patch

from oxygen.commands.airflow import deploy_airflow, get_dag_label_deploy, to_identifier
from oxygen.exec.dag import DAG
from oxygen.exec.task import Task


class AirflowTestCase(TestCase):
    def test_to_identifier(self):
        """
        Test that to_identifier converts a string to a valid python identifier.

        This is to ensure that if for example a DAG label is called "hello-world"
        (invalid python variable/identifier name), when the DAG label is used
        within the Airflow python definition, it is converted into a valid
        identifier/variable name (e.g. hello_world).

        """
        self.assertEqual("hello_world", to_identifier("hello-world"))
        self.assertEqual("HelloWorld", to_identifier("Hello World"))

    def test_to_identifier_raises(self):
        with self.assertRaises(ValueError):
            to_identifier("1world")

    def test_get_dag_label_deploy(self):
        """Test that we get a dag label merged with the branch"""
        self.assertEqual(
            get_dag_label_deploy("feature/foo", "sample"), "sample_feature-foo"
        )

    @patch("oxygen.commands.airflow.datetime.datetime")
    @patch("oxygen.commands.airflow.get_dag_label_deploy")
    @patch("oxygen.commands.airflow.slugify")
    @patch("oxygen.commands.airflow.import_string")
    def test_deploy_airflow(self, import_mock, slug_mock, get_label_mock, dt_mock):
        storage_mock = Mock()
        storage_cls_mock = Mock()
        storage_cls_mock.return_value = storage_mock
        dt_mock.utcnow.return_value = datetime(2021, 9, 13, 10, 6, 10)
        import_mock.return_value = storage_cls_mock
        slug_mock.side_effect = lambda x: x.lower()
        get_label_mock.side_effect = lambda x, y: f"{y}_{x}"

        class TaskA(Task):
            label = "task_a"

        class TaskB(Task):
            label = "task_b"

        class SampleDAG(DAG):
            label = "sample"
            tasks = [TaskA, TaskB]

        deploy_airflow(SampleDAG(), "develop", "dags/")

        import_mock.assert_called_once_with("oxygen.files.storages.local.LocalStorage")
        storage_cls_mock.assert_called_once_with("bucket-name", storage_root="/")
        storage_mock.touch.assert_called_once()
        file_path, io = storage_mock.touch.call_args[0]
        self.assertEqual(file_path, "dags/pricing_sample_develop.py")
        self.assertEqual(
            io.read(),
            open(os.path.join(dirname(__file__), "airflow_output.txt")).read(),
        )
