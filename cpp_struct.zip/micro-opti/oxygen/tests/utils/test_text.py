from unittest import TestCase

from oxygen.exceptions import ValidationError
from oxygen.utils.text import validate_slug


class TextUtilsTestCase(TestCase):
    def test_validate_slug(self):
        self.assertTrue(validate_slug("hello-world"))

    def test_validate_slug_invalid(self):
        self.assertFalse(validate_slug("HELLO-world", raises=False))
        self.assertFalse(validate_slug("hello-world ", raises=False))
        self.assertFalse(validate_slug("hello world", raises=False))
        self.assertFalse(validate_slug("hello-world!", raises=False))

    def test_validate_slug_raises(self):
        with self.assertRaises(ValidationError):
            validate_slug("HELLO WORLD")
