from unittest import TestCase
from unittest.mock import Mock, patch

from oxygen.utils.git import get_branch, get_commit, get_tag


class GitUtilsTestCase(TestCase):
    @patch("oxygen.utils.git.Repo")
    def test_get_tag(self, repo_mock):
        repo = Mock()
        tag = Mock()
        tag.commit = "189249f8"
        tag.__str__ = lambda self: "v1.0"
        repo.head.commit = "189249f8"
        repo.tags = [tag]
        repo_mock.return_value = repo
        self.assertEqual(str(get_tag(fallback=True)), "v1.0")

    @patch("oxygen.utils.git.Repo")
    def test_get_commit(self, repo_mock):
        repo = Mock()
        repo.head.commit = "189249f8"
        repo_mock.return_value = repo
        self.assertEqual(get_commit(fallback=True), "189249f8")

    @patch("oxygen.utils.git.Repo")
    def test_get_branch(self, repo_mock):
        repo = Mock()
        repo.active_branch.name = "develop"
        repo_mock.return_value = repo
        self.assertEqual(get_branch(fallback=True), "develop")
