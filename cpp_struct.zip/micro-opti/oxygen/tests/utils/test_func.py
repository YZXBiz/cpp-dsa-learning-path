from unittest import TestCase

from oxygen.utils.func import classproperty


class FuncTestCase(TestCase):
    def test_classproperty(self):
        """
        Test that classproperty can be accessed on a class
        rather than on a class instance. Notice we are accessing
        `name` without first instantiating `F`.
        """

        class F:
            @classproperty
            def name(cls):
                return cls.__name__

        self.assertEqual(F.name, "F")
