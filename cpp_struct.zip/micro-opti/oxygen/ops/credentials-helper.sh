#!/bin/bash
echo username=$GIT_CREDS_USR
echo password=$GIT_CREDS_PSW
