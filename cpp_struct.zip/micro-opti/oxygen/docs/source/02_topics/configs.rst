.. _topic_configs:

Configs
=======

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Oxygen break up configurations into two types, "Application Settings" and "Model Configuration". The two types
have distinct responsibilities and are used in different ways throughout a project.


Application Settings
####################

The term "settings" in Oxygen specifically refers to the "Application Settings" that control the
environment and application configuration of your project.

For example, the Application Settings define things such as:

* Cloud integrations, hostnames and credentials.
* Logging configuration.
* Activated modules.
* Run ID and Run Folder definitions.

The default ``settings.py`` file is initiated when you use the :ref:`topic_commands`
and it provides you with reasonable defaults to start building your project.

The settings file that is loaded by default is controlled by the ``SETTINGS_MODULE`` environment variable, and automatically
falls back on the ``configs.settings`` value in case this environment variable is missing.

This means that you can have multiple settings files in your project and change which one is
used depending on which environment you are running your code on. You could for example have
a ``local.py`` settings file for local development and a ``prod.py`` settings file for when you
are running your code in production.

For a full list of available settings, see the :ref:`reference_settings`.


Model Configuration & Run Context
#################################

Most Data Science projects require the ability to tweak parameters of a model to modify the execution.

For example, it is common to have to define things such as:

* What currency or country code are we generating data for?
* What date range are we loading in data for when we are training our model?
* What features are we including in our model.

This is just a few samples of the type of data that data scientists might need to define. These parameters
are not stored within the "Application Settings" but instead we define them as YAML in what we call the
"Model Configuration".

By default, when you generate a new project using the :ref:`topic_commands`,
it generates a default, mostly empty config at ``configs/config.yaml``, this is where we can start adding our
model configuration and parameters.


The ``context`` is the object that holds your "Model Configuration" at runtime. It is a singleton object that can
be imported from anywhere in your pipeline and it should be treated as immutable since modifying a global object
in the middle of execution might make things difficult to debug.

The context is loaded as soon as we trigger our run using the CLI and the contents of the context can depend on
multiple things:

* The ``config.yaml`` file checked into the current branch.
* Any ``--patch`` paths to additional files defined when calling the :ref:`topic_commands`.
* If we are re-running an existing run using the ``--context`` parameter when calling the :ref:`topic_commands`.
* Custom implementation of a ``ContextManager`` that overrides how contexts are being created.

As you can see, the loading and definition of a context can be quite complex depending on use case, but the key thing to remember is that a
single execution of a run can only have 1 context.


Example Usage
+++++++++++++

Let's say that we extend our default ``config.yaml`` file to have a ``baseline.days`` parameter like below:


.. code-block::

   # Default params.
   meta:
      run_id:
      run_folder:
      created_at:

   # Custom params.
   baseline:
      days: 3  # Look back 3 days of data.



We can easily access this parameter from any task in our project with the following code:


.. code-block::

   from oxygen.exec.task import Task
   from oxygen.conf.context import context

   class SampleTask(Task):

      def run(self):
         # prints '3'
         print(context.baseline.days)



Runtime parameters
++++++++++++++++++

There are a few parameters available in the ``context`` that Oxygen sets internally when
it initiates the context. These parameters are unique per run.

run_id
------

The ``context.run_id`` is the unique id of the run. By default, the ``run_id`` is generated
by the python ``uuid.uuid4()`` function and produces a long, unique ID.

This can be customized by updating the ``RUN_ID_CALLABLE`` :ref:`reference_settings` to a callable that returns
a string. You could for example update it to generate a timestamp or a human readable label
instead of a uuid if you wanted to.

run_folder
----------

The ``context.run_folder`` is the unique directory where files are versioned and stored for
the current execution of a run. Any files loaded or saved using a ``Schema`` or a ``Reader`` with the argument
``root=False`` will automatically attempt to read and write files from this directory.

By default, the ``run_folder`` is set to a combination of the current year, month, date and
the runs ``run_id``.

This can be customized by updating the ``RUN_FOLDER_CALLABLE`` :ref:`reference_settings` to a callable that returns
a folder directory relative to the ``STORAGE_ROOT``.

created_at
----------

The ``context.created_at`` is a ``datetime`` value of when the run was started


Override Context by DAG
+++++++++++++++++++++++

It is possible to set custom context parameters on a ``DAG`` class that will patch
the existing context. This allows you to automatically set certain parameters depending
on which DAG that is executed.

See more on :ref:`topic_dags`.


Customize Context Creation
++++++++++++++++++++++++++

There are plenty of situations where you might want to have more control of how a context is created. For example,
you might want the context to automatically load configurations stored on a Cloud Storage, an API or simply add
the current git branch or commit to the context automatically.

Whatever custom behavior you require, you can achieve this by defining your own ``ContextManager`` class that
defines how the context is loaded and initiated.

.. code-block::

   from oxygen.conf.context import BaseContextManager


   class CustomContextManager(BaseContextManager):
      """
      Custom context manager that adds the current git
      branch to the context to allow for tracking of
      what branch that is being executed on what run.
      """
      def get_run_meta(self):
         meta = super().get_run_meta
         meta["git_branch"] = "master"
         return meta



You can then update the ``CONTEXT_BACKEND`` :ref:`reference_settings` to
point to this new class.


.. code-block::

   CONTEXT_BACKEND = "path.to.my.context.CustomContextManager"



Serialize Context in Run Folder
+++++++++++++++++++++++++++++++

As soon as you run a DAG, it will automatically generate a run folder (:ref:`topic_mlops`)
for your run where it will version any output or meta information about the run.

The ``context`` is automatically serialized and stored as a ``.yaml`` file in this run folder as soon
as a DAG is triggered. This allows you to later inspect exactly what parameters a run was being executed with
in case you have to debug or investigate a run after it has completed.
