.. _topic_readers:


Readers
=======

.. toctree::
   :maxdepth: 2
   :caption: Contents:

The ``Reader`` class is responsible for defining the detailed logic related to reading or
writing dataframes to disk. The specific ``Reader`` class in use can be configured using
your project's :ref:`reference_settings`.

Generally, you do not need to use the ``Reader`` object directly, most of the time you will
use a :ref:`topic_schemas` to read and write dataframes to disk,
which in turn is a wrapper around the ``Reader`` object.

The ``Reader`` object that is used throughout your project by default is lazily evaluated and
defined at ``oxygen.files.readers.reader``. It loads whatever ``READER_BACKEND`` that is defined
in your settings whenever it is first used.


.. code-block::

    from oxygen.files.readers import reader
    from .schemas import SampleSchema

    # Using the reader object directly.
    df = reader.read("path/to/file.csv", schema=SampleSchema)

    # Shortcut using the Schema.
    df = SampleSchema.load("path/to/file.csv")


Note that you can also instantiate your own reader object if you want to avoid using
the default reader set in your settings file. This could be useful if for some reason
you always use the ``SparkReader`` but you have an edge case where you want to use the
``PandasReader``.

.. code-block::

    from oxygen.files.readers.pandas import PandasReader
    from oxygen.fiels.readers import reader
    from .schemas import SampleSchema


    # Reading file using Pandas
    pd_reader = PandasReader()
    df = pd_reader.read("path/to/file.csv", schema=SampleSchema)

    # Reading file using Spark (if set in settings.py)
    df = reader.read("path/to/file.csv", schema=SampleSchema)


PandasReader
############

Available at: ``oxygen.files.readers.pandas.PandasReader``.

The ``PandasReader`` is responsible for reading and writing data to Pandas DataFrames. This
is the ``Reader`` that is set as the default reader for any new project.


SparkReader
###########

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Available at: ``oxygen.files.readers.spark.SparkReader``.

The ``SparkReader`` is responsible for reading and writing data to Spark DataFrames. To enable
the ``SparkReader`` you should update the ``READER_BACKEND`` in your project's :ref:`reference_settings`.


BigQueryReader
##############

Available at: ``oxygen.files.readers.bigquery.BigQueryReader``.

The ``BigQueryReader`` is responsible for reading and writing data to Pandas DataFrames from BigQuery. To enable
the ``BigQueryReader`` you should update the ``READER_BACKEND`` in your project's :ref:`reference_settings`.


Creating a custom Reader
########################

If you want to modify the behavior of an existing reader, you can create your own ``Reader`` backend
by inheriting from the ``oxygen.files.readers.base.BaseReader`` and giving the python dotted path to your new
``Reader`` in the ``READER_BACKEND`` :ref:`reference_settings`.
