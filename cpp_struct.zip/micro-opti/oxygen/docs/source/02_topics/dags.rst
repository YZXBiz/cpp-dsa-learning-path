.. _topic_dags:

Directed-Acyclic-Graphs (DAG)
=============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


One of the core pieces of any data science project -- other than the data itself -- is the construction
of a pipeline that execute the steps that make up your model one by one until you get your final
results.

This document explains how the different pieces that make up a model fit in together, and
how you can create your own pipeline.

A pipeline in oxygen is also refered to as a "DAG". Here is a simple example of a preprocess ```DAG``` that we will
refer to throughout this document.

.. code-block::

    from oxygen.exec import DAG, Task

    class PreprocessDAG(DAG):
        label = "preprocess"
        tasks = (
            ProcessProducts,
            ProcessPrices,
            ProcessTransactions,
        )

    class ProcessProducts(Task):
        def run(self):
            """Logic related to prepare product data"""

    class ProcessPrices(Task):
        def run(self):
            """Logic related to prepare price data"""

    class ProcessTransactions(Task):
        def run(self):
            """Logic related to prepare transaction data"""



Defining a DAG
##############

A DAG is a simple class that is responsible
for grouping a set of Tasks together and
define in which order they should be executed.

As you can see from our example ``PreprocessDAG``, it groups a set of preprocess ``Task`` classes
under the ``PreprocessDAG.tasks`` attribute and give the ``DAG`` a label. The ``label`` is the name
of our ``DAG`` and defines how we will refer to our DAG later when we want to execute it.

.. code-block::

    class PreprocessDAG(DAG):
        label = "preprocess"
        tasks = (
            ProcessProducts,
            ProcessPrices,
            ProcessTransactions,
        )


In our simple example, this defines a ``DAG`` that executes 3 tasks one by one in the order
from top to bottom.

Setting DAG specific context parameters
+++++++++++++++++++++++++++++++++++++++

There might be situations where you want different DAG's to have specific :ref:`topic_configs` parameters set to them depending on what DAG that is being executed.

You can define a ``context`` attribute on your DAG class which will act as a patch dictionary that is applied to the context when the DAG is executed.

.. code-block::

    class PreprocessDAG(DAG):
        label = "preprocess"
        tasks = (
            ProcessProducts,
            ProcessPrices,
            ProcessTransactions,
        )
        # Setting a custom context that is only
        # applied for this `preprocess` DAG.
        context = {"foo": 1}

Running a DAG
#############

Your ``DAG`` is automatically loaded to your projects CLI and callable from the ``./run.py dag <label>``
command as long as the module that the ``DAG`` belongs to is included in your projects ``INSTALLED_MODULES`` :ref:`reference_settings`.

This means that to run our ``PreprocessDAG`` defined earlier, we can call it by the ``preprocess`` label
that we set using the following CLI command:

.. code-block::

    $ python run.py dag preprocess


As you can see, this makes it very easy to have multiple ``DAG`` definitions in your project
and call them one by one. For example you might separate your project into ``preprocess``,
``test``, ``predict`` and so on to make your pipelines shorter and independant from
each other.

The execution of a DAG
######################

A DAG is simply a definition. It does not
contain any logic related to the actual execution of the defined ``Task`` classes,
this is instead the job of the ``Executor``.

This means that a single ``DAG`` can be executed in different ways depending on which
``Executor`` that is set for the project. For example, you might want to execute things
locally, or on a remote service using message queues, or on a SaaS platform like Databricks.

No matter how you execute things, your code and ``DAG`` looks the same, its only the settings
relating to the ``Executor`` of your project that is updated. This makes it very convenient
to switch from local development to production infrastructure.

Creating a Task
###############

A ``Task`` is an individual step within your ``DAG``. The ``Task`` is where most of your code
and custom logic will reside, this is where you spend most of your development efforts
in any project.

The ``Task`` class is a simple interface that allows the rest of the pieces that make up a
pipeline to understand the entrypoint of your code and how it can be executed, this
entrypoint is the ``run()`` method.

.. code-block::

    class ProcessProducts(Task):
        def run(self):
            """Logic related to prepare product data"""


What you fill your ``Task`` with is completely up to you, go ahead and read in your data
as Dataframes and run your models. Feel free to separate your code into multiple files
or classes if it makes sense, what matters is that the ``Task`` is the entrypoint to your
module -- and it is what is used within your ``DAG`` definition to make up your pipeline.

Note that the ``Task.run()`` method do not accept any arguments. This is to force each
task to be independant from each other, and make sure that they do not rely on in-memory
arguments or data to be passed into them.

The benefits of this are:

- Tasks are composable and can be reused across ``DAG`` defintions no matter what other ``Task``
  that is executed right before it.
- Tasks are replayable and you can either retry a failed run, or resume a run from a specific
  ``Task`` without having to run the full pipeline and depend on in-memory objects being passed
  through from task to task.
- Tasks can be executed across different machines or processes without shared memory.

The way you share data between tasks are through file reads and writes. ``TaskA`` might save
output to a database or file, and ``TaskB`` might read in this data if it depend on it.

Executor
########

An ``Executor`` is the class that implements the actual execution of the ``Task`` classes within
our ``DAG``. At first glance you might think that you "just want to run" your code but this
is actually a quite complex topic.

- Do you want to run your code on your local machine or VM?
- Do you want to deploy and run your code on a platform like Databricks?
- Do you want to use message queues and workers to execute your Tasks?
- Do you want to use technologies such as Airflow or Luigi to run your Tasks?

You control how your pipeline is executed by setting the ``EXECUTOR_BACKEND`` :ref:`reference_settings` to the implementation
that you want to use. You can use a built-in ``Executor`` or you are free to implement
your own for your own needs.

.. code-block::

    # settings.py
    EXECUTOR_BACKEND = "oxygen.exec.executors.LocalExecutor"


By separating the execution of the Tasks from the business logic itself, you can easily
customize the execution from for example development on your local machine, running your
test suite and deploying your pipeline on a production system -- without having to change
your the code or implementation of your pipeline.

Building your own Executor
##########################

The ``LocalExecutor`` executes the ``DAG`` on whatever machine that the command is being executed on.
In some use cases you might want to override this behavior to for example deploy the code on a remote
Airflow kubernetes cluster and run the code remotely.

For these kind of situations, you will have to build your own Executor that implements the behavior you want.

.. code-block::

    from oxygen.exec.executors.base import Executor
    from .client import AirflowClient


    class AirflowExecutor(Executor):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.client = AirflowClient()

        def run_dag(self, dag, *args, **kwargs):
            # Deploy current code to Airflow storage.
            self.client.deploy_code()
            # Send request to Airflow REST API to
            # trigger the deployed DAG.
            self.client.trigger_dag(dag.label)

        ...


You can then activate this custom ``Executor`` by setting the ``EXECUTOR_BACKEND`` :ref:`reference_settings`
to point to your new class.

.. code-block::

    EXECUTOR_BACKEND = "path.to.custom.executor.AirflowExecutor"


Parallel Tasks and advanced DAG's
#################################

In the examples above, we simply use a list of ``Task`` classes in our ``DAG`` definition. By default
this executes all the tasks sequentially.

If you want to build more complex DAGs that execute tasks in parallel, you can use the ``Sequential`` and ``Concurrent``
classes to group tasks together in both sequential or concurrent execution.

See examples below.

.. code-block::

    from .tasks import Task1, Task1, Task3, Task4, Task5, Task6
    from oxygen.exec.dag import DAG
    from oxygen.exec.task import Concurrent, Sequential


    class SampleDAG(DAG):
        """
        This is a dag consisting of 3 parallel tasks on which depends
        a final task.
        +-------+
        | Task1 |--------------|
        +-------+              v
        +-------+          +-------+
        | Task2 |--------> | Task4 |
        +-------+          +-------+
        +-------+              ^
        | Task3 |--------------|
        +-------+
        """
        label = "complex"


        tasks = [
            Concurrent(
                Task1,
                Task2,
                Task3,
            ),
            Task4
        ]


    class AnotherSampleDAG(DAG):
        """
                        +-------+     +-------+
            |-----------> | Task2 | --> | Task3 |------------|
            |             +-------+     +-------+            v
        +-------+                                        +-------+
        | Task1 |                                        | Task6 |
        +-------+                                        +-------+
            |             +-------+     +-------+            ^
            |---------->  | Task4 | --> | Task5 |------------|
                        +-------+     +-------+
        """
        label = "complex"

        tasks = [
            Task1,
            Concurrent(
                Sequential(Task2, Task3),
                Sequential(Task4, Task5),
            ),
            Task6
        ]
