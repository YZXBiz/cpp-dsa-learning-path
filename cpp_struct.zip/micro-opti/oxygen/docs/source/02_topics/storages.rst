.. _topic_storages:

Storages
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:


A ``Storage`` class is an abstraction of file actions for a specific type of file system.

This allow you to write the same code in your model but seemlessly switch between using your
local storage or cloud storage simply by updating your ``STORAGE_BACKEND`` in your project's
:ref:`reference_settings`.

The ``oxygen.files.storages.storage`` object is a lazily evaluated instance of your ``STORAGE_BACKEND``
that is evaluated whenever it is first used.

.. code-block::

    # settings.py
    # Use local file system.
    STORAGE_BACKEND = "oxygen.files.storages.local.LocalStorage"
    # Use Azure Cloud file system.
    STORAGE_BACKEND = "oxygen.files.storages.azure.AzureStorage"


.. code-block::

    # tasks.py
    from oxygen.files.storages import storage

    files, dirs = storage.listdir("path/to/dir")


As illustrated by the example above, you can easily switch your ``STORAGE_BACKEND`` to
control if the ``storage.listdir()`` is listing the contents of a directory on the cloud
or on your local file system, without having to modify your code.

This allows you to develop and test on your local machine, deploy in the cloud for production
and adjust your code to future client demands with minimal changes to your codebase.

LocalStorage
############

The ``LocalStorage`` class is a wrapper around many of the normal, builtins of Python such
as ``open()`` or ``os.path.isdir()`` that allow you to interact with the local file system
of wherever your code is running from.

This class is used by default when you create a new project and is suitable for when
you are developing on your local machine or if you are running your code in production
on a single Virtual Machine.

AzureStorage
############

The ``AzureStorage`` class is a wrapper around the Azure SDK that allow us to interact
with the Azure Blob Storage file system.

This class can be used by changing the ``STORAGE_BACKEND`` to ``oxygen.files.storages.azure.AzureStorage``
and is suitable to use whenever your data is located in the cloud.

GoogleStorage
#############

The ``GoogleStorage`` class is a wrapper around the Google SDK that allow us to interact with the Google Cloud Storage file system.

This class can be used by changing the ``STORAGE_BACKEND`` to ``oxygen.files.storages.google.GoogleStorage`` and is suitable to use when your data is stored on the GCP cloud.

S3Storage
#########

The ``S3Storage`` class is a wrapper around the Boto SDK that allows us to interact with any S3 file system. This backend class can be used both to connect to AWS S3 but also DigitalOcean S3.

This class can be used by changing the ``STORAGE_BACKEND`` to ``oxygen.files.storages.s3.S3Storage`` and is suitable to use when your data is stored on the AWS or DigitalOcean cloud.

Creating a custom storage
#########################

You can easily extend Oxygen's storage backends by creating your own if you need to add support
for additional file systems.

Simply extend the base class at ``oxygen.files.storages.base.BaseStorage`` and implement the
methods required that fallback on ``NotImplementedError``.
