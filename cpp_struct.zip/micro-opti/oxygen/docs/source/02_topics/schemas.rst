.. _topic_schemas:


Schemas
=======

.. toctree::
   :maxdepth: 2
   :caption: Contents:


A ``Schema`` is a definition of the expected structure of your data. By defining a schema
in your code you can easily automate behavior that enforces that the data is compatible
with the expected ``Schema``, which in turn allows you to reduce bugs and create a robust
project.

Let's start with an example of a schema describing a product:


.. code-block::

    from oxygen.files.schemas import Schema, StringColumn, FloatColumn, IntegerColumn
    from oxygen.files.validators.pandas import NotNullValidator


    class ProductSchema(Schema):
        product_id = IntegerColumn(source="REFERENCE", validators=[NotNullValidator()])
        name = StringColumn()
        price = FloatColumn()



A simple, small class that defines the expected column of the product data. This ``Schema``
can then automatically handle things such as:

* Validate column names and column types.
* Rename columns from the client source data to the projects naming conventions.
* Run custom validation logic on column level using the ``Validator`` classes.
* Translate schemas depending on ``Reader`` used, e.g. convert it into a PySpark Schema or
  a Pandas Schema.
* Make it easy to understand what type of data your code is interacting with.


Schema Load and Save API
########################

A Schema comes with wrapper arounds the ``Reader`` instance's ``.read()`` and ``.write()`` methods
which allow you to easily interact with your data through an easy to read API.

We could read in and write out a Dataframe using our ``ProductSchema`` defined above in the following manner:

.. code-block::

    # Load in data from disk to DataFrame
    df = ProductSchema.load("products.parquet")

    # Save data to disk from DataFrame.
    ProductSchema.save("products-modified.csv", df)


Note that we can interchangably use file formats and extensions without having to write
custom code that adjust to the file type that is being loaded or saved. Our ``Reader`` class
takes care of using the correct logic under the hood by itself.


Autofilter Columns
##################

The default behavior of a ``Schema`` is to automatically filter out the columns that are defined
in the schema from the source data. That means that if your data contains 50 columns and
your schema only defines 5 of these columns, the other 45 columns will automatically be
discarded.


Columns
#######

A ``Schema`` is made up by a definition of ``Column`` fields. The ``Column`` class is just
an abstraction of the actual data type of our data columns which in turn makes our code
agnostic to what technology that is used under the hood.

No matter if you are creating a project that is using Spark as a ``Reader`` or Pandas as a
``Reader``, your ``Schema`` definition and its ``Column`` fields will look the same. This makes it
relatively easy to switch between technologies throughout the lifetime of a project.

Oxygen comes with the following column definitions out of the box:

* ``StringColumn``
* ``IntegerColumn``
* ``NullableIntegerColumn``
* ``FloatColumn``
* ``DateColumn``
* ``DateTimeColumn``
* ``BoolColumn``
* ``PandasCategoryColumn``


Column Source
#############

It is quite common that data scientists want to rename columns from their original source
names defined by the client, to custom, readable names that follow the projects naming conventions.
Oxygen makes this very easy by providing the ``source`` kwarg on the ``Column`` class to specify
the source data column name.

The ``Reader`` will use the ``Column.source`` attribute to then automatically rename data from the
source columns to the attribute name as you read in the data.

.. code-block::

    # Auto rename column from ``PRODUCT_NAME`` to ``name``
    name = StringColumn(source="PRODUCT_NAME")



Column Validators
#################

You can provide a :ref:`topic_validators` on a ``Column`` level to specify
reusable and DRY validation behavior other than simply just validating the columns existance
and its data type.

.. code-block::

    # Add custom validation behavior that enforce that no value is Null.
    name = StringColumn(validators=[NotNullValidator()])



Custom Columns
##############


.. note::

    Some ``Reader`` classes might also need additional work to add support for
    your new ``Column`` in e.g. casting values, validating etc.


If the built in columns are not enough to support your needs, you can easily create
your own custom column by extending the ``Column`` class.

.. code-block::

    from oxygen.files.schemas import Column


    class SmallIntegerColumn(Column):
        dtype = np.int8
