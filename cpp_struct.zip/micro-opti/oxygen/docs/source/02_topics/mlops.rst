.. _topic_mlops:


ML Ops & Versioning
===================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


File Paths and File Versioning
##############################

As you introduce the concept of a pipeline, you also introduce the concept of a "run".
You might run the pipeline hundreds of times with different parameters and versions of
the code, and you will want to separate the outputs of each run so that you can compare
the results between runs later, and reproduce the results of previous runs.

This leads to the topic of "file versioning". File versioning simply means that each run
has a snapshot or a version of some (or all) of the files related to it, so that you can
later go back and see the exact input and output that was produced.

To do this, we must structure our file system into directories that are specific to runs,
and other directories that are shared among runs.

For example:

.. code-block::

    data/
    source/
        transactions.parquet
    runs/
        2020/
          1/
            22/
              1234-5678-9123-4567/
                baseline.parquet
                output.parquet
              0987-6543-2109-8765/
                baseline.parquet
                output.parquet


By structuring it like this, it means that we can keep the large source data files in
a shared directory that all runs read from, but the output of each task is stored within
a run folder so that the data can be compared at later stages.


Constructing File Paths from Root or Run Folder
+++++++++++++++++++++++++++++++++++++++++++++++

As you use a ``Schema`` or a ``Reader`` to interact with files, it will automatically format
the prefixed file path for you depending on if you want to interact with a file relative
to the root, or relative to the run folder.

You can control if you want to write a path relative to the root or not by using the
``root`` kwarg in the ``.load()`` and ``.save()`` methods.

.. code-block::

    # Attempts to interact with file relative to run folder
    # 'data/runs/2020/1/22/1234-5678-9012-3456/baseline.parquet'
    df = SampleSchema.load("baseline.parquet")
    SampleSchema.save("baseline.parquet", df)

    # Attempts to interact with file relative to root folder
    # 'data/baseline.parquet'
    df = SampleSchema.load("baseline.parquet", root=True)
    SampleSchema.save("baseline.parquet", df, root=True)


By default, ``root`` is ``False`` which means that the default behavior is that it creates
file paths relative to the run's run_folder.

Change Run ID Definition
++++++++++++++++++++++++

By default, the run id is a `random UUID <https://docs.python.org/3/library/uuid.html#uuid.uuid4>`_
that is initiated within the :ref:`topic_configs`. of a run.

This can be overriden by changing the ``RUN_ID_CALLABLE`` setting within the
:ref:`reference_settings` to a function that return a unique string.


Change Run Folder Definition
++++++++++++++++++++++++++++

By default, the run folder is a path constructed as ``runs/YYYY/MM/DD/RUN_ID/``. This generates
a unique path that is bucketed by date to make it easier to sort and find the directory
that you are looking for.

This can be overriden by changing the ``RUN_FOLDER_CALLABLE`` setting within the
:ref:`reference_settings` to a function that returns a unique path.
