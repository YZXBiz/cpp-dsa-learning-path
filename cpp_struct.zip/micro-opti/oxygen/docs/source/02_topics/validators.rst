.. _topic_validators:


Validators
==========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

The ``Validator`` class is used to create DataFrame validators that can be set on either
a specific column or a complete set of columns in a ``Schema``.

.. code-block::

    from oxygen.files.schemas import Schema, StringColumn
    from oxygen.files.validators.pandas import NotNullValidator

    class SampleSchema(Schema):
        # Validate the title field to not contain null values.
        title = StringColumn(validators=[NotNullValidator()])


    class SampleSchema(Schema):
        # Validate that no field within this schema contains any
        # null values. This validates col1, col2 and col3.
        validators=[NotNullValidator()]
        col1 = StringColumn()
        col2 = StringColumn()
        col3 = StringColumn()


Validators are normally small classes (or functions, any callable will do) that validate for
a single thing, so that they can be reused and composed together in different ways across
different columns and sets of data.

Since the code required to validate the data depends on which type of technology that
is being used, validators must be custom written depending on what ``Reader`` is used.
Because of this we separate validators into "pandas validators" and "spark validators".


Pandas Validators
#################

Oxygen Framework comes with some validators ready to be used out of the box. The
current ``Validator`` classes for Pandas can be found at ``oxygen.files.validators.pandas``
and they are:

* ``NotNullValidator``.
* ``UniqueValidator``.
* ``RangeValidator``.
* ``MinValueValidator``.
* ``MaxValueValidator``.
* ``RegexValidator``.


Spark Validators
################

Oxygen Framework comes with some validators ready to be used out of the box. The
current ``Validator`` classes for Spark can be found at ``oxygen.files.validators.spark``
and they are:

* ``NotNullValidator``.
* ``UniqueValidator``.
* ``RangeValidator``.
* ``MinValueValidator``.
* ``MaxValueValidator``.
* ``RegexValidator``.

Remember that validating large amounts of data can add a lot of additional execution time to your model on distributed data sets due to shuffling.


Creating your own validator
###########################

Creating your own validator is simple, just create a callable that expects a ``df`` and ``col``
arguments being passed into it. There is a base class named ``Validator`` that you can use
for the sake of readability, but you could also simply create your own function.

.. code-block::

    from oxygen.files.validators.base import Validator
    from oxygen.exceptions import ValidationError


    class NotNullValidator(Validator):
        """Validate if data contain null values"""
        def __call__(self, df, col=None):
            cols = [col] if col else df.columns
            if df[cols].isnull().values.any():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain null values."
                    )

                raise ValidationError(
                    f"Dataframe contains null values."
                )


Note that we use the ``__call__`` dunder method to make our **validator instance** a callable.

You could also write this validator as a function in the following manner:

.. code-block::

    def not_null_validator(df, col=None):
        cols = [col] if col else df.columns
        if df[cols].isnull().values.any():
            if len(cols) == 1:
                raise ValidationError(
                    f"Column '{col}' contain null values."
                )

            raise ValidationError(
                f"Dataframe contains null values."
            )
