.. Compass documentation master file, created by
   sphinx-quickstart on Thu Feb  2 11:29:35 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Compass's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   01_get-started/index.rst
   02_topics/index.rst
   03_reference/index.rst
   04_tutorials/index.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
