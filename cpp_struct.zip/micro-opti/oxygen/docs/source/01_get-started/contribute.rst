.. _intro_contribute:

Contribute
==========

To ensure a working application that adhere to our project practices, please see the following sections.


pre-commit hooks
################

To ensure that your code changes adhere to our style guides, linters and security scans, please ensure you run the following command to run all scans before you push your code or do a Pull Request.


.. code-block::

   pre-commit run -a


Run Test Suite
##############


Build Image.

.. code-block::

   cd tests/
   docker build -t oxygen -f ./Dockerfile ../


Run tests:

.. code-block::

   cd tests/
   docker run
      -v $(pwd):/app/
      -v $(pwd)/../oxygen:/src/oxygen
      oxygen
