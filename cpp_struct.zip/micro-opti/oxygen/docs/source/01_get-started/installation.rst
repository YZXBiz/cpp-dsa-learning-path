.. _intro_install:


Installation
============

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Since Oxygen is not a open source package and not published on PyPi, it is recommended that
you bundle Oxygen with your client case repository to ensure that handover is simple and that
the client case repository do not depend on dependencies from a private BCG repository.

For example, you might structure your repository like this:

.. code-block::

    docs/
        # Our project documentation
    libs/
        # Clone the oxygen repository here
        oxygen/
    project/
        # Our project files.
    requirements.txt


You can then add the following line to your ``requirements.txt`` file:


.. code-block::

    -e ./libs/oxygen/
    pandas==1.0.2
    numpy==1.19.4
    ...


Finally you can install your dependencies with the following command:


.. code-block::

    pip install -Ur requirements.txt


Test installation
#################

To test that you successfully installed Oxygen, run the following command and ensure you
see the following output in your terminal:

.. code-block::

    $ oxygen-cli.py --help
    Usage: oxygen-cli.py [OPTIONS] COMMAND [ARGS]...

    Options:
    --help  Show this message and exit.

    Commands:
    dag
    startmodule
    startproject


Next Steps
##########

To setup a Oxygen project, please read more on the tutorial of :ref:`tutorial_first_project`.
