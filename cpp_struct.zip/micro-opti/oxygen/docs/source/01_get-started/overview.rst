.. _intro_overview:


Overview
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Oxygen is a high-level pipeline framework that allows data scientists and machine learning engineers to rapidly develop
production level projects. The framework is agnostic to what technology stack or cloud provider that the project is using and
does not provide plug-and-play models to solve a specific use case, instead it focuses on solving the building blocks that make
up the foundation of a data science project such as:

* Providing structure to a code base.
* Orchestrating a pipeline.
* Managing configuration and settings.
* File operations and validations.

The framework do make some opinionated decisions and come with some integrations out of the box, but it is built to allow teams
to easily extend, customize to their own individual needs.


Licensing and IP
################

Copyright © 2024 by Boston Consulting Group. All rights reserved


Features
########

Structure your codebase into modules, Tasks and DAGs
++++++++++++++++++++++++++++++++++++++++++++++++++++

Most Data Science projects are some sort of pipeline of actions. Oxygen provides you with
the building blocks to create a DAG that consist of multiple Tasks that contain the custom
logic of your pipeline and later execute step by step.

This structure makes it very easy to industrialize the product and add support for Airflow
and other similar scheduling, pipeline and visualization tools.


.. code-block::

    from oxygen.exec.dag import DAG
    from oxygen.exec.task import Task


    class SampleDAG(DAG):
        """Execute dag using ``./run.py dag sample``"""
        label = "sample"
        tasks = [
            ETLTask,
            BaselineTask,
            UpliftTask,
            OptimizationTask,
            FormatOutputTask,
        ]

    ...

    class BaselineTask(Task):

        def run(self):
            # Logic related to calculating a baseline.



By composing a pipeline out of individual tasks, the code becomes composable and easily
maintainable with a clear separation of concerns. If the developer want to try another
Baseline, simply replace the ``BaselineTask`` in the DAG with a ``NewBaselineTask``.

There are no long run scripts with random function calls spread out over the code base
which makes it difficult to recompose the execution of the pipeline, everything is clearly
defined and easy to understand with this clear structure.


Validate your data using File Schemas
+++++++++++++++++++++++++++++++++++++

All data science projects depends on reading and writing data. The Oxygen Framework allows
data scientists to focus on the actual model building and data science instead of file system
integrations, validations and making sure that the data is of the correct data type.

This is solved using what Oxygen calls a ``Schema`` that define the expectations of a data source.


.. code-block::

    from oxygen.files.schemas import Schema, StringColumn, IntegerColumn, FloatColumn
    from oxygen.files.validators.pandas import NotNullValidator


    class TransactionSchema(Schema):
        transaction_id = IntegerColumn(source="REFERENCE", validators=[NotNullValidator()]),
        cart_id = IntegerColumn()
        total = FloatColumn()
        code = StringColumn()


    df = TransactionSchema.load("transactions.parquet")


The ``Schema`` is responsible for:

* Enforcing data types of data
* Renaming source columns from the original data to new column names
* Providing custom validation logic
* API/Entrypoint for reading and writing data.

By using schemas to define the expectations of the data, you can create small, lightweight classes
that make your code easier to read but adds a tremendous amount of power and capabilities to your codebase,
while also keeping your codebase DRY.


Use build in integrations for cloud services
++++++++++++++++++++++++++++++++++++++++++++

In the beginning your codebase might start off as something that you run on a single VM or
your local machine, but pretty quickly you will start integrating it with cloud services to
read data from Amazon S3 or Azure Blob Storage.

Instead of having to write these integrations from scratch for each project you work on,
the Oxygen Framework provides you with some of these integrations out of the box. You can
even switch between local/cloud or between cloud services without having to change your code!


.. code-block::

    # settings.py

    STORAGE_CLASS = "oxygen.files.storages.local.LocalStorage"



.. code-block::

    # tasks.py
    from oxygen.files.storages import storage


    contents = storage.open("path/to/file.txt")


Simply update the ``STORAGE_BACKEND`` setting from ``LocalStorage`` to ``AzureStorage`` to now
suddently read from the cloud. The ``storage`` object is a lazily evaluated object that
is instantiated by a different class depending on how you set your settings.

This allows you to easily separate behavior from your local development to your production
environment simply by modifying your settings instead of having to modify your code.


Comes with support for Spark and Pandas
+++++++++++++++++++++++++++++++++++++++


.. warning::

    Spark Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.


Out of the box, Oxygen allows you to use its File Schemas to validate, read and write either
Spark or Pandas DataFrames. The configuration of what type of DataFrame that a project is
using is configurable using the ``READER_BACKEND`` in the settings.py file that belong to
your project.


.. code-block::

    READER_BACKEND = "oxygen.files.readers.pandas.PandasReader"


You can of course extend the functionality of Oxygen by creating your own ``Reader`` class
for whatever technology you wish for, and point the ``READER_BACKEND`` to it.


Generate initial project files with CLI
+++++++++++++++++++++++++++++++++++++++

Accelerate the start of a new project by generating some initial files that create the
structure for your new project.


.. code-block::

    $ oxygen-cli.py startproject retailcase



.. code-block::

    $ python run.py startmodule core


The sample files generated gives you a minimal starting point to get you going with your
new case, and include micro code examples to show you how things relate to each other.


Extend the framework with your own behavior
+++++++++++++++++++++++++++++++++++++++++++

The concept of the ``STORAGE_BACKEND`` setting described above are reused in many different
aspects throughout the Oxygen Framework. This means that you can easily write your own
classes that override the default Oxygen behavior and just update your ``settings.py`` file
to apply these changes throughout your codebase.


.. code-block::

    from oxygen.files.storages.base import Storage


    class MyCustomStorage(Storage):

        def open(self, file_path: str, mode="rb"):
            # Custom file open implementation


    # settings.py
    STORAGE_BACKEND = "retailcase.core.custom.MyCustomStorage"


Oxygen attempts to come with the batteries included for you to build a production level
data science project, but it also attempts to be flexible and allow for customization since
it is built with the mentality that it cannot predict every use case and every project.
