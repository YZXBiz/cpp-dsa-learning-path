.. _reference_settings:

Settings
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

The term "Settings" in Oxygen specifically refers to the application settings that allow you
to customize the behavior of the Oxygen application, it does not refer to "model parameters"
which instead is handled by the [Context](./context.md).

The default ``settings.py`` file is initiated when you use the [startproject command](../execution/commands.md)
and it provides you with reasonable defaults to start building your project.

The settings file that is loaded by default is controlled by the ``SETTINGS_MODULE`` environment
variable, and automatically falls back on the ``{project_name}.settings`` value in case this
environment variable is missing.

This means that you can have multiple settings files in your project and change which one is
used depending on which environment you are running your code on. You could for example have
a ``local.py`` settings file for local development and a ``prod.py`` settings file for when you
are running your code in production.

Settings Reference
##################

BASE_DIR
++++++++

Defaults to the root of your project if you used the ``startproject`` command to generate
the scaffolding.

This value should be the absolute path to the root of your project where your ``run.py`` file
is located.

INSTALLED_MODULES
+++++++++++++++++

Defaults to ``[]``.

List of python dotted paths to each Oxygen module that we want to automatically load when
we bootstrap our application. You must define your modules path here for it to automatically
load commands, tasks and dags.

CONFIG_PATH
+++++++++++

Defaults to: ``{BASE_DIR}/{PROJECT_NAME}/config.yaml``.

Path to the yaml file that the ``Context`` will load, containing any model parameters.

CONFIG_PATCH
++++++++++++

Defaults to: ``None``.

String path to a YAML file that will be added to the default ``Context``.

CONTEXT_BACKEND
+++++++++++++++

Defaults to: ``"oxygen.conf.context.DefaultContextManager"``

Point to the class that handles the creation of the context object. If you would like
to customize or override the context initiation behavior, you could create your own
``ContextManager`` and point to it using this setting.

EXECUTOR_BACKEND
++++++++++++++++

Defaults to: ``oxygen.exec.executors.LocalExecutor``

The ``Executor`` class that will be used to run any dags. By default it uses the
``LocalExecutor`` which runs the ``DAG`` and its ``Task`` classes on the local machine from
where the command is executed.

READER_BACKEND
++++++++++++++

Defaults to: ``oxygen.files.readers.PandasReader``.

The ``Reader`` class that will be used to read and write dataframes.

STORAGE_BACKEND
+++++++++++++++

Defaults to: ``oxygen.files.storages.local.LocalStorage``.

The ``Storage`` class that will be used to interact with the file system for actions such
as reading/writing files, listing directories, check file existence etc.

STORAGE_ROOT
++++++++++++

Defaults to ``{BASE_DIR}/data``.

Path to the root of the directory where we want to read and write files from. This path
is automatically prepended to any file paths used within Oxygen and prevents the developer
from accidentally reading or writing to files outside of this path.

STORAGE_HOSTNAME
++++++++++++++++

Defaults to ``None``.

The prefixed hostname of a storage. This could for example be used by the ``SparkReader`` to
prefix the paths with the full URL of the cloud storage. E.g.

.. code-block::

    STORAGE_HOSTNAME = "wasbs://storage.cloudservice.com"


LOGGING
+++++++

Defaults to a reasonable logging config.

A dictionary containing a python logging ``dictConf`` that is automatically loaded during
the boostrapping of our application.

TASK_MODULES
++++++++++++

Defaults to: ``["tasks"]``.

The python packages within an Oxygen module where Oxygen should attempt to look for any tasks
during autoloading.

DAG_MODULES
+++++++++++

Defaults to: ``["dags"]``.

The python packages within an Oxygen module where Oxygen should attempt to look for any dags
during autoloading.

COMMAND_MODULES
+++++++++++++++

Defaults to: ``["commands"]``.

The python packages within an Oxygen module where Oxygen should attempt to look for any commands
during autoloading.

RUN_ID_CALLABLE
+++++++++++++++

Defaults to: ``lambda: str(uuid.uuid4())``.

The callable used to generate our ``context.run_id`` value. Should point to a callable
that accepts no arguments and that return a unique string.

RUN_FOLDER_CALLABLE
+++++++++++++++++++

Defaults to: ``lambda dt, run_id: dt.strftime(f"/runs/%Y/%m/%d/{run_id}/")``.

The callable used to generate our ``context.run_folder`` value. Should point to a callable
that accepts a ``datetime`` and a ``run_id`` argument and that generates a unique file path.

SPARK_CONFIG
++++++++++++

Defaults to: ``{}``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Key value mapping of any spark configuration values that we want to add to our spark
connection used by the ``SparkReader``. See available properties in `PySpark Documentation <https://spark.apache.org/docs/2.1.0/configuration.html#available-properties>`_.

START_TASK
++++++++++

Defaults to: ``None``.

Dotted path to a ``Task`` that we want to inject into the start of all of our ``DAG`` classes
throughout the project. This can be used to automatically do some bootstrapping or initiation
of our pipeline.

END_TASK
++++++++

Defaults to: ``None``.

Dotted path to a ``Task`` that we want to inject into the end of all of our ``DAG`` classes
throughout the project. This can be used to automatically do some cleanup, diagnostics or
reporting in the end of the execution of a ``DAG``.

SQL_CONNECTION
++++++++++++++

Defaults to: ``None``.

Fully qualified connection string to be used by the SQLAlchemy ``create_engine`` function
which is used to read/write from SQL databases. This can be used to connect to various
SQL connection endpoints, including Spark.

Example: ``postgresql://postgres:pw123@localhost:5432/postgres``

AZURE_STORAGE_CONTAINER
+++++++++++++++++++++++

Defaults to: ``None``.

String of the container name used by the ``AzureStorage`` backend.

AZURE_STORAGE_NAME
++++++++++++++++++

Defaults to: ``None``.

String of the storage name used by the ``AzureStorage`` backend.

AZURE_STORAGE_KEY
+++++++++++++++++

Defaults to: ``None``.

String of the storage key used by the ``AzureStorage`` backend.

AZURE_SAS_TOKEN
+++++++++++++++

Defaults to: ``None``.

String of SAS token to be used by the ``AzureStorage`` backend as a means of authenticating.
You should use SAS token OR storage key, not both.

DATABRICKS_HOSTNAME
+++++++++++++++++++

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

This option is mandatory when using the ``DatabricksExecutor``.

String hostname of the Databricks platform. For example "westeurope.azuredatabricks.net"

DATABRICKS_TOKEN
++++++++++++++++

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

This option is mandatory when using the ``DatabricksExecutor``.

String token used to authenticate with the Databricks platform.

DATABRICKS_RUN_NAME
+++++++++++++++++++

Defaults to: ``"Spark job"``

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

String label of a job that controls how it appears within the Databricks platform and dashboard.

DATABRICKS_SPARK_VERSION
++++++++++++++++++++++++

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

This option is mandatory when using the ``DatabricksExecutor``.

String label of which runtime that new Databricks clusters that get provisioned by the
executor should use. E.g. ``"5.5.x-cpu-ml-scala2.11"``.

DATABRICKS_SPARK_CONFIG
+++++++++++++++++++++++

Defaults to: ``{}``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Dictionary of a key value mapping containing the configuration that gets passed into
the Databricks Spark Config. See available properties in `PySpark Documentation <https://spark.apache.org/docs/2.1.0/configuration.html#available-properties>`_.

DATABRICKS_NODE_TYPE
++++++++++++++++++++

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

This option is mandatory when using the ``DatabricksExecutor``.

String label representing the node/instance type of each node in new clusters that get
provisioned by the Databricks executor. E.g. ``"Standard_DS3_v2"``.

DATABRICKS_DEFAULT_WORKERS
++++++++++++++++++++++++++

Defaults to: ``2``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Numeric value indicating how many workers that are provisioned in a new cluster if
the user do not specify a ``workers`` argument when running the DAG.

DATABRICKS_MAX_WORKERS
++++++++++++++++++++++

Defaults to: ``10``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Numeric value indicating the maximum number of workers that can be provisioned in a new
cluster using the ``workers`` argument when running the DAG.

This limit is here to prevent developers from accidentally setting up very large and
expensive clusters.

DATABRICKS_CUSTOM_TAGS
++++++++++++++++++++++

Defaults to: ``{}``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Dictionary of a key value mapping containing tag names and tag values that should
be tagged on the cluster that get provisioned by the Databricks executor. The tags
can be used to make it easier to identify clusters in the future.

DATABRICKS_ENV_VARS
+++++++++++++++++++

Defaults to: ``{}``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

Dictionary of a key value mapping containing environment variables that should be set
on the cluster that get provisioned by the Databricks executor.

DATABRICKS_REQUIREMENTS
+++++++++++++++++++++++

Defaults to: ``[]``.

.. warning::

    Deprecated, to be removed in v2.0.0. Recommendation is to interact with data in Spark using SQL rather than
    as PySpark DataFrames using readers such as ``PandasReader``.

List of Python dependencies that should be installed by ``pip`` as a "init script" on a newly
provisioned Databricks cluster.

Normally, any dependencies of your application should be bundled in the wheel itself and defined
in the ``setup.py`` file of your application, but there might be certain situations where you want
to install dependencies directly using a script explicitly.

GOOGLE_PROJECT
++++++++++++++

This option is mandatory when using ``GoogleStorage`` or ``BigQueryReader``.

The GCP project that you are using and where your infrastructure is provisioned. E.g. ``"my-gcp-project"``.

GOOGLE_LOCATION
+++++++++++++++

This option is mandatory when using ``GoogleStorage`` or ``BigQueryReader``.

The region where your Google Cloud Storage bucket are located. E.g. ``"EU"``.

GOOGLE_GCS_BUCKET
+++++++++++++++++

This option is mandatory when using ``GoogleStorage`` or ``BigQueryReader``.

The name of the Google Cloud Storage bucket that you are using for storage. E.g. ``"my-bucket"``.

GOOGLE_TEMP_PATH
++++++++++++++++

This option is mandatory when using ``GoogleStorage`` or ``BigQueryReader``.

The ``BigQueryReader`` backend is caching results on Google Cloud Storage, this option defines the temporary folder where results are cached. E.g. ``"tmp/"``.

GOOGLE_BIGQUERY_TMP_DATASET
+++++++++++++++++++++++++++

This option is mandatory when using ``GoogleStorage`` or ``BigQueryReader``.

When the ``BigQueryReader`` backend is reading data from BigQuery, it is storing results temporary in a custom BigQuery dataset, and then exporting that dataset as a file on Google Cloud Storage. This option defines the name of the dataset that holds the temporary data.

E.g. ``"my_dataset"``.

AWS_ACCESS_KEY_ID
+++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defines the access key used to authenticate to the S3 bucket.

AWS_SECRET_ACCESS_KEY
+++++++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defines the secret key used to authenticate to the S3 bucket.

AWS_STORAGE_BUCKET_NAME
+++++++++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defines the bucket name.

AWS_S3_REGION_NAME
++++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defines the region slug.

AWS_S3_ENDPOINT_URL
+++++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defines the S3 Endpoint URL.

AWS_IS_GZIPPED
++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Allows you to define if files will be .gzip compressed by default.

Defaults to ``False``.

AWS_S3_OBJECT_PARAMETERS
++++++++++++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defaults to ``{}``.

Allows you to define meta data and object parameters on the objects created on the bucket. Set to for example `{'CacheControl': 'max-age=86400'}` to enable HTTP cache headers on the files.

AWS_DEFAULT_ACL
+++++++++++++++

This option is mandatory when using ``S3Storage`` as ``STORAGE_BACKEND``.

Defaults to ``None``.

This setting defines the access rights to the objects created on the bucket. The default setting means that it will inherit the bucket's ACL option.

Set to for example `'public-read'` to enable public access.

AIRFLOW_CLIENT_ID
+++++++++++++++++

Defaults to: ``None``.

The airflow client ID is used by the Airflow API client to interact with DAG's on Airflow for actions such as triggering, pausing and deleting DAG's.

For more details of how to get the client ID on Google Cloud Platform, see the `GCP documentation <https://cloud.google.com/composer/docs/how-to/using/triggering-with-gcf#get_the_client_id_of_the_iam_proxy>`_.

Note that a client id is not required for deploying DAG's on Airflow. Only for REST API access.

AIRFLOW_DAG_PREFIX
++++++++++++++++++

Defaults to: ``None``.

String that act as a prefix to each dag name that is deployed to Airflow. This is useful if you are sharing Airflow across
use cases and you want to ensure that each use case is prefixed on each of its DAGs.

AIRFLOW_URI
+++++++++++

Defaults to: ``None``.

The base URL of the Airflow web service. This is used by the Airflow API client to format
the API endpoints that it should request when triggering, deleting and pausing DAG's.

Example of an AIRFLOW_URI could be ``https://airflow.appspot.com/``.

AIRFLOW_PRE_SCRIPT
++++++++++++++++++

Defaults to: ``None``.

The pre-script is a hook that allows you to inject bash commands to be executed before the task of each Kubernetes pod is called.

For example, you might want to add a ``cd app/`` as a pre-script before the ``python run.py task`` command is called.

AIRFLOW_KUBERNETES_AFFINITY
+++++++++++++++++++++++++++

Defaults to: ``None``.

This is a dictionary affinity configuration that can be added to each Kubernetes pod to customize on what nodes that your pods are scheduled.

See more about `Kubernetes Affinity <https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity>`_.

AIRFLOW_DEPLOY_DAGS
+++++++++++++++++++

Defaults to: ``[]``.

List of DAG classes that determines which DAG's that are deployed by the ``./run.py airflow deploy`` command when calling it on branch that is not ``develop`` or ``master``. This allows you to limit what DAG's that are deployed on feature branches to avoid deploying potentially dozens of DAG's every time you deploy a new branch.

AIRFLOW_STORAGE_BACKEND
+++++++++++++++++++++++

Defaults to: ``"oxygen.files.storages.local.LocalStorage"``.

Storage backend that determines how it will read/write DAG files to be loaded by Airflow. It is configured separately from the ``STORAGE_BACKEND`` setting to allow for custom storages for Airflow than the rest of the application.

This storage is used when using the ``./run.py airflow deploy`` command.

AIRFLOW_BUCKET
++++++++++++++

Defaults to: ``None``.

Storage bucket name used by ``AIRFLOW_STORAGE_BACKEND`` when uploading DAG files to Airflow. This bucket name is used when executing the ``./run.py airflow deploy`` command.

AIRFLOW_IMAGE
+++++++++++++

Defaults to: ``"application"``.

The Docker image name that Kubernetes is using when running Airflow tasks on Kubernetes.

PANDAS_DTYPE_BACKEND
++++++++++++++++++++

Defaults to: ``"numpy_nullable"``.

Allow to override which ``dtype_backend`` to use when using Pandas, this can be used to
switch to ``pyarrow`` for improved performance.
