Reference
=========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   settings.rst
