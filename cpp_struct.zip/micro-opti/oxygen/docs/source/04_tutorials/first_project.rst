.. _tutorial_first_project:

First Project
=============

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Writing your first Oxygen app
#############################

Let's learn by an example.

In this tutorial we will generate a new Oxygen project using the Oxygen CLI and start
building our first pipeline consisting of a ``DAG`` and a ``Task``.

We'll assume that [Oxygen is installed]({% link pages/introduction/install.md %}) already. You can tell
if Oxygen is installed by typing the following command in your terminal.

.. code-block::

    oxygen-cli.py --help


Creating a project
##################

By using the Oxygen CLI we can generate some initial scaffolding for our project by
typing the following command in the terminal.

.. code-block::

    oxygen-cli.py startproject promo


The ``startproject`` command will create a "promo" project and initiate it with entrypoint
of our application and some default settings to start out with. After executing the
command you should see a directory structure that look like the following.

.. code-block::

    promo/
    data/
        .gitkeep
    configs/
        __init__.py
        settings.py
        config.yaml
    run.py


These files are:

* The outer ``promo/`` folder is the container of our application. The name do not matter
  at all for Oxygen, you can rename it to whatever you want.
* The ``data/`` folder is the default location for where we store our data files.
* The ``data/.gitkeep`` file is an empty file that allow us to commit our data folder even
  though it does not contain any data files yet.
* The inner ``configs/`` folder is the container of application wide files such as our
  application settings and context configuration file.
* The ``configs/__init__.py`` file is an empty file that tell Python that our directory is
  to be considered as a python package.
* The ``configs/settings.py`` file is a python settings file that contain all of our application
  settings which will later be used from within our application during runtime.
* The ``configs/config.yaml`` file is a data science model configuration file in YAML format
  that allow the developer to specify parameters related to the execution of a model.
* The ``run.py`` file is the entrypoint to our application CLI.


Creating our first module
#########################

Now we already have a project. A project is just a collection of modules that together
make up our application. Without a module, our project do not offer much value.

To create your first module, write the following command from within your terminal using
the ``run.py`` file that we just created within our new project.

.. code-block::

    python run.py startmodule core


The ``startmodule`` command will now initiate a ``core`` folder from within our project.
This new folder will contain multiple files which are meant to contain the business logic
of our application. A project may contain one or many modules. It's up to the developer
how they want to structure their project.

After you execute the command you will have the following project structure:

.. code-block::

    promo/
    core/
        __init__.py
        commands.py
        dags.py
        schemas.py
        tasks.py
        tests.py
    data/
        .gitkeep
    promo/
        __init__.py
        settings.py
        config.yaml
    run.py


The files are:

* The ``core/`` folder is the container of our new module.
* The ``core/__init__.py`` file is an empty file that tell Python that our directory is
  to be considered as a python package.
* The ``core/commands.py`` file contains all commands that we want to add to our ``run.py`` CLI.
  Simply add any commands in here and they will automatically be available from within the CLI
  when you type ``python run.py --help``.
* The ``core/dags.py`` file contain our ``DAG`` definition. A ``DAG`` is a pipeline made up of multiple ``Task``
  definitions that we want to execute in a specific order.
* The ``core/schemas.py`` file contain our data schema definitions. A ``Schema`` is simply a specification
  of how we expect a file or a data source to look like in terms of columns, types, validations and constraints.
* The ``core/tasks.py`` file contain our ``Task`` defintion. A ``Task`` is part of a ``DAG`` and is an isolated part
  of our pipeline. The ``Task`` is the class that contain most of our business logic.
* The ``core/tests.py`` file is where we keep the unit tests for our module.

You can convert these files into Python packages by simply converting them into a
directory and placing a ``__init__.py`` file within it that in turn imports all the
objects that you want to be auto imported.

For example, you could spread your ``Task`` classes into multiple files with the
following structure:

.. code-block::

    core/
    ...
    tasks/
        __init__.py
        etl.py
        baseline.py


You are free to delete any file that you do not require in your module. These are just
initiation of the different parts that could make up a module. They are not mandatory.


Creating our file schema
########################

One of the most fundamental parts of any data science projects is the data itself.
Throughout almost every step of our pipeline, we are expected to read and write data
to and from files stored on some type of storage device -- either cloud or locally.

Reading and writing data is not as easy as it sounds. It comes with many pieces such as:

* Storage integration (e.g reading from AWS S3 or Azure Blob Storage)
* Renaming columns from source names to internal names.
* Validating data types.
* Validating column existance.
* Validating business constraints such as a value must be unique or not null.

The concept of ``Schema`` allow us to easily define the expected format of our data and automatically
enforce and abstract away these concepts so that we can write code that focus on Data Science
and less on the basic concepts of reading and writing files.

Let's create a simple schema for our pipeline. The schemas are by convention stored in
our ``schemas.py`` file located within the newly created ``core/`` module.

.. code-block::

    from oxygen.files.schemas import Schema, IntegerColumn, StringColumn, FloatColumn
    from oxygen.files.validators.pandas import NotNullValidator


    class ProductSchema(Schema):
        product_id = IntegerColumn(validators=[NotNullValidator()])
        name = StringColumn()
        price = FloatColumn()


This schema defines the expected format of our product data with the following constraints:

* Our data is expected to contain a ``product_id`` column containing numeric data.
* Our ``product_id`` column is automatically validating that the values are not null.
* Our data is expected to contain a ``name`` column containing text data.
* Our data is expected to contain a ``price`` column containing decimal numeric data.

Before we move on to the next section, let's make sure that we create a sample data file
that match the format of our schema so that we can later illustrate the usage of our schema.

Create a new file at ``data/products.csv`` with the following contents:

.. code-block::

    product_id,name,price
    1,Red Shirt,10.5
    2,Blue Shirt,14.9
    3,Green Shirt,13.2


Creating a Task for our pipeline
################################

As mentioned earlier, a pipeline is made up of a ``DAG`` which in turn is a collection of
``Task`` classes that execute in a perticular order. The ``Task`` is where most of our code
will reside in our data science projects since this is the container of each part of our
pipeline.

An example of what type of tasks you might have in a project would be:

* ETLTask
* CalculateBaselineTask
* CalculateUpliftTask
* OptimizerTask
* FormatOutputTask

Tasks are stored in the ``tasks.py`` file within our module. Just like in other cases, you
can convert this into a python package by creating a directory named ``tasks/`` with an
``__init__.py`` file within it and then splitting your actual tasks between multiple files.

Let's write our own ``SampleTask`` within our new ``core/tasks.py`` file that was generated
in an earlier step.

.. code-block::

    from oxygen.exec.task import Task
    from .schemas import ProductSchema


    class SampleTask(Task):

        def run(self):
            # Load our data.
            df = ProductSchema.load("products.csv", root=True)
            # Print our data.
            print(df.head())
            # Save our data.
            ProductSchema.save("products.parquet", df, root=True)


Our very minimal and simple task can be described by the following:

* Any task inherits from the ``Task`` class which defines the interface of how a ``Task``
  is executed.
* The ``SampleTask.run()`` function is the entrypoint of our task. Note that a ``Task`` do not
  accept any in-memory kwargs being passed into it from other tasks. Each task is completely
  isolated from each other and do not directly depend on anything being passed from one task
  to another.
* We use the ``ProductSchema`` that we defined in a previous step to read in the ``products.csv``
  data that we created. Note that we do not need to include the ``data/`` folder in our path.
* Our ``ProductSchema.load()`` function returns a Pandas DataFrame. The load function automatically
  validates that the data follows the expected schema. If your data is incorrect you would see
  an ``ValidationError`` being raised.
* Our ``ProductSchema.save()`` function saves our DataFrame to disk. The save function automatically
  validates that the DataFrame contains the correct data format according to the schema before it
  saves the data to disk.

All that is required from a ``Task`` is that it uses the ``run()`` function as the entrypoint of
the execution. The rest of the structure is up to the developer and Oxygen is not opinionated
about it.

You could split your code across multiple files and classes, you could store each task in
its own folder, or you could store all your tasks in the same file. As long as you make all
tasks available from the ``tasks`` python package of your module, they will automatically be
imported and discovered by Oxygen.


Define our pipeline using a DAG
###############################

Once again as repeated in previous sections of this tutorial, a Pipeline in Oxygen is
made up of multiple ``Task`` classes that are defined within a ``DAG``. To complete our first
pipeline we must therefore define our ``DAG`` before we can execute it.

DAG's are stored within a modules ``dags.py``. They must be discoverable within a modules
``dags`` python package for the CLI to be able to autoload and discover them. This means that
you can also create a ``dags/`` directory with an ``__init__.py`` file and split your ``DAG``
classes across multiple files if you wanted to.

Let's create a simple ``DAG`` that use our newly created ``SampleTask`` within it.

.. code-block::

    from oxygen.exec.dag import DAG
    from .tasks import SampleTask


    class SampleDAG(DAG):
        label = "sample"
        tasks = [SampleTask]


This small, simple class is a pretty good representation of how mosts ``DAG`` look like.
Since the business logic of our pipeline are within ``Task`` classes, the ``DAG`` becomes
fairly simple classes work as containers and defintions of our pipeline more than some
kind of custom logic.

Our ``SampleDAG`` class above can be described in the following manner:

* It uses the ``DAG`` base class which defines the interface of how a ``DAG`` is executed
  when triggered.
* We define a label which sets how we will refer to our ``DAG`` from within the CLI. If
  a label is not defined, it will use the lowercase class name as a label by default. Labels
  must be unique.
* We define a list of ``Task`` classes that we want to execute from top to bottom. In this
  case we add our ``SampleTask`` that we created in an earlier step.

That's it! We have now created our first ``DAG`` that will execute our ``SampleTask`` whenever
it is executed.


Running our pipeline
####################

Before we can run our pipeline, we must tell our project that we have added a new ``core``
module, so that our project can automatically discover our ``DAG`` and ``Task`` definitions
that we have created and make them available to call from our CLI.

Do you remember when we created our project, that it also generated a ``settings.py`` file?
This file contains our application settings including which modules that we should automatically
load and discover.

This is set in the ``INSTALLED_MODULES`` setting.

To install our ``core`` module, simply add its dotted python path to the ``INSTALLED_MODULES`` list
like the following:

.. code-block::

    INSTALLED_MODULES = [
        "core",
    ]


Voila! You can now call your ``SampleDAG`` from the ``run.py`` CLI using the ``dag`` command and
your ``SampleDAG`` label that we set to ``sample``.

.. code-block::

    python run.py dag sample


You should now see the following output in your terminal:

.. code-block::

    $ python run.py dag sample
    product_id         name  price
    0           1    Red Shirt   10.5
    1           2   Blue Shirt   14.9
    2           3  Green Shirt   13.2
