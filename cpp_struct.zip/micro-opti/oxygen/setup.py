from setuptools import find_packages, setup

import oxygen


def get_dependencies(path):
    with open(path, encoding="utf-8") as f:
        return f.read().splitlines()


base_deps = get_dependencies("requirements/base.txt")
azure_deps = get_dependencies("requirements/azure.txt")
aws_deps = get_dependencies("requirements/aws.txt")
databricks_deps = get_dependencies("requirements/databricks.txt")
google_deps = get_dependencies("requirements/google.txt")
pandas_deps = get_dependencies("requirements/pandas.txt")
spark_deps = get_dependencies("requirements/spark.txt")

setup(
    name="Oxygen",
    version=oxygen.VERSION,
    scripts=["oxygen/bin/oxygen-cli.py"],
    packages=find_packages(),
    install_requires=base_deps + pandas_deps,
    include_package_data=True,
    extras_require={
        # can be installed by pip install oxygen[spark]
        "azure": base_deps + azure_deps,
        "aws": base_deps + aws_deps,
        "google": base_deps + google_deps,
        "pandas": base_deps + pandas_deps,
        "spark": base_deps + spark_deps,
        "databricks": base_deps + databricks_deps,
        "all": (
            base_deps
            + pandas_deps
            + spark_deps
            + azure_deps
            + databricks_deps
            + google_deps
            + aws_deps
        ),
    },
)
