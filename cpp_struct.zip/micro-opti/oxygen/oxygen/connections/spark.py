import os

from pyspark.conf import SparkConf
from pyspark.sql import SparkSession

from oxygen.conf.settings import settings
from oxygen.utils.loading import LazyObject


def _spark_connection() -> SparkSession:
    """Instantiate the session to connect to our Spark Cluster.

    The connection itself takes a while to initiate, therefor we
    handle the spark connection as a lazily evaluated object so
    that it can be imported and passed around freely without
    slowing down the code.

    """
    spark_config = SparkConf()
    for key, value in getattr(settings, "SPARK_CONFIG", {}).items():
        spark_config.set(key, value)

    spark_instance = (
        SparkSession.builder.config(conf=spark_config)
        .appName(os.getenv("APP_NAME", "default"))
        .getOrCreate()
    )

    return spark_instance


spark = LazyObject(_spark_connection)
