import logging.config
from importlib import import_module

from oxygen.conf.settings import settings


def bootstrap():
    """Preload modules defined in INSTALLED_MODULES"""
    if hasattr(settings, "LOGGING"):
        logging.config.dictConfig(settings.LOGGING)

    tasks_modules = getattr(settings, "TASK_MODULES", ["tasks"])
    dag_modules = getattr(settings, "DAG_MODULES", ["dags"])
    command_modules = getattr(settings, "COMMAND_MODULES", ["commands"])

    for module in settings.INSTALLED_MODULES:
        all_modules = tasks_modules + dag_modules + command_modules
        all_modules_path = [f"{module}.{pkg}" for pkg in all_modules]

        for pkg_path in all_modules_path:
            try:
                import_module(pkg_path)
            except ModuleNotFoundError as ex:
                # Only skip raising the error if it was
                # the attempted module path that failed to load,
                # and not a nested import from within that module.
                if pkg_path in str(ex.msg):
                    continue

                raise
