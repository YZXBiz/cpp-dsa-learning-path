from oxygen.conf.settings import settings
from oxygen.utils.loading import LazyObject, import_string

# pylint: disable=unnecessary-lambda
storage = LazyObject(lambda: import_string(settings.STORAGE_BACKEND)())
