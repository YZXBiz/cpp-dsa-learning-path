import os
from io import BytesIO, StringIO
from pathlib import Path
from typing import Optional, Union
from urllib.parse import urlparse

from oxygen.conf.settings import settings


class Storage:
    is_remote = False

    # pylint: disable=W0613
    def __init__(self, *args, **kwargs) -> None:
        super().__init__()
        if "storage_root" in kwargs and kwargs["storage_root"] is not None:
            self.storage_root = kwargs["storage_root"]
        else:
            self.storage_root = settings.STORAGE_ROOT

    def open(self, file_path: str, mode="rb"):
        """Open a file to read it"""
        raise NotImplementedError()

    def url(self, file_path):
        """Get public url to file"""
        raise NotImplementedError()

    def abspath(self, path):
        """Get absolute path to file"""
        if os.name == "nt":
            # If we're on Windows, we need to be careful what the heck the path is
            if path[1] == ":":
                # This is a drive letter followed by a colon, so it's really a file
                path = f"file://{path}"
            urlpath = urlparse(path)

            if urlpath.scheme == "file":
                # We're a file path, so our netloc is the directory
                path = urlpath.netloc
            else:
                # Can this scenario actually occur?
                path = urlpath.path

        else:
            # Not on Windows, so we can proceed much easier
            path = urlparse(path).path
            path = "" if path == "/" else path

        ends_in_slash = path.endswith(os.path.sep)
        if not path.startswith(self.storage_root):
            path = str(Path(self.storage_root) / path.lstrip("/"))

        # Enforce keeping same ending /.
        if ends_in_slash:
            path = f"{path.rstrip(os.path.sep)}{os.path.sep}"
        return path

    def relpath(self, path):
        """Get relative path to STORAGE_ROOT"""
        if os.name == "nt":
            return str(Path(path).relative_to(settings.BASE_DIR))

        # Default code is for Linux
        return str(
            Path(f"{os.path.sep}{path.lstrip(os.path.sep)}").relative_to(
                self.storage_root or "/"  # In case STORAGE_ROOT is ""
            )
        )

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Create a new file"""
        raise NotImplementedError()

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Copy a file from local storage to Storage Class storage"""
        raise NotImplementedError()

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file"""
        raise NotImplementedError()

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory"""
        raise NotImplementedError()

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Args:
            dir_path: Path of directory to list contents of.

        Returns:
            Tuple: 2 value tuple that consist of
                   List of Subdirectories and
                   List of Files.

        """
        raise NotImplementedError()

    def isfile(self, file_path: str) -> bool:
        """Check if file_path is actually a file"""
        raise NotImplementedError()

    def isdir(self, dir_path: str) -> bool:
        """Check if dir_path is actually a directory"""
        raise NotImplementedError()

    def exists(self, path: str) -> bool:
        """Check if path actually exists"""
        raise NotImplementedError()
