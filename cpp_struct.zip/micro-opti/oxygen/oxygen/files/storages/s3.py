import logging
import mimetypes
import os
from io import BytesIO, StringIO
from pathlib import Path
from typing import Optional, Union
from urllib.parse import urlparse

import boto3
from botocore.client import Config
from botocore.exceptions import ClientError

from oxygen.conf.settings import settings

from .base import Storage

logger = logging.getLogger(__name__)


class S3Storage(Storage):
    is_remote = True
    MAX_CHUNK_SIZE = 32_000_000

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._connection = None
        self._bucket = None
        self.region_name = settings.AWS_S3_REGION_NAME
        self.use_ssl = True
        self.endpoint_url = settings.AWS_S3_ENDPOINT_URL
        self.config = Config(
            s3={"addressing_style": None},
            signature_version=None,
            proxies=None,
        )
        self.verify = True
        self.default_content_type = "application/octet-stream"
        self.get_object_parameters = settings.AWS_S3_OBJECT_PARAMETERS
        self.default_acl = settings.AWS_DEFAULT_ACL
        self.access_key, self.secret_key = (
            settings.AWS_ACCESS_KEY_ID,
            settings.AWS_SECRET_ACCESS_KEY,
        )
        self.storage_root = settings.STORAGE_ROOT.lstrip("/")

    @property
    def connection(self):
        if self._connection is None:
            session = boto3.session.Session()
            self._connection = session.resource(
                "s3",
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region_name,
                use_ssl=self.use_ssl,
                endpoint_url=self.endpoint_url,
                config=self.config,
                verify=self.verify,
            )

        return self._connection

    @property
    def bucket(self):
        if self._bucket is None:
            self._bucket = self.connection.Bucket(settings.AWS_STORAGE_BUCKET_NAME)
        return self._bucket

    def _get_write_params(self, file_path):
        params = {}
        _type, encoding = mimetypes.guess_type(file_path)
        content_type = _type or self.default_content_type
        params["ContentType"] = content_type
        if encoding:
            params["ContentEncoding"] = encoding

        if "ACL" not in params and self.default_acl:
            params["ACL"] = self.default_acl

        return params

    def relpath(self, path):
        """Get relative path to STORAGE_ROOT"""
        if not path.startswith(self.storage_root):
            return path

        return str(Path(path).relative_to(self.storage_root)) + (
            "/" if path.endswith("/") else ""
        )

    def abspath(self, path):
        """Get absolute path to file"""
        path = urlparse(path).path.lstrip("/")

        if not path.startswith(self.storage_root):
            path = os.path.join(self.storage_root, path.lstrip("/"))
        return path

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Save file to disk"""
        if isinstance(content, StringIO):
            content = self._to_bytes(content)
        obj = self.bucket.Object(self.abspath(file_path))
        content.seek(0, os.SEEK_SET)
        obj.upload_fileobj(
            content, ExtraArgs=self._get_write_params(self.abspath(file_path))
        )

    def open(self, file_path, mode="r") -> Union[StringIO, BytesIO]:
        """Opens a file and return a StringIO object with its contents"""
        file_path = self.abspath(file_path)
        obj = self.bucket.Object(file_path)
        handler = BytesIO()
        try:
            obj.download_fileobj(handler)
        except ClientError as exc:
            raise FileNotFoundError(f"File '{file_path}' not found.") from exc
        handler.seek(0, os.SEEK_SET)
        if "b" not in mode:
            return StringIO(handler.read().decode("utf-8"))
        return handler

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
        verbose: bool = True,
    ) -> None:
        """Copy a file or a directory"""
        if verbose:
            logger.debug("%s -> %s", src_path, dest_path)
        if not self.exists(src_path):
            raise FileNotFoundError(f"File at {src_path} not found.")
        if self.exists(dest_path) and not overwrite:
            raise FileExistsError(f"A file already exists at '{dest_path}'")
        if self.isfile(src_path):
            # If src is a file, it is very straight forward, we simply
            # copy the file.
            with self.open(src_path, mode="rb") as stream:
                self.touch(dest_path, stream)
        elif self.isdir(src_path):
            # If src is a dir, we recursively call self.cp() on all dirs
            # and files within.
            dirs, files = self.listdir(src_path)
            if dirs and not recursive:
                raise FileExistsError(
                    f"Path '{src_path}' contains directories but recursive is not set."
                )

            paths = dirs + files
            for path in paths:
                self.cp(
                    path,
                    str(
                        Path(dest_path.lstrip("/"))
                        / str(Path(path).relative_to(src_path.lstrip("/"))).lstrip("/")
                    ),
                    recursive=recursive,
                    overwrite=overwrite,
                )
        else:
            # Something must have gone horrible wrong with the file system
            # if we cannot identify if the path is a file or dir. This might
            # happen if the Google SDK/API implementation is incorrect.
            raise ValueError(f"Path '{src_path}' is neither a directory or a file.")

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file"""
        if self.isdir(file_path):
            dirs, files = self.listdir(file_path)
            if (dirs or files) and not recursive:
                raise FileExistsError(
                    "Option `recursive` must be set to delete directories "
                    "with existing files in it."
                )
            for item in dirs + files:
                self.rm(item, recursive=recursive)
            if file_path not in {".", ""}:
                try:
                    self.bucket.Object(self.abspath(file_path)).delete()
                except ClientError:
                    logger.warning("Failed to delete file at path '%s'", file_path)
        else:
            try:
                self.bucket.Object(self.abspath(file_path)).delete()
            except ClientError:
                logger.warning("Failed to delete file at path '%s'", file_path)

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory"""
        if mode is not None:
            logger.warning("`mode` is not used for `{self.__class__.__name__}`")

        # Ensure dir ends with /
        dir_path = f"{dir_path}/" if not dir_path.endswith("/") else dir_path

        if self.exists(dir_path):
            logger.warning("Directory '%s' already exists.", dir_path)
            return

        parent = os.path.dirname(dir_path.rstrip("/"))
        if parent and not self.exists(parent) and not make_parents:
            raise FileNotFoundError(
                f"Parent directory '{parent}' does not exist. "
                f"Use option `make_parents` to automatically create parent directories."
            )

        self.connection.meta.client.put_object(
            Bucket=settings.AWS_STORAGE_BUCKET_NAME,
            Key=self.abspath(dir_path).rstrip("/") + "/",
        )

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Args:
            dir_path: Path of directory to list contents of.

        Returns:
            Tuple: 2 value tuple that consist of
                   List of Subdirectories and
                   List of Files.

        """
        dir_path = "" if dir_path == "." else dir_path
        return self._list_objects(dir_path)

    def isfile(self, file_path: str) -> bool:
        """Check if file_path is actually a file"""
        return self._exists(file_path) and not file_path.endswith("/")

    def isdir(self, dir_path: str) -> bool:
        """Check if dir_path is actually a directory"""
        if dir_path == ".":
            return True

        dir_path = self.abspath(dir_path).rstrip("/") + "/"
        if self._exists(dir_path):
            return True

        dirs, files = self._list_objects(dir_path, config={"MaxItems": 1})
        return bool(dirs or files)

    def exists(self, path):
        return self.isfile(path) or self.isdir(path)

    def _list_objects(self, path, config=None):
        config = config or {}
        dirs, files = [], []
        dir_path = self.abspath(path)
        if dir_path and not dir_path.endswith("/"):
            dir_path += "/"
        paginator = self.connection.meta.client.get_paginator("list_objects")
        pages = paginator.paginate(
            Bucket=settings.AWS_STORAGE_BUCKET_NAME,
            Delimiter="/",
            Prefix=self.abspath(dir_path),
            PaginationConfig=config,
        )
        for page in pages:
            for entry in page.get("CommonPrefixes", ()):
                if self.abspath(self.relpath(entry["Prefix"])) == dir_path:
                    continue
                dirs.append(f"{self.relpath(entry['Prefix']).rstrip('/')}/")
            for entry in page.get("Contents", ()):
                if self.abspath(self.relpath(entry["Key"])) == dir_path:
                    continue
                files.append(self.relpath(entry["Key"]))
        return dirs, files

    def _exists(self, path):
        try:
            self.connection.meta.client.head_object(
                Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=self.abspath(path)
            )
            return True
        except ClientError:
            return False

    def _to_bytes(self, content: StringIO):
        """Write a StringIO stream to BytesIO"""
        io = BytesIO()
        while True:
            chunk = content.read(self.MAX_CHUNK_SIZE)
            if not chunk:
                break

            io.write(bytes(chunk.encode("utf-8")))

        io.seek(0)
        return io

    def url(self, file_path):
        """Get public url to file"""
        raise NotImplementedError()
