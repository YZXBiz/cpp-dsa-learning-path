import logging
from datetime import datetime, timedelta
from io import BytesIO, StringIO
from pathlib import Path
from typing import Optional, Union

from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import (
    BlobClient,
    BlobSasPermissions,
    BlobServiceClient,
    generate_blob_sas,
)

from oxygen.conf.settings import settings

from .base import Storage

logger = logging.getLogger(__name__)


class AzureStorage(Storage):
    is_remote = True

    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._client = None
        self._service_client = None
        self.timeout = 30
        self.storage_hostname = kwargs.get("storage_hostname", None)
        self.azure_storage_name = kwargs.get("azure_storage_name", None)
        self.access_key = kwargs.get("access_key", None)
        self.sas_token = kwargs.get("sas_token", None)
        self.azure_storage_container = kwargs.get("azure_storage_container", None)

        if not self.azure_storage_name:
            self.azure_storage_name = settings.AZURE_STORAGE_NAME
        if not (self.access_key or self.sas_token):
            self.access_key = getattr(settings, "AZURE_STORAGE_KEY", None)
        if not (self.access_key or self.sas_token):
            self.sas_token = getattr(settings, "AZURE_SAS_TOKEN", None)
        if not self.azure_storage_container:
            self.azure_storage_container = settings.AZURE_STORAGE_CONTAINER

        assert (
            self.access_key or self.sas_token
        ), "Either 'AZURE_STORAGE_KEY' or 'AZURE_SAS_TOKEN' must be set."
        assert not (
            self.access_key and self.sas_token
        ), "Either 'AZURE_STORAGE_KEY' or 'AZURE_SAS_TOKEN' must be set, not both."
        self.storage_root = settings.STORAGE_ROOT.lstrip("/")

    @property
    def service_client(self):
        if not self._service_client:
            account_domain = "blob.core.windows.net"
            account_url = f"https://{self.azure_storage_name}.{account_domain}"
            if self.access_key:
                credential = self.access_key
            elif self.sas_token:
                credential = self.sas_token
            else:
                raise ValueError("Credentials must be set.")

            self._service_client = BlobServiceClient(account_url, credential=credential)

        return self._service_client

    @property
    def client(self):
        if not self._client:
            self._client = self.service_client.get_container_client(
                self.azure_storage_container
            )

        return self._client

    def relpath(self, path):
        """Get relative path to STORAGE_ROOT"""
        if not path.startswith(self.storage_root):
            return path

        return str(Path(path).relative_to(self.storage_root)) + (
            "/" if path.endswith("/") else ""
        )

    def abspath(self, path: str):
        """Remove preceding slashes in absolute path"""
        return super().abspath(path).lstrip("/")

    def open(self, file_path: str, mode: Optional[str] = None):
        """Open a file to stream"""
        file = BytesIO()
        stream = self.client.download_blob(
            self.abspath(file_path), timeout=self.timeout
        )
        stream.download_to_stream(file)
        file.seek(0)
        return file

    def url(self, file_path: str) -> str:
        """Generate a URL to file that can be used for remote services"""
        # Default to 7 days expiration time.
        expire_at = datetime.utcnow() + timedelta(
            seconds=settings.AZURE_EXPIRE_SECONDS or (60 * 60 * 24 * 7)
        )

        # For private blobs we must generate and append a SAS token to
        # the URL to ensure that the blob is readable in the browser.
        sas_token = generate_blob_sas(
            self.azure_storage_name,
            self.azure_storage_container,
            file_path,
            account_key=self.access_key,
            permission=BlobSasPermissions(read=True),
            expiry=expire_at,
        )

        container_blob_url = self.client.get_blob_client(file_path).url
        return BlobClient.from_blob_url(container_blob_url, credential=sas_token).url

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory.

        The Azure Blob Service only allow us to create blobs (files).
        Because of this, we have to "hack" our way to create a directory
        by first creating an empty blob and then deleting it.

        """
        if mode is not None:
            logger.warning("`mode` is not used for `{self.__class__.__name__}`")

        temp_file_name = str(Path(self.abspath(dir_path)) / ".empty")
        self.touch(temp_file_name, StringIO(""))
        self.rm(temp_file_name)

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Create a new file"""
        content.seek(0)
        if isinstance(content, StringIO):
            # Convert to bytes.
            content = BytesIO(content.read().encode("utf-8"))

        self.client.upload_blob(
            self.abspath(file_path), content, overwrite=True, timeout=self.timeout
        )

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file"""
        if self.isdir(file_path) and not recursive:
            dirs, files = self.listdir(file_path)
            if dirs or files:
                raise FileExistsError(
                    "Must use recursive flag to delete dir with existing files in it."
                )

        self.client.delete_blob(self.abspath(file_path), timeout=self.timeout)

    def isfile(self, file_path: str) -> bool:
        """Check if file_path is actually a file"""
        return (
            self.exists(file_path)
            and (Path(file_path).suffix) != ""
            and not bool(self._list_all(file_path, num_results=1))
        )

    def isdir(self, dir_path: str) -> bool:
        """Check if dir_path is actually a directory"""
        if dir_path == ".":
            return True

        if not self.exists(dir_path):
            return False

        blobs = self._list_all(dir_path, num_results=1)

        return bool(blobs)

    def exists(self, path) -> bool:
        """Check if a file or directory exists"""
        blob_client = self.client.get_blob_client(self.abspath(path))
        try:
            blob_client.get_blob_properties()
            return True
        except ResourceNotFoundError:
            return False

    def _list_all(self, dir_path, num_results=None):
        if dir_path and not dir_path.endswith("/"):
            dir_path += "/"

        blobs = [
            b.name
            for b in self.client.list_blobs(
                name_starts_with=self.abspath(dir_path),
                maxresults=num_results,
            )
        ]

        # Ensure that returned blobs do not contain the current folder.
        return list(
            filter(
                lambda x: self.abspath(x) != self.abspath(dir_path.rstrip("/")), blobs
            )
        )

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Values returned are paths to dirs or files relative
        to the STORAGE_ROOT.

        Returns:
            Tuple: 2 value tuple that consist of
                    List of Subdirectories and
                    List of Files.

        """
        files: list[str] = []
        dirs: set[str] = set()

        if dir_path and not dir_path.endswith("/"):
            dir_path += "/"

        blobs = self._list_all(dir_path)
        for name in blobs:
            dir_length = len(self.abspath(dir_path))
            n = self.abspath(name)[dir_length:].lstrip("/")
            # If the path after the requested path includes a /, its a subdir or a blob
            # that resides within a subdir, so get the subdir name and add it.
            if "/" in n:
                dir_name = self.relpath(
                    str(Path(self.abspath(dir_path)) / n.split("/", 1)[0])
                )
                if dir_name != dir_path:
                    dirs.add(dir_name)
            # Else its a blob that resides within the current directory.
            else:
                file_name = self.relpath(str(Path(self.abspath(dir_path)) / n))
                if self.abspath(file_name) != self.abspath(dir_path):
                    files.append(file_name)

        return list(dirs), list(filter(lambda x: x not in dirs, files))

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Copy a file or a directory"""
        if not self.exists(src_path):
            raise FileNotFoundError(f"File at {src_path} not found.")
        if self.exists(dest_path) and not overwrite:
            raise FileExistsError(f"A file already exists at '{dest_path}'")

        if self.isfile(src_path):
            # If src is a file, it is very straight forward, we simply
            # copy the file.
            with self.open(src_path) as stream:
                self.touch(dest_path, stream)
        elif self.isdir(src_path):
            # If src is a dir, we recursively call self.cp() on all dirs
            # and files within.
            dirs, files = self.listdir(src_path)
            if dirs and not recursive:
                raise FileExistsError(
                    f"Path '{src_path}' contains directories but recursive is not set."
                )

            paths = dirs + files
            for path in paths:
                self.cp(
                    path,
                    str(Path(dest_path) / path.replace(src_path, "").lstrip("/")),
                    recursive=recursive,
                    overwrite=overwrite,
                )
        else:
            # Something must have gone horrible wrong with the file system
            # if we cannot identify if the path is a file or dir. This might
            # happen if the Azure SDK/API implementation is incorrect.
            raise ValueError(f"Path '{src_path}' is neither a directory or a file.")

    def get_blob_metadata(self, file_path: str):
        blob_client = self.client.get_blob_client(self.abspath(file_path))
        return blob_client.get_blob_properties()
