import os
from io import BytesIO, StringIO
from pathlib import Path
from typing import Optional, Union
from urllib.parse import urlparse

from oxygen.conf.settings import settings

from .base import Storage


class LocalStorage(Storage):
    def open(self, file_path: str, mode="rb"):
        """Open a file to stream"""
        return open(
            self.abspath(file_path),
            mode=mode,
            encoding="utf-8" if "b" not in mode else None,
        )

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Create a new file"""
        content.seek(0)
        self.mkdir(os.path.dirname(file_path), make_parents=True)
        mode = "w" if isinstance(content, StringIO) else "wb"
        with open(
            self.abspath(file_path),
            mode=mode,
            encoding="utf-8" if "b" not in mode else None,
        ) as f:
            while True:
                chunk = content.read(256_000_000)  # 256 MB Chunks.
                if not chunk:
                    break
                f.write(chunk)

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file"""
        if not self.exists(file_path):
            return

        if self.isdir(file_path) and not recursive:
            dirs, files = self.listdir(file_path)
            if dirs or files:
                raise FileExistsError(
                    "Must use recursive flag to delete dir with existing files in it."
                )

        if self.isfile(file_path):
            os.remove(self.abspath(file_path))
        elif self.isdir(file_path):
            os.rmdir(self.abspath(file_path))
        else:
            raise ValueError(f"Path '{file_path}' is neither a file or a directory.")

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory"""
        # Unset the current process umask while we
        # create directories to mirror bash mkdir behavior.
        original_mask = os.umask(0)
        mode = mode or 0o777
        try:
            if make_parents:
                os.makedirs(self.abspath(dir_path), mode=mode, exist_ok=True)
            else:
                try:
                    os.mkdir(self.abspath(dir_path))
                except FileNotFoundError as exc:
                    raise FileNotFoundError(
                        f"No such file or directory: '{self.abspath(dir_path)}'. "
                        f"Use make_parents=True if you want to create missing parents."
                    ) from exc
                except FileExistsError:
                    # It is OK that dir already exists, just
                    # silence it.
                    pass
        finally:
            os.umask(original_mask)

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Args:
            dir_path: Path of directory to list contents of.

        Returns:
            Tuple: 2 value tuple that consist of
                   List of Subdirectories and
                   List of Files.

        """
        files = []
        dirs = []

        for entry in os.listdir(self.abspath(dir_path)):
            entry_path = str(Path(self.abspath(dir_path)) / entry)
            # Ignore hidden files.
            if entry.startswith("."):
                continue

            if os.path.isfile(entry_path):
                files.append(self.relpath(entry_path))
            elif os.path.isdir(entry_path):
                dirs.append(self.relpath(entry_path))

        return dirs, files

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Copy a file or a directory"""
        if not self.exists(src_path):
            raise FileNotFoundError(f"File at {src_path} not found.")
        if self.exists(dest_path) and not overwrite:
            raise FileExistsError(f"A file already exists at '{dest_path}'")

        if self.isfile(src_path):
            # If src is a file, it is very straight forward, we simply
            # copy the file.
            with self.open(src_path) as stream:
                self.touch(dest_path, stream)
        elif self.isdir(src_path):
            # If src is a dir, we recursively call self.cp() on all dirs
            # and files within.
            dirs, files = self.listdir(src_path)
            if dirs and not recursive:
                raise FileExistsError(
                    f"Path '{src_path}' contains directories but recursive is not set."
                )

            paths = dirs + files
            for path in paths:
                self.cp(
                    path,
                    str(Path(dest_path) / path.replace(src_path, "").lstrip("/")),
                    recursive=recursive,
                    overwrite=overwrite,
                )
        else:
            # Something must have gone horrible wrong with the file system
            # if we cannot identify if the path is a file or dir. This
            # should not happen on LocalStorage.
            raise ValueError(f"Path '{src_path}' is neither a directory or a file.")

    def isfile(self, file_path: str) -> bool:
        """Check if file_path is actually a file"""
        return os.path.isfile(self.abspath(file_path))

    def isdir(self, dir_path: str) -> bool:
        """Check if dir_path is actually a directory"""
        return os.path.isdir(self.abspath(dir_path))

    def exists(self, path) -> bool:
        """Check if path actually exists"""
        return os.path.exists(self.abspath(path))

    def url(self, file_path):
        """Get public url to file"""
        raise NotImplementedError()


class RepoReadOnlyStorage(LocalStorage):
    """
    A local storage that points to the repository codebase.
    Can only be used in read only mode, and is recommended to e.g read configurations
    stored with the codebase.
    """

    def abspath(self, path):
        """Get absolute path to file"""

        if os.name == "nt":
            # If we're on Windows, we need to be careful what the heck the path is
            if path[1] == ":":
                # This is a drive letter followed by a colon, so it's really a file
                path = f"file://{path}"

            urlpath = urlparse(path)

            if urlpath.scheme == "file":
                # We're a file path, so our netloc is the directory
                path = urlpath.netloc
            else:
                # Can this scenario actually occur?
                path = urlpath.path

        else:
            # Not on Windows, so we can proceed much easier
            path = urlparse(path).path
            path = "" if path == "/" else path

        if not path.startswith(settings.BASE_DIR):
            path = str(Path(settings.BASE_DIR) / path.lstrip(os.path.sep))

        return path

    def relpath(self, path):
        """Get relative path to BASE_DIR"""

        if os.name == "nt":
            return str(Path(path).relative_to(settings.BASE_DIR))

        # Default code is for Linux
        return str(
            Path(f"{os.path.sep}{path.lstrip(os.path.sep)}").relative_to(
                settings.BASE_DIR
            )
        )

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        raise NotImplementedError("Unauthorized operation on repository storage.")

    def rm(self, file_path: str, recursive: bool = False) -> None:
        raise NotImplementedError("Unauthorized operation on repository storage.")

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        raise NotImplementedError("Unauthorized operation on repository storage.")

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        raise NotImplementedError("Unauthorized operation on repository storage.")

    def url(self, file_path):
        """Get public url to file"""
        raise NotImplementedError()
