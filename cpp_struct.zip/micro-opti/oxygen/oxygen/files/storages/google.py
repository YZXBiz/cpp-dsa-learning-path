import logging
import os
from io import BytesIO, StringIO
from pathlib import Path
from typing import Optional, Union
from urllib.parse import urlparse

from google.api_core.exceptions import NotFound as GoogleNotFound
from google.cloud import storage

from oxygen.conf.settings import settings
from oxygen.files.storages.base import Storage

logger = logging.getLogger(__name__)


class GoogleStorage(Storage):
    """Storage Backend that enables connectivity to Google Cloud Storage"""

    is_remote = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        bucket_name = kwargs.pop("bucket_name", None)
        ignore_root = kwargs.pop("ignore_root", False)
        if not bucket_name:
            bucket_name = getattr(settings, "GOOGLE_GCS_BUCKET", None)
        assert (
            bucket_name is not None
        ), "GOOGLE_GCS_BUCKET setting must be set when using GoogleStorage."
        self._client = storage.Client()
        self._bucket = self._client.bucket(bucket_name)
        self.ignore_root = ignore_root
        self.storage_root = settings.STORAGE_ROOT.lstrip("/")

    def relpath(self, path):
        """Get relative path to STORAGE_ROOT"""
        if not path.startswith(self.storage_root):
            return path

        return str(Path(path).relative_to(self.storage_root)) + (
            "/" if path.endswith("/") else ""
        )

    def abspath(self, path):
        """Get absolute path to file"""
        path = urlparse(path).path.lstrip("/")

        if not path.startswith(self.storage_root):
            path = os.path.join(self.storage_root, path.lstrip("/"))
        return path

    def open(self, file_path, mode="rb"):
        """Open a file and loead it into a BytesIO file like object"""
        if mode != "rb":
            logger.warning("`mode` is not used for `{self.__class__.__name__}`")

        file_obj = BytesIO()
        try:
            self._bucket.blob(self.abspath(file_path)).download_to_file(file_obj)
        except GoogleNotFound as exc:
            raise FileNotFoundError(
                f'File "{self.abspath(file_path)}" does not exist.'
            ) from exc
        file_obj.seek(0)
        return file_obj

    def url(self, file_path):
        return (
            "https://console.cloud.google.com/storage/browser/"
            f"{self._bucket.name}/{self.abspath(file_path)}"
        )

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Creates a file from a file like object"""
        assert not file_path.endswith("/"), "File names cannot end with '/'."
        # Always ensure file pointer is reset.
        content.seek(0)
        # Convert to bytes.
        if isinstance(content, StringIO):
            content = BytesIO(content.read().encode("utf-8"))

        self._bucket.blob(self.abspath(file_path)).upload_from_file(content)

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Copy a file or a directory"""
        if not self.exists(src_path):
            raise FileNotFoundError(f"File at {src_path} not found.")
        if self.exists(dest_path) and not overwrite:
            raise FileExistsError(f"A file already exists at '{dest_path}'")

        if self.isfile(src_path):
            # If src is a file, it is very straight forward, we simply
            # copy the file.
            with self.open(src_path) as stream:
                self.touch(dest_path, stream)
        elif self.isdir(src_path):
            # If src is a dir, we recursively call self.cp() on all dirs
            # and files within.
            dirs, files = self.listdir(src_path)
            if dirs and not recursive:
                raise FileExistsError(
                    f"Path '{src_path}' contains directories but recursive is not set."
                )

            paths = dirs + files
            for path in paths:
                self.cp(
                    path,
                    str(
                        Path(dest_path.lstrip("/"))
                        / str(Path(path).relative_to(src_path.lstrip("/"))).lstrip("/")
                    ),
                    recursive=recursive,
                    overwrite=overwrite,
                )
        else:
            # Something must have gone horrible wrong with the file system
            # if we cannot identify if the path is a file or dir. This might
            # happen if the Google SDK/API implementation is incorrect.
            raise ValueError(f"Path '{src_path}' is neither a directory or a file.")

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file or directory"""
        if self.isdir(file_path):
            dirs, files = self.listdir(file_path)
            if (dirs or files) and not recursive:
                raise FileExistsError(
                    "Option `recursive` must be set to delete directories "
                    "with existing files in it."
                )
            for item in dirs + files:
                self.rm(item, recursive=recursive)
        else:
            self._bucket.blob(self.abspath(file_path)).delete()

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory"""
        if mode is not None:
            logger.warning("`mode` is not used for `{self.__class__.__name__}`")

        # Ensure path always ends with /, this is required by GCP Storage.
        dir_path = f"{dir_path}/" if not dir_path.endswith("/") else dir_path

        if self.exists(dir_path):
            logger.warning("Directory '%s' already exists.", dir_path)
            return

        parent = os.path.dirname(dir_path)
        if not self.exists(parent) and not make_parents:
            raise FileNotFoundError(
                f"Parent directory '{parent}' does not exist. "
                f"Use option `make_parents` to automatically create parent directories."
            )

        # Create empty blob. Blobs with 0 size and ending with `/` are dirs
        # in Google Cloud Storage.
        self._bucket.blob(self.abspath(dir_path)).upload_from_file(BytesIO())

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Args:
            dir_path: Path of directory to list contents of.

        Returns:
            Tuple: 2 value tuple that consist of
                   List of Subdirectories and
                   List of Files.

        """
        dirs: list[str] = []
        files: list[str] = []

        for blob in self._client.list_blobs(
            self._bucket, prefix=self.abspath(dir_path)
        ):
            if self.isdir(blob.name):
                dirs += (
                    [f"{self.relpath(blob.name).rstrip('/')}/"]
                    if self._is_in_root(blob.name, dir_path)
                    else []
                )
            else:
                # Google Cloud Storage treats "directories" a bit different than a
                # normal file system. If a blob exists at foo/bar/file.csv, it does not
                # mean that there is a "folder blob" at foo/bar/. Meaning, it might not
                # be returned by list_blobs() and covered by the former if statement
                # above.
                #
                # Here we add the dirname of a file if that dir is in the `dir_path`
                # folder and its not the `dir_path` itself.
                if self._is_in_root(os.path.dirname(blob.name), dir_path) and (
                    os.path.dirname(blob.name)
                    != os.path.dirname(self.abspath(dir_path))
                ):
                    dirs += [f"{self.relpath(os.path.dirname(blob.name)).rstrip('/')}/"]

                files += (
                    [self.relpath(blob.name)]
                    if self._is_in_root(blob.name, dir_path)
                    else []
                )

        # Ensure that dirs are unique.
        return list(set(dirs)), files

    def _is_in_root(self, blob_name: str, dir_path: str) -> bool:
        """
        Helper function used by listdir to figure out if blob is
        directly under dir_path or in a subdirectory
        """
        return os.path.dirname(blob_name.strip("/")) == self.abspath(dir_path).strip(
            "/"
        )

    def isfile(self, file_path: str) -> bool:
        """Check if file_path exists and is actually a file"""

        return self._bucket.blob(
            self.abspath(file_path)
        ).exists() and not file_path.endswith("/")

    def isdir(self, dir_path: str) -> bool:
        """Check if dir_path exists and is actually a directory"""
        dir_path = self.abspath(dir_path).rstrip("/") + "/"

        # In GCS, if you explicitly create a folder called test/,
        # _bucket.blob("test/").exists() will return True, but won't if you create a
        # file test/hello.txt without explicitly creating "test/".

        # It's a dir if blob(path).exists() returns True (path must end with a slash),
        # or if it contains at least one file.
        return self._bucket.blob(dir_path).exists() or bool(
            list(
                self._client.list_blobs(
                    self._bucket,
                    prefix=dir_path,
                    max_results=1,
                )
            )
        )

    def exists(self, path: str) -> bool:
        """Check if blob at path actually exists.

        Due to how blobs are done in GCP, we cannot trust .exists() to work
        on both files and dirs, we must therefore have separate implementations
        for files and directories.

        In GCS, a file and a folder can have the same name, for example:
        foo/bar/ (a folder)     or     foo/foo.bar/ (a folder)
        foo/bar  (a file)              foo/foo.bar (a file)

        For this reason, one must be careful when invoking this exists function.
        (As 'exists' may return True for a file when you could be looking for a folder)
        Ideally, it should be avoided and 'isfile' and 'isdir' must be used instead.
        """

        return self.isfile(path) or self.isdir(path)

    def list_files_by_prefix(self, prefix, max_results=None) -> list[str]:
        """List files given a prefix

        Arguments:
            - prefix: The files prefix
            - max_results: Maximum number of results to return

        Returns:
            List of filenames starting with <prefix>
        """
        return [
            self.relpath(blob.name)
            for blob in self._client.list_blobs(
                self._bucket, prefix=self.abspath(prefix), max_results=max_results
            )
        ]
