# flake8: noqa
from oxygen.conf.settings import settings
from oxygen.utils.loading import LazyObject, import_string

from .pandas import PandasReader

# pylint: disable=unnecessary-lambda
reader = LazyObject(lambda: import_string(settings.READER_BACKEND)())
