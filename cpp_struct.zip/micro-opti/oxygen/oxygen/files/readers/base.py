import os
from pathlib import Path
from urllib.parse import urlparse

from oxygen.conf.context import context
from oxygen.conf.settings import settings
from oxygen.files.storages import storage


class Reader:
    """Abstract class responsible for loading a DataFrame"""

    def to_schema(self, schema):
        """Convert an Oxygen schema to a Reader specific schema"""
        raise NotImplementedError

    def validate(self, df, schema):
        """Should raise oxygen.exceptions.ValidationError if fail"""
        raise NotImplementedError

    def convert(self, df, schema, mode):
        """Convert columns based on custom Converter.

        This is applied after ``cast`` and before ``validate`` both in reading and
        writing.

        Arguments:
            - df: DataFrame to read/write.
            - schema: Schema of the DataFrame.
            - mode: {'r', 'w', 'rw'}; specifies if conversion is for read and/or write.

        """
        for col, obj in schema.get_columns().items():
            for converter in obj.converters:
                converter(df, col, mode=mode)

    def rename(self, df, schema):
        """Rename columns based on schema mapping"""
        raise NotImplementedError

    def cast(self, df, schema):
        """Cast df into a schema.

        This both attempts to cast the dtypes of each column but
        it also selects/filters out the columns that is set in
        the schema and discard any other columns in the data.

        """
        raise NotImplementedError

    def read(
        self,
        file_path,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        *args,
        **kwargs,
    ):
        """Read dataframe from disk"""
        raise NotImplementedError

    def write(
        self,
        file_path,
        df,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        *args,
        **kwargs,
    ):
        """Write dataframe to disk"""
        raise NotImplementedError

    def format_path(
        self, path: str, root: bool = False, ignore_host: bool = False
    ) -> str:
        """Format the full file path that the reader use to read in files.

        Arguments:
            path: The relative path that we should format into a full path,
                  expected to already include the STORAGE_ROOT.
            root: If we should format path relative to root or run folder.
            ignore_host: Do not append the host name to the path.

        """
        host = getattr(settings, "STORAGE_HOSTNAME", None) if not ignore_host else ""
        parsed = urlparse(host or "")
        run_folder = (
            context.meta.run_folder.lstrip(os.path.sep) if root is False else ""
        )
        if not storage.is_remote and os.name == "nt":
            run_folder = run_folder.replace("/", os.path.sep).lstrip(os.path.sep)

        full_path = str(
            Path(parsed.netloc)
            / parsed.path.lstrip(os.path.sep)
            / settings.STORAGE_ROOT.lstrip(os.path.sep)
            / run_folder
            / path.lstrip(os.path.sep)
        )
        scheme = f"{parsed.scheme}://" if parsed.scheme else ""
        if scheme:
            full_path = f"{scheme}{full_path.lstrip(os.path.sep)}"
        elif os.name != "nt":
            full_path = f".{os.path.sep}{full_path.lstrip(os.path.sep)}"

        return full_path
