import datetime
import hashlib
import logging
import os
from typing import Any, Optional

import numpy as np
import pandas as pd
from google.cloud.bigquery import (
    Client,
    ExtractJobConfig,
    QueryJobConfig,
    WriteDisposition,
)

from oxygen.conf.settings import settings
from oxygen.exceptions import ValidationError
from oxygen.files.readers import PandasReader
from oxygen.files.schemas import DateColumn, Schema
from oxygen.files.storages import storage

logger = logging.getLogger(__name__)


class BigQueryReader(PandasReader):
    """
    PandasReader extended to also be able to
    read data from Google BigQuery.
    """

    TYPE_MAPPING = {
        np.int32: "INT64",
        np.int64: "INT64",
        np.float32: "FLOAT64",
        np.float64: "FLOAT64",
        str: "STRING",
        "datetime64[ns]": "DATETIME",
        "date": "DATE",
        bool: "BOOL",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._client = Client()

    def to_schema(self, schema):
        """Convert an Oxygen schema to a Reader specific schema"""
        return dict(schema.get_dtypes().items())

    def cast(self, df, schema):
        """Cast df into a schema.

        This both attempts to cast the dtypes of each column but
        it also selects/filters out the columns that is set in
        the schema and discard any other columns in the data.

        """
        dtypes = self.to_schema(schema)
        diff = set(dtypes.keys()).difference(set(df.columns))
        if diff:
            raise ValidationError(f"Columns of data do not match schema ({diff}).")

        # Dates are a special exception that require us to use to_datetime
        # instead of .astype()
        date_cols = {k for k, v in dtypes.items() if v == "datetime64[ns]"}
        for date_col in date_cols:
            df[date_col] = pd.to_datetime(
                df[date_col], format=schema.get_columns()[date_col].format
            )

        castable_dtypes = {
            key: value for key, value in dtypes.items() if key not in date_cols
        }

        for key, dtype in castable_dtypes.items():
            try:
                df[key] = df[key].astype(dtype)
            except ValueError as ex:
                logger.warning(
                    "Casting of column '%s' to '%s' failed due to: '%s'",
                    key,
                    dtype,
                    ex,
                )
        return df[dtypes.keys()]

    def read(
        self,
        file_path,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        data_format=None,
        *args,
        **kwargs,
    ):
        """Read dataframe from disk"""
        ext = data_format or os.path.splitext(file_path)[1]
        if ext in {".csv", ".txt"}:
            dtype = self.get_dtype_schema(schema) if schema else None
            df = self._read_csv(file_path, root=root, dtype=dtype, *args, **kwargs)
        elif ext in {".xlsx"}:
            df = self._read_xlsx(file_path, root=root, *args, **kwargs)
        elif ext in {".parquet", ".pq"}:
            df = self._read_parquet(file_path, root=root, *args, **kwargs)
        elif ext in {"bq", "bigquery"}:
            df = self._read_bigquery(
                table=file_path,
                schema=schema,
                *args,
                **kwargs,
            )
        else:
            raise ValueError(
                f"'{self.__class__.__name__}' do not support reading "
                f"data of type '{ext}'."
            )

        if schema:
            df = self.convert_to_schema(
                df=df,
                schema=schema,
                cast=cast,
                convert=convert,
                validate=validate,
                clean=True,
            )

        return df

    def write(
        self,
        file_path,
        df,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        data_format=None,
        *args,
        **kwargs,
    ):
        """Write dataframe to disk"""
        if schema:
            df = self.convert_to_schema(
                df=df, schema=schema, validate=validate, cast=cast, convert=convert
            )

        ext = data_format or os.path.splitext(file_path)[1]

        if ext in {"bq", "bigquery"}:
            self._write_bigquery(table=file_path, df=df, schema=schema, *args, **kwargs)
            # Since BigQuery is not a "file", we do not want to continue
            # execution and manage directories etc after we write to BigQuery,
            # we break execution here.
            return

        dirname = self.format_path(
            os.path.dirname(file_path), root=root, ignore_host=True
        )
        storage.mkdir(dirname, make_parents=True)
        try:
            if ext in {".csv", ".txt"}:
                self._write_csv(file_path, df, root=root, *args, **kwargs)
            elif ext in {".xlsx"}:
                self._write_xlsx(file_path, df, root=root, *args, **kwargs)
            elif ext in {".parquet", ".pq"}:
                self._write_parquet(file_path, df, root=root, *args, **kwargs)
            else:
                raise ValueError(
                    f"'{self.__class__.__name__}' do not support writing "
                    f"files of type '{ext}'."
                )
        except Exception as ex:
            # If something goes wrong with writing the file, cleanup
            # the dir to remove leaving dead dirs around.
            try:
                storage.rm(dirname)
            except FileExistsError:
                # If file exists in the directory,
                # just ignore the error and leave dir in place.
                pass
            raise ex

    def _write_bigquery(self, table, df, schema, *args, **kwargs):
        """Write a dataframe to a bigquery table.

        Arguments:
            - table: The BigQuery table to write data to.
            - df: The dataframe that we want to store.
            - schema: The Schema class to use as table schema.
            - args: Args passed down to the to_gbq() method.
            - kwargs: Kwargs passed down to the to_gbq() method.

        """
        # Since we are modifying types temporarily in this method,
        # we want to ensure this is only done on a "local" instance
        # of the dataframe and not effecting the source dataframe.
        df = df.copy()

        # Set default behavior for if_exists.
        kwargs["if_exists"] = kwargs.get("if_exists", "append")
        logger.debug("Attempting to upload to table '%s'", table)
        schema_map = self._get_schema_map(schema) if schema else None

        if schema_map:
            # The pandas-gbq package is always converting datetime64[ns]
            # dtypes into a format with time details (%H:%M:%S), this cause
            # an issue when we want to store as DATE. We can circumvent
            # this problem by converting dates to string before we write
            # to BQ.
            for field in schema_map:
                if field["type"] == "DATE":
                    df[field["name"]] = df[field["name"]].astype(str)

        df.to_gbq(
            destination_table=table,
            project_id=settings.GOOGLE_PROJECT,
            table_schema=schema_map,
            *args,
            **kwargs,
        )
        logger.info("Data uploaded to table '%s'.", table)

    def _get_schema_map(self, schema):
        """Get mapping between Oxygen Schema and BigQuery Table Schema.

        Args:
            - schema: Our Oxygen Schema that we want to match schema from.

        Returns:
            List of dictionary objects that is mapping fields to each other
            and what type to use.

        """
        fields = []
        for k, v in schema.get_columns().items():
            if v.dtype not in self.TYPE_MAPPING:
                raise KeyError(
                    f"The type '{v.dtype}' is not supported in "
                    f"{self.__class__.__name__} 'TYPE_MAPPING'"
                )

            fields.append(
                {
                    "name": k,
                    "type": self.TYPE_MAPPING[
                        # `DateColumn` is an exception, we do not want to pass
                        # the np.datetime64[ns] dtype, instead we overwrite it
                        # with a custom dtype to separate datetime and date.
                        v.dtype
                        if not isinstance(v, DateColumn)
                        else "date"
                    ],
                }
            )
        return fields

    def _read_bigquery(
        self, table, schema=None, where=None, sql=None, cache=None, *args, **kwargs
    ) -> pd.DataFrame:
        """Read in data from BigQuery to Pandas Dataframe.

        Arguments:
            - table: The SQL table to read from. This is always injected into
                the final query together with the google project id.
            - schema: Optional, use schema to automatically extract columns to select.
            - where: Optional, injected into query as WHERE clause.
            - sql: Optional, provide a full SQL query to read. The SQL query expects
                the table name to be replaced with %(table)s so that the function
                can inject the fully completed table name.
            - cache: If results should be cached on bucket or not.
            - args:

        """

        assert sql or schema, "Either kwarg 'sql' or 'schema' must be set."
        sql = sql or BigQueryReader.generate_sql(
            table=table, schema=schema, where=where
        )

        if cache is None:
            cache = settings.ENABLE_BIGQUERY_CACHE

        tbl_name = f"tmp_results_{BigQueryReader.get_query_hash(sql)}"
        tbl_path = storage.abspath(
            f"/{settings.GOOGLE_TEMP_PATH.strip('/')}/{tbl_name}_*.csv"
        )
        dest = f"gs://{settings.GOOGLE_GCS_BUCKET}/{tbl_path}"  # noqa

        if cache and storage.list_files_by_prefix(
            prefix=tbl_path.replace("_*.csv", "_"), max_results=1
        ):
            if "suffix" not in kwargs:
                kwargs["suffix"] = tbl_name

            return self.get_df_from_tmp(
                *args,
                **kwargs,
            )

        tbl_obj = self._client.get_dataset(
            f"{settings.GOOGLE_PROJECT}.{settings.GOOGLE_BIGQUERY_TMP_DATASET}"
        ).table(tbl_name)

        # Execute SQL query provided as kwarg, and store output in a temp table.
        self._client.query(
            sql % {"table": f"{settings.GOOGLE_PROJECT}.{table}"},
            location=settings.GOOGLE_LOCATION,
            job_config=QueryJobConfig(
                destination=tbl_obj,
                write_disposition=WriteDisposition.WRITE_TRUNCATE,
            ),
        ).result()

        # Extract the temp table results and store as compressed .csv on cloud storage.
        try:
            self._client.extract_table(
                tbl_obj,
                dest,
                location=settings.GOOGLE_LOCATION,
                job_config=ExtractJobConfig(compression="GZIP"),
            ).result()
            logger.debug("Query results extracted to GCS: %s", dest)
        finally:
            # Cleanup temp table no matter if fail or succeed.
            self._client.delete_table(tbl_obj)
            logger.info("BQ table `%s` deleted", tbl_name)

        if "suffix" not in kwargs:
            kwargs["suffix"] = tbl_name

        return self.get_df_from_tmp(
            *args,
            **kwargs,
        )

    @staticmethod
    def get_query_hash(sql: str):
        """Get MD5 hash of SQL query salted by date"""
        salt = datetime.datetime.utcnow().strftime("%Y-%m-%d")
        return hashlib.md5(f"{sql}-{salt}".encode("utf-8")).hexdigest()

    def get_df_from_tmp(
        self,
        suffix: str,
        tmp_dir=None,
        *args,
        **kwargs,
    ) -> pd.DataFrame:
        """Read in Pandas dataframe from multiple files in tmp dir.

        Arguments:
            - suffix: The temporary files are created with a suffix to its file name to
                separate the file names from other queries/results.
            - tmp_dir: Directory on the cloud bucket where we should read files from.

        """
        # Merge the result files into a single dataframe.

        if tmp_dir is None:
            tmp_dir = settings.GOOGLE_TEMP_PATH

        files = storage.list_files_by_prefix(tmp_dir.strip("/") + "/" + suffix)

        if "root" not in kwargs:
            kwargs["root"] = True

        return pd.concat(
            [
                self.read(
                    fname,
                    compression="gzip",
                    *args,
                    **kwargs,
                )
                for fname in files
            ],
            ignore_index=True,
        )

    @staticmethod
    def generate_sql(
        table: str,
        schema: Schema,
        where: Optional[str] = None,
    ):
        """Generate SELECT sql query based on schema"""
        return (
            f"SELECT {', '.join(schema.get_mapping().keys())} FROM "
            f"{settings.GOOGLE_PROJECT}.{table} "
            f"WHERE {where or 'true'}"
        )

    def get_dtype_schema(self, schema: Schema) -> dict[str, Any]:
        """
        Convert the reader schema into a read_csv dtype kwarg compatible dictionary.

        When reading in data from CSV using pandas, you can specify the dtype
        of each column to ensure that data is loaded and casted correctly.
        This format does not allow "datetime64[ns]".

        Since we still re-cast the data when cast=True, the columns still
        end up being datetime in the end.

        """
        schema = self.to_schema(schema)
        for key in schema:
            schema[key] = str if schema[key] == "datetime64[ns]" else schema[key]
        return schema
