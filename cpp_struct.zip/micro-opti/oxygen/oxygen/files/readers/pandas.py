import logging
import os
import tempfile
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from io import BytesIO, StringIO
from typing import TYPE_CHECKING

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from sqlalchemy import create_engine

from oxygen.conf.settings import settings
from oxygen.exceptions import ValidationError
from oxygen.files.readers.base import Reader
from oxygen.files.storages import storage

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from oxygen.files.schemas import Schema


class PandasReader(Reader):
    def to_schema(self, schema):
        """Convert an Oxygen schema to a Reader specific schema"""
        # Pandas treat str as `object`, so we have to convert
        # the default Oxygen dtype of str to object and keep rest same.
        return {
            k: (v if v is not str else object) for k, v in schema.get_dtypes().items()
        }

    def validate(self, df, schema):
        if df.empty:
            raise ValidationError("Loaded df is empty.")

        dtypes = self.to_schema(schema)

        # Check if column names and count match schema
        if set(df.columns) != set(dtypes.keys()):
            diff = set(df.columns).difference(set(dtypes.keys()))
            raise ValidationError(
                f"Columns do not match between dataframe and schema. '{diff}'"
            )

        # Check if column dtypes match schema
        for col in df.columns:
            if (
                df[col].dtype != dtypes[col]
                # Treat object and str the same for pandas.
                and not (df[col].dtype == object and dtypes[col] == str)
            ):
                raise ValidationError(
                    f"Column '{col}' should be of type '{dtypes[col]}' but is "
                    f"of type '{df[col].dtype}'"
                )

        # Run all column level validators
        for col, obj in schema.get_columns().items():
            for validator in obj.validators:
                validator(df, col)

        # Run all schema level validators
        for validator in schema.validators or []:
            validator(df)

    def rename(self, df, schema):
        """Rename columns based on schema mapping"""
        return df.rename(schema.get_mapping(), axis=1)

    def cast(self, df, schema):
        """Cast df into a schema.

        This both attempts to cast the dtypes of each column but
        it also selects/filters out the columns that is set in
        the schema and discard any other columns in the data.

        """
        try:
            dtypes = self.to_schema(schema)
            diff = set(dtypes.keys()).difference(set(df.columns))
            if diff:
                raise ValidationError(f"Columns of data do not match schema ({diff}).")

            # Dates are a special exception that require us to use to_datetime
            # instead of .astype()
            date_cols = {k for k, v in dtypes.items() if v == "datetime64[ns]"}
            for date_col in date_cols:
                df[date_col] = pd.to_datetime(
                    df[date_col], format=schema.get_columns()[date_col].format
                )

            castable_dtypes = {
                key: value for key, value in dtypes.items() if key not in date_cols
            }
            return df.astype(castable_dtypes)[dtypes.keys()]
        except ValueError as ex:
            logger.warning(ex)
            return df

    def read(
        self,
        file_path,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        data_format=None,
        *args,
        **kwargs,
    ):
        """Read dataframe from disk"""
        ext = data_format or os.path.splitext(file_path)[1]
        if ext in {"sql"}:
            df = self._read_sql(table=file_path, schema=schema, *args, **kwargs)
        elif ext in {".csv", ".txt"}:
            df = self._read_csv(file_path, root=root, *args, **kwargs)
        elif ext in {".xlsx"}:
            df = self._read_xlsx(file_path, root=root, *args, **kwargs)
        elif ext in {".parquet", ".pq", ".parquet.gzip", ".pq.gzip"}:
            df = self._read_parquet(file_path, root=root, *args, **kwargs)
        else:
            raise ValueError(
                f"'{self.__class__.__name__}' do not support reading "
                f"files of type '{ext}'."
            )

        if schema:
            df = self.rename(df, schema)
            if cast:
                df = self.cast(df, schema)
            if convert:
                schema.convert(df, mode="r")
            df = schema.clean(df)
            if validate:
                schema.validate(df)

        return df

    def _read_sql(self, table, schema=None, where=None, sql=None, *args, **kwargs):
        """Read data from SQL"""
        assert getattr(
            settings, "SQL_CONNECTION", None
        ), "`SQL_CONNECTION` setting must be set to be able to read from SQL"
        assert sql or schema, "Either kwarg 'sql' or 'schema' must be set."
        sql = sql or self.generate_sql(table=table, schema=schema, where=where)
        engine = create_engine(settings.SQL_CONNECTION)
        logger.info("SQL query executed: \n %s", sql)
        return pd.read_sql(
            sql, engine, dtype_backend=settings.PANDAS_DTYPE_BACKEND, *args, **kwargs
        )

    def _read_csv(self, file_path, root=False, *args, **kwargs):
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        if not storage.is_remote:
            logger.debug("Attempting to read csv file from '%s'", file_path)
            df = pd.read_csv(
                file_path, dtype_backend=settings.PANDAS_DTYPE_BACKEND, *args, **kwargs
            )
        else:
            with self._copy_to_tmp(file_path) as tmp:
                logger.debug("Attempting to read csv file from '%s'", tmp.name)
                df = pd.read_csv(
                    tmp.name,
                    dtype_backend=settings.PANDAS_DTYPE_BACKEND,
                    *args,
                    **kwargs,
                )

        return df

    def _read_xlsx(self, file_path, root=False, *args, **kwargs):
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        if not storage.is_remote:
            logger.debug("Attempting to read xlsx file from '%s'", file_path)
            df = pd.read_excel(
                file_path, dtype_backend=settings.PANDAS_DTYPE_BACKEND, *args, **kwargs
            )
        else:
            with self._copy_to_tmp(file_path) as tmp:
                logger.debug("Attempting to read xlsx file from '%s'", tmp.name)
                df = pd.read_excel(
                    tmp.name,
                    dtype_backend=settings.PANDAS_DTYPE_BACKEND,
                    *args,
                    **kwargs,
                )

        return df

    def _read_parquet(self, file_path, root=False, *args, **kwargs):
        """Read parquet either from file or from directory.

        Some times .parquet files are defined as a single file, and other times
        they are split into multiple parts stored in a .parquet/ directory.
        This function will check if the file_path points to a directory
        or a single file, and concatenate the parts if necessary.

        """
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        if not storage.is_remote:
            logger.debug("Attempting to read parquet file from '%s'", file_path)
            df = pd.read_parquet(
                file_path, dtype_backend=settings.PANDAS_DTYPE_BACKEND, *args, **kwargs
            )
        else:
            logger.debug("Attempting to read parquet file from '%s'", file_path)
            files = (
                storage.listdir(file_path)[1]
                if storage.isdir(file_path)
                else [file_path]
            )
            df = pd.DataFrame()
            # Ensure that only .parquet files from directory is fetched.
            # This will ignore files such as _SUCCESS.
            files = list(
                filter(lambda x: os.path.splitext(x)[1] in {".pq", ".parquet"}, files)
            )

            # Read in data in multithreadded manner.
            parts = self._read_parquet_parts(files, *args, **kwargs)
            df = pd.concat([df, *parts])

        return df

    def _read_parquet_parts(self, files, *args, **kwargs):
        """Use multithreading to read in parts in parllel to speed up IO"""
        with ThreadPoolExecutor(max_workers=min(32, os.cpu_count() + 4)) as pool:
            results = pool.map(
                lambda x: self._read_parquet_part(file_path=x, *args, **kwargs), files
            )
        return list(results)

    def _read_parquet_part(self, file_path, *args, **kwargs):
        """Read in a single part as a temp file"""
        with self._copy_to_tmp(file_path) as tmp:
            return pd.read_parquet(
                tmp.name, dtype_backend=settings.PANDAS_DTYPE_BACKEND, *args, **kwargs
            )

    @contextmanager
    def _copy_to_tmp(self, file_path):
        """
        Context manager that write file from storage to tmp file
        and auto cleanup file in the end of context.
        """
        with storage.open(file_path, mode="rb") as stream:
            tmp = tempfile.NamedTemporaryFile()
            try:
                while True:
                    chunk = stream.read(4_000_000)
                    if not chunk:
                        break

                    # Convert to bytes if required.
                    if isinstance(chunk, str):
                        chunk = chunk.encode("utf8")

                    tmp.write(chunk)

                # Reset file pointer.
                tmp.seek(0)
                yield tmp
            finally:
                tmp.close()

    def convert_to_schema(
        self,
        df: pd.DataFrame,
        schema: "Schema",
        cast: bool = True,
        convert: bool = True,
        validate: bool = True,
        clean: bool = True,
    ):
        df = self.rename(df, schema)
        if cast:
            df = self.cast(df, schema)
        if convert:
            schema.convert(df, mode="w")
        if clean:
            df = schema.clean(df)
        if validate:
            schema.validate(df)
        return df

    def write(
        self,
        file_path,
        df,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        data_format=None,
        *args,
        **kwargs,
    ):
        """Write dataframe to disk"""
        if schema:
            df = self.convert_to_schema(
                df=df, schema=schema, validate=validate, cast=cast, convert=convert
            )

        ext = data_format or os.path.splitext(file_path)[1]
        dirname = self.format_path(
            os.path.dirname(file_path), root=root, ignore_host=True
        )
        storage.mkdir(dirname, make_parents=True)
        try:
            if ext in {"sql"}:
                self._write_sql(file_path, df, *args, **kwargs)
            elif ext in {".csv", ".txt"}:
                self._write_csv(file_path, df, root=root, *args, **kwargs)
            elif ext in {".xlsx"}:
                self._write_xlsx(file_path, df, root=root, *args, **kwargs)
            elif ext in {".parquet", ".pq"}:
                self._write_parquet(file_path, df, root=root, *args, **kwargs)
            else:
                raise ValueError(
                    f"'{self.__class__.__name__}' do not support writing "
                    f"files of type '{ext}'."
                )
        except Exception as ex:
            # If something goes wrong with writing the file, cleanup
            # the dir to remove leaving dead dirs around.
            try:
                storage.rm(dirname)
            except FileExistsError:
                # If file exists in the directory,
                # just ignore the error and leave dir in place.
                pass
            raise ex

    def _write_sql(self, table, df, *args, **kwargs):
        """Write data to SQL"""
        assert getattr(
            settings, "SQL_CONNECTION", None
        ), "`SQL_CONNECTION` setting must be set to be able to write to SQL"
        engine = create_engine(settings.SQL_CONNECTION)
        df.to_sql(table, engine, *args, **kwargs)

    def _write_csv(self, file_path, df, root=False, *args, **kwargs):
        """Write Dataframe to csv file"""
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        logger.debug("Attempting to write csv file to '%s'", file_path)
        if not storage.is_remote:
            df.to_csv(file_path, *args, **kwargs)
        else:
            handler = StringIO(newline="")
            df.to_csv(handler, *args, **kwargs)
            handler.seek(0)
            storage.touch(file_path, handler)

    def _write_xlsx(self, file_path, df, root=False, *args, **kwargs):
        """Write Dataframe to excel file"""
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        logger.debug("Attempting to write xlsx file to '%s'", file_path)
        if not storage.is_remote:
            df.to_excel(file_path, *args, **kwargs)
        else:
            handler = BytesIO()
            with pd.ExcelWriter(handler, engine="xlsxwriter") as writer:
                df.to_excel(writer, *args, **kwargs)
            handler.seek(0)
            storage.touch(file_path, handler)

    def _write_parquet(self, file_path, df, root=False, *args, **kwargs):
        """Write Dataframe to parquet file"""
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        logger.debug("Attempting to write parquet file to '%s'", file_path)
        if not storage.is_remote:
            df.to_parquet(file_path, *args, **kwargs)
        else:
            handler = BytesIO()
            table = pa.Table.from_pandas(df)
            pq.write_table(table, handler)
            handler.seek(0)
            storage.touch(file_path, handler)

    @staticmethod
    def generate_sql(table, schema, where=None):
        """Generate SELECT sql query based on schema"""
        return (
            f"SELECT {', '.join(schema.get_mapping().keys())} FROM "
            f"{table} "
            f"WHERE {where or 'true'}"
        )
