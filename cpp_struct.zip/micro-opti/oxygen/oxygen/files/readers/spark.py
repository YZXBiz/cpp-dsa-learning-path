import logging
import os
from datetime import datetime

import numpy as np
from pyspark.sql import types
from pyspark.sql.types import DateType, FloatType, StringType, StructType, TimestampType

from oxygen.conf.settings import settings
from oxygen.connections.spark import spark
from oxygen.files.validators import ValidationError
from oxygen.utils.func import deprecated

from .base import Reader

logger = logging.getLogger(__name__)


@deprecated(version="2.0.0")
class SparkReader(Reader):

    TYPE_MAPPING = {
        np.int32: types.IntegerType,
        np.int64: types.LongType,
        np.float32: types.FloatType,
        np.float64: types.DoubleType,
        str: types.StringType,
        "datetime64[ns]": types.TimestampType,
        bool: types.BooleanType,
    }

    def to_schema(self, schema):
        """Convert oxygen types to spark types and schema"""
        try:
            return types.StructType(
                [
                    types.StructField(key, self.TYPE_MAPPING[value]())
                    for key, value in schema.get_dtypes().items()
                ]
            )
        except KeyError as exc:
            raise TypeError(
                f"Type is not supported by {self.__class__.__name__}"
            ) from exc

    def validate(self, df, schema):
        """Validate that a spark dataframe match the schema"""
        self._compare_schemas(self.to_schema(schema), df.schema)
        # Run all column level validators
        for col, obj in schema.get_columns().items():
            for validator in obj.validators:
                validator(df, col)

        # Run all schema level validators
        for validator in schema.validators or []:
            validator(df)

    def _compare_schemas(self, schema_a, schema_b):
        """Compare the schema with another schema.

        The schema return any differences in columns included or
        type differences between columns.

        Raises:
            ValidationError: List of errors for each error found.

        """
        schema_a_mapping = {f.name: f.dataType for f in schema_a.fields}
        schema_b_mapping = {f.name: f.dataType for f in schema_b.fields}
        errors = []

        # Get column differences.
        column_diff = set(schema_a_mapping.keys()) ^ set(schema_b_mapping.keys())
        for col in column_diff:
            errors.append(f"Missing column '{col}'. Column must exist in both schemas.")

        # Get all columns where the type/schema do not match each other.
        type_diff = {
            key
            for key in schema_a_mapping.keys()
            if key in schema_b_mapping
            and schema_a_mapping[key] != schema_b_mapping[key]
        }
        for col in type_diff:
            type_name = schema_a_mapping[col].__class__.__name__
            errors.append(f"Column '{col}' should be of type '{type_name}'")

        # If there were any errors found, convert the strings into ValidationErrors.
        if errors and len(errors) <= 1:
            raise ValidationError(errors[0])
        if errors and len(errors) > 1:
            raise ValidationError([ValidationError(error) for error in errors])

    def rename(self, df, schema):
        """Rename dataframe columns according to schema"""
        cols = list(df.columns)
        mapping = schema.get_mapping()
        # The mapping and renaming has already been applied
        # to this data. No need to rename it again.
        if not set(cols).issuperset(set(mapping.keys())):
            return df

        # Make sure all cols are represented
        # in the mapping to avoid accidentally
        # filtering out cols in the .select()
        for col in cols:
            if col not in mapping:
                mapping[col] = col

        return df.select(
            *[df[old_key].alias(new_key) for old_key, new_key in mapping.items()]
        )

    def cast(self, df, schema):
        """Cast df into a schema.

        This both attempts to cast the dtypes of each column but
        it also selects/filters out the columns that is set in
        the schema and discard any other columns in the data.

        """
        try:
            fields = {
                key: self.TYPE_MAPPING[value]
                for key, value in schema.get_dtypes().items()
            }
        except KeyError as exc:
            raise TypeError(
                f"Type is not supported by {self.__class__.__name__}"
            ) from exc
        return df.select(
            *[
                df[field].cast(fields[field]())
                for field in schema.get_mapping().values()
            ]
        )

    def read(
        self,
        file_path,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        data_format=None,
        *args,
        **kwargs,
    ):
        """Read dataframe from disk"""
        ext = data_format or os.path.splitext(file_path)[1]
        if ext in {".csv", ".txt", ".psv", ".dat"}:
            df = self._read_csv(file_path, root=root, *args, **kwargs)
        elif ext in {".parquet", ".pq"}:
            df = self._read_parquet(file_path, root=root, *args, **kwargs)
        elif ext in {".json"}:
            df = self._read_json(file_path, root=root, *args, **kwargs)
        else:
            raise ValueError(
                f"'{self.__class__.__name__}' do not support reading "
                f"files of type '{ext}'."
            )

        if schema:
            df = self.rename(df, schema)
            if cast:
                df = self.cast(df, schema)
            if convert:
                schema.convert(df, mode="r")
            df = schema.clean(df)
            if validate:
                self.validate(df, schema)

        return df

    def _read_csv(self, file_path, root=False, *args, **kwargs):
        full_path = self.format_path(file_path, root)
        header = kwargs.pop("header", True)
        logger.debug("Attempting to read csv file from '%s'", full_path)
        return spark.read.csv(full_path, header=header, *args, **kwargs)

    def _read_parquet(self, file_path, root=False, *args, **kwargs):
        full_path = self.format_path(file_path, root)
        logger.debug("Attempting to read parquet file from '%s'", full_path)
        return spark.read.format("parquet").load(full_path, *args, **kwargs)

    def _read_json(self, file_path, root=False, spark_schema=None):
        # handle all types of jsons
        full_path = self.format_path(file_path, root)
        logger.debug("Attempting to read json file from '%s'", full_path)
        rdd_ip = spark.sparkContext.textFile(full_path)
        json_string = rdd_ip.take(1)[0]
        data_json_str = json_string

        # check for trailing comma
        if data_json_str[-1] == ",":
            data_json_str = data_json_str[:-1]

        # check for leading and trailing brackets
        if data_json_str[0] != "[":
            data_json_str = "[" + data_json_str
        if data_json_str[-1] != "]":
            data_json_str = data_json_str + "]"
        if data_json_str[-2:] == ",]":
            data_json_str = data_json_str[:-2] + "]"

        df = spark.read.json(
            spark.sparkContext.parallelize([data_json_str]), schema=spark_schema
        )
        return df

    def write(
        self,
        file_path,
        df,
        schema=None,
        validate=True,
        root=False,
        cast=True,
        convert=True,
        *args,
        **kwargs,
    ):
        """Write dataframe to disk"""
        if schema:
            if cast:
                df = self.cast(df, schema)
            if convert:
                schema.convert(df, mode="w")
            if validate:
                schema.validate(df)

        _, ext = os.path.splitext(file_path)
        if ext in {".csv", ".txt"}:
            self._write_csv(file_path, df, root=root, *args, **kwargs)
        elif ext in {".parquet", ".pq"}:
            self._write_parquet(file_path, df, root=root, *args, **kwargs)
        else:
            raise ValueError(
                f"'{self.__class__.__name__}' do not support writing "
                f"files of type '{ext}'."
            )

    def write_sql_pool(self, table_name, df, limit_output=False, **kwargs):
        """Write dataframe to SQL pool using Spark native functionality"""
        # extract temp dir
        temp_dir = kwargs.pop("temp_dir", "/datamart/temp_spark_tables")
        root = kwargs.pop("root", True)
        mode = kwargs.pop("mode", "append")
        temp_dir_path = self.format_path(temp_dir, root)
        if limit_output:
            df = df.limit(1000)  # for testing

        logger.debug("Attempting to write table to '%s'", table_name)
        df.write.mode(mode).format("com.databricks.spark.sqldw").option(
            "url", settings.SPARK_SQL_WRITE_CONNECTION
        ).option("dbtable", table_name).option("tempDir", temp_dir_path).option(
            "forwardSparkAzureStorageCredentials", "true"
        ).option(
            "user", settings.DEDICATED_USERNAME
        ).option(
            "password", settings.DEDICATED_PASSWORD
        ).save()

    def _write_csv(self, file_path, df, root=False, *args, **kwargs):
        """Write spark dataframe to disk as csv file"""
        full_path = self.format_path(file_path, root)
        logger.debug("Attempting to write csv file to '%s'", full_path)
        df.write.csv(full_path, *args, **kwargs)

    def _write_parquet(self, file_path, df, root=False, *args, **kwargs):
        """Write spark dataframe to disk as parquet file"""
        full_path = self.format_path(file_path, root)
        logger.debug("Attempting to write parquet file to '%s'", full_path)
        df.write.parquet(full_path, *args, **kwargs)

    def start_logger(self, pipeline_name=None, stage_name=None, input_filename=None):
        """Start logging time and initialise pipeline parameters"""
        logger.debug("Logging info : %s - %s", pipeline_name, stage_name)
        start_time = datetime.utcnow()
        pipeline_run_date = start_time.date()
        return [
            pipeline_run_date,
            start_time,
            pipeline_name,
            stage_name,
            input_filename,
        ]

    def stop_logger(self, arg_list, error_msg=None):
        """Write process log into SQL table"""

        log_schema = (
            StructType()
            .add("pipeline_run_date", DateType())
            .add("pipeline_name", StringType())
            .add("stage_name", StringType())
            .add("start_time", TimestampType())
            .add("completion_time", TimestampType())
            .add("duration_in_sec", FloatType())
            .add("input_filename", StringType())
        )

        completion_time = datetime.utcnow()
        duration = completion_time - arg_list[1]
        if not error_msg:
            df = spark.createDataFrame(
                [
                    (
                        arg_list[0],
                        arg_list[2],
                        arg_list[3],
                        arg_list[1],
                        completion_time,
                        duration.total_seconds(),
                        arg_list[4],
                    )
                ],
                log_schema,
            )
        else:
            df = spark.createDataFrame(
                [
                    (
                        arg_list[0],
                        arg_list[2],
                        arg_list[3],
                        arg_list[1],
                        None,
                        None,
                        error_msg,
                    )
                ],
                log_schema,
            )
        self.write_sql_pool("endstate.pipeline_logs", df)
