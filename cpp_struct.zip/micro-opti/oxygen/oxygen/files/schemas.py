from typing import Any, Optional

import numpy as np
import pandas as pd
from box import Box

from oxygen.files.readers import reader
from oxygen.utils.func import classproperty


class Schema:
    """Schema to define file interfaces"""

    validators = None

    @classproperty
    def fields(self):
        return Box({k: k for k in self.get_columns().keys()})

    @classmethod
    def clean(cls, df):
        """Hook to allow modification of dataframe before validation.

        This hook can be used to convert types or modify values ahead
        of validation, for example convert timestamps to datetime or similar.

        """
        return df

    @classmethod
    def validate(cls, df):
        """Validate contents of file"""
        reader.validate(df, schema=cls)

    @classmethod
    def convert(cls, df, mode):
        reader.convert(df, schema=cls, mode=mode)

    @classmethod
    def load(
        cls,
        file_path: str,
        validate: bool = True,
        convert: bool = True,
        root: bool = False,
        cast: bool = True,
        *args,
        **kwargs,
    ):
        """Load a DataFrame from file path.

        Arguments:
            file_path: Path to file.
            validate: Should run validators or not.
            convert: Pass to reader function.
            root: Pass to reader function.
            cast: Pass to reader function.
            args: Pass to reader function.
            kwargs: Pass to reader function.

        """
        return reader.read(
            file_path,
            schema=cls,
            validate=validate,
            convert=convert,
            root=root,
            cast=cast,
            *args,
            **kwargs,
        )

    @classmethod
    def save(
        cls,
        file_path,
        df,
        validate: bool = True,
        convert: bool = True,
        root: bool = False,
        cast: bool = True,
        *args,
        **kwargs,
    ) -> None:
        """Saves the file to disk and automatically validates it by Schema"""
        reader.write(
            file_path=file_path,
            df=df,
            schema=cls,
            validate=validate,
            convert=convert,
            root=root,
            cast=cast,
            *args,
            **kwargs,
        )

    @classmethod
    def get_dtypes(cls):
        """Get mapping of name and dtype for each column"""
        return {k: v.dtype for k, v in cls.get_columns().items()}

    @classmethod
    def get_mapping(cls):
        """Get renaming mapping from source data to dataframe of schema"""
        return {(v.source or k): k for k, v in cls.get_columns().items()}

    @classmethod
    def get_columns(cls):
        """Get all columns of the schema"""
        # Use cls().__dir__() over dir(cls) to avoid sorting
        # alphabetically and keep order attributes are defined in.
        excluded = {"fields"}
        # pylint: disable=unnecessary-dunder-call
        cols = list(filter(lambda x: x not in excluded, cls().__dir__()))
        return {k: getattr(cls, k) for k in cols if isinstance(getattr(cls, k), Column)}


class Converter:
    """
    A converter is a class that can be added to a Schema to automatically
    modify data as it is being written or read.
    """

    def __call__(self, df, col=None, mode="r"):
        """Entrypoint for converter.

        Args:
            df: DataFrame.
            col: Column name.
            mode: {'r', 'rw', 'w'}; should the converter be applied when reading
                or writing.
        """
        raise NotImplementedError


class Column:
    dtype: Optional[Any] = None

    def __init__(self, dtype=None, source=None, validators=None, converters=None):
        self.dtype = dtype if dtype else self.dtype
        self.source = source
        self.validators = validators or []
        self.converters = converters or []

    def __repr__(self):
        return f"<{self.__class__.__name__}>"


class StringColumn(Column):
    dtype = str


class IntegerColumn(Column):
    dtype = np.int64


class NullableIntegerColumn(Column):
    dtype = pd.Int64Dtype()


class FloatColumn(Column):
    dtype = np.float64


class BoolColumn(Column):
    dtype = bool


class ListColumn(Column):
    dtype = list


class PandasCategoryColumn(Column):
    """
    Category dtype only exist in pandas, there is
    no equal type in for example Spark.
    """

    dtype = "category"


class DateColumn(Column):
    dtype = "datetime64[ns]"

    # pylint: disable=redefined-builtin
    def __init__(self, dtype=None, source=None, validators=None, format="%Y-%m-%d"):
        super().__init__(dtype, source, validators)
        self.format = format


class DateTimeColumn(Column):
    dtype = "datetime64[ns]"

    # pylint: disable=redefined-builtin
    def __init__(
        self, dtype=None, source=None, validators=None, format="%Y-%m-%d %H:%M:%S"
    ):
        super().__init__(dtype, source, validators)
        self.format = format
