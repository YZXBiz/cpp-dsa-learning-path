"""Collection of validatiors to validate Pandas Dataframes"""
from pandas.api.types import is_string_dtype

from oxygen.exceptions import ValidationError

from .base import Validator


class NotNullValidator(Validator):
    """Check if any value is null"""

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns
        if df[cols].isnull().values.any():
            if len(cols) == 1:
                raise ValidationError(f"Column '{col}' contain null values.")

            raise ValidationError("Dataframe contains null values.")


class UniqueValidator(Validator):
    """Check that all values are unique"""

    def __init__(self, unique_cols=None):
        self.unique_cols = unique_cols

    def __call__(self, df, col=None):
        if self.unique_cols:
            cols = self.unique_cols
        else:
            cols = [col] if col else df.columns

        if df[cols].duplicated().values.any():
            if len(cols) == 1:
                raise ValidationError(f"Column '{col}' contain duplicated values.")

            cols_formatted = ", ".join([f"'{col}'" for col in cols])
            raise ValidationError(
                f"Dataframe contains duplicated values "
                f"across columns {cols_formatted}."
            )


class RangeValidator(Validator):
    """Check that comperative value are within range"""

    def __init__(self, start=None, end=None):
        self.start = start
        self.end = end

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns
        if self.start is not None and self.end is not None:
            if ((df[cols] < self.start) | (df[cols] > self.end)).values.any():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values outside "
                        f"of range {self.start} - {self.end}."
                    )

                raise ValidationError(
                    f"Dataframe contains values outside "
                    f"of range {self.start} - {self.end}."
                )

        elif self.start is not None:
            if (df[cols] < self.start).values.any():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values less than {self.start}."
                    )

                raise ValidationError(
                    f"Dataframe contains values less than {self.start}."
                )

        elif self.end is not None:
            if (df[cols] > self.end).values.any():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values higher than {self.end}."
                    )

                raise ValidationError(
                    f"Dataframe contains values higher than {self.end}."
                )
        else:
            raise ValueError("RangeValidator must have a defined range.")


class MinValueValidator(Validator):
    """Check that numeric value is greater than"""

    def __init__(self, limit):
        self.limit = limit

    def __call__(self, df, col=None):
        # Shortcut to RangeValidator with only a lower limit.
        RangeValidator(start=self.limit)(df, col)


class MaxValueValidator(Validator):
    """Check that numeric value is less than"""

    def __init__(self, limit):
        self.limit = limit

    def __call__(self, df, col=None):
        # Shortcut to RangeValidator with only a upper limit.
        RangeValidator(end=self.limit)(df, col)


class RegexValidator(Validator):
    """Validate that value match regex pattern"""

    def __init__(self, pattern):
        self.pattern = pattern

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns
        for column in cols:
            # Series must be of dtype string for us to
            # apply a regex match on it.
            if not is_string_dtype(df[column]):
                raise TypeError(
                    f"Column '{column}' must be of dtype 'str' to use RegexValidator."
                )

            if not df[column].str.match(self.pattern).values.all():
                raise ValidationError(
                    f"Column '{column}' contain values not "
                    f"matching pattern '{self.pattern}'."
                )
