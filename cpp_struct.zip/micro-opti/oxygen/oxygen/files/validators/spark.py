"""Collection of validatiors to validate Spark Dataframes"""
from functools import reduce
from operator import or_

from pyspark.sql import functions as F

from oxygen.exceptions import ValidationError
from oxygen.utils.func import deprecated

from .base import Validator


@deprecated(version="2.0.0")
class NotNullValidator(Validator):
    """Check if any value is null"""

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns
        if df.filter(reduce(or_, (F.isnull(col) for col in cols))).first():
            if len(cols) == 1:
                raise ValidationError(f"Column '{col}' contain null values.")

            raise ValidationError("Dataframe contains null values.")


@deprecated(version="2.0.0")
class UniqueValidator(Validator):
    """Check that all values are unique"""

    def __init__(self, unique_cols=None):
        self.unique_cols = unique_cols

    def __call__(self, df, col=None):
        if self.unique_cols:
            cols = self.unique_cols
        else:
            cols = [col] if col else df.columns

        if df.select(*cols).count() != df.select(*cols).dropDuplicates().count():
            if len(cols) == 1:
                raise ValidationError(f"Column '{col}' contain duplicated values.")

            cols_formatted = ", ".join([f"'{col}'" for col in cols])
            raise ValidationError(
                f"Dataframe contains duplicated values "
                f"across columns {cols_formatted}."
            )


@deprecated(version="2.0.0")
class RangeValidator(Validator):
    """Check that comperable values are within range"""

    def __init__(self, start=None, end=None):
        self.start = start
        self.end = end

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns
        if self.start is not None and self.end is not None:
            if df.filter(
                reduce(
                    or_,
                    (
                        (F.col(col) < self.start) | (F.col(col) > self.end)
                        for col in cols
                    ),
                )
            ).first():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values outside "
                        f"of range {self.start} - {self.end}."
                    )

                raise ValidationError(
                    f"Dataframe contains values outside "
                    f"of range {self.start} - {self.end}."
                )

        elif self.start is not None:
            if df.filter(
                reduce(or_, (F.col(col) < self.start for col in cols))
            ).first():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values less than {self.start}."
                    )

                raise ValidationError(
                    f"Dataframe contains values less than {self.start}."
                )

        elif self.end is not None:
            if df.filter(reduce(or_, (F.col(col) > self.end for col in cols))).first():
                if len(cols) == 1:
                    raise ValidationError(
                        f"Column '{col}' contain values higher than {self.end}."
                    )

                raise ValidationError(
                    f"Dataframe contains values higher than {self.end}."
                )
        else:
            raise ValueError("RangeValidator must have a defined range.")


@deprecated(version="2.0.0")
class MinValueValidator(Validator):
    """Check that numeric value is greater than"""

    def __init__(self, limit):
        self.limit = limit

    def __call__(self, df, col=None):
        # Shortcut to RangeValidator with only a lower limit.
        RangeValidator(start=self.limit)(df, col)


@deprecated(version="2.0.0")
class MaxValueValidator(Validator):
    """Check that numeric value is less than"""

    def __init__(self, limit):
        self.limit = limit

    def __call__(self, df, col=None):
        # Shortcut to RangeValidator with only a upper limit.
        RangeValidator(end=self.limit)(df, col)


@deprecated(version="2.0.0")
class RegexValidator(Validator):
    """Validate that value match regex pattern"""

    def __init__(self, pattern):
        self.pattern = pattern

    def __call__(self, df, col=None):
        cols = [col] if col else df.columns

        # Series must be of dtype string for us to
        # apply a regex match on it.
        dtypes = dict(df.dtypes)
        for column in cols:
            if dtypes[column] != "string":
                raise TypeError(
                    f"Column '{column}' must be of dtype 'str' to use RegexValidator."
                )

        # Check if any col does NOT match our regexp.
        if df.filter(
            reduce(or_, (~F.col(column).rlike(self.pattern) for column in cols))
        ).first():
            raise ValidationError(
                f"Column '{col}' contain values not "
                f"matching pattern '{self.pattern}'."
            )
