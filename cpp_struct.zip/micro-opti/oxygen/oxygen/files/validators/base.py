class Validator:
    """Base validator that other validators inherit from.

    Raises:
        ValidatorError is raised if data is invalid.

    """

    def __call__(self, df, col=None):
        raise NotImplementedError
