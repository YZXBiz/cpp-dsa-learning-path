# flake8: noqa
from oxygen.exceptions import ValidationError
