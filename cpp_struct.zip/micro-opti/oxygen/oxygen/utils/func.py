import logging

logger = logging.getLogger(__name__)


class classproperty:
    """
    Decorator like @property that can be on class rather than on instances.

    E.g.

    class F:
        @classproperty
        def fields(cls):
            return cls.__name__

    >> F.fields

    """

    def __init__(self, method=None):
        self.fget = method

    def __get__(self, instance, cls=None):
        return self.fget(cls)

    def getter(self, method):
        self.fget = method
        return self


def deprecated(version=None):
    """
    Decorator to tag a function as deprecated and auto
    log deprecation warning message
    """

    def _decorator(f):
        logger.warning(
            (
                "Function is deprecated no longer supported. "
                "Feature will be removed in version '%s'"
            ),
            version,
        )
        return f

    return _decorator
