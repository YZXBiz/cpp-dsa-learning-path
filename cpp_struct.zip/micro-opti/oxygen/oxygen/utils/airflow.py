import json
from datetime import datetime
from typing import Any, Optional, Union
from urllib.parse import urljoin

import requests

from oxygen.conf.settings import settings


class BaseAirflowClient:
    """
    Client for connecting to the Airflow experimental REST API.
    cf. https://airflow.apache.org/docs/stable/rest-api-ref.html
    """

    def __init__(self) -> None:
        self._base_api_url = urljoin(f"{settings.AIRFLOW_URI}", "api/experimental/")
        self._base_admin_url = urljoin(f"{settings.AIRFLOW_URI}", "admin/")
        self._client_id = settings.AIRFLOW_CLIENT_ID

    def trigger_dag(
        self,
        dag_id: str,
        run_id: Optional[str] = None,
        execution_date: Optional[Union[datetime, str]] = None,
        conf: dict[str, Any] = None,
    ):
        """

        Args:
            dag_id: The DAG id.
            run_id: The run id to trigger the dag with.
            execution_date: YYYY-mm-DDTHH:MM:SS
            conf: A configuration to pass to the dag on trigger

        Returns:
            A dictionary with the json response
        """
        if conf is None:
            conf = {}
        if dag_id == "":
            return {"error": "Invalid dag id"}

        rel_url = f"dags/{dag_id}/dag_runs"
        if execution_date is not None:
            execution_date = (
                execution_date
                if isinstance(execution_date, str)
                else execution_date.strftime("%Y-%m-%dT%H:%M:%S")
            )

        return self._post(
            rel_url,
            run_id=run_id,
            execution_date=execution_date,
            conf=conf,
        )

    def get_dag_runs(self, dag_id):
        rel_url = f"dags/{dag_id}/dag_runs"
        return self._get(rel_url)

    def get_dag_run_state(self, dag_id, execution_date):
        execution_date_fmt = execution_date.strftime("%Y-%m-%dT%H:%M:%S")
        rel_url = f"dags/{dag_id}/dag_runs/{execution_date_fmt}"
        return self._get(rel_url)

    def test(self):
        rel_url = "test"
        return self._get(rel_url)

    def pause_dag(self, dag_id):
        rel_url = f"dags/{dag_id}/paused/true"
        return self._get(rel_url)

    def unpause_dag(self, dag_id):
        rel_url = f"dags/{dag_id}/paused/false"
        return self._get(rel_url)

    def delete_dag(self, dag_id):
        rel_url = f"dags/{dag_id}"
        return self._delete(rel_url)

    def _post(self, relative_url, **kwargs):
        data = json.dumps({k: v for k, v in kwargs.items() if v})
        return self._make_iap_request(relative_url, "POST", data=data)

    def _get(self, relative_url, **kwargs):
        params = json.dumps({k: v for k, v in kwargs.items() if v})
        return self._make_iap_request(relative_url, "GET", params=params)

    def _delete(self, relative_url, **kwargs):
        return self._make_iap_request(relative_url, "DELETE", **kwargs)

    def _make_iap_request(self, relative_url, method, base_url=None, **kwargs):
        """Makes a request to an application protected by Identity-Aware Proxy.

        Arguments:
          - relative_url: Path to fetch
          - method: The request method to use
                  ('GET', 'OPTIONS', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE')
          - base_url: Base URL to use in any HTTP request
          - **kwargs: Any of the parameters defined for the request function:
                    https://github.com/requests/requests/blob/master/requests/api.py
                    If no timeout is provided, it is set to 90 by default.
        Returns:
          The page body, or raises an exception if the page couldn't be retrieved.
        """
        raise NotImplementedError(
            "Missing _make_iap_request definition that defines request methodology"
            " for the cloud vendor."
        )

    def list_dags(self):
        """
        List all dags available.

        **NB: This is not an actual API call, but it probably is the only way to
        get a list of all dags, as list_dags is not yet supported by the experimental
        API.
        Returns:
            A dictionary with stats on dags : For each dag, a list of runs with states.
                {
                    "<dag_id>": [
                        {
                            "state": "<state>",
                            "count": "<count>"
                        },
                        ...
                    ]
                    ...
                }
        """

        rel_url = "airflow/dag_stats"
        return self._make_iap_request(rel_url, "GET", base_url=self._base_admin_url)


class AirflowAPIError(Exception):
    """Raised on Airflow API request failure"""


class GoogleAirflowClient(BaseAirflowClient):
    def _make_iap_request(self, relative_url, method, base_url=None, **kwargs):
        """Makes a request to an application protected by Identity-Aware Proxy.

        Arguments:
          - relative_url: Path to fetch
          - method: The request method to use
                  ('GET', 'OPTIONS', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE')
          - base_url: Base URL to use in any HTTP request
          - **kwargs: Any of the parameters defined for the request function:
                    https://github.com/requests/requests/blob/master/requests/api.py
                    If no timeout is provided, it is set to 90 by default.

        Returns:
          The page body, or raises an exception if the page couldn't be retrieved.
        """
        # pylint: disable=import-outside-toplevel
        from google.auth.transport.requests import Request
        from google.oauth2 import id_token

        timeout = kwargs.pop("timeout", 90)

        if base_url is None:
            base_url = self._base_api_url

        # Obtain an OpenID Connect (OIDC) token from metadata server or using service
        # account.
        open_id_connect_token = id_token.fetch_id_token(Request(), self._client_id)

        headers = {
            "Authorization": f"Bearer {open_id_connect_token}",
            "Cache-Control": "no-cache",
            "Content-Type": "application/json",
        }
        resp = requests.request(
            method,
            urljoin(base_url, relative_url),
            headers=headers,
            timeout=timeout,
            **kwargs,
        )
        if resp.status_code == 403:
            raise AirflowAPIError(
                "Service account does not have permission to "
                "access the IAP-protected application."
            )
        if resp.status_code != 200:
            try:
                error = json.loads(resp.text)["error"]
            except json.JSONDecodeError:
                error = f"Bad response from application: {resp.status_code}"

            raise AirflowAPIError(error)

        return json.loads(resp.text)
