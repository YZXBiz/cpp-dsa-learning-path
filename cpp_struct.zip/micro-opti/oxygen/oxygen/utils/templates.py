import os

from jinja2 import Environment, PackageLoader


def create_files_from_templates(files, **context):
    env = Environment(loader=PackageLoader("oxygen", "templates"))
    for file_path, template in files.items():
        template = env.get_template(template)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, mode="w", encoding="utf-8") as handler:
            handler.write(template.render(**context))
