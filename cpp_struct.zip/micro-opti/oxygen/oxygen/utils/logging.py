import logging

from termcolor import colored


def log_multiline(lines: list[str], level: int):
    logger = logging.getLogger(__name__)
    width = max(len(row) for row in lines)
    # Add start block of # symbols
    message = ("\n" + "#" * width) * 3 + "\n"

    for line in lines:
        message += f"{line}\n"

    # Remove final line break.
    message = message[:-2]
    # Add end block of # symbols
    message += ("\n" + "#" * width) * 3 + "\n"
    logger.log(level=level, msg=message)


class ColorHandler(logging.StreamHandler):
    """A color log handler.
    The ``colors`` parameter is optional, and you can use any ANSI color.
      * Black
      * Red
      * Green
      * Yellow
      * Blue
      * Magenta
      * Cyan
      * White
    The default colors are:
      * debug: magenta
      * info: cyan
      * warning: yellow
      * error: red
      * critical: red
    """

    def __init__(self, stream=None, colors=None):
        logging.StreamHandler.__init__(self, stream)
        colors = colors or {}
        self.colors = {
            "critical": colors.get("critical", "red"),
            "error": colors.get("error", "red"),
            "warning": colors.get("warning", "yellow"),
            "info": colors.get("info", "cyan"),
            "debug": colors.get("debug", "magenta"),
        }

    def _get_color(self, level):
        if level >= logging.CRITICAL:
            return self.colors["critical"]  # pragma: no cover
        if level >= logging.ERROR:
            return self.colors["error"]  # pragma: no cover
        if level >= logging.WARNING:
            return self.colors["warning"]  # pragma: no cover
        if level >= logging.INFO:
            return self.colors["info"]
        if level >= logging.DEBUG:  # pragma: no cover
            return self.colors["debug"]  # pragma: no cover

        return None  # pragma: no cover

    def format(self, record: str) -> str:
        """The handler formatter.
        Args:
            record: The record to format.
        Returns:
            The record formatted as a string.
        """
        text = logging.StreamHandler.format(self, record)
        color = self._get_color(record.levelno)
        return colored(text, color)
        # return click.style(text, color)


class LazyFileHandler(logging.FileHandler):
    """
    FileHandler that evaluates the log file name using a function
    called the first time a log message is written.

    This allows us to use log files named by for example date or
    run ids that is not known when the log is initiated but only
    when the log message is written.

    """

    def __init__(self, filename, mode="a", encoding=None):
        self.callback = filename
        self.mode = mode
        self.encoding = encoding
        # We don't open the stream, but we still need to call the
        # Handler constructor to set level, formatter, lock etc.
        # logging.Handler.__init__(self)
        super().__init__(filename, mode, encoding, delay=True)
        self.stream = None

    @property
    def baseFilename(self):
        return self.callback()
