import logging

from git import InvalidGitRepositoryError, Repo

logger = logging.getLogger(__name__)


def get_git_label(fallback=True):
    """Attempts to get a descriptive string of this git state.

    This could either be a git branch, a git tag or a git commit.

    """
    return (
        get_branch(fallback=fallback)
        or get_tag(fallback=fallback)
        or get_commit(fallback=fallback)
    )


def get_tag(fallback=True):
    """Get the active tag for this commit"""
    try:
        repo = Repo("../")
        tag = next((t for t in repo.tags if t.commit == repo.head.commit), None)
    except InvalidGitRepositoryError as e:
        if not fallback:
            raise e
        logger.warning("Git repository was not found.")

    return tag


def get_commit(fallback=True):
    """Get the current commit hash"""
    try:
        repo = Repo("../")
        commit = repo.head.commit
    except InvalidGitRepositoryError as e:
        if not fallback:
            raise e
        logger.warning("Git repository was not found.")

    return commit


def get_branch(fallback=True):
    """Get the current branch.

    Attempts to get the current git branch, if git repository is not
     available, it fallsback on `master`, unless otherwise specified.

    """
    try:
        branch = Repo("../").active_branch.name
    except TypeError:
        # If we are in a git repository, but in a detached state
        # so no active branch exists.
        branch = None
    except InvalidGitRepositoryError as e:
        if not fallback:
            raise e
        logger.warning("Git repository was not found, using fallback tag.")
        branch = "master"

    return branch
