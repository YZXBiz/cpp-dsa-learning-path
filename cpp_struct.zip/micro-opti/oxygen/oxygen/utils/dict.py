from collections.abc import Iterator
from datetime import datetime
from typing import Any, Optional


def merge(
    a: dict[Any, Any],
    b: dict[Any, Any],
    path: Optional[list[str]] = None,
    allow_new_key: bool = True,
):
    """Merge dictionaries in a nested manner.

    Args:
        a: Dict in which the merge is done
        b: The second dict
        path: Full list of parent keys
        allow_new_key: Whether keys present in `b` but not in `a` should be allowed

    Given `a` is {"a": 1, "b": {"foo": 1}}
    Given `b` is {"b": {"bar": 2}}
    Result should be {"a": 1, "b": {"foo": 1, "bar": 2}}

    """
    path = path or []
    a = {} if a is None else a
    b = {} if b is None else b

    for key in b:
        if key in a:
            # For float and int, cast both to float.
            if (
                a[key] is not None
                and b[key] is not None
                and (
                    (isinstance(a[key], int) and isinstance(b[key], float))
                    or (isinstance(a[key], float) and isinstance(b[key], int))
                )
            ):
                a[key] = float(a[key])
                b[key] = float(b[key])

            # Sanity check that we don't merge different types.
            if (
                a[key] is not None
                and b[key] is not None
                and not isinstance(a[key], type(b[key]))
            ):
                raise ValueError(
                    f"Conflicting types '{a[key].__class__.__name__}' and "
                    f"'{b[key].__class__.__name__}' at '{'.'.join(path + [str(key)])}'"
                )

            if isinstance(a[key], dict) and isinstance(b[key], dict):
                merge(a[key], b[key], path + [str(key)], allow_new_key)
            else:
                a[key] = b[key]
        elif not allow_new_key:
            raise ValueError(
                f"Key '{'.'.join(path + [str(key)])}' missing in the source dictionary"
            )
        else:
            a[key] = b[key]

    return a


def dotted_keys_to_dict(key_vals: Iterator[tuple]):
    """Construct a nested dictionary from one with dot-separated keys.

    e.g. {a.b.c: d} --> {a: {b: {c: d}}}
    e.g. {a: b} --> {a: b}

    Args:
        key_vals: List of tuples, each containing a possibly-dotted
                  key and a corresponding value.

    Returns:
        single dictionary containing all keys, split and nested.

    """
    patch: dict[str, Any] = {}

    for key, value in key_vals:
        parent = patch
        subkeys = key.split(".")

        # Move the parent down to the smallest encompassing dict
        # for the final subkey.  If the parent does not contain
        # an intermediate subkey, initialize the dict and then
        # continue looping.

        for subkey in subkeys[:-1]:
            if subkey in parent:
                parent = parent[subkey]
            else:
                parent[subkey] = {}
                parent = parent[subkey]

        # Attempt to parse the value to an number or a date
        try:
            value = float(value)
        except ValueError:
            try:
                # pylint: disable=redefined-variable-type
                value = datetime.strptime(value, "%Y-%m-%d").date()
            except ValueError:
                pass

        # With parent being the smallest encompassing dict,
        # set the value for the last subkey.

        subkey = subkeys[-1]
        parent[subkey] = value

    return patch
