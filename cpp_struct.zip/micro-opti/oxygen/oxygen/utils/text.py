import re
import unicodedata

from oxygen.exceptions import ValidationError


def slugify(value, allow_unicode=False):
    """Convert a string to a slug.

    E.g. converts `Hello World` to `hello-world` or
    `feature/foo-bar` to `feature-foo-bar`.

    """
    value = str(value)
    if allow_unicode:
        value = unicodedata.normalize("NFKC", value)
    else:
        value = (
            unicodedata.normalize("NFKD", value)
            .encode("ascii", "ignore")
            .decode("ascii")
        )
    return re.sub(r"[^\w]", "-", value.lower()).strip("-")


def validate_slug(k, raises=True, max_length=250):
    """Validate string format of a slug.

    A slug is a lowercase string without whitespaces.
    E.g. "hello-world".

    """
    SLUG_REGEX = re.compile(r"^[a-z0-9-_]+$")
    try:
        if not isinstance(k, str):
            raise ValidationError("The key has to be a string")
        if len(k) > max_length:
            raise ValidationError(
                f"The slug has to be less than {max_length} characters"
            )
        if not SLUG_REGEX.match(k):
            raise ValidationError(
                f"The slug '{k}' has to be made up of lowercase "
                "alphanumeric characters and dashes exclusively."
            )
    # If `raises` is set to False, we simply return False
    # on failed validation rather than raising an error.
    except ValidationError:
        if raises:
            raise
        return False
    return True
