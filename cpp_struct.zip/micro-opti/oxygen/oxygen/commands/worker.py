import logging

from celery import Celery

from oxygen.commands.cli import cli
from oxygen.conf.settings import settings
from oxygen.utils.loading import LazyObject

from .dag import dag_command

logger = logging.getLogger(__name__)


def create_celery():
    """
    Factory function to create Celery app.

    Wrapped in function call to avoid eager evaluation
    of the lazy `settings` object.

    """
    app = Celery("oxygen")
    app.config_from_object(settings, namespace="CELERY")
    app.autodiscover_tasks()
    app.conf.task_routes = {
        "oxygen.*": {
            "queue": (
                settings.WORKER_QUEUE if hasattr(settings, "WORKER_QUEUE") else "oxygen"
            )
        },
    }
    return app


celery = LazyObject(create_celery)


@celery.task(name="oxygen.run_dag")
def run_dag(*args, **kwargs):
    """Celery task that can be used to trigger runs"""
    dag_command(*args, **kwargs)


@cli.group()
def worker():
    """Group for all airflow commands"""


@worker.command()
def start():
    """Start Celery worker"""
    queue = settings.WORKER_QUEUE if hasattr(settings, "WORKER_QUEUE") else "oxygen"
    worker_instance = celery.Worker(queues=[queue])
    worker_instance.start()
