import datetime
import logging
import os
import re
from io import StringIO
from typing import Optional

import click
from git import InvalidGitRepositoryError
from jinja2 import Environment, FileSystemLoader, PackageLoader

from oxygen.commands.cli import cli
from oxygen.conf.settings import settings
from oxygen.exec.task import Sequential
from oxygen.utils.git import get_git_label
from oxygen.utils.loading import import_string
from oxygen.utils.text import slugify

logger = logging.getLogger(__name__)


@cli.group()
def airflow():
    """Group for all airflow commands"""


@airflow.command()
@click.argument("path", type=str, required=True)
@click.argument("dag", type=str, required=False)
@click.option("--branch", "-b", type=str, help="The branch to deploy the dags to")
def deploy(path: str, dag: Optional[str] = None, branch: Optional[str] = None):
    """Command to deploy DAG to Airflow.

    Deploy an Oxygen DAG by label if provided by `dag` or
    deploy all registered DAG's as Airflow DAG's.

    """
    # pylint: disable=import-outside-toplevel
    from oxygen.exec.dag import REGISTRY

    if dag and dag not in REGISTRY:
        raise KeyError(f"DAG '{dag}' was not found in DAG registry.")

    try:
        label = branch or get_git_label(fallback=False)
    except InvalidGitRepositoryError:
        label = click.prompt(
            "No valid Git Repository was found. Please provide the name of "
            "your current branch to deploy your dag(s) to",
            type=str,
        )

    # If dag is not set, then include all dags.
    dags = (
        [dag]
        if dag
        else (
            list(REGISTRY.keys())
            if label in {"develop", "master"}
            else [import_string(d).name for d in settings.AIRFLOW_DEPLOY_DAGS]
        )
    )

    for dag_key in dags:
        DAG = REGISTRY[dag_key]
        logger.debug("Deploying DAG '%s' with label '%s' to Airflow.", dag_key, label)
        deploy_airflow(dag=DAG(), git_label=label, path=path)


def deploy_airflow(dag, git_label, path):
    """Deploy dag to airflow bucket"""
    label = dag.label or dag.__class__.__name__.lower()
    dag_label = get_dag_label_deploy(git_label, label)
    if settings.AIRFLOW_DAG_PREFIX:
        dag_label = f"{settings.AIRFLOW_DAG_PREFIX}_{dag_label}"
    git_tag = slugify(git_label)

    # Add custom filter to environment
    _, template = get_jinja(dag=dag)

    file_path = os.path.join(path, f"{dag_label}.py")

    dag_links = Sequential(*dag.inject_tasks()).links

    AirflowStorage = import_string(settings.AIRFLOW_STORAGE_BACKEND)
    airflow_storage = AirflowStorage(settings.AIRFLOW_BUCKET, storage_root="/")

    airflow_storage.touch(
        file_path,
        StringIO(
            template.render(
                **{
                    "dag": dag,
                    "dag_label": dag_label,
                    "links": dag_links,
                    "image": f"{settings.AIRFLOW_IMAGE}:{git_tag}",
                    "pre_script": settings.AIRFLOW_PRE_SCRIPT,
                    "affinity": settings.AIRFLOW_KUBERNETES_AFFINITY,
                    "timestamp": datetime.datetime.utcnow().strftime(
                        "%Y-%m-%d_%H:%M:%S"
                    ),
                }
            )
        ),
    )


def get_jinja(dag):
    """Get the correct jinja environment and template.

    Users might want to override template for airflow DAGs.
    This function allow users to customize airflow template on
    either the DAG or the Settings object.

    Returns:
        Environment, Template

    """
    if dag.extra_options.get("airflow_template"):
        print(dag.extra_options)
        env = Environment(loader=FileSystemLoader(settings.BASE_DIR))
        env.filters["to_identifier"] = to_identifier
        template = env.get_template(dag.extra_options.get("airflow_template"))
    elif settings.AIRFLOW_TEMPLATE:
        env = Environment(loader=FileSystemLoader(settings.BASE_DIR))
        env.filters["to_identifier"] = to_identifier
        template = env.get_template(settings.AIRFLOW_TEMPLATE)
    else:
        env = Environment(loader=PackageLoader("oxygen", "templates/airflow"))
        env.filters["to_identifier"] = to_identifier
        template = env.get_template("dag.j2")

    return env, template


def to_identifier(value):
    """Custom filter that convert a string to a python identifier"""
    if not value:
        return None

    # Remove none alphanumerical or hyphen/dashes.
    value = re.sub(r"[^a-zA-Z0-9_-]", "", value)
    # Replace hyphen and whitespace with underscore.
    value = re.sub(r"[\s-]", "_", value)

    if not value.isidentifier():
        raise ValueError(f"'{value}' is not a valid Python identifier.")

    return value


def get_dag_label_deploy(branch: str, label: str):
    """Retrieve the full dag name used for deployment to Airflow

    Args:
        branch: The deployment branch
        label: The DAG label

    Returns:

    """

    git_tag = slugify(branch)
    dag_label = f"{label}_{git_tag}"

    return dag_label
