import click


@click.group()
def cli():
    """Base group that all commands extend from."""
