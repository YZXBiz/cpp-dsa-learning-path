import logging
import os
from functools import reduce
from io import StringIO
from pathlib import Path
from typing import Any, Optional

import click
import yaml

from oxygen.commands.cli import cli
from oxygen.conf.context import Context
from oxygen.conf.context import context as oxy_context
from oxygen.conf.context import context_manager
from oxygen.conf.settings import settings
from oxygen.exec.executors import LocalExecutor
from oxygen.exec.task import Task
from oxygen.files.storages import storage
from oxygen.utils.dict import merge
from oxygen.utils.loading import import_string

logger = logging.getLogger(__name__)


@cli.command()
@click.option(
    "--copy-from",
    "-cp",
    help="Start a new run with a new run id by copying data from another run folder.",
)
@click.option("--task", "-t", help="Label of task to start run from.")
@click.option("--context", "-c", help="Load existing context from path.")
@click.option("--context_override", default = None, help="json file to override parameters")
@click.option("--patch", "-p", multiple=True)
@click.option(
    "--refreshcontext",
    default=False,
    is_flag=True,
    help="Update the context with latest config file.",
)
@click.option("--args", "-a", multiple=True)
@click.option(
    "--local",
    default=False,
    is_flag=True,
    help="Execute run using local executor.",
)
@click.argument("label", type=str, required=True)
def dag(**kwargs):
    """
    Wrapper of dag_command
    """
    dag_command(**kwargs)


def dag_command(
    label: str,
    local: bool = False,
    args: Optional[list[str]] = None,
    refreshcontext: bool = False,
    patch: Optional[list[str]] = None,
    context: Optional[str] = None,
    task: Optional[str] = None,
    copy_from: Optional[str] = None,
    **kwargs
):
    """Run a dag by its label.

    Arguments:
        label: The label of the dag that we want to run.
        local: Flag forcing LocalExecutor
        args: Arguments passed on to the runner.
        refreshcontext: Force refresh of the context that is reused
                        with the --context option.
        patch: List of paths to patch files to override context with.
        context: Path to old context we want to reuse.
        task: Run a DAG starting from a specific task instead of start.
        copy_from: Other run folder to copy into new run folder.

    """
    # pylint: disable=import-outside-toplevel
    from oxygen.exec.dag import REGISTRY

    try:
        DAG = REGISTRY[label]
    except KeyError as exc:
        logger.warning("Available dags are %s", ",".join(REGISTRY.keys()))
        raise KeyError(f"A DAG with the label '{label}' could not be found.") from exc

    if kwargs["context_override"]:
        with open(os.path.abspath(kwargs["context_override"]),'r') as f:
            DAG.context = yaml.load(f, Loader=yaml.SafeLoader)
    
    args = args or []
    Executor = import_string(settings.EXECUTOR_BACKEND) if not local else LocalExecutor
    dag_instance = DAG()

    # Handle option where we start a new run by copying
    # another run first.
    if copy_from:
        assert not (
            copy_from and context
        ), "Only one of `--copy-from` or `--context` can be used."
        _create_run_from(src_path=copy_from)
        context = str(Path(oxy_context.meta.run_folder) / "context.yaml")

    # If we are replaying from a specific task, get subset of tasks.
    dag_instance.tasks = (
        _slice_tasks(task, dag_instance.tasks) if task else dag_instance.tasks
    )
    _load_context(dag_instance, refreshcontext, context, patch)

    # Convert any extra arguments passed in by -a to a kwarg dictionary
    # to be passed to the Executor.
    Executor().run_dag(dag_instance, **_get_kwargs(args))


def _get_kwargs(args: list[str]):
    """Convert strings of `=` separated key value pairs into a dictionary"""
    if any("=" not in arg for arg in args):
        raise ValueError("Extra arguments must be a key value mapping separated by '='")
    return dict([arg.split("=") for arg in args])


def _slice_tasks(task: str, tasks: list[Task]):
    """Slice a list of tasks by a task label"""
    for index, t in enumerate(tasks):
        if task == (t.label or t.__name__.lower()):
            break
    else:
        raise ValueError(f"Task '{task}' was not found in DAG.")

    return tasks[index:]


def _load_context(
    dag_instance,
    refreshcontext: bool = False,
    context: Optional[str] = None,
    patch: Optional[list[str]] = None,
):
    # Convert list of paths to a single dictionary of merged
    # yaml files.
    def _load_yaml(file_path):
        with storage.open(file_path) as stream:
            return yaml.load(stream, Loader=yaml.SafeLoader)

    patch_dict: dict[str, Any] = (
        {}
        if not patch
        else reduce(
            merge,
            [_load_yaml(path) for path in patch],
        )
    )
    assert context is None or os.path.splitext(context)[1] in {
        ".yaml"
    }, "`context` must be a path to a context.yaml file."
    if context and not storage.exists(context):
        logger.info("Context %s do not exist, creating new.", context)
        Context.create_context(
            meta=context_manager.get_run_meta(
                run_id=os.path.basename(os.path.dirname(context.rstrip(os.sep))),
                run_folder=os.path.dirname(context.rstrip(os.sep)),
            )
        )

    if context:
        # If context file path is passed in, then load
        # context from disk.
        Context.create_context(config=context_manager.load_config(context))

    if refreshcontext:
        # Use meta data from loaded context, but populate the
        # rest with new config.
        Context.create_context(
            patch={"meta": oxy_context.to_dict()["meta"]}, force=True
        )

    if patch_dict:
        Context.create_context(
            config=oxy_context.to_dict(), patch=patch_dict, force=True
        )

    # Only apply the dag.context patch to the context if we asked
    # for a refresh, or if we are not providing any context to load from
    # and we are creating a brand new, fresh context.
    if (refreshcontext and dag_instance.context) or (
        not context and dag_instance.context
    ):
        Context.create_context(
            config=oxy_context.to_dict(), patch=dag_instance.context, force=True
        )


def _create_run_from(src_path: str):
    """
    Create a new run with a new run id and dir but populate
    it with files from another run folder.
    """
    storage.cp(src_path, oxy_context.meta.run_folder, recursive=True, overwrite=True)
    context_path = str(Path(oxy_context.meta.run_folder) / "context.yaml")
    with storage.open(context_path) as stream:
        config = yaml.load(stream, Loader=yaml.SafeLoader)
        config["meta"] = oxy_context.meta.to_dict()

    storage.touch(context_path, StringIO(yaml.dump(config)))
    Context.create_context(config=context_manager.load_config(context_path))
