import os
from pathlib import Path

import click

from oxygen.commands.cli import cli
from oxygen.utils.templates import create_files_from_templates


@cli.command()
@click.argument("name", type=str, required=True)
@click.argument("path", type=str, required=False, default=".")
@click.option(
    "--overwrite",
    default=False,
    is_flag=True,
    help="If we should overwrite existing files.",
)
def startproject(name, path, overwrite):
    """Instantiate a project"""
    name = name.strip("/")
    dest = str(Path(path) / name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Path '{path}' must exist before creating a project.")

    if os.path.exists(dest) and not overwrite:
        raise FileExistsError(f"Path '{dest}' already exists.")

    files = {
        str(Path(dest) / "run.py"): "project/run.j2",
        str(Path(dest) / "data" / ".gitkeep"): "generic/empty.j2",
        str(Path(dest) / "configs" / "__init__.py"): "generic/empty.j2",
        str(Path(dest) / "configs" / "settings.py"): "project/settings.j2",
        str(Path(dest) / "configs" / "config.yaml"): "project/config.j2",
    }

    create_files_from_templates(files, name=name)
