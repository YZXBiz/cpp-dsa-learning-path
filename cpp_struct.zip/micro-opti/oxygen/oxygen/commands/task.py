import logging
import os
from datetime import datetime
from io import BytesIO
from pathlib import Path

import click
import yaml

from oxygen.commands.cli import cli
from oxygen.conf.context import Context, context_manager
from oxygen.conf.settings import settings
from oxygen.files.storages import storage
from oxygen.files.storages.local import RepoReadOnlyStorage
from oxygen.utils.dict import merge

logger = logging.getLogger(__name__)


@cli.command()
@click.argument("task_label", type=str, required=True)
@click.option("--run-folder", "-f", help="Run folder to use.")
@click.option("--config", "-c", help="Config path to load patch config from.")
def task(**kwargs):
    task_command(**kwargs)


def task_command(task_label, run_folder=None, config=None):
    """Command to run a single task.

    Used by for example Kubernetes/Airflow to run a
    single task at a time on each Pod rather than
    executing the full DAG.

    """
    # pylint: disable=import-outside-toplevel
    from oxygen.exec.task import REGISTRY

    if task_label not in REGISTRY:
        raise KeyError(f"Task '{task}' was not found in task registry.")

    if run_folder is not None and run_folder.startswith("None"):
        run_folder = None
    if config is not None and config.startswith("None"):
        config = None

    # If a run folder argument is given, then reuse any
    # existing context or generate a new context at given path.
    if run_folder:
        context_path = str(Path(run_folder) / "context.yaml")
        if not storage.exists(context_path):
            run_id = os.path.basename(run_folder.rstrip(os.sep))
            # Get the base config and the base patch
            base_config = context_manager.load_config(
                settings.CONFIG_PATH, RepoReadOnlyStorage()
            )

            patch = {
                "meta": {
                    "run_id": run_id,
                    "run_folder": run_folder,
                    "created_at": datetime.utcnow(),
                }
            }

            patch = (
                merge(
                    patch,
                    context_manager.load_config(settings.CONFIG_PATCH, storage),
                    allow_new_key=True,
                )
                if settings.CONFIG_PATCH
                else patch
            )

            # If a config path is given, we add additional configurations
            # to our patch variable. Meaning we'll patch our base config with
            # the config file that user defined when calling command.
            if config:
                if storage.exists(config):
                    patch_config = context_manager.load_config(config)
                    patch = merge(patch_config, patch, allow_new_key=True)
                else:
                    logger.info("'%s' file do not exist, skipping patch.", config)

            # Generate the final context based on the patch and config.
            context = Context.create_context(config=base_config, patch=patch)

            # Store updated context on disk.
            logger.debug(
                "Creating context at '%s' \n"
                "Run folder at '%s' does not exist yet. Creating...",
                context_path,
                run_folder,
            )
            storage.touch(
                context_path,
                BytesIO(bytes(yaml.dump(context.to_dict()).encode("utf-8"))),
            )
        else:
            # If context already exists, just load it.
            Context.create_context(context_manager.load_config(context_path))
            logger.debug("Context at path '%s' already exists.", context_path)

    # Get our task from our task registry by label
    # and execute the task.
    Task = REGISTRY[task_label]
    Task().run()
