import os
from pathlib import Path

import click

from oxygen.commands.cli import cli
from oxygen.utils.templates import create_files_from_templates


@cli.command()
@click.argument("name", type=str, required=True)
@click.argument("path", type=str, required=False, default=".")
@click.option(
    "--overwrite",
    default=False,
    is_flag=True,
    help="If we should overwrite existing files.",
)
def startmodule(name, path, overwrite):
    """Instantiate a project module"""
    name = name.strip("/")
    dest = str(Path(path) / name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Path '{path}' must exist before creating a module.")

    if os.path.exists(dest) and not overwrite:
        raise FileExistsError(f"Path '{dest}' already exists.")

    files = {
        str(Path(dest) / "__init__.py"): "generic/empty.j2",
        str(Path(dest) / "commands.py"): "module/commands.j2",
        str(Path(dest) / "dags.py"): "module/dags.j2",
        str(Path(dest) / "schemas.py"): "module/schemas.j2",
        str(Path(dest) / "tasks.py"): "module/tasks.j2",
        str(Path(dest) / "tests.py"): "module/tests.j2",
    }

    create_files_from_templates(files, name=name)
