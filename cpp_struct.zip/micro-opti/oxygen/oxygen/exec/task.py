import logging
import sys
import time
from collections import defaultdict
from collections.abc import Callable
from multiprocessing import Process
from pathlib import Path
from typing import Optional

from oxygen.conf.context import context
from oxygen.files.storages import storage
from oxygen.utils.logging import log_multiline
from oxygen.utils.text import validate_slug

logger = logging.getLogger(__name__)
REGISTRY: dict[str, Callable] = {}


class Task:
    """A Task contains logic for a single step in a Dag"""

    label: Optional[str] = None

    def __init_subclass__(cls, **kwargs):
        """Register the class in a REGISTRY to be used from cli"""
        super().__init_subclass__(**kwargs)
        name = cls.label or cls.__name__.lower()
        validate_slug(name)  # Raises ValidationError if fail.
        if name in REGISTRY:
            raise KeyError(f"REGISTRY already contains a Task labeled '{name}'.")

        REGISTRY[name] = cls

    def _run(self) -> None:
        """
        Wrapper around the run function for e.g. benchmarking
        """
        task_start = time.time()

        logger.info(
            "\n\n%s\n%s\n%s",
            ("-" * 88),
            (self.label or self.__class__.__name__).center(88),
            ("-" * 88),
        )
        self.run()

        task_end = time.time()
        # pylint: disable=consider-using-f-string
        elapsed = "{0:,.2f}".format(task_end - task_start)

        nchar = len(elapsed)

        logger.info("\n\n%s %ss ----\n", ("-" * (81 - nchar)), elapsed)

    def run(self) -> None:
        """Entrypoint of the task"""
        raise NotImplementedError()


class MultiTask(Task):
    """
    An abstract Task to represent a group of tasks to be executed in a certain way.

    """

    def __init__(self, first_task, *tasks):
        super().__init__()
        self.tasks = (first_task,) + tasks
        self.links = defaultdict(list)
        for t in filter(lambda task: not isinstance(task, MultiTask), self.tasks):
            self.links[t] = []
        self.populate_links()

    def _run(self):
        return self.run()

    def populate_links(self) -> None:
        """
        Generate the adjacency list of the graph represented by this MultiTask.

        """
        for multitask in filter(lambda task: isinstance(task, MultiTask), self.tasks):
            for task, next_tasks in multitask.links.items():
                self.links[task].extend(next_tasks)

    def get_sources_and_sinks(self) -> tuple[list[Task], list[Task]]:
        """
        Retrieve the lists of sources and sinks for the subgraph
        represented by this task.

        Returns:
            A tuple consisting of a list of sources and a list of sinks.
        """
        raise NotImplementedError()


class Sequential(MultiTask):
    """
    A group of tasks to be executed sequentially.

    """

    def run(self):
        for task in self.tasks:
            instance = task if isinstance(task, MultiTask) else task()
            instance._run()

    def populate_links(self) -> None:
        """
        Generate the adjacency list of the graph represented by this Sequential
        MultiTask.

        Besides generating the internal links of the tasks in this group, we need
        to generate the inter-links between any two consecutive tasks, as they are
        run sequentially.
        """
        super().populate_links()

        for task, next_task in zip(self.tasks, self.tasks[1:]):
            if isinstance(task, MultiTask):
                _, task_sinks = task.get_sources_and_sinks()
            else:
                task_sinks = [task]

            if isinstance(next_task, MultiTask):
                next_task_sources, _ = next_task.get_sources_and_sinks()
            else:
                next_task_sources = [next_task]

            # Connect sinks to next sources

            for sink in task_sinks:
                for source in next_task_sources:
                    self.links[sink].append(source)

            for source in next_task_sources:
                _ = self.links[source]  # We need source in the set of keys

    def get_sources_and_sinks(self) -> tuple[list[Task], list[Task]]:
        if isinstance(self.tasks[0], MultiTask):
            sources, _ = self.tasks[0].get_sources_and_sinks()
        else:
            sources = [self.tasks[0]]

        if isinstance(self.tasks[-1], MultiTask):
            _, sinks = self.tasks[-1].get_sources_and_sinks()
        else:
            sinks = [self.tasks[-1]]

        return sources, sinks


class Concurrent(MultiTask):
    """
    A group of tasks to be executed concurrently.

    """

    def run(self):
        processes = []
        for task in self.tasks:
            instance = task if isinstance(task, MultiTask) else task()
            target_function = instance._run
            process = Process(target=target_function)
            processes.append(process)
            process.start()

        for process in processes:
            process.join()

    def get_sources_and_sinks(self) -> tuple[list[Task], list[Task]]:
        sources, sinks = [], []

        for task in self.tasks:
            if not isinstance(task, MultiTask):
                sources.append(task)
                sinks.append(task)
            else:
                task_sources, task_sinks = task.get_sources_and_sinks()
                sources.extend(task_sources)
                sinks.extend(task_sinks)

        return sources, sinks


class BootstrapTask(Task):
    """
    Optional task to be used in beginning of DAG
    for bootstrap functionality.
    """

    def run(self) -> None:
        # Init run directory.
        context_path = str(Path(context.meta.run_folder) / "context.yaml")
        if not storage.exists(context_path):
            storage.mkdir(context.meta.run_folder, make_parents=True)

        log_multiline(
            [
                f"Python version: {sys.version.split()[0]}",
                f"Run ID: {context.meta.run_id}",
                f"Run folder: {context.meta.run_folder}",
                f"Created At: {context.meta.created_at}",
            ],
            level=logging.INFO,
        )
