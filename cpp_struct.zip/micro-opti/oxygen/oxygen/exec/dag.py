import logging
from collections.abc import Callable
from typing import Any, Optional

from oxygen.conf.settings import settings
from oxygen.utils.loading import import_string
from oxygen.utils.text import validate_slug

from .task import Task

logger = logging.getLogger(__name__)
REGISTRY: dict[str, Callable] = {}


class DAG:
    """Directed Acyclic Graph definition.

    Define a set of tasks that are executed in a specific
    order within the directed graph.

    """

    ignore_inject_tasks: bool = False
    tasks: list[Task] = []
    label: Optional[str] = None
    context: Optional[dict[str, Any]] = None
    extra_options: dict[str, Any] = {}

    def __init_subclass__(cls, **kwargs):
        """Register the class in a REGISTRY to be used from cli"""
        super().__init_subclass__(**kwargs)
        name = cls.label or cls.__name__.lower()
        validate_slug(name)  # Raises ValidationError if fail.
        if name in REGISTRY:
            raise KeyError(f"REGISTRY already contains a DAG labeled '{name}'.")

        cls.name = name
        REGISTRY[name] = cls

    def inject_tasks(self) -> list[Task]:
        """Inject settings tasks into the list of user defined tasks.

        This could include tasks such as Boostrapping, Ending, Diagnostics etc
        that is injected in the beginning or end of dag.

        """
        tasks = self.tasks
        if self.ignore_inject_tasks:
            return tasks

        if settings.START_TASK:
            tasks.insert(0, import_string(settings.START_TASK))

        if settings.END_TASK:
            tasks.append(import_string(settings.END_TASK))

        return tasks
