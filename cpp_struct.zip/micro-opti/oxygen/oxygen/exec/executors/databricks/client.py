import logging
import os
import time
from base64 import standard_b64decode, standard_b64encode
from collections.abc import Generator
from contextlib import contextmanager
from io import BytesIO
from typing import Any, Optional

import requests

from oxygen.conf.settings import settings
from oxygen.exceptions import RunError
from oxygen.utils.func import deprecated

logger = logging.getLogger(__name__)


@deprecated(version="2.0.0")
class DatabricksClient:
    """Client to interact with the Azure Databricks REST API"""

    BYTES_LIMIT = 2**20  # 1 MB chunks, limited by databricks API.

    def __init__(self):
        self.url = f"https://{settings.DATABRICKS_HOSTNAME}/api/2.0"
        self.headers = {
            "Authorization": (
                b"Basic "
                + standard_b64encode(
                    (b"token:" + bytes(settings.DATABRICKS_TOKEN.encode("utf-8")))
                )
            )
        }

    @contextmanager
    def create_handle(
        self, file_path: str, overwrite: bool = True
    ) -> Generator[int, None, None]:
        """Context manager for opening a file handle to write to.

        Manager automatically takes care of closing the handle
        in the end of writing or in case of failure.

        """
        res = requests.post(
            url=f"{self.url}/dbfs/create",
            json={
                "path": f"/{file_path.lstrip('/')}",
                "overwrite": overwrite,
            },
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()

        content = res.json()
        if "handle" not in content:
            raise requests.exceptions.HTTPError(
                "Handle request did not response with a 'handle'."
            )

        try:
            yield content["handle"]
        finally:
            logger.debug("Closing handle %s", content["handle"])
            res = requests.post(
                url=f"{self.url}/dbfs/close",
                json={"handle": content["handle"]},
                headers=self.headers,
                timeout=90,
            )
            res.raise_for_status()

    def read(self, file_path: str) -> BytesIO:
        assert file_path.startswith("dbfs:/"), "File path must use the dbfs:/ schema"

        res = requests.get(
            f"{self.url}/dbfs/read",
            json={"path": file_path.lstrip("dbfs:")},
            headers=self.headers,
            timeout=90,
        )
        try:
            res.raise_for_status()
        except requests.exceptions.HTTPError as exc:
            if exc.response.status_code == 404:
                raise FileNotFoundError(
                    f"File at '{file_path}' was not found."
                ) from exc
            raise

        return BytesIO(standard_b64decode(res.json()["data"]))

    def add_block(self, chunk: bytes, handle: int) -> None:
        """Write chunk to a block of data.

        Must first create a handle using the
        create_handle function.

        """
        res = requests.post(
            f"{self.url}/dbfs/add-block",
            json={"data": standard_b64encode(chunk).decode(), "handle": handle},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()

    def get_file_info(self, path: str) -> Optional[dict[str, Any]]:
        """Get file info from the Databricks REST API.

        The file info received contains data such as if
        the path exists or not, if its a file, if its a dir and more.

        """
        res = requests.get(
            f"{self.url}/dbfs/list",
            json={"path": path},
            headers=self.headers,
            timeout=90,
        )

        content = res.json()
        return content if "errors" not in content else None

    def get_cluster_info(self, cluster_id: str):
        """Get the state of a cluster"""
        res = requests.get(
            url=f"{self.url}/clusters/get",
            json={"cluster_id": cluster_id},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()
        return res.json()

    def get_job_info(self, run_id: int):
        """Get state of an existing job"""
        res = requests.get(
            url=f"{self.url}/jobs/runs/get",
            json={"run_id": run_id},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()
        return res.json()

    def get_job_list(self, job_id: int):
        res = requests.get(
            url=f"{self.url}/jobs/runs/list",
            json={"job_id": job_id},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()
        return res.json()

    def get_library_statuses(self, cluster_id: str):
        """Get the status of all installations going on in a cluster"""
        res = requests.get(
            url=f"{self.url}/libraries/cluster-status",
            json={"cluster_id": cluster_id},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()
        return res.json()["library_statuses"]

    def install_libraries(self, cluster_id: str, libraries: list[dict[str, str]]):
        """Install the latest wheel on a cluster_id.

        Send request to the databricks REST API to install
        new dependencies. The installation is started but
        not necessarily finished when we get our response.

        """
        res = requests.post(
            url=f"{self.url}/libraries/install",
            json={"cluster_id": cluster_id, "libraries": libraries},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()

    def start_cluster(self, cluster_id: str):
        """Start an existing cluster if it has not been started already"""
        cluster_info = self.get_cluster_info(cluster_id)
        # If the cluster is not terminated, do nothing.
        if cluster_info["state"] != "TERMINATED":
            return

        res = requests.post(
            url=f"{self.url}/clusters/start",
            json={"cluster_id": cluster_id},
            headers=self.headers,
            timeout=90,
        )
        res.raise_for_status()

    def submit_job(
        self,
        entrypoint: str,
        parameters: list[str],
        cluster_id: Optional[str] = None,
        workers: Optional[int] = None,
        libraries: Optional[list[dict[str, str]]] = None,
    ) -> int:
        """Submit a spark job to Databricks REST API and run immediately.

        The REST call already expects the python files to exist on the dbfs:/
        before this method is called.

        """
        if workers:
            if not 1 <= workers <= settings.DATABRICKS_MAX_WORKERS:
                raise AssertionError(
                    f"Worker count must be within range of "
                    f"1-{settings.DATABRICKS_MAX_WORKERS}."
                )

        payload = {
            "run_name": settings.DATABRICKS_RUN_NAME,
            "libraries": libraries or [],
            "spark_python_task": {
                "python_file": entrypoint,
                "parameters": parameters,
            },
        }

        # If we want to submit a job on an existing cluster.
        if cluster_id:
            payload["existing_cluster_id"] = cluster_id
        # If we want to start a new cluster for our job.
        else:
            payload["new_cluster"] = {
                "spark_version": settings.DATABRICKS_SPARK_VERSION,
                "node_type_id": settings.DATABRICKS_NODE_TYPE,
                "num_workers": workers or settings.DATABRICKS_DEFAULT_WORKERS,
                "custom_tags": settings.DATABRICKS_CUSTOM_TAGS,
                "spark_env_vars": settings.DATABRICKS_ENV_VARS,
                "spark_conf": settings.DATABRICKS_SPARK_CONFIG,
                "init_scripts": [
                    {
                        "dbfs": {
                            "destination": f"{os.path.dirname(entrypoint)}/init_scripts"
                        }
                    }
                ],
            }

        res = requests.post(
            url=f"{self.url}/jobs/runs/submit",
            json=payload,
            headers=self.headers,
            timeout=90,
        )

        res.raise_for_status()
        return res.json()["run_id"]


def await_status(run_id: int):
    """Await a job until its done.

    This method will run forever until the job either finishes or terminates.

    """
    WAIT_TIME = 10
    dbclient = DatabricksClient()

    logger.info("Awaiting job %s to be started...", run_id)
    while True:
        time.sleep(WAIT_TIME)
        contents = dbclient.get_job_info(run_id)
        if contents["state"]["life_cycle_state"] in {"PENDING", "RUNNING"}:
            logger.info(
                "Run %s is in state '%s'", run_id, contents["state"]["life_cycle_state"]
            )
            continue

        if "result_state" not in contents["state"]:
            raise RunError(f"Run {run_id} did not finish with a result_state.")

        if contents["state"]["result_state"] == "SUCCESS":
            logger.info("Run %s finished successfully.", run_id)
        else:
            logger.error(
                "Run %s finished in state '%s'",
                run_id,
                contents["state"]["result_state"],
            )

        logger.info("See logs at %s", contents["run_page_url"])
        return
