class DatabricksError(Exception):
    """Error raised by Databricks service"""
