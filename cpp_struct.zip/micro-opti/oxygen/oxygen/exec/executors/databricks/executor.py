import logging
import os
import shutil
import subprocess
import time
from io import StringIO
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from oxygen.conf.settings import settings
from oxygen.exec.executors.base import Executor
from oxygen.utils.func import deprecated

from .client import DatabricksClient, await_status
from .exceptions import DatabricksError
from .storage import DatabricksStorage

logger = logging.getLogger(__name__)


@deprecated(version="2.0.0")
class DatabricksExecutor(Executor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.client = DatabricksClient()

    def run_dag(self, dag, **kwargs):
        cluster = kwargs.pop("cluster", None)
        workers = kwargs.pop("workers", 2)
        response = self.deploy_databricks(cluster)

        dbfs_path = response["dbfs_path"]
        entrypoint = f"dbfs:{dbfs_path}/run.py"
        parameters = ["dag", dag.label, "--local"]
        run_id = self.client.submit_job(
            entrypoint=entrypoint,
            parameters=parameters,
            cluster_id=cluster,
            workers=workers,
            libraries=response["libraries"],
        )
        await_status(run_id=run_id)

    def deploy_databricks(self, cluster: Optional[str] = None) -> dict[str, Any]:
        """Deploy the application to Databricks.

        Full deployment to Databricks including building a wheel, uploading files,
        starting clusters, installing libraries, awaiting statuses etc.

        Arguments:
            cluster: The cluster id of any existing cluster we want to
                deploy to.

        Returns:
            Data related to the deployment such as which libraries that
            was installed and at which temporary folder on dbfs:/ that
            files were deployed to.

        """
        dbfs_path = f"/tmp/{str(uuid4())}/app"
        files = [os.path.join(settings.BASE_DIR, "run.py")]
        libraries = []
        for lib in settings.DATABRICKS_LIBRARIES:
            whl_path = self.build_wheel(path=lib)
            files.append(whl_path)

        deployed_files = self.deploy_files(dbfs_path, files)
        for wheel in filter(lambda f: os.path.splitext(f)[1] == ".whl", deployed_files):
            libraries.append({"whl": f"dbfs:{wheel}"})

        # If we are using an existing cluster,
        # make sure the cluster is started and updated
        # before we submit our job.
        if cluster:
            self.client.start_cluster(cluster)
            self.await_cluster_start(cluster)
            self.client.install_libraries(cluster_id=cluster, libraries=libraries)
            self.await_libraries(cluster, libraries)

        return {"dbfs_path": dbfs_path, "libraries": libraries}

    def build_wheel(self, path) -> str:
        """Build our python .whl file to be deployed to Databricks.

        This packages our application as a `promo` package so that later our
        run.py file from Databricks can use `import promo` to access the
        rest of our code.

        """
        logger.info("Building wheel.")
        # Cleanup previous build artifacts.
        dist_path = os.path.join(path, "dist")
        build_path = os.path.join(path, "build")
        if os.path.exists(dist_path):
            shutil.rmtree(dist_path, ignore_errors=True)
        if os.path.exists(build_path):
            shutil.rmtree(build_path, ignore_errors=True)

        setup_path = os.path.join(path, "setup.py")
        if not os.path.exists(setup_path):
            raise FileNotFoundError(f"Project has no setup.py file at '{setup_path}'")

        os.chdir(path)
        # pylint: disable=consider-using-with
        subprocess.Popen(["python3", "setup.py", "-q", "bdist_wheel"])

        # Wait for the subprocess to finish building our .whl
        self.await_build(dist_path)

        # Cleanup build artifacts.
        shutil.rmtree(build_path, ignore_errors=True)

        # Get and return the file name of the distribution created.
        files = os.listdir(dist_path)
        if not files:
            raise FileNotFoundError("Failed to generate distribution wheel.")
        return os.path.join(dist_path, files[0])

    def deploy_files(self, dbfs_path: str, files):
        """Copy files to Databricks FileSystem.

        The files must exist on the dbfs:/ for our Databricks job to
        be able to execute it. So we must first copy them from local to
        remote dbfs:// file system.

        """
        databricks: DatabricksStorage = DatabricksStorage()
        paths = []

        for file_path in files:
            base_filepath = os.path.basename(file_path)
            logger.info("Uploading %s to %s", file_path, dbfs_path)
            databricks.cp(file_path, f"{dbfs_path}/{base_filepath}")
            paths.append(f"{dbfs_path}/{base_filepath}")

        init_script = self.generate_init_scripts()
        databricks.touch(str(Path(dbfs_path) / "init_scripts"), StringIO(init_script))
        return paths

    def await_build(self, dir_path):
        """Await the building of our .whl package.

        We build the .whl using a subprocess that is running async in
        the background. Because of this we must await it to complete
        before we copy the .whl and deploy it to Databricks.

        """
        while True:
            # As long as the dir does not exist and no files exists within it,
            # continue awaiting the results.
            if not os.path.exists(dir_path) or not os.listdir(dir_path):
                logger.debug("Awaiting building files in directory '%s'", dir_path)
                time.sleep(2)
                continue

            time.sleep(2)
            return

    def await_cluster_start(self, cluster_id: str):
        """Wait for a cluster to get into the RUNNING state.

        Raises:
            DatabricksError: If the cluster actually terminates for some reason.

        """
        cluster_info = self.client.get_cluster_info(cluster_id)
        while cluster_info["state"] != "RUNNING":
            if cluster_info["state"] == "TERMINATED":
                raise DatabricksError(
                    f"Cluster '{cluster_id}' terminated when it was expected to start."
                )

            logger.info(
                "Waiting for cluster to start, currently in state %s",
                cluster_info["state"],
            )
            time.sleep(5)
            cluster_info = self.client.get_cluster_info(cluster_id)

    def generate_init_scripts(self):
        if not hasattr(settings, "DATABRICKS_REQUIREMENTS"):
            return None

        commands = " && ".join(
            [
                f"/databricks/python3/bin/pip install {dep}"
                for dep in settings.DATABRICKS_REQUIREMENTS
            ]
        )
        logger.debug("Generated command '%s'", commands)
        return commands

    def await_libraries(
        self,
        cluster_id: str,
        libraries: list[dict[str, str]],
    ):
        """Wait for all libraries to be installed.

        Arguments:
            cluster_id: The id that we await libraries to be installed on.
            libraries: Libraries that should be monitored for failure. If
                any of these libraries fail to install, error is raised.

        Raises:
            DatabricksError: If library installation within the databricks
                             cluster fails.

        """
        statuses = self.client.get_library_statuses(cluster_id)
        # Keep waiting as long as at least 1 library is installing.
        while any(status["status"] == "INSTALLING" for status in statuses):
            # Check if any of the packages failed to install.
            failed = [
                status["library"]
                for status in statuses
                if status["status"] == "FAILED" and status["library"] in libraries
            ]
            if failed:
                raise DatabricksError(f"Failed to install libraries {failed}.")

            time.sleep(5)
            logger.info("Waiting for installation of packages to finish.")
            statuses = self.client.get_library_statuses(cluster_id)

        logger.debug("Installation of packages finished.")
