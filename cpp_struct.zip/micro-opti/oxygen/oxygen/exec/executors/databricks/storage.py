import logging
from io import BytesIO, StringIO
from typing import Optional, Union

from oxygen.files.storages.base import Storage
from oxygen.utils.func import deprecated

from .client import DatabricksClient

logger = logging.getLogger(__name__)


@deprecated(version="2.0.0")
class DatabricksStorage(Storage):
    """Storage class for intereacting with the dbfs:/ file system"""

    def __init__(self, **kwargs):
        self.client = DatabricksClient()
        super().__init__(**kwargs)

    def url(self, file_path):
        """Get public url to file"""
        return f"dbfs:/{file_path.lstrip('/')}"

    def open(self, file_path: str, mode="rb"):
        """Open a file and return its stream handler"""
        return self.client.read(file_path)

    def touch(self, file_path: str, content: Union[BytesIO, StringIO]) -> None:
        """Create a new file"""
        content.seek(0)
        # Convert to bytes if required.
        if isinstance(content, StringIO):
            content = BytesIO(content.read().encode("utf-8"))

        with self.client.create_handle(file_path) as handle:
            while True:
                chunk = content.read(self.client.BYTES_LIMIT)
                if not chunk:
                    break
                self.client.add_block(chunk, handle)

    def cp(
        self,
        src_path: str,
        dest_path: str,
        recursive: bool = False,
        overwrite: bool = False,
    ) -> None:
        logger.info("Copying file '%s' to '%s'", src_path, dest_path)
        with self.client.create_handle(dest_path) as handle:
            logger.debug("Handle is %s", handle)
            with open(src_path, mode="rb") as src:
                while True:
                    chunk = src.read(self.client.BYTES_LIMIT)
                    logger.debug("Chunk is %d bytes long.", len(chunk))
                    if not chunk:
                        logger.debug("Breaking because no more chunks.")
                        break
                    logger.debug("Adding chunk to handle %s", handle)
                    self.client.add_block(chunk, handle)

    def isfile(self, file_path: str) -> bool:
        info = self.client.get_file_info(file_path)
        if not info:
            raise FileNotFoundError(f"File '{file_path}' does not exist.")
        return info["is_file"]

    def isdir(self, dir_path: str) -> bool:
        info = self.client.get_file_info(dir_path)
        if not info:
            raise FileNotFoundError(f"Directory '{dir_path}' does not exist.")
        return info["is_dir"]

    def exists(self, path: str) -> bool:
        """Check if file exists.

        Return bool based on if the files key
        exists within the response returned
        from the Databricks API.

        """
        info = self.client.get_file_info(path) or {}
        return "files" in info

    def mkdir(
        self, dir_path: str, make_parents: bool = False, mode: Optional[int] = None
    ) -> None:
        """Create a new directory"""
        raise NotImplementedError()

    def listdir(self, dir_path: str) -> tuple[list[str], list[str]]:
        """List files and directories in directory.

        Args:
            dir_path: Path of directory to list contents of.

        Returns:
            Tuple: 2 value tuple that consist of
                   List of Subdirectories and
                   List of Files.

        """
        raise NotImplementedError()

    def rm(self, file_path: str, recursive: bool = False) -> None:
        """Delete a file"""
        raise NotImplementedError()
