class Executor:
    def run_dag(self, dag, **kwargs):
        raise NotImplementedError
