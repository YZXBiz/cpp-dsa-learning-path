import logging
import time

from oxygen.exec.task import MultiTask

from .base import Executor

logger = logging.getLogger(__name__)


class LocalExecutor(Executor):
    def run_dag(self, dag, **kwargs):
        """
        Run the dags with advanced syntax, supporting
        both sequential and concurrent runs

        """
        dag_start = time.time()
        for task in dag.inject_tasks():

            # Execute our task
            instance = task if isinstance(task, MultiTask) else task()
            instance._run()

        # Benchmark dag
        dag_end = time.time()
        # pylint: disable=consider-using-f-string
        elapsed = "{0:.2f}".format(dag_end - dag_start)
        logger.info("Finished dag %s in %s seconds.", dag.__class__.__name__, elapsed)
