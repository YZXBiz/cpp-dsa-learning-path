class ValidationError(Exception):
    """Exception for when validation of file or data fails"""


class RunError(Exception):
    """Exeception raised during an actual model run"""
