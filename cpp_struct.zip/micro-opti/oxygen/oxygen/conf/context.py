import logging
import uuid
from datetime import datetime
from functools import reduce
from io import BytesIO
from pathlib import Path
from typing import Any, Optional, Union

import yaml
from box import Box

from oxygen.conf.settings import settings
from oxygen.files.storages import storage
from oxygen.files.storages.local import RepoReadOnlyStorage
from oxygen.utils.dict import merge
from oxygen.utils.loading import LazyObject, import_string

logger = logging.getLogger(__name__)


class BaseContextManager:
    """Base class that define interface for context backends"""

    def get_context_patches(self):
        """Patches that will be applied to all contexts"""
        return []

    def create_context(
        self,
        config: Optional[dict[str, Any]] = None,
        patches: Optional[list[dict[str, Any]]] = None,
    ):
        """Main entrypoint to generate a new context.

        Returns:
            Dictionary of context.

        """
        raise NotImplementedError()

    def store_context(self, ctx, force=False):
        """Hook to store context when created.

        This can be used to for example serialize and store
        the context in a directory when its created so that
        it can be inspected later.

        """
        raise NotImplementedError()

    def load_config(self, path, config_storage=None):
        """Load config file from disk.

        Only handle logic related to reading in the YAML files from disk. Allows
        for reading both a single file path to a YAML file, or a dictionary full
        of YAML files and then merge them together into a single dictionary.

        """
        raise NotImplementedError()


class DefaultContextManager(BaseContextManager):
    """
    Default context manager used when generating a new project.

    This context manager reads in YAML files and merge it with meta data
    or patch dictionaries for the run.
    """

    config: Optional[dict[str, Any]]
    patches: Optional[list[dict[str, Any]]]

    def __init__(self) -> None:
        super().__init__()
        self.patches = None
        self.config = None

    def get_run_meta(
        self, run_id: Optional[str] = None, run_folder: Optional[str] = None
    ):
        """Generate the run meta data patch to be added to context"""
        created_at = datetime.now()
        run_id_func = getattr(settings, "RUN_ID_CALLABLE", None) or (
            lambda: str(uuid.uuid4())
        )
        run_folder_func = getattr(settings, "RUN_FOLDER_CALLABLE", None) or (
            lambda dt, run_id: dt.strftime(f"/runs/%Y/%m/%d/{run_id}/")
        )
        run_id = run_id or run_id_func()

        return {
            "meta": {
                "run_id": run_id,
                "created_at": created_at,
                "run_folder": run_folder or run_folder_func(created_at, run_id),
            }
        }

    def create_context(
        self,
        config: Optional[dict[str, Any]] = None,
        patches: Optional[list[dict[str, Any]]] = None,
        meta: Optional[dict[str, Any]] = None,
    ):
        """Main entrypoint to generate a new context.

        Returns:
            Dictionary of context.

        """
        self.config = config
        self.patches = patches or []
        # If no initial config provided, load from disk
        # and populate the meta data.
        if not config:
            # Get any additional patches defined by Context Backend.
            self.config = self.load_config(settings.CONFIG_PATH, RepoReadOnlyStorage())
            self.patches.extend(self.get_context_patches())
            self.patches.insert(0, meta or self.get_run_meta())

        # Merge all context dictionaries into single context.
        return reduce(merge, self.patches, self.config)

    def store_context(self, ctx, force=False):
        """Store context in run folder when created.

        Arguments:
            - ctx: dictionary of context.
            - force: If we should force overwrite if file already exists.

        """
        # If the context is not aware of any meta
        # data yet, it means the context is not ready
        # to be stored.
        if "meta" not in ctx:
            return

        ctx_path = str(Path(ctx["meta"]["run_folder"]) / "context.yaml")
        # If context already exists and we are not force overwriting it,
        # the simply skip re-creating it.
        if storage.exists(ctx_path) and not force:
            return

        storage.touch(
            ctx_path,
            BytesIO(bytes(yaml.dump(ctx).encode("utf-8"))),
        )

    def load_config(self, path, config_storage=None):
        """Load config file from disk.

        Only handle logic related to reading in the YAML files from disk. Allows
        for reading both a single file path to a YAML file, or a dictionary full
        of YAML files and then merge them together into a single dictionary.

        """
        config_storage = config_storage or storage
        # Load config from one config or multiple config files
        if config_storage.isfile(path):
            configs = [path]
        else:
            configs = []
            for file in config_storage.listdir(path)[1]:
                if file.endswith(".yml") or file.endswith(".yaml"):
                    configs.append(file)

        config = {}
        for part_config in configs:
            with config_storage.open(part_config) as stream:
                part_config = yaml.load(stream, Loader=yaml.SafeLoader)
                config = merge(config, part_config)
        return config


class Context:
    """Context is a object that is the scope of a single execution run.

    This means that it can hold configuration related to that specific
    run such as the run directory, the run unique id, the run config
    parameters and so on.

    The object is lazy and only instantiated whenever it is first used.
    After the first use, its a singleton that is never recreated.

    """

    _instance = None
    _data = Box()

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(Context, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self, data=None):
        if data:
            self._data.clear()
            self._data.update(data)

    def __repr__(self):
        return f"<Context: {self._data}>"

    def __str__(self):
        return str(self._data)

    def __hash__(self):
        return hash(self._data)

    def __dir__(self):
        return dir(self._data)

    def __getattr__(self, attr):
        return getattr(self._data, attr)

    def __setattr__(self, attr, value):
        """Context is immutable"""
        raise TypeError(
            f"'{self.__class__.__name__}' object does not support item assignment"
        )

    @classmethod
    def create_context(
        cls,
        config: Optional[dict[str, Any]] = None,
        patch: Optional[Union[list[Any], Any]] = None,
        meta: Optional[dict[str, Any]] = None,
        force: bool = False,
    ):
        # For backwards compatibility, ensure that patches is a list.
        patches: list[Any] = patch or []
        patches = [patch] if not isinstance(patch, list) else patch
        assert getattr(settings, "CONTEXT_BACKEND"), "Missing setting CONTEXT_BACKEND."
        # Generate new context using backend configured.
        ctx = context_manager.create_context(config, patches, meta=meta)

        # Store context to disk
        context_manager.store_context(ctx, force)

        # Update the singleton context with the new context.
        instance = cls()
        instance._data.clear()
        instance._data.update(ctx)
        return instance


# pylint: disable=unnecessary-lambda
context_manager = LazyObject(lambda: import_string(settings.CONTEXT_BACKEND)())
context = LazyObject(lambda: Context._instance or Context.create_context())
