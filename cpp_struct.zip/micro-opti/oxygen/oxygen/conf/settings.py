import importlib
import logging
import os

from oxygen.utils.loading import LazyObject

logger = logging.getLogger(__name__)


class Settings:
    START_TASK = "oxygen.exec.task.BootstrapTask"
    END_TASK = None
    SQL_CONNECTION = None
    CONTEXT_BACKEND = "oxygen.conf.context.DefaultContextManager"
    EXECUTOR_BACKEND = "oxygen.exec.executors.LocalExecutor"
    READER_BACKEND = "oxygen.files.readers.PandasReader"
    STORAGE_BACKEND = "oxygen.files.storages.local.LocalStorage"
    STORAGE_HOSTNAME = None
    CONFIG_PATCH = None
    LOGGING = {}
    TASK_MODULES = ["tasks"]
    DAG_MODULES = ["dags"]
    COMMAND_MODULES = ["commands"]
    SPARK_CONFIG = {}
    AZURE_STORAGE_CONTAINER = None
    AZURE_STORAGE_NAME = None
    AZURE_STORAGE_KEY = None
    AZURE_SAS_TOKEN = None
    AZURE_EXPIRE_SECONDS = 60 * 60 * 24 * 7  # 7 days
    DATABRICKS_HOSTNAME = None
    DATABRICKS_TOKEN = None
    DATABRICKS_RUN_NAME = "Spark job"
    DATABRICKS_SPARK_VERSION = None
    DATABRICKS_DEFAULT_WORKERS = 2
    DATABRICKS_MAX_WORKERS = 10
    DATABRICKS_CUSTOM_TAGS = {}
    DATABRICKS_ENV_VARS = {}
    DATABRICKS_REQUIREMENTS = []
    DATABRICKS_SPARK_CONFIG = {}
    DATABRICKS_NODE_TYPE = "None"
    GOOGLE_PROJECT = None
    GOOGLE_LOCATION = "EU"
    GOOGLE_GCS_BUCKET = None
    GOOGLE_TEMP_PATH = "tmp/"
    GOOGLE_BIGQUERY_TMP_DATASET = "tmp"
    AIRFLOW_CLIENT_ID = None
    AIRFLOW_TEMPLATE = None
    AIRFLOW_URI = None
    AIRFLOW_PRE_SCRIPT = None
    AIRFLOW_KUBERNETES_AFFINITY = None
    AIRFLOW_DEPLOY_DAGS = []
    AIRFLOW_DAG_PREFIX = None
    AIRFLOW_STORAGE_BACKEND = "oxygen.files.storages.local.LocalStorage"
    AIRFLOW_BUCKET = None
    AIRFLOW_IMAGE = "application"
    AWS_ACCESS_KEY_ID = None
    AWS_SECRET_ACCESS_KEY = None
    AWS_STORAGE_BUCKET_NAME = None
    AWS_S3_REGION_NAME = None
    AWS_S3_ENDPOINT_URL = None
    AWS_IS_GZIPPED = False
    AWS_S3_OBJECT_PARAMETERS = {}
    AWS_DEFAULT_ACL = None
    PANDAS_DTYPE_BACKEND = "pyarrow"

    def __init__(self, settings_module):
        logger.info("Loaded settings module '%s'", settings_module)
        module = importlib.import_module(settings_module)
        for setting in dir(module):
            if setting.isupper():
                setting_value = getattr(module, setting)
                setattr(self, setting, setting_value)


settings = LazyObject(lambda: Settings(os.getenv("SETTINGS_MODULE")))
