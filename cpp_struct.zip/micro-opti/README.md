# Assortment Modeling

This repository provides an assortment modeling pipeline. Comments in the `core/dags/e2e.py` file describe the purpose of each data processing task to provide clarity and context for pipeline execution.

The clustering pipeline is separate from `e2e.py`; please refer to the `store_clustering.py` file in the `dags` folder to better understand this pipeline.

- **Store Clustering**, **Space Elasticity**, **Need State**, **Optimization**, and **Finacial Projection**: This repository retains complete pipelines for these modules, including all associated logic and methods. Refer to the core/tasks or core/modules folders to better understand their implementation and approach.
- **Data Preprocessing**: Since detailed task and module files for data preprocessing have been removed, please refer to the `core/schemas` folder for an understanding of the data structures used in preprocessing tasks.
