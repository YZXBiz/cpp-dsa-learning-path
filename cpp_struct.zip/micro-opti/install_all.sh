#!/bin/bash

pip install -r requirements.txt
pip install -r oxygen/requirements/all.txt
pip install -e oxygen
pip install fsutils==1.6
