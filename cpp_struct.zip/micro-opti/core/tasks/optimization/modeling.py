import gc
import psutil
from core.modules.optimization.data_prep import (
    load_all_relevant_sets_and_contraint_data,
)
from core.modules.optimization.model_parallelization_v2 import (
    formulate_and_solve_all_opti_problems_in_dept_v2,
    format_output,
    format_ranking_output
)
from core.utils.scope_helpers import (
    get_filtered_category_level_plano_cat_and_depts_in_scope,
    create_optimization_scope_tuple,
)
from core.utils.run_parameter import (
    update_scenario_column
)
from core.utils.space_context.run_versioning import complete_file_path
from core.utils.optimizer_helpers import *

from oxygen.conf.settings import settings
from oxygen.conf.context import context
from oxygen.exec.task import Task

import pandas as pd
import logging
from snowflake.connector.pandas_tools import write_pandas

import ipdb

log = logging.getLogger(__name__)


class OptimizationModeling(Task):
    def run(self):
        """
        This task will create sets, formulate and solve the micro-space optimization model for a given `dependent_var`
        and `plano_cat_desc`
        """
        dict_category_level_plano_cat_desc_and_depts = (
            get_filtered_category_level_plano_cat_and_depts_in_scope()
        )
        list_tuples_optimizer = create_optimization_scope_tuple(
            dict_category_level_plano_cat_desc_and_depts=dict_category_level_plano_cat_desc_and_depts,
            optimizer_granularity=context.groupby_granularity.optimizer,
        )
        category_level_input_schema = select_category_level_input_schema(
            context.groupby_granularity.optimizer
        )
        category_level_output_schema = select_OptimizationMasterModelingOutput_schema(
            context.groupby_granularity.optimizer
        )
        for dependent_var in list(
            dict(context.optimization.data_prep.objective_functions).values()
        ):
            n_cpu = min(
                int(psutil.cpu_count(logical=False) / 4) - 2, 24
            )  # Leaving 2 for the VM to function
            log.info(f"Parallelizing optimization on {n_cpu}CPUs")
            for tuple_optimizer in list_tuples_optimizer:
                category_level_dept_nbr, plano_cat_desc, department = tuple_optimizer
                path_load_master_optimization_dataset = complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.preprocessing.optimization_master_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.preprocessing,
                    dependent_var=dependent_var,
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    department=department,
                )
                df_optimization_master_data_dept = category_level_input_schema.load(
                    file_path=path_load_master_optimization_dataset,
                    root=context.data_stores.optimization.save_to_datastores_root.preprocessing,
                )
                # Loading sets and constraint relevant datasets (potentially from API)
                (
                    df_supplier_and_brand_requested_space,
                    df_global_linear_change_requested_space,
                    df_local_items_requested_space,
                    df_items_forced_facings_guardrails,
                    df_own_brand_space_constraints,
                    df_max_facings_per_sku,
                    df_pivot_and_linked_sku_pair_constraints,
                    df_need_state_min_max_facings_constraints,
                    df_item_POD_active,
                    df_item_POD_exempt,
                    df_brand_POD_active,
                    df_original_cluster_IOH_constraints,
                    df_full_ioh_curves_wide,
                    df_latest_space_data,
                    df_sales_data,
                ) = load_all_relevant_sets_and_contraint_data()

                df_optimization_granularity_output, df_final_adjusted = (
                    formulate_and_solve_all_opti_problems_in_dept_v2(
                    df_optimization_master_data_dept=df_optimization_master_data_dept,
                    df_supplier_and_brand_requested_space=df_supplier_and_brand_requested_space,
                    df_global_linear_change_requested_space=df_global_linear_change_requested_space,
                    df_local_items_requested_space=df_local_items_requested_space,
                    df_items_forced_facings_guardrails=df_items_forced_facings_guardrails,
                    df_own_brand_space_constraints=df_own_brand_space_constraints,
                    df_max_facings_per_sku=df_max_facings_per_sku,
                    df_item_POD_active=df_item_POD_active,
                    df_item_POD_exempt=df_item_POD_exempt,
                    df_brand_POD_active=df_brand_POD_active,
                    df_pivot_and_linked_sku_pair_constraints=df_pivot_and_linked_sku_pair_constraints,
                    df_need_state_min_max_facings_constraints=df_need_state_min_max_facings_constraints,
                    df_original_cluster_IOH_constraints=df_original_cluster_IOH_constraints,
                    df_full_ioh_curves_wide=df_full_ioh_curves_wide,
                    dependent_var=dependent_var,
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    department=department,
                ))

                modeling_output_file_path = complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.modeling.optimization_master_output_dept_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    dependent_var=dependent_var,
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    department=department,
                )
 
                if df_optimization_granularity_output.shape[0] != 0:
                    category_level_output_schema.save(
                        df=df_optimization_granularity_output,
                        file_path=modeling_output_file_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )

                    df_optimization_granularity_output_dup_check = df_optimization_granularity_output[
                        df_optimization_granularity_output["x_ifcg_optimal_value"] == 1
                    ]
                    if len(df_optimization_granularity_output_dup_check) != len(
                        df_optimization_granularity_output_dup_check.drop_duplicates(
                            subset=(
                                context.groupby_granularity.optimizer
                                + context.optimization.data_prep.addtl_agg_optimizer_sku_level
                            )
                        )
                    ):
                        raise ValueError(
                            f"Found duplicates in df_optimization_granularity_output {modeling_output_file_path}, "
                            f"please check data and pipeline"
                        )

                if df_final_adjusted.shape[0] != 0:
                    df_final_output = format_output(
                        df_final_adjusted,
                        df_latest_space_data,
                        df_sales_data
                    )

                    # Get ranking output
                    df_ranking_output = format_ranking_output(df_final_output)
                    df_final_output = df_final_output[
                        df_final_output["x_ifcg_optimal_value"] == 1
                    ]
                    
                    final_ranking_output_path = complete_file_path(
                        context.data_stores.optimization.root_path,
                        context.data_stores.optimization.modeling.optimization_master_full_output_dept_df,
                        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        plano_cat_desc=plano_cat_desc,
                    )

                    reader.write(
                        df=df_ranking_output,
                        file_path=final_ranking_output_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )

                    
                    # TODO: Move to own function, use oxygen to control schema, move tables to config
                    # Prep output for pandas
                    log.info("Writing final output to Snowflake")
                    df_final_output["model_version"] = context.meta.model_version
                    df_final_output["scenario_id"] = context.meta.scenario_id
                    df_final_output["prcs_run_dt"] = pd.Timestamp.now().replace(tzinfo=None)
                    # Fetch the largest prcs_run_id from the table and increment it
                    query = f"""
                        SELECT MAX(PRCS_RUN_ID) AS max_run_id 
                        FROM DL_FSCA_SLFSRV.TWA07.{context.data_stores.output_data.table_name.final_opti_output}
                    """
                    max_run_id_df = settings.SNOWFLAKE_CONNECTION.cursor().execute(query).fetch_pandas_all()
                    max_run_id = max_run_id_df["MAX_RUN_ID"].iloc[0] if not max_run_id_df.empty else 0
                    df_final_output["prcs_run_id"] = max_run_id + 1

                    df_final_output.columns = map(str.upper, df_final_output.columns)
                    df_final_output = df_final_output.drop(columns=["X_IFCG_OPTIMAL_VALUE",
                                                                     "N_TRANSFERENCE_SKU", 
                                                                     "N_OPTIMAL_SPACE_PRODUCTIVITY",
                                                                     "N_CURRENT_SPACE_PRODUCTIVITY",
                                                                     "N_ADJUSTED_OPTIMAL_SPACE_PRODUCTIVITY",
                                                                     "N_ADJUSTED_CURRENT_SPACE_PRODUCTIVITY",
                                                                     "N_OPTIMAL_SPACE_PRODUCTIVITY_VALIDATE",
                                                                     "SALES_MLTP" # Temp
                                                                   ])
                    write_pandas(settings.SNOWFLAKE_CONNECTION, df_final_output, 
                                       context.data_stores.output_data.table_name.final_opti_output, 
                                       database="DL_FSCA_SLFSRV", 
                                       schema="TWA07",
                                )
                    
                    end_time = pd.Timestamp.now().replace(tzinfo=None)
                    update_scenario_column(context.meta.scenario_id, "END_TIME", end_time)
                    update_scenario_column(context.meta.scenario_id, "STATUS", "COMPLETED")
                    log.info(f"Updated scenario {context.meta.scenario_id} END_TIME and STATUS to COMPLETED")
                    
                    # Write output to file
                    df_final_output.columns = map(str.lower, df_final_output.columns)
                    df_final_output["cluster_labels_volume_risk"] = df_final_output["final_cluster_labels"]
                    df_final_output["final_cluster_labels"] = df_final_output["cluster"]
                    
                    final_output_path = complete_file_path(
                        context.data_stores.optimization.root_path,
                        context.data_stores.optimization.modeling.optimization_master_processed_output_dept_df,
                        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        plano_cat_desc=plano_cat_desc,
                    )

                    reader.write(
                        df=df_final_output,
                        file_path=final_output_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )

                del df_optimization_granularity_output
                del df_supplier_and_brand_requested_space
                del df_local_items_requested_space
                del df_items_forced_facings_guardrails
                del df_own_brand_space_constraints
                del df_max_facings_per_sku
                del df_pivot_and_linked_sku_pair_constraints
                del df_need_state_min_max_facings_constraints
                del df_final_adjusted
                
                # del df_optimization_master_data_dept
                gc.collect()