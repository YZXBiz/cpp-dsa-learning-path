from core.modules.optimization.data_pull import (
    pull_snowflake_data,
    df_merge_categories,
    get_forced_facings,
    get_facings_for_slow_moving,
    get_need_state_facings,
    get_linked_skus,
    df_pull_final_clusters,
    df_pull_space_data,
    df_pull_store_characteristics,
    df_pull_pog_category_map,
    df_pull_cluster_item_scope,
    df_pull_cluster_item_master,
    df_pull_sku_transference,
    df_pull_item_space_productivity,
    df_pull_full_need_state_productivity,
    df_pull_need_state_productivity,
    df_pull_local_item_space,
    df_pull_forced_facings,
    df_pull_max_sku_facings,
    df_pull_max_ns_facings,
)
from core.schemas.store_clustering import (
    FilteredFinalClusterLabelsWithCategoryLevelSchema
)
from core.schemas.schemas import (
    LatestSpaceDataWithCategoryLevelFtSchema,
    PogCategoryMappingSchema,
    SkuTransferenceSchema,
)
from core.schemas.optimization import (
    StoreSpaceCharacteristicsWithCategoryLevelSchema,
    LocalItemsSpaceConstraintsWithCategoryLevel,
    ForcedFacingsMostGranular,
    MaxFacingsPerSkuInDeptConstraintWithCategoryLevel,
    NeedStateMinMaxFacingsConstraintWithCategoryLevel,
    OrientationMapping,
    BrandPODConstraints,
    ItemsPODExempt,
    ItemsPODConstraints,
    DCStoreMapping,
    RemovalPenalty
)
from core.schemas.client_input.schemas import (
    ItemInScopePerClusterFilteredSchema,
    ItemInScopeWithHierarchySchema,
)
from core.schemas.space_elasticity import (
    LatestSkuFacingsPogCategoryDept,
    SkuSpecificSpaceProductivityPerFacing,
)
from oxygen.files.readers import reader
from core.utils.space_context.run_versioning import complete_file_path

from oxygen.conf.context import context
from oxygen.exec.task import Task
from core.utils.misc import root_with_run_id

import logging
import ipdb

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


class OptimizationDataPull(Task):
    def run(self):
        """
        This task pulls data from Snowflake & flat files to create the various files which are used as input
        in the subsequent tasks of the optimization.
        """

        # Pull snowflake data
        (
            df_base,
            df_odd_items,
            df_elasticity,
            df_saturation,
            df_saturation_lvl1,
            df_sales,
            df_dc_store_mapping,
            df_dnp,
            df_otch_skus,
            df_removal_penalty
        ) = pull_snowflake_data()

        # df_base.to_parquet("df_base.parquet", index=False)
        # df_odd_items.to_parquet("df_odd_items.parquet", index=False)
        # df_elasticity.to_parquet("df_elasticity.parquet", index=False)
        # df_saturation.to_parquet("df_saturation.parquet", index=False)
        # df_saturation_lvl1.to_parquet("df_saturation_lvl1.parquet", index=False)
        # df_sales.to_parquet("df_sales.parquet", index=False)
        # df_dc_store_mapping.to_parquet("df_dc_store_mapping.parquet", index=False)
        # df_dnp.to_parquet("df_dnp.parquet", index=False)
        # df_otch_skus.to_parquet("df_otch_skus.parquet", index=False)
        # df_removal_penalty.to_parquet("df_removal_penalty.parquet", index=False)

        # df_base = pd.read_parquet("./df_base.parquet")
        # df_odd_items = pd.read_parquet("df_odd_items.parquet")
        # df_elasticity = pd.read_parquet("df_elasticity.parquet")
        # df_saturation = pd.read_parquet("df_saturation.parquet")
        # df_saturation_lvl1 = pd.read_parquet("df_saturation_lvl1.parquet")
        # df_sales = pd.read_parquet("df_sales.parquet")
        # df_dc_store_mapping = pd.read_parquet("df_dc_store_mapping.parquet")
        # df_dnp = pd.read_parquet("df_dnp.parquet")
        # df_otch_skus = pd.read_parquet("df_otch_skus.parquet")
        # df_removal_penalty = pd.read_parquet("df_removal_penalty.parquet")

        log.info(f"Need state run ID: {df_base['need_state_run_id'].unique()}")
        log.info(f"SKU level curves run ID: \n{df_elasticity[['plano_cat_desc', 'sku_curves_id']].drop_duplicates()}")
        # log.info(f"Need State level curves run ID: \n{df_saturation[['plano_cat_desc', 'ns_curves_id']].drop_duplicates()}")

        # Fill missing private_label_ind for new items with 0 # TO DO MO: verify this
        df_base.loc[(df_base["source"] == "new") & (df_base["private_label_ind"].isna()), "private_label_ind"] = 0
        # Merge planograms which are to be treated as one
        df_base = df_merge_categories(df_base, context.general_filters.categories_to_merge)

        # If an item is marked as new for the planogram, remove duplicate & keep entry with facing count
        new_items = df_base[df_base["source"] == "new"][["item_no_nbr", "plano_id"]].drop_duplicates()
        new_items["new_ind"] = 1
        df_base = df_base.merge(new_items, on=["item_no_nbr", "plano_id"], how="left")
        df_base.loc[df_base["new_ind"] == 1, "source"] = "new"
        df_base = df_base.sort_values("n_current_facings_sku", ascending=False)
        df_base = df_base.drop_duplicates(subset=["final_cluster_labels", "lp_flags", "plano_id",
                                                  "sub_plano", "plano_ft", "fixture_size", 
                                                  "store_nbr", "item_no_nbr", "risk_flag", "volume_flag"])  
        # ipdb.set_trace()

        # # add DC information
        # df_base = add_dc_store_count_information(df_base, df_dc_store_mapping)

        # Get items which need to keep facings where they currently exists
        df_enforced_skus = get_forced_facings(df_base, df_otch_skus)
        
        # Get slow moving items which need to be forced to 0 facings
        df_slow_moving = get_facings_for_slow_moving(df_base)
        
        # Get need states facing rule overrides
        df_need_state_facings = get_need_state_facings(df_base)
        
        # Get linked skus
        df_linked_skus = get_linked_skus(df_base)
        
        # Set all plano_ids to the same dtype
        df_base["plano_id"] = df_base["plano_id"].astype(str)
        df_enforced_skus["plano_id"] = df_enforced_skus["plano_id"].astype(str)
        df_odd_items["plano_id"] = df_odd_items["plano_id"].astype(str)
        
        # Log extracted categories
        loaded_categories = df_base["plano_cat_desc"].unique()
        log.info(f"Pulled data for categories: {loaded_categories}")
        
        # Save sales data 
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.historical_sales,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving sales data with {df_sales.shape[0]} rows to {output_path}")
        reader.write(
            df=df_sales,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        # # Save store_dc mapping data
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.dc_store_mapping,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving dc store mapping data with {df_dc_store_mapping.shape[0]} rows to {output_path}")
        DCStoreMapping.save(
            df=df_dc_store_mapping,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            )
        )

        # Save removal penalty data
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.removal_penalty,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving removal penalty data with {df_removal_penalty.shape[0]} rows to {output_path}")

        if df_removal_penalty.empty:
            log.warning("removal_penalty empty; writing single dummy row to bypass validation.")
            cols = getattr(RemovalPenalty, "COLUMNS", df_removal_penalty.columns.tolist())
            df_removal_penalty = pd.DataFrame([{c: 1 for c in cols}])
        RemovalPenalty.save(
            df=df_removal_penalty,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            )
        )
        
        # Save linked SKUs
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.optimization_config.model_formulation.pivot_linked_item_constraints_path,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        df_linked_skus['category_level_dept_nbr'] = df_linked_skus['category_level_dept_nbr'].astype(str)
        df_linked_skus['dept_id'] = df_linked_skus['dept_id'].fillna(0).astype(np.int64)
        log.info(f"Saving linked skus data with {df_linked_skus.shape[0]} rows to {output_path}")
        reader.write(
            df=df_linked_skus,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )   
        # # Some other code
        df_output = df_pull_final_clusters(df_base)
        output_path = complete_file_path(
            context.data_stores.store_clustering.root_path,
            context.data_stores.store_clustering.final.clustering_final_labels_df,
            at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            run_id_folder=context.run_id.clustering_run_id,
        )
        log.info(f"Saving final clusters with {df_output.shape[0]} rows to {output_path}")
        FilteredFinalClusterLabelsWithCategoryLevelSchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_space_data(df_base)
        output_path = complete_file_path(
            context.data_stores.store_clustering.root_path,
            context.data_stores.store_clustering.final.latest_space_data_path_df,
            at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            run_id_folder=context.run_id.clustering_run_id,
        )
        log.info(f"Saving full space data with {df_output.shape[0]} rows to {output_path}")
        reader.write(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_store_characteristics(df_base)
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.store_characteristics_master,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving store characteristics data with {df_output.shape[0]} rows to {output_path}")
        StoreSpaceCharacteristicsWithCategoryLevelSchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            )
        )

        df_output = df_pull_pog_category_map(df_base)
        output_path = complete_file_path(
            context.data_stores.etl.root_path,
            context.data_stores.etl.etl_pog_category_mapping.file_name,
        )
        log.info(f"Saving pog category data with {df_output.shape[0]} rows to {output_path}")
        PogCategoryMappingSchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )
        df_output = df_pull_cluster_item_scope(df_base)

        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.item_scope_per_cluster,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving cluster items scope data with {df_output.shape[0]} rows to {output_path}")
        df_output["item_no_nbr"] = df_output["item_no_nbr"].astype(np.int64)
        
        df_output = df_output[~df_output["private_label_ind"].isna()].copy()
        df_output["private_label_ind"] = df_output["private_label_ind"].astype(np.int64)

        ItemInScopePerClusterFilteredSchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_cluster_item_master(df_base)
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.item_master_file,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving cluster items master data with {df_output.shape[0]} rows to {output_path}")

        df_output["item_no_nbr"] = df_output["item_no_nbr"].astype(np.int64)
        df_output = df_output[~df_output["private_label_ind"].isna()].copy()
        df_output["private_label_ind"] = df_output["private_label_ind"].astype(np.int64)

        ItemInScopeWithHierarchySchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_sku_transference(df_base)
        output_path = complete_file_path(
            context.data_stores.store_clustering.root_path,
            context.data_stores.store_clustering.final.transference_df,
            at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            run_id_folder=context.run_id.clustering_run_id,
        )
        log.info(f"Saving transference data with {df_output.shape[0]} rows to {output_path}")
        SkuTransferenceSchema.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_item_space_productivity(df_base, df_elasticity, df_dnp)

        # Get unique categories in dataframe to loop through
        cat_dept_dict = (
            df_output[["plano_cat_desc", "dept_id"]]
            .drop_duplicates()
            .set_index("plano_cat_desc")
            .to_dict()["dept_id"]
        )

        for cat in cat_dept_dict:
            final_cat = df_output[df_output["plano_cat_desc"] == cat]
            cat_name = cat.replace(" ", "_")
            dept_id = cat_dept_dict[cat]

            output_path = complete_file_path(
                context.data_stores.space_elasticity.root_path,
                context.data_stores.space_elasticity.modeling.space_productivity_cluster_sku_df,
                at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                run_id_folder=context.run_id.elasticity_run_id,
                plano_cat_desc=str(cat_name),
                department=str(dept_id),
                dependent_var=context.optimization.data_prep.objective_functions.dnp,
            )
            log.info(f"Saving elasticity curves data with {final_cat.shape[0]} rows to {output_path}")
            SkuSpecificSpaceProductivityPerFacing.save(
                df=final_cat,
                file_path=output_path,
                root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
            )

        df_output = df_pull_need_state_productivity(df_base, df_saturation)

        # Get unique categories in dataframe to loop through
        cat_dept_dict = (
            df_output[["plano_cat_desc", "dept_id"]]
            .drop_duplicates()
            .set_index("plano_cat_desc")
            .to_dict()["dept_id"]
        )

        for cat in cat_dept_dict:
            final_cat = df_output[df_output["plano_cat_desc"] == cat]
            cat_name = cat.replace(" ", "_")
            dept_id = cat_dept_dict[cat]

            output_path = complete_file_path(
                context.data_stores.space_elasticity.root_path,
                context.data_stores.space_elasticity.modeling.space_productivity_need_state_df,
                at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                run_id_folder=context.run_id.elasticity_run_id,
                plano_cat_desc=str(cat_name),
                department=str(dept_id),
                dependent_var=context.optimization.data_prep.objective_functions.dnp,
            )
            log.info(f"Saving need state productivity data with {final_cat.shape[0]} rows to {output_path}")
            reader.write(
                df=final_cat,
                file_path=output_path,
                root=root_with_run_id(
                    context.run_id.clustering_run_id,
                    context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
                ),
            )

        df_output = df_pull_full_need_state_productivity(df_base, df_saturation, df_saturation_lvl1)

        for cat in cat_dept_dict:
            final_cat = df_output[df_output["plano_cat_desc"] == cat]
            cat_name = cat.replace(" ", "_")
            dept_id = cat_dept_dict[cat]

            output_path = complete_file_path(
                context.data_stores.space_elasticity.root_path,
                context.data_stores.space_elasticity.modeling.space_productivity_need_state_full_df,
                at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                run_id_folder=context.run_id.elasticity_run_id,
                plano_cat_desc=str(cat_name),
                department=str(dept_id),
                dependent_var=context.optimization.data_prep.objective_functions.dnp
            )
            log.info(f"Saving need state saturation data with {final_cat.shape[0]} rows to {output_path}")
            reader.write(
                df=final_cat,
                file_path=output_path,
                root=root_with_run_id(
                    context.run_id.clustering_run_id,
                    context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
                ),
            )

        # Create base orientation table
        df_orientation = pd.DataFrame({
            "orientation": "front",
            "equivalent_width_dimension": "width",
            "equivalent_height_dimension": "height",
            "equivalent_depth_dimension": "depth"
        }, index=[0])
        output_path = complete_file_path(
            context.data_stores.raw_mapping.root_path,
            context.data_stores.raw_mapping.orientation_mapping.file_name,
        )
        log.info(f"Saving orientation mapping data with {df_orientation.shape[0]} rows to {output_path}")
        OrientationMapping.save(
            df=df_orientation,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_local_item_space(df_base)
        output_path = complete_file_path(
            context.data_stores.etl.root_path,
            context.data_stores.etl.etl_opti_constraint_data_local_items.file_name,
        )
        log.info(f"Saving local item space data with {df_output.shape[0]} rows to {output_path}")
        LocalItemsSpaceConstraintsWithCategoryLevel.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_forced_facings = df_pull_forced_facings(df_base,
                                           df_elasticity,
                                           df_odd_items,
                                           df_enforced_skus,
                                           df_slow_moving)
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.forced_facings.merged_output_path,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving item forced facings data with {df_forced_facings.shape[0]} rows to {output_path}")
        ForcedFacingsMostGranular.save(
            df=df_forced_facings,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_max_sku_facings(df_base)
        output_path = complete_file_path(
            context.data_stores.etl.root_path,
            context.data_stores.etl.etl_opti_constraint_data_max_facings_per_sku.file_name,
        )
        log.info(f"Saving sku max facing data with {df_output.shape[0]} rows to {output_path}")
        MaxFacingsPerSkuInDeptConstraintWithCategoryLevel.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_output = df_pull_max_ns_facings(df_base,
                                           df_odd_items,
                                           df_forced_facings,
                                           df_need_state_facings)
        output_path = complete_file_path(
            context.data_stores.etl.root_path,
            context.data_stores.etl.etl_opti_constraint_data_need_state_min_max_facings_constraints.file_name,
        )
        log.info(f"Saving need state forced facings data with {df_output.shape[0]} rows to {output_path}")
        NeedStateMinMaxFacingsConstraintWithCategoryLevel.save(
            df=df_output,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        # Create files which contain data we currently don't track
        df_item_pod = pd.DataFrame({
            "item_no_nbr": 1,
            "plano_cat_id": 0,
            "plano_cat_desc": "",
            "dept_id": 0,
            "category_level_dept_nbr": 0,
            "category_level_dept_name": 0,
            "min_POD": 0,
            "max_POD": 9999999999
        }, index=[0])
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.manual_item_POD_constraints,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving item pod data with {df_item_pod.shape[0]} rows to {output_path}")
        ItemsPODConstraints.save(
            df=df_item_pod,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_brand_pod = pd.DataFrame({
            "brand_name": "",
            "plano_cat_id": 0,
            "plano_cat_desc": "",
            "dept_id": 0,
            "category_level_dept_nbr": 0,
            "category_level_dept_name": 0,
            "min_brand_POD": 0,
            "max_brand_POD": 9999999999
        }, index=[0])
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.manual_brand_POD_constraints,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving brand pod data with {df_brand_pod.shape[0]} rows to {output_path}")
        BrandPODConstraints.save(
            df=df_brand_pod,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        df_exempt_item = pd.DataFrame({
            "item_no_nbr": 1,
            "plano_cat_id": 0,
            "plano_cat_desc": "",
            "dept_id": 0,
            "category_level_dept_nbr": 0,
            "category_level_dept_name": 0,
        }, index=[0])
        output_path = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.data_stores.client_input_process.POD_exempt_items,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        log.info(f"Saving exempt items data with {df_exempt_item.shape[0]} rows to {output_path}")
        ItemsPODExempt.save(
            df=df_exempt_item,
            file_path=output_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )