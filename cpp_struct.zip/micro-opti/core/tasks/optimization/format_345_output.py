from core.modules.optimization.format_345_output import (
    append_additional_recommendations,
    generate_assrt_id_mapping,
    build_item_type_flags_from_detailed,
    build_planogram_item_attributes,
    build_model_core_output,
    build_dictionary_df
)

from core.utils.scope_helpers import (
    get_filtered_category_level_plano_cat_and_depts_in_scope,
    create_optimization_scope_tuple,
)

from core.utils.optimizer_helpers import *
from core.utils.storage import save_multi_tab_excel

from oxygen.conf.settings import settings
from oxygen.conf.context import context
from oxygen.exec.task import Task

import pandas as pd
import numpy as np
import logging
import os
from snowflake.connector.pandas_tools import write_pandas
import ipdb

log = logging.getLogger(__name__)


class Optimization345Output(Task):
    def run(self):
        """
        This task will create a 345 output & write it to Snowflake
        """
        # Set random seed & get config variables
        np.random.seed(context.meta.random_seed)
        scenario_id = context.optimization.format_345_output.scenario_id
        request_type = context.optimization.format_345_output.request_type
        max_additional_recommendations = context.optimization.format_345_output.additional_recommendations

        # Get need state timestamp. If need state timestamp is Null, set to large value in the future
        if context.data_stores.raw_data.table_filters.need_state_timestamp is None:
            need_state_timestamp = 20601231235959
        else:
            need_state_timestamp = context.data_stores.raw_data.table_filters.need_state_timestamp

        # Get categories to run
        dict_category_level_plano_cat_desc_and_depts = (
            get_filtered_category_level_plano_cat_and_depts_in_scope()
        )
        list_tuples_optimizer = create_optimization_scope_tuple(
            dict_category_level_plano_cat_desc_and_depts=dict_category_level_plano_cat_desc_and_depts,
            optimizer_granularity=context.groupby_granularity.optimizer,
        )

        for dependent_var in list(
                dict(context.optimization.data_prep.objective_functions).values()
        ):
            for tuple_optimizer in list_tuples_optimizer:
                category_level_dept_nbr, plano_cat_desc, department = tuple_optimizer
                log.info(
                    f"Preparing optimization master dataset for dependent_var={dependent_var} "
                    f"and category_level_dept_nbr={category_level_dept_nbr} and plano_cat_desc={plano_cat_desc} and dept_id={department}..."
                )
                # Read full output file
                final_output_path = complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.modeling.optimization_master_processed_output_dept_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    plano_cat_desc=plano_cat_desc,
                )

                # Check if output file was created. If not, means the problem was infeaisble
                file_path = os.path.join(settings.STORAGE_ROOT, context.meta.run_folder.lstrip(os.sep), final_output_path)
                
                if os.path.exists(file_path):
                    df_final_output = reader.read(
                        file_path=final_output_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )
    
                    # Read ranking data
                    output_ranking_path = complete_file_path(
                        context.data_stores.optimization.root_path,
                        context.data_stores.optimization.modeling.optimization_master_full_output_dept_df,
                        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        plano_cat_desc=plano_cat_desc,
                    )
                    df_rank = reader.read(
                        file_path=output_ranking_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )
    
                    # Read need state attribute data
                    df_attribute_sql_query = f"""
                        SELECT DISTINCT
                            PLANOGRAM_NBR AS "plano_nbr",
                            PRODUCT_ID AS "sku_nbr",
                            NEED_STATE AS "need_state",
                            CDT AS "cdt",
                            "attribute_key" AS "attribute_name",
                            "attribute_value"
                        FROM {context.data_stores.raw_data.table_name.need_state_table}
                        WHERE TIMESTAMP = (SELECT MAX(TIMESTAMP) 
                                           FROM {context.data_stores.raw_data.table_name.need_state_table}
                                           WHERE TIMESTAMP <= {need_state_timestamp}     
                                    )
                    """
                    log.info("Loading need state attribute table from Snowflake")
                    df_product_attr = settings.SNOWFLAKE_CONNECTION.cursor().execute(df_attribute_sql_query).fetch_pandas_all()
                    log.info(f"    loaded dataframe size: {df_product_attr.shape}")
    
                    # Process 345 output
                    df_combined = append_additional_recommendations(df_rank, max_additional_recommendations)
                    df_assrt_map = generate_assrt_id_mapping(df_combined, scenario_id)
                    df_item_flags = build_item_type_flags_from_detailed(df_final_output)
                    df_item_attr = build_planogram_item_attributes(df_combined, df_product_attr, scenario_id)
                    df_model = build_model_core_output(df_combined, df_assrt_map, df_item_flags, scenario_id, request_type)
                    df_dict = build_dictionary_df()
    
                    # Write model core output to Snowflake
                    df_model.columns = map(str.upper, df_model.columns)                
                    write_pandas(settings.SNOWFLAKE_CONNECTION, df_model, 
                                       "C835645_MICRO_OPTI_345_MODEL_CORE_OUTPUT", 
                                       database="DL_FSCA_SLFSRV", 
                                       schema="TWA07",
                                       auto_create_table=True
                                )
    
                    # Write assrt map to Snowflake
                    df_assrt_map.columns = map(str.upper, df_assrt_map.columns)                
                    write_pandas(settings.SNOWFLAKE_CONNECTION, df_assrt_map, 
                                       "C835645_MICRO_OPTI_345_ASSRT_MAP", 
                                       database="DL_FSCA_SLFSRV", 
                                       schema="TWA07",
                                       auto_create_table=True
                                )
                    
                    # Write planogram item attributes to Snowflake
                    df_item_attr.columns = map(str.upper, df_item_attr.columns)                
                    write_pandas(settings.SNOWFLAKE_CONNECTION, df_item_attr, 
                                       "C835645_MICRO_OPTI_345_PLANOGRAM_ITEM_ATTR", 
                                       database="DL_FSCA_SLFSRV", 
                                       schema="TWA07",
                                       auto_create_table=True
                                )
    
                    # Write output to Excel file
                    dict_345_output = {
                        "MODEL_CORE_OUTPUT": df_model,
                        "ASSRT_MAP": df_assrt_map,
                        "PLANOGRAM_ITEM_ATTR": df_item_attr,
                        "DICTIONARY": df_dict,
                    }
                    final_345_output_path = complete_file_path(
                        context.data_stores.optimization.root_path,
                        context.data_stores.optimization.modeling.optimization_345_full_recommendation,
                        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        plano_cat_desc=plano_cat_desc,
                    )
                    save_multi_tab_excel(
                        save_dict=dict_345_output,
                        path=final_345_output_path,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )
                else:
                    log.info(
                        f"No output found for plano_cat_desc {plano_cat_desc}. Skipping 345 output"
                    )