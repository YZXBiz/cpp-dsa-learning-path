import pandas as pd

from core.modules.optimization.data_prep import (
    create_master_optimization_input,
    get_config_percentile_facings_in_dept,
    get_linear_space_for_existing_item,
    get_latest_facings_per_rep_store_item_no,
    add_dc_store_count_information,
    add_removal_penalty_information,
    load_all_relevant_sku_and_pog_category_data,
)
from core.schemas.optimization import (
    PrioritizedStoreRepresentativeSchema,
    PrioritizedStoreRepresentativeWithCategoryLevelSchema,
)
from core.utils.scope_helpers import (
    get_filtered_category_level_plano_cat_and_depts_in_scope,
    create_optimization_scope_tuple,
    get_item_in_scope_per_cluster_path_and_root,
)
from core.utils.elasticity_helpers import load_cluster_data_based_on_agg_granularity
from core.schemas.client_input.schemas import ItemInScopePerClusterFilteredSchema
from core.utils.space_context.run_versioning import complete_file_path
from core.utils.optimizer_helpers import select_category_level_input_schema
from oxygen.conf.context import context
from oxygen.exec.task import Task
import logging
import ipdb
import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


class OptimizationDataPrep(Task):
    def run(self):
        """
        This task pre-processes multiple data sources to create an optimization master dataset that will be used all
        throughout modeling and post-processing for the optimization module. Each dataset created is for a given
        `dependent_var`, `plano_cat_desc` and `dept_id` (as reflected in the file paths)
        """

        dict_category_level_plano_cat_desc_and_depts = (
            get_filtered_category_level_plano_cat_and_depts_in_scope()
        )
        list_tuples_optimizer = create_optimization_scope_tuple(
            dict_category_level_plano_cat_desc_and_depts=dict_category_level_plano_cat_desc_and_depts,
            optimizer_granularity=context.groupby_granularity.optimizer,
        )

        # Loading list of prioritized [plano_cat_id, plano_cat_desc, plano_ft, final_cluster_labels] and their
        # store representative
        if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
            df_prioritized_store_representatives = PrioritizedStoreRepresentativeSchema.load(
                file_path=complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.store_representatives.prioritized_store_representatives_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
                ),
                root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
            )
        else:
            df_prioritized_store_representatives = PrioritizedStoreRepresentativeWithCategoryLevelSchema.load(
                file_path=complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.store_representatives.prioritized_store_representatives_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
                ),
                root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
            )

        (
            path_item_in_scope_per_cluster,
            root_item_in_scope_per_cluster,
        ) = get_item_in_scope_per_cluster_path_and_root()
        df_cluster_item_no = ItemInScopePerClusterFilteredSchema.load(
            file_path=path_item_in_scope_per_cluster,
            root=root_item_in_scope_per_cluster,
        ).rename(columns={"vendor_name": "supplier_name"})
        # Note: df_cluster_item_no will include all item in scope, including new item as well
        df_final_clusters = load_cluster_data_based_on_agg_granularity(
            use_cluster_labels=context.cluster_labels_based_on.optimization_item_scope
        )

        for dependent_var in list(
                dict(context.optimization.data_prep.objective_functions).values()
        ):
            for tuple_optimizer in list_tuples_optimizer:
                category_level_dept_nbr, plano_cat_desc, department = tuple_optimizer
                log.info(
                    f"Preparing optimization master dataset for dependent_var={dependent_var} "
                    f"and category_level_dept_nbr={category_level_dept_nbr} and plano_cat_desc={plano_cat_desc} and dept_id={department}..."
                )
                # Loading relevant datasets
                (
                    df_latest_sku_level_facings,
                    df_space_productivity_per_facing,
                    df_sku_transference,
                    df_space_productivity_need_state,
                    df_new_item_linear_space,
                    df_existing_linear_space,
                    df_dc_store_mapping,
                    df_removal_penalty
                ) = load_all_relevant_sku_and_pog_category_data(
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    dependent_var=dependent_var,
                    department=department,
                )

                # SKU and POG-level data
                if "category_level_dept_nbr" in context.groupby_granularity.optimizer:
                    df_prioritized_store_representatives_filt = (
                        df_prioritized_store_representatives[
                            (
                                    df_prioritized_store_representatives["category_level_dept_nbr"]
                                    == category_level_dept_nbr
                            )
                            & (
                                    df_prioritized_store_representatives["plano_cat_desc"]
                                    == plano_cat_desc
                            )
                            & (
                                    df_prioritized_store_representatives["dept_id"]
                                    == department
                            )
                            ]
                    )
                else:
                    df_prioritized_store_representatives_filt = (
                        df_prioritized_store_representatives[
                            (
                                    df_prioritized_store_representatives["plano_cat_desc"]
                                    == plano_cat_desc
                            )
                            & (
                                    df_prioritized_store_representatives["dept_id"]
                                    == department
                            )
                            ]
                    )

                # this should have 3 cluster labels,
                df_rep_store_item_no_w_latest_facings = get_latest_facings_per_rep_store_item_no(
                    df_cluster_item_no=df_cluster_item_no,
                    df_latest_sku_level_facings=df_latest_sku_level_facings,
                    df_prioritized_store_representatives_filt=df_prioritized_store_representatives_filt,
                )

                df_optimization_master_input_exploded_item_no = get_linear_space_for_existing_item(
                    df_rep_store_item_no_w_latest_facings=df_rep_store_item_no_w_latest_facings,
                    agg_level_clustering=context.groupby_granularity.clustering,
                    df_final_clusters=df_final_clusters,
                    df_latest_sku_level_facings=df_latest_sku_level_facings,
                    df_existing_linear_space=df_existing_linear_space
                )

                df_config_percentile_facings_in_dept = get_config_percentile_facings_in_dept(
                    agg_level_clustering=context.groupby_granularity.clustering,
                    df_latest_sku_level_facings=df_latest_sku_level_facings,
                    df_final_clusters=df_final_clusters,
                    config_percentile=context.optimization.data_prep.max_percentile_facings_in_dept_cluster,
                )

                df_optimization_master_input_exploded_item_no = add_dc_store_count_information(
                    df_optimization_master_input_exploded_item_no=df_optimization_master_input_exploded_item_no,
                    df_dc_store_mapping=df_dc_store_mapping
                )

                df_optimization_master_input_exploded_item_no = add_removal_penalty_information(
                    df_optimization_master_input_exploded_item_no=df_optimization_master_input_exploded_item_no,
                    df_removal_penalty=df_removal_penalty
                )

                # Creating master optimization dataset
                df_optimization_master_input = create_master_optimization_input(
                    df_optimization_master_input_exploded_item_no=df_optimization_master_input_exploded_item_no,
                    df_space_productivity_per_facing=df_space_productivity_per_facing,  # has category_level_dept_nbr
                    df_new_item_linear_space=df_new_item_linear_space,
                    df_config_percentile_facings_in_dept=df_config_percentile_facings_in_dept,
                    df_sku_transference=df_sku_transference,
                    df_space_productivity_need_state=df_space_productivity_need_state,  # has category_level_dept_nbr
                )

                # Saving master optimization dataset
                path_save_master_optimization_dataset = complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.preprocessing.optimization_master_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.preprocessing,
                    dependent_var=dependent_var,
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    department=department,
                )

                # TODO : Fix this
                category_level_input_schema = select_category_level_input_schema(
                    context.groupby_granularity.optimizer
                )

                df_optimization_master_input['clone_item_item_no_nbr'] = df_optimization_master_input['clone_item_item_no_nbr'].astype(np.float64)
                df_optimization_master_input['n_current_facings_sku'] = df_optimization_master_input['n_current_facings_sku'].astype(np.int64)
                df_optimization_master_input['saturation_facings'] = df_optimization_master_input['saturation_facings'].fillna(
                        df_optimization_master_input['saturation_facings'].mode()[0]
                    ).astype(np.int64)
                df_optimization_master_input['is_elasticity_overridden'] = df_optimization_master_input['is_elasticity_overridden'].fillna(0).astype(np.int64)
                for i in range(18):
                    column_name = f'n_boh_facings_{i}'
                    df_optimization_master_input[column_name] = df_optimization_master_input[column_name].astype(np.float64)

                category_level_input_schema.save(
                    df=df_optimization_master_input,
                    file_path=path_save_master_optimization_dataset,
                    root=context.data_stores.optimization.save_to_datastores_root.preprocessing,
                )

                log.info(
                    f"Successfully saved optimization master dataset to {path_save_master_optimization_dataset}"
                )

                if len(df_optimization_master_input) != len(
                        df_optimization_master_input.drop_duplicates(
                            subset=(
                                    context.groupby_granularity.optimizer
                                    + context.optimization.data_prep.addtl_agg_optimizer_sku_level
                            )
                        )
                ):
                    df_optimization_master_input[df_optimization_master_input.duplicated(subset=(
                                    context.groupby_granularity.optimizer
                                    + context.optimization.data_prep.addtl_agg_optimizer_sku_level
                            ), keep=False)].to_csv("duplicated_items.csv", index=False)
                    
                    ipdb.set_trace()
                    raise ValueError(
                        f"Found duplicates in df_optimization_master_input {path_save_master_optimization_dataset}, "
                        f"please check data and pipeline"
                    )
