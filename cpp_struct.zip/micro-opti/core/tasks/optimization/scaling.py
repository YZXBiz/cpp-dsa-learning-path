
# Data manipulation and analysis
import pandas as pd
import numpy as np
from decimal import Decimal

# System and timing utilities
import logging
import itertools as it

from pathlib import Path

# Custom utilities for Snowflake connection and Azure Data Lake Storage
from fsutils import run_sf_sql as rp

# Snowflake specific imports
from snowflake.connector.pandas_tools import write_pandas

from oxygen.conf.settings import settings
from oxygen.conf.context import context
from oxygen.exec.task import Task

import pandas as pd
import logging

import ipdb
import pdb

log = logging.getLogger(__name__)

class OptimizationScaling(Task):    

    def run(self):
        """
        This task will take the adjusted ouputs from the optimization modeling and scale them to align with
        actual store sales`
        """

        log.info("Fetching raw optimization data...")
        df_runs_raw = self.fetch_raw_optimization_data()

        log.info("Fetching actual sales data...")
        df_actual_sales_scaling = self.fetch_actual_sales_data()

        log.info("Smoothen saturation adjustments...")
        df_smoothened_adj_projections = self.smoothen_adjusted_sales(df_runs_raw)

        log.info("Format raw_ opti data for normalization calulations...")
        df_runs = self.prep_raw_opti_output(df_smoothened_adj_projections)
        
        log.info("Pulling clone items...")
        df_cloned_sku = self.prep_clone_sku_mapping()
        
        log.info("Calculating normalization factors...")
        df_runs_norm = self.calculate_normalization_factors(df_runs, df_actual_sales_scaling, df_cloned_sku)

        log.info("Applying scaling...")
        df_scaled = self.apply_scaling(df_smoothened_adj_projections, df_runs_norm)
        
        log.info("Get lvl1 transference effect for existing items")
        df_lvl1_transference, lv1_ns_df = self.pull_transference_effect(df_scaled)

        log.info("apply transference effect into existing items...")
        df_scaled_w_transference = self.apply_transference_effect(df_scaled, df_lvl1_transference, lv1_ns_df)
        
        df_upload = self.create_facings_change_categories(df_scaled_w_transference)
        
        log.info(f"Saving scaled results to {context.scaling_sales.output_tables.final_opti_output_scaled}...")

        df_upload.columns = map(str.upper, df_upload.columns)

        try:
            cursor = settings.SNOWFLAKE_CONNECTION.cursor()
            cursor.execute(
                f"DESCRIBE TABLE DL_FSCA_SLFSRV.TWA07.{context.scaling_sales.output_tables.final_opti_output_scaled}")
            log.info("Save the table using existing schema...")
            snowflake_columns = [row[0] for row in cursor.fetchall()]
            
            # Add missing columns with null values
            for col in snowflake_columns:
                if col not in df_upload.columns:
                    df_upload[col] = None
                    log.info(f"Added missing column '{col}' with null values")
            
            df_upload = df_upload[snowflake_columns]
        except:
            log.info(
                f"Table: DL_FSCA_SLFSRV.TWA07.{context.scaling_sales.output_tables.final_opti_output_scaled} cannot be found")
            log.info("Creating a new table and keep all columns in the dataframe")


        write_pandas(
            settings.SNOWFLAKE_CONNECTION, 
            df_upload, 
            context.scaling_sales.output_tables.final_opti_output_scaled, 
            database="DL_FSCA_SLFSRV",
            schema = 'TWA07',
            overwrite=False,
            auto_create_table=True
        )

        log.info("Scaling Task Complete...")

    def prep_clone_sku_mapping(self):
        cloned_sku_sql = f"""
        SELECT DISTINCT  
                POG_NUMBER as plano_id,
                UPC as item_no_nbr,
                REPLACED_SKU_NUMBER as cloned_item
        FROM {context.data_stores.raw_data.table_name.new_skus_table}
        WHERE TRUE
        AND category in ('{"', '".join(context.data_stores.raw_data.categories)}')
        AND REPLACED_SKU_NUMBER IS NOT NULL
        """
        log.info(f"Fetching new/cloned sku data from table: {context.data_stores.raw_data.table_name.new_skus_table} ")
        df_cloned_sku = settings.SNOWFLAKE_CONNECTION.cursor().execute(cloned_sku_sql).fetch_pandas_all()
        df_cloned_sku.columns = map(str.lower, df_cloned_sku.columns)
        if df_cloned_sku.empty:
            df_cloned_sku = pd.DataFrame(columns=["plano_id", "item_no_nbr", "cloned_item"])

        return df_cloned_sku

    def fetch_raw_optimization_data(self):
        """
        Pull raw opti values from previous step, performs some formatting and creates units sold 
        columns for adjusted current and optimal sales.
        """
        query = f"""
        SELECT *
        FROM DL_FSCA_SLFSRV.TWA07.{context.data_stores.output_data.table_name.final_opti_output}
        WHERE run_id = '{context.meta.run_id}'
        """
        
        df = settings.SNOWFLAKE_CONNECTION.cursor().execute(query).fetch_pandas_all()
        df.columns = map(str.lower, df.columns)

        #format and create new columns:
        df["plano_id"] = df["plano_id"].astype(int)

        return df

    def fetch_actual_sales_data(self):
        """
        Returns aggregated sales at the assortment, item level for the time period
        defined in the config
        """
        # Fetch the largest prcs_run_id from the table and increment it
        sales_sql_query = f"""
            WITH L52_SALES AS (
                    SELECT 
                        SKU_NBR, 
                        STORE_NBR, 
                        MAX(a.FISCAL_WEEK_NBR) AS MAX_FISCAL_WEEK,
                        SUM(TOT_SCAN_SALES) AS L52_TOTAL_SALES
                    FROM {context.data_stores.raw_data.table_name.sku_features_table} a
                    LEFT JOIN {context.data_stores.raw_data.table_name.fiscal_week_table} b on a.fiscal_week_nbr = b.fiscal_week_nbr
                    WHERE 
                        TRUE
                        AND coalesce(ad_rgn_cd, 'NA') NOT IN ('F', 'W', '999')
                        and a.fiscal_week_nbr between {context.scaling_sales.time_period.week_nbr_start} and {context.scaling_sales.time_period.week_nbr_end}
                    GROUP BY SKU_NBR, STORE_NBR
                )
                , 
                
                -- CTE 2: Standardize planogram categories (map LAUNDRY to HOUSEHOLD)
                MODIFIED_PLANO AS (
                    SELECT *,
                        CASE 
                            WHEN PLANO_CAT_DSC = 'HOUSEHOLD' THEN REPLACE(CAT_DSC, 'LAUNDRY', 'HOUSEHOLD')
                            WHEN PLANO_CAT_DSC = 'BEVERAGES' THEN REPLACE(CAT_DSC, 'SODA', 'BEVERAGES')
                            ELSE CAT_DSC
                        END AS CLEAN_CAT_DSC,
                    FROM {context.data_stores.raw_data.table_name.planogram_table}
                    WHERE 
                        PLANO_CAT_DSC = CLEAN_CAT_DSC 
                        -- Filter for specific planogram numbers in scope
                        AND (planogram_dsc, planogram_version_id) not in (('SHAVING NEEDS', 602))
                        AND risk_flag not in ('ERS')
                ), 
                
                -- CTE 3: Get items that are in scope from the latest optimization runs
                ITEMS_IN_SCOPE AS (
                SELECT DISTINCT 
                ITEM_NO_NBR AS SKU_NBR, 
                FIXTURE_DESC AS PLANOGRAM_DSC
                FROM DL_FSCA_SLFSRV.TWA07.{context.data_stores.output_data.table_name.final_opti_output}
                WHERE run_id = '{context.meta.run_id}'
                )
                , 
                -- CTE 4: Join all data sources to create versioned item sales
                VERSION_ITEM_SALES AS (
                    SELECT DISTINCT 
                            -- Create cluster label combining original cluster with volume and risk flags
                            CONCAT("rebalanced_demand_cluster_labels",'_',SSC.SPECIAL_VERSION_ID , '-', VOLUME_FLAG, '_', RISK_FLAG) AS FINAL_CLUSTER_LABELS,
                            PLANOGRAM_DSC AS FIXTURE_DESC, 
                            PLANOGRAM_NBR AS PLANO_ID,
                            -- Special handling for planogram 9677/9700 fixture width
                            CASE
                                WHEN STORE_NBR IN (SELECT DISTINCT STORE_NBR FROM MODIFIED_PLANO WHERE PLANOGRAM_NBR = 9677) 
                                    AND PLANOGRAM_NBR = 9700
                                THEN CAST(FIXTURE_WIDTH_NBR + 1000 AS INTEGER)
                                ELSE CAST(FIXTURE_WIDTH_NBR AS INTEGER)
                            END AS PLANO_FT,
                            FIXTURE_HEIGHT_NBR AS FIXTURE_SIZE, 
                            STORE_NBR, 
                            SKU_NBR AS ITEM_NO_NBR,
                            VM. VENDOR_NM AS VENDOR_NAME,
                            S.L52_TOTAL_SALES, 
                            S.MAX_FISCAL_WEEK
                    FROM MODIFIED_PLANO PM
                    LEFT JOIN {context.data_stores.raw_data.table_name.cluster_table} CL
                        ON PM.STORE_NBR = CL."store_nbr" AND PM.PLANO_CAT_DSC = CL.CAT_DSC
                    LEFT JOIN L52_SALES S
                        USING(SKU_NBR, STORE_NBR)
                    LEFT JOIN {context.data_stores.raw_data.table_name.sku_table} SKU
                    USING(SKU_NBR)
                    LEFT JOIN {context.data_stores.raw_data.table_name.vendor_table} VM
                    ON SKU.VENDOR_NBR = VM.VENDOR_NBR
                    LEFT JOIN {context.data_stores.raw_data.table_name.planogram_store_version} SSC USING (PLANOGRAM_NBR,PLANOGRAM_DSC, STORE_NBR)
                    INNER JOIN ITEMS_IN_SCOPE
                        USING (SKU_NBR, PLANOGRAM_DSC)
                    WHERE "rebalanced_demand_cluster_labels" IS NOT NULL
                )
                
                -- Final aggregation by cluster, planogram, and item
                SELECT 
                    FINAL_CLUSTER_LABELS, 
                    PLANO_ID, 
                    PLANO_FT, 
                    FIXTURE_SIZE, 
                    ITEM_NO_NBR, 
                    VENDOR_NAME,
                    SUM(L52_TOTAL_SALES) AS TOTAL_SALES,
                    MAX(MAX_FISCAL_WEEK) AS MAX_FISCAL_WEEK
                FROM VERSION_ITEM_SALES
                GROUP BY ALL
            """

        # Execute the sales query and fetch results into a pandas DataFrame
        # This provides actual L52 sales aggregated at the assortment + item level
        df = settings.SNOWFLAKE_CONNECTION.cursor().execute(sales_sql_query).fetch_pandas_all()

        # Convert all column names to lowercase for consistency
        df.columns = map(str.lower, df.columns)
        df["plano_id"] = df["plano_id"].astype(int)
        return df

    def prep_raw_opti_output(self, df_raw):
        """
        Aggregate the raw opti data from assorment/pog version level to assortment level
        """
        groupby_ids = [
            'run_id', 'plano_id', 'item_no_nbr', 'item_no_desc', 'brand_name',
        'vendor_name', 'seg_dsc', 'discontinue_item', 'new_item',
        'need_state_unique_id',  'scenario_id', 
            'final_cluster_labels', 'plano_cat_desc', 'plano_cat_id',
        'fixture_desc', 'plano_ft', 'fixture_size', 'cluster',
        'volume', 'risk', 
        ]

        metrics = ['n_current_adjusted_projected_dnp','n_current_adjusted_projected_sales', 'n_current_projected_dnp','n_current_projected_margin', 'n_current_projected_sales',
                'n_current_projected_units_sold', 'n_current_adjusted_projected_units_sold', 
                
                'n_optimal_adjusted_projected_dnp','n_optimal_adjusted_projected_sales', 'n_optimal_projected_dnp','n_optimal_projected_margin', 'n_optimal_projected_sales',
                'n_optimal_projected_units_sold', 'n_optimal_adjusted_projected_units_sold',]

        facing_metrics = ['n_current_facings_sku','n_current_linear_space_used_sku', 
                        'n_optimal_facings_sku','n_optimal_linear_space_used_sku',]

        multiplier = 'n_stores'

        agg_dict = {metric: (f"{metric}","sum") for metric in metrics}
        agg_dict["dnp_ratio"] = ("dnp_ratio","mean")
        agg_dict[multiplier] = (multiplier,"mean")
        for metric in facing_metrics:
            agg_dict[metric] = (metric,"sum")


        df_updated = (
            df_raw
            .assign(**{metric: lambda dx, metric=metric: dx[metric] * dx[multiplier] 
                    for metric in metrics + facing_metrics})
            .groupby(groupby_ids)
            .agg(**agg_dict).reset_index()
                        )
        return df_updated

    def smoothen_adjusted_sales(self, df):
        """
        This functions performs additional adjustments to the adjusted current and optimal projected sales
        by re-spreading the total saturation adjustment within an assortment and need state based on a 
        ratio proportional to their respective current/optimal unadjusted sales projections
        """
        groupby_cols = [
            "need_state_unique_id",
            "final_cluster_labels",
            "plano_id",
            'plano_ft',
            'fixture_size'
        ]
        
        # Calculate individual saturation effects
        df["saturation_effect_curr_sales"] = df["n_current_adjusted_projected_sales"] - df["n_current_projected_sales"]
        df["saturation_effect_opt_sales"] = df["n_optimal_adjusted_projected_sales"] - df["n_optimal_projected_sales"]

        # Calculate total saturation effect per need state & assortment
        df["total_saturation_effect_curr_sales"] = df.groupby(groupby_cols)["saturation_effect_curr_sales"].transform(sum)
        df["total_saturation_effect_opt_sales"] = df.groupby(groupby_cols)["saturation_effect_opt_sales"].transform(sum)

        # Calculate re-spread saturation effect
        df["total_curr_projected_sales"] = df.groupby(groupby_cols)["n_current_projected_sales"].transform(sum)
        df["smoothened_saturation_effect_curr_sales"] = (
            df["total_saturation_effect_curr_sales"] * df["n_current_projected_sales"]
            / df["total_curr_projected_sales"]
        )

        df["total_opt_projected_sales"] = df.groupby(groupby_cols)["n_optimal_projected_sales"].transform(sum)
        df["smoothened_saturation_effect_opt_sales"] = (
            df["total_saturation_effect_opt_sales"] * df["n_optimal_projected_sales"]
            / df["total_opt_projected_sales"]
        )

        # Apply re-spread saturation effect to smoothen adjusted projected sales
        df["n_current_pre_adjusted_projected_sales"] = df["n_current_adjusted_projected_sales"]
        df["n_optimal_pre_adjusted_projected_sales"] = df["n_optimal_adjusted_projected_sales"]

        df["n_current_adjusted_projected_sales"] = (
            df["n_current_projected_sales"] + df["smoothened_saturation_effect_curr_sales"]
        )
        df["n_optimal_adjusted_projected_sales"] = (
            df["n_optimal_projected_sales"] + df["smoothened_saturation_effect_opt_sales"]
        )

        drop_cols=[
            "saturation_effect_curr_sales",
            "saturation_effect_opt_sales",
            "total_saturation_effect_curr_sales",
            "total_saturation_effect_opt_sales",
            "total_curr_projected_sales",
            "total_opt_projected_sales",
            "smoothened_saturation_effect_curr_sales",
            "smoothened_saturation_effect_opt_sales",
            "n_current_pre_adjusted_projected_sales",
            "n_optimal_pre_adjusted_projected_sales"
        ]

        df = df.drop(columns=drop_cols)
        # get price in current/optimal scenario
        # Calculate unit price for volume conversion:
        df['curr_unit_price'] = df['n_current_projected_sales']/df['n_current_projected_units_sold']
        df['opt_unit_price'] = df['n_optimal_projected_sales']/df['n_optimal_projected_units_sold']

        # Create Volume adjusted columns:
        df['n_current_adjusted_projected_units_sold'] = df['n_current_adjusted_projected_sales']/df['curr_unit_price']
        df['n_optimal_adjusted_projected_units_sold'] = df['n_optimal_adjusted_projected_sales']/df['opt_unit_price']

        
        return df
    
    def calculate_normalization_factors(self, df_runs, df_actual_sales_scaling, df_cloned_sku):
        """
        This function calculates normalization factors to adjust projected sales figures in optimization runs 
        based on actual historical sales data. The goal is to align model-generated projections with real-world 
        performance, improving the accuracy of downstream analysis.
        """

        # define smoothing variables:
        sales_normalized_factor = context.scaling_sales.smoothing_factors.sales_normalized_factor
        baysian_smooth_alpha = context.scaling_sales.smoothing_factors.baysian_smooth_alpha
        scaling_factor = context.scaling_sales.smoothing_factors.scaling_factor

        # Aggregate runs data to get total current facings and sales per unique combination
        # This handles cases where the same item appears multiple times in a run
        df_runs_agg = (
            df_runs.groupby([
            "run_id", 
            "final_cluster_labels", 
            "plano_id",
            "plano_ft",
            "fixture_size",
            "need_state_unique_id",
            "item_no_nbr"
        ]).agg(
            cf=("n_current_facings_sku", "sum"),        # Total current facings
            # curr_sales=("n_current_projected_sales", "sum")  # Total current projected sales
            curr_sales=("n_current_adjusted_projected_sales", "sum"),
            n_stores=("n_stores","first")
        ).reset_index())

        # --------------------------------
        # Merge with Actual Sales
        # --------------------------------

        # Join actual L52 sales data to the optimization runs
        # This allows us to calculate normalization factors
        df_runs_extended_agg = df_runs_agg.merge(
            df_actual_sales_scaling,
            on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"],
            # on=["item_no_nbr", "plano_id", ],
            how="left"
        )
        # Ensure numeric types for calculations
        df_runs_extended_agg["curr_sales"] = df_runs_extended_agg["curr_sales"].astype(float)
        df_runs_extended_agg["total_sales"] = df_runs_extended_agg["total_sales"].astype(float)

        # --------------------------------
        # Calculate Normalization Factors
        # --------------------------------

        # Step1: Calculate assortment-level normalization factors
        # Adding Clone items info
        df_cloned_sku_stats = (df_runs_extended_agg.merge(df_cloned_sku, left_on=["item_no_nbr", "plano_id"],
                                                         right_on=["cloned_item", "plano_id"], how="inner")
                                [["run_id", "final_cluster_labels", "plano_id", "plano_ft", "fixture_size",
                                  "need_state_unique_id", "item_no_nbr_y", "cloned_item", "curr_sales", "total_sales"]]
                                .rename(columns={"item_no_nbr_y": "item_no_nbr"})
                               )

        df_runs_extended_agg = (df_runs_extended_agg.merge(df_cloned_sku_stats,
                                                          on=["run_id", "final_cluster_labels",
                                                              "plano_id", "plano_ft", "fixture_size",
                                                              "need_state_unique_id", "item_no_nbr"],
                                                          how='left', suffixes=('_org', '_cloned')
                                                          )
                                                    .assign(
                                                    curr_sales=lambda dx: dx["curr_sales_cloned"].combine_first(dx["curr_sales_org"]),
                                                    total_sales=lambda dx: dx["total_sales_cloned"].combine_first(dx["total_sales_org"]),
                                                )
                                                    .drop(columns=["curr_sales_cloned", "curr_sales_org", "total_sales_cloned", "total_sales_org"])
                                )


        # Calculate normalization factor: actual_sales / projected_sales
        # This factor will be used to adjust all projected sales values
        df_runs_extended_agg["normalization_factor"] = np.nan
        df_runs_extended_agg.loc[
            (df_runs_extended_agg["curr_sales"] > 0), "normalization_factor"
        ] = (
            df_runs_extended_agg["total_sales"] / df_runs_extended_agg["curr_sales"]
        )

        # Handle cases where total_sales is 0 but curr_sales > 0 - set normalization factor to 1 as the logic above makes it zero.
        df_runs_extended_agg.loc[
            (df_runs_extended_agg["curr_sales"] > 0) & (df_runs_extended_agg["total_sales"] == 0), 
            "normalization_factor"
        ] = 1.0

        # Level 2: Fill by need_state within cluster/plano/size combination
        log.info(f"Percent of skus using median for scaling: {round(df_runs_extended_agg.normalization_factor.isna().sum()/len(df_runs_extended_agg.normalization_factor),2)}%")
        log.info(f"Percent of sales using median for scaling: {round(df_runs_extended_agg[df_runs_extended_agg['normalization_factor'].isna()]['total_sales'].sum()/df_runs_extended_agg['total_sales'].sum(),2)}%")
        
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].fillna(
        df_runs_extended_agg.groupby(
            ["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"]
        )['total_sales'].transform("sum")/df_runs_extended_agg.groupby(
            ["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"]
        )['curr_sales'].transform("sum") * sales_normalized_factor
        )
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].replace([np.inf, -np.inf], np.nan)

        # Level 3: Fill by cluster/plano/size combination
        # log.info(df_runs_extended_agg.normalization_factor.isna().sum())
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].fillna(
            df_runs_extended_agg.groupby(
                ["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"]
            )['total_sales'].transform("sum")/df_runs_extended_agg.groupby(
                ["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"]
            )['curr_sales'].transform("sum") * sales_normalized_factor

        )
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].replace([np.inf, -np.inf], np.nan)

        # Level 4: Fill by cluster/plano combination
        # log.info(df_runs_extended_agg.normalization_factor.isna().sum())
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].fillna(
            df_runs_extended_agg.groupby(
                ["final_cluster_labels", "plano_id"]
            )['total_sales'].transform("sum")/df_runs_extended_agg.groupby(
                ["final_cluster_labels", "plano_id"]
            )['curr_sales'].transform("sum") * sales_normalized_factor
        )
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].replace([np.inf, -np.inf], np.nan)

        # Level 5: Fill by plano only (most general)
        # log.info(df_runs_extended_agg.normalization_factor.isna().sum())
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].fillna(
            df_runs_extended_agg.groupby(
                ["plano_id"]
            )['total_sales'].transform("sum")/df_runs_extended_agg.groupby(
                ["plano_id"]
            )['curr_sales'].transform("sum") * sales_normalized_factor
        )
        df_runs_extended_agg["normalization_factor"] = df_runs_extended_agg["normalization_factor"].replace([np.inf, -np.inf], np.nan)
        # log.info(df_runs_extended_agg.normalization_factor.isna().sum())

        # --------------------------------
        # Prepare Final Adjustment Table
        # --------------------------------

        # Keep only the columns needed for merging back normalization factors
        df_runs_extended_agg = df_runs_extended_agg[[
            "run_id", "item_no_nbr","cloned_item","plano_id",
            "final_cluster_labels", "plano_ft", "fixture_size", 
            "normalization_factor", "total_sales"
        ]].drop_duplicates()

        # --------------------------------
        # Apply Adjustments to Original Data
        # --------------------------------

        # Merge normalization factors back to the original runs data
        df_runs_final = df_runs.merge(
            df_runs_extended_agg,
            on=["run_id", 
                "final_cluster_labels", "plano_id", "plano_ft", "fixture_size", 
                "plano_id", "item_no_nbr"],
            how="left"
        )

        # get NS_level_normalization_factor



        # Baysian Smooth
        global_factor = float(df_actual_sales_scaling.total_sales.sum())/df_runs.n_optimal_adjusted_projected_sales.sum()
        df_runs_final["normalization_factor"] = (df_runs_final["normalization_factor"] * (1-baysian_smooth_alpha) + global_factor * baysian_smooth_alpha) * scaling_factor
        # Final safety check: fill any remaining NA values with 1
        df_runs_final["normalization_factor"] = df_runs_final["normalization_factor"].fillna(1.0)

        return df_runs_final

    def apply_scaling(self, df_runs_raw, df_runs_final):
        """
        This function applies normalization factors to scale projected sales and volume metrics in 
        optimization runs, aligning them with actual sales data. It also calculates promotional (DNP) 
        adjustments and generates store-level scaled metrics for downstream reporting and analysis.
        """

        # Apply normalization factor to all projected sales columns
        # This scales the optimization projections to match actual sales levels

        # Adjust current state projections
        df_runs_final["n_current_scaled_adjusted_projected_sales"] = (
            df_runs_final["n_current_adjusted_projected_sales"] 
            * df_runs_final["normalization_factor"] 
        )

        # Adjust optimal state projections
        df_runs_final["n_optimal_scaled_adjusted_projected_sales"] = (
            df_runs_final["n_optimal_adjusted_projected_sales"]
            * df_runs_final["normalization_factor"]
        )

        ###########################################
        # Apply normalization for volume as well:
        ###########################################
        df_runs_final["n_current_scaled_adjusted_projected_units_sold"] = (
            df_runs_final["n_current_adjusted_projected_units_sold"] 
            * df_runs_final["normalization_factor"]
        )

        # Adjust optimal state projections
        df_runs_final["n_optimal_scaled_adjusted_projected_units_sold"] = (
            df_runs_final["n_optimal_adjusted_projected_units_sold"]
            * df_runs_final["normalization_factor"]
        )

        # --------------------------------
        # If projected sales = 0 but we do have l52 wks of sales in that assortment, adjust that to l52wks of sales then
        # --------------------------------
        # df_runs_final["n_optimal_adjusted_projected_sales"] = np.where((df_runs_final["n_current_adjusted_projected_sales"]==0) & (df_runs_final["n_optimal_adjusted_projected_sales"]==0),
        #                                                                df_runs_final["total_sales"], df_runs_final["n_optimal_adjusted_projected_sales"])


        # df_runs_final["n_current_adjusted_projected_sales"] = np.where((df_runs_final["n_current_adjusted_projected_sales"]==0) & (df_runs_final["discontinue_item"]==0),
        #                                                                df_runs_final["total_sales"], df_runs_final["n_current_adjusted_projected_sales"])



        # --------------------------------
        # Apply DNP Adjustments
        # --------------------------------

        # Calculate (DNP) amounts by applying DNP ratio to adjusted sales
        # DNP represents the portion of sales that comes from promotional activities

        # DNP for current state
        df_runs_final["n_current_scaled_adjusted_projected_dnp"] = (
            df_runs_final["n_current_scaled_adjusted_projected_sales"] 
            * df_runs_final["dnp_ratio"] 
        )

        # DNP for optimal state
        df_runs_final["n_optimal_scaled_adjusted_projected_dnp"] = (
            df_runs_final["n_optimal_scaled_adjusted_projected_sales"]
            * df_runs_final["dnp_ratio"]
        )

        # --------------------------------
        # Adjust New SKUs DNP logic
        # --------------------------------
        log.info("Adjust New SKUs scaling factors based on CM input")
        df_runs_final = self.adjust_new_sku_projection(df_runs_final)

        # --------------------------------
        # Temporary fix: Prevent positive facing SKUs from having zero scaled sales
        # --------------------------------
        # For items where scaled sales became zero but original adjusted sales were positive,
        # revert back to the original scaled sales (before new SKU adjustments)
        zero_new_items_mask = (
            (df_runs_final["n_optimal_adjusted_projected_sales"] > 0) &
            (df_runs_final["n_optimal_scaled_adjusted_projected_sales"] == 0)
        )

        if zero_new_items_mask.sum() > 0:
            log.warning(f"Found {zero_new_items_mask.sum()} records with zero scaled sales. Reverting to original scaling.")
            
            # Revert to original scaled values (normalization_factor * adjusted_sales)
            for scenario in ["current", "optimal"]:
                df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_scaled_adjusted_projected_sales"] = (
                    df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_adjusted_projected_sales"]
                )
                
                df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_scaled_adjusted_projected_units_sold"] = (
                    df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_adjusted_projected_units_sold"]
                )
                
                df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_scaled_adjusted_projected_dnp"] = (
                    df_runs_final.loc[zero_new_items_mask, f"n_{scenario}_adjusted_projected_dnp"]
                )
        # --------------------------------
        # Collect the sales uplift after the scaling factor
        # --------------------------------

        l52_sales = df_runs_final.pipe(lambda dx: dx[dx['cloned_item'].isna()]).total_sales.sum()
        curr_sales_adj_scaled = df_runs_final.n_current_scaled_adjusted_projected_sales.sum()
        opt_sales_adj_scaled = df_runs_final.n_optimal_scaled_adjusted_projected_sales.sum()

        curr_sales_adj = df_runs_final['n_current_adjusted_projected_sales'].sum()
        opt_sales_adj = df_runs_final['n_optimal_adjusted_projected_sales'].sum()

        log.info(f"L52W sales: {round(l52_sales, 1)}, Opti Scaled Adjusted Current Sales: {round(curr_sales_adj_scaled, 1)}")
        log.info(f"Lift before scaling: {round((opt_sales_adj - curr_sales_adj) / curr_sales_adj, 3)}, After scaling: {round((opt_sales_adj_scaled - curr_sales_adj_scaled) / curr_sales_adj_scaled, 3)}")

        # --------------------------------
        # Create rep store level scaled columns
        # --------------------------------

        # divide by n_stores for the raw POG/CLUSTER/item level
        base_cols = [
            'n_current_scaled_adjusted_projected_sales',
            'n_optimal_scaled_adjusted_projected_sales',
            'n_current_scaled_adjusted_projected_units_sold',
            'n_optimal_scaled_adjusted_projected_units_sold',
            'n_current_scaled_adjusted_projected_dnp',
            'n_optimal_scaled_adjusted_projected_dnp'
        ]

        n_store_cols = [col + '_n_stores' for col in base_cols]
        df_runs_final[n_store_cols] = df_runs_final[base_cols]
        df_runs_final[base_cols] = df_runs_final[base_cols].div(df_runs_final['n_stores'], axis=0)

        # --------------------------------
        # Merge for final upload Table
        # --------------------------------

        # Keep the OG opti table but add the new columns we need
        drop_cols = [
            'curr_unit_price',
            'opt_unit_price',
        ]
        
        scaled_cols = [
            'normalization_factor',
            'total_sales',
            'n_current_scaled_adjusted_projected_sales',
            'n_optimal_scaled_adjusted_projected_sales',
            'n_current_scaled_adjusted_projected_units_sold',
            'n_optimal_scaled_adjusted_projected_units_sold',
            'n_current_scaled_adjusted_projected_dnp',
            'n_optimal_scaled_adjusted_projected_dnp'
        ]

        join_cols = [
            'plano_id', 'item_no_nbr', 'item_no_desc', 'brand_name',
        'vendor_name', 'seg_dsc', 'discontinue_item', 'new_item',
        'need_state_unique_id', 'scenario_id', 'final_cluster_labels',
        'plano_cat_desc', 'plano_cat_id', 'fixture_desc', 'plano_ft',
        'fixture_size', 'cluster', 'volume', 'risk',
        ]

        df_upload = df_runs_raw.drop(columns=drop_cols).merge(df_runs_final[join_cols + scaled_cols + n_store_cols], how='left', on=join_cols)
        return df_upload

    def adjust_new_sku_projection(self, df_runs_final):
        """
        Based on estimated sales, door count input from the new SKU template, update the sales/margin/volume columns for new SKUs

        Scaled sales(if no cloned items) = Estimated Sales / Estimated door count X Optimal Door Count X Incremental Facing Uplift

        Incremental Facing Uplift at i = Productivity at facing i/productivity at facing (i-1)

        """
        new_sku_sql = f"""
        SELECT *
        FROM {context.data_stores.raw_data.table_name.need_state_table}
        WHERE (STANDARDIZED_DSC, timestamp) in (
            SELECT STANDARDIZED_DSC, max(timestamp) as timestamp
            FROM {context.data_stores.raw_data.table_name.need_state_table}
            WHERE STANDARDIZED_DSC in ('{"', '".join(context.data_stores.raw_data.categories)}')
            GROUP BY ALL
        )
        AND "New Item" = True 
        """

        log.info(f"Fetching new sku data from table: {context.data_stores.raw_data.table_name.need_state_table}")
        df_new_sku = settings.SNOWFLAKE_CONNECTION.cursor().execute(new_sku_sql).fetch_pandas_all()

        if df_new_sku.empty:
            log.info("No new items found, skipping the new items adjustments...")
            return df_runs_final

        total_stores = df_runs_final.groupby(["item_no_nbr"])["n_stores"].sum().max()
        log.info(
            f"total stores in scope: {total_stores}, will use this number as estimated door count for new items if it's not given")

        # Convert all column names to lowercase for consistency
        df_new_sku.columns = map(str.lower, df_new_sku.columns)
        df_new_sku = df_new_sku[
            (~df_new_sku["estimated_annual_sales"].isna()) & (df_new_sku["estimated_annual_sales"] > 0)]
        df_new_sku["estimated_door_count"] = df_new_sku["estimated_door_count"].fillna(total_stores)
        df_new_sku["sales_per_door"] = df_new_sku["estimated_annual_sales"] / df_new_sku["estimated_door_count"]
        df_new_sku["item_no_nbr"] = df_new_sku["product_id"]
        df_new_sku = df_new_sku[["item_no_nbr", "sales_per_door"]].drop_duplicates()


        new_sku_elasticity_sql = f"""
        WITH CATEGORY_TRANSFORMED AS (
            SELECT *,
                CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                    WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                    ELSE CAT_DSC
                END AS TRANSFORMED_CAT_DSC
            FROM {context.data_stores.raw_data.table_name.elasticity_curve_table}
        )
        
        SELECT concat(SPLIT_PART(cluster,'-',1),'_',special_version_id,'-',SPLIT_PART(cluster,'-',2)) as final_cluster_labels, *,
        sku_nbr as item_no_nbr
        FROM CATEGORY_TRANSFORMED
        CROSS JOIN (SELECT distinct special_version_id
                    FROM {context.data_stores.raw_data.table_name.planogram_store_version}
                    WHERE PLANO_CAT_DSC in ('{"', '".join(context.data_stores.raw_data.categories)}')
                    )
        WHERE SKU_NBR in 
            (
            SELECT distinct product_id
            FROM {context.data_stores.raw_data.table_name.need_state_table}
            WHERE TRUE
            AND (STANDARDIZED_DSC, timestamp) in (
                SELECT STANDARDIZED_DSC, max(timestamp) as timestamp
                FROM {context.data_stores.raw_data.table_name.need_state_table}
                WHERE STANDARDIZED_DSC in ('{"', '".join(context.data_stores.raw_data.categories)}')
                GROUP BY ALL
                    )
            AND "New Item" = True
            )
        AND (TRANSFORMED_CAT_DSC, timestamp) in (
            SELECT CAT_DSC, max(timestamp) as timestamp
            FROM {context.data_stores.raw_data.table_name.elasticity_curve_table} WHERE CAT_DSC in ('{"', '".join(context.data_stores.raw_data.categories)}')
            GROUP BY ALL
            )
        """

        log.info(f"Fetching new sku elasticity...")
        df_new_sku_elasticity = settings.SNOWFLAKE_CONNECTION.cursor().execute(
            new_sku_elasticity_sql).fetch_pandas_all()
        df_new_sku_elasticity.columns = map(str.lower, df_new_sku_elasticity.columns)
        cols = ["final_cluster_labels", "item_no_nbr", "planogram_dsc",
                "n_space_prod_fit_facings_0", "n_space_prod_fit_facings_1",
                "n_space_prod_fit_facings_2",
                "n_space_prod_fit_facings_3", "n_space_prod_fit_facings_4", "n_space_prod_fit_facings_5",
                "n_space_prod_fit_facings_6",
                "n_space_prod_fit_facings_7", "n_space_prod_fit_facings_8", "n_space_prod_fit_facings_9",
                "n_space_prod_fit_facings_10"
                ]
        df_new_sku_elasticity_uplift = df_new_sku_elasticity[cols].rename(columns = {"planogram_dsc":"fixture_desc"})
        df_new_sku_elasticity_uplift.loc[:, f"uplift_facings_1"] = 1
        df_new_sku_elasticity_uplift.loc[:, f"uplift_facings_0"] = 1
        for facing in range(2, 11):
            df_new_sku_elasticity_uplift.loc[:, f"uplift_facings_{facing}"] = (
                    df_new_sku_elasticity_uplift.loc[:, f"n_space_prod_fit_facings_{facing}"] /
                    df_new_sku_elasticity_uplift.loc[:, "n_space_prod_fit_facings_1"]
            )
        df_runs_final_adj = df_runs_final.merge(df_new_sku, on=["item_no_nbr"], how='left') \
            .merge(df_new_sku_elasticity_uplift, on=["item_no_nbr", "final_cluster_labels", "fixture_desc"], how='left')
        for scenario in ["current", "optimal"]:
            df_runs_final_adj[f"n_{scenario}_facings"] = df_runs_final_adj[f"n_{scenario}_facings_sku"] / \
                                                         df_runs_final_adj["n_stores"]

            df_runs_final_adj[f"n_{scenario}_facings_uplift"] = np.select(
                [df_runs_final_adj[f"n_{scenario}_facings"].eq(i) for i in range(2, 11)],
                [df_runs_final_adj[f"uplift_facings_{i}"] for i in range(2, 11)],
                default=1
            )

            df_runs_final_adj[f"n_{scenario}_pods"] = np.where(df_runs_final_adj[f"n_{scenario}_facings_sku"] > 0,
                                                               df_runs_final_adj["n_stores"], 0)

            df_runs_final_adj[f"n_{scenario}_scaled_adjusted_projected_sales"] = np.where(
                (~df_runs_final_adj["sales_per_door"].isna()) & (df_runs_final_adj["cloned_item"].isna()),
                df_runs_final_adj["sales_per_door"] * df_runs_final_adj[f"n_{scenario}_pods"]
                * df_runs_final_adj[f"n_{scenario}_facings_uplift"],
                df_runs_final_adj[f"n_{scenario}_scaled_adjusted_projected_sales"]
            )

            df_runs_final_adj[f"n_{scenario}_scaled_adjusted_projected_units_sold"] = np.nan_to_num(
                np.where(
                    (~df_runs_final_adj["sales_per_door"].isna()) & (df_runs_final_adj["cloned_item"].isna()),
                    df_runs_final_adj["sales_per_door"] * df_runs_final_adj[f"n_{scenario}_pods"]
                    * df_runs_final_adj[f"n_{scenario}_facings_uplift"] / df_runs_final_adj[
                        f"n_{scenario}_adjusted_projected_sales"] * df_runs_final_adj[
                        f"n_{scenario}_adjusted_projected_units_sold"],
                    df_runs_final_adj[f"n_{scenario}_adjusted_projected_units_sold"]
                )
            )

            df_runs_final_adj[f"n_{scenario}_scaled_adjusted_projected_dnp"] = (
                    df_runs_final_adj[f"n_{scenario}_scaled_adjusted_projected_sales"] * df_runs_final["dnp_ratio"])

        return df_runs_final_adj

    def create_facings_change_categories(self, df_scaled_opti):
        """
        This function takes the scaled df and creates binary flags to indicate if an item in the assortment is:
            1. New to a store
            2. New to Chain
            3. Removed from a store
            4. Increased Facings
            5. Decreased Facing
            6. No change in Facings
        """

        #   New Item to store
        df_scaled_opti['new_to_store_flag'] = (
            (df_scaled_opti["n_optimal_facings_sku"] > 0) & 
            (df_scaled_opti["n_current_facings_sku"] == 0) & 
            (df_scaled_opti["new_item"] == 0)
        ).astype(int)

        # Removed Item
        df_scaled_opti['removed_from_store_flag'] = (
            (df_scaled_opti["n_optimal_facings_sku"] == 0) & 
            (df_scaled_opti["n_current_facings_sku"] > 0)
        ).astype(int)

        # Increase Facings (only when not a New Item)
        df_scaled_opti['increased_facings_flag'] = (
            (df_scaled_opti['new_to_store_flag'] == 0) & 
            (df_scaled_opti["new_item"] == 0) &
            (df_scaled_opti["n_optimal_facings_sku"] > df_scaled_opti["n_current_facings_sku"])
        ).astype(int)

        # Decrease Facings (only when not a Removed Item)
        df_scaled_opti['decreased_facings_flag'] = (
            (df_scaled_opti['removed_from_store_flag'] == 0) & 
            (df_scaled_opti["n_optimal_facings_sku"] < df_scaled_opti["n_current_facings_sku"])
        ).astype(int)

        # No Change
        df_scaled_opti['no_facings_change_flag'] = (
            (df_scaled_opti["n_optimal_facings_sku"] == df_scaled_opti["n_current_facings_sku"]) &
            (df_scaled_opti["new_item"] == 0)
        ).astype(int)

        # Category Validation (sum of five flags
        flag_cols = [
            'new_to_store_flag', 'new_item', 'removed_from_store_flag', 
            'increased_facings_flag', 'decreased_facings_flag', 'no_facings_change_flag'
        ]
        df_scaled_opti['cat_val_check'] = df_scaled_opti[flag_cols].sum(axis=1)
        
        # Log warning if any row has ambiguous or missing categorization
        invalid_rows = df_scaled_opti[df_scaled_opti['cat_val_check'] != 1]
        if not invalid_rows.empty:
            logging.warning(
                f"{len(invalid_rows)} rows have ambiguous or missing facings change categories (cat_val_check != 1)."
            )
            # Optional: log a few examples
            logging.debug("Sample problematic rows:\n%s", invalid_rows.head())

            # Output invalid rows 
            invalid_rows.to_csv("invalid_facings_rows.csv", index=False)

        df_scaled_opti['facings_change_category'] = df_scaled_opti[flag_cols].idxmax(axis=1)
        df_scaled_opti['facings_change_category'] = np.where(
            df_scaled_opti['facings_change_category']=='new_item',
            'new_to_chain_flag', 
            df_scaled_opti['facings_change_category']
        )

        return df_scaled_opti

    def pull_transference_effect(self,df_scaled):
        lv1_q = f"""
        SELECT 
            distinct
            product_id as item_no_nbr,
            cdt, 
            "attribute_value" as lvl1_attribute
        FROM {context.data_stores.raw_data.table_name.need_state_table}
        WHERE "attribute_key" = 'ATTRIBUTE_1'
        and (timestamp) in (
            SELECT max(timestamp)
            FROM {context.data_stores.raw_data.table_name.need_state_table}
            WHERE TRUE
            AND CASE
                WHEN PLANOGRAM_DSC = 'HOUSEHOLD' THEN REPLACE(STANDARDIZED_DSC, 'LAUNDRY', 'HOUSEHOLD')
                WHEN PLANOGRAM_DSC = 'BEVERAGE COOLER' THEN REPLACE(STANDARDIZED_DSC, 'SODA', 'BEVERAGES')
                WHEN PLANOGRAM_DSC = 'COLD REMEDIES'
                AND PRODUCT_ID IN (550147, 553771, 668672, 641986, 289586)
                THEN REPLACE(STANDARDIZED_DSC, 'HOME DIAGNOSTICS', 'COLD REMEDIES')
                ELSE STANDARDIZED_DSC
            END IN ('{"', '".join(context.data_stores.raw_data.categories)}')
            )
        """


        transference_q = f"""
        with latest_ns_lv1 as (
                SELECT 
                    distinct 
                    product_id as item_no_nbr,
                    cdt, 
                    "attribute_value" as lvl1_attribute
                FROM {context.data_stores.raw_data.table_name.need_state_table}
                WHERE "attribute_key" = 'ATTRIBUTE_1'
                and (timestamp) in (
                    SELECT max(timestamp)
                    FROM {context.data_stores.raw_data.table_name.need_state_table}
                    WHERE TRUE
                    AND CASE
                        WHEN PLANOGRAM_DSC = 'HOUSEHOLD' THEN REPLACE(STANDARDIZED_DSC, 'LAUNDRY', 'HOUSEHOLD')
                        WHEN PLANOGRAM_DSC = 'BEVERAGE COOLER' THEN REPLACE(STANDARDIZED_DSC, 'SODA', 'BEVERAGES')
                        WHEN PLANOGRAM_DSC = 'COLD REMEDIES'
                        AND PRODUCT_ID IN (550147, 553771, 668672, 641986, 289586)
                        THEN REPLACE(STANDARDIZED_DSC, 'HOME DIAGNOSTICS', 'COLD REMEDIES')
                        ELSE STANDARDIZED_DSC
                    END IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                    )
                )
                ,
                walk_rate as (
                    SELECT DISTINCT 
                        SKU_ID AS ITEM_NO_NBR, 
                        MEDIAN(WALK_RATE) AS  walk_rate,
                    FROM {context.data_stores.raw_data.table_name.walk_rate_table}
                    WHERE ANALYSIS_END_DATE = (SELECT MAX(ANALYSIS_END_DATE) FROM {context.data_stores.raw_data.table_name.walk_rate_table})
                    AND SKU_ID in (
                    SELECT DISTINCT item_no_nbr FROM latest_ns_lv1
                    )
                    GROUP BY SKU_ID
                )
                
                SELECT a.*, b.walk_rate
                FROM latest_ns_lv1 a
                LEFT JOIN walk_rate b on a.item_no_nbr = b.item_no_nbr
                WHERE walk_rate is not null;
        """

        df_sku_walk_rate = settings.SNOWFLAKE_CONNECTION.cursor().execute(transference_q).fetch_pandas_all()
        lv1_ns_df = settings.SNOWFLAKE_CONNECTION.cursor().execute(lv1_q).fetch_pandas_all()

        df_sku_walk_rate.columns = map(str.lower, df_sku_walk_rate.columns)
        lv1_ns_df.columns = map(str.lower, lv1_ns_df.columns)

        df_sku_sales = df_scaled.groupby(["item_no_nbr"])["total_sales"].sum().reset_index()

        def wavg(group, avg_name, weight_name):
            """
            Calculates the weighted average for a grouped DataFrame.
            """
            # Use np.average for an efficient calculation
            s = np.sum(group[weight_name])
            return np.average(group[avg_name], weights=group[weight_name]) if s!=0 else np.nan

        # Caclculate sales weighted walk rate of existing items within CDT, lvl1 attribute. Clip the walk rate.
        walk_rate_lower_limit = context.scaling_sales.transference_factors.walk_rate_limit_lower
        walk_rate_upper_limit = context.scaling_sales.transference_factors.walk_rate_limit_upper
        df_lvl1_walk_rate = (df_sku_sales.merge(df_sku_walk_rate, on=["item_no_nbr"], how="left")
                                        .groupby(["cdt","lvl1_attribute"])
                                        .apply(wavg, "walk_rate","total_sales")
                                        .clip(lower=walk_rate_lower_limit, upper=walk_rate_upper_limit)
                                        .reset_index(name="lvl1_walk_rate")
                             )

        return df_lvl1_walk_rate, lv1_ns_df

    def apply_transference_effect(self, df_scaled, df_lvl1_transference, lv1_ns_df):
        assortment_idx = ["plano_id", "final_cluster_labels", "plano_ft", "fixture_size"]

        # 1. For each Need_states with new items only, calculate the transference value per lv1
        existing_need_states = df_scaled.pipe(lambda dx: dx[dx["new_item"] == 0])["need_state_unique_id"].unique()
        new_need_states = df_scaled[
            df_scaled.groupby("need_state_unique_id")["new_item"].transform("sum")
            ==df_scaled.groupby("need_state_unique_id")["new_item"].transform("count")
        ]["need_state_unique_id"].unique()
        new_sku_transference_sales = (df_scaled
                                      # .pipe(lambda dx, existing_need_states=existing_need_states: dx[~dx["need_state_unique_id"].isin(existing_need_states)])
                                      # .pipe(lambda dx: dx[dx["new_item"] == 1])
                                      [df_scaled["need_state_unique_id"].isin(new_need_states)]
                                      .merge(lv1_ns_df, on=["item_no_nbr"], how="left")
                                      .merge(df_lvl1_transference, on=["cdt","lvl1_attribute"], how="left")
                                      .assign(lvl1_walk_rate=lambda dx: dx["lvl1_walk_rate"].fillna(dx['lvl1_walk_rate'].mean()))
                                      .assign(lvl1_walk_rate=lambda dx: dx["lvl1_walk_rate"].fillna(0.2))
                                      .assign(transference_sales=lambda dx: dx["n_optimal_scaled_adjusted_projected_sales_n_stores"] * (1 - dx["lvl1_walk_rate"]))
                                      )[assortment_idx + ["item_no_nbr", "cdt", "lvl1_attribute", "lvl1_walk_rate", "transference_sales"]]

        df_scaled = (df_scaled.merge(lv1_ns_df, on=["item_no_nbr"], how="left")
                              .merge(df_lvl1_transference, on=["cdt","lvl1_attribute"], how="left")
                             .assign(lvl1_walk_rate=lambda dx: dx["lvl1_walk_rate"].fillna(dx['lvl1_walk_rate'].mean()))
                             .assign(lvl1_walk_rate=lambda dx: dx["lvl1_walk_rate"].fillna(0.2))
                     )

        keep_cols = list(df_scaled.columns)
        df_scaled_unadjusted = df_scaled.pipe(lambda dx: dx[(dx["new_item"] == 1) | (dx["discontinue_item"] == 1)])

        df_scaled_adjusted = df_scaled.pipe(lambda dx: dx[(dx["new_item"] == 0) & (dx["discontinue_item"] == 0)])

        df_scaled_adjusted = (df_scaled_adjusted.assign(sales_ratio_lv1 = lambda dx: dx["n_optimal_scaled_adjusted_projected_sales_n_stores"]/dx.groupby(assortment_idx + ["cdt", "lvl1_attribute"])["n_optimal_scaled_adjusted_projected_sales_n_stores"].transform(lambda x: x.sum()))
                                                .assign(sales_ratio_cdt=lambda dx: dx["n_optimal_scaled_adjusted_projected_sales_n_stores"] /
                                                                           dx.groupby(assortment_idx +  ["cdt"])["n_optimal_scaled_adjusted_projected_sales_n_stores"].transform(lambda x: x.sum()))
                                                .assign(sales_ratio_category=lambda dx: dx["n_optimal_scaled_adjusted_projected_sales_n_stores"] /
                                                           dx.groupby(assortment_idx)["n_optimal_scaled_adjusted_projected_sales_n_stores"].transform(lambda x: x.sum()))
                              )

        # 2. Check for each lv1 transference, if any existing items share the same transference attribute
        lv1_existing_items = df_scaled_adjusted.pipe(lambda dx: dx[dx["n_optimal_facings_sku"] > 0])[
            assortment_idx + ["cdt", "lvl1_attribute"]].drop_duplicates()
        cdt_existing_items = df_scaled_adjusted.pipe(lambda dx: dx[dx["n_optimal_facings_sku"] > 0])[
            assortment_idx + ["cdt"]].drop_duplicates()

        new_sku_transference_sales_assigned_to_lv1 = (new_sku_transference_sales
                                                      .merge(lv1_existing_items,
                                                             on=assortment_idx + ["cdt", "lvl1_attribute"])
                                                      .groupby(assortment_idx + ["cdt", "lvl1_attribute"])[
                                                          "transference_sales"].sum()
                                                      .reset_index(name="transference_sales_lvl1")
                                                      )
        new_sku_transference_sales_assigned_to_cdt = (
            new_sku_transference_sales.merge(lv1_existing_items, on=assortment_idx + ["cdt", "lvl1_attribute"],
                                             indicator=True, how='left')
            .pipe(lambda dx: dx[dx["_merge"] == 'left_only'])
            .merge(cdt_existing_items, on=assortment_idx + ["cdt"], how='inner')
            .groupby(assortment_idx + ["cdt"])["transference_sales"].sum()
            .reset_index(name="transference_sales_cdt")
            )
        new_sku_transference_sales_assigned_to_category = (
            new_sku_transference_sales.merge(cdt_existing_items, on=assortment_idx + ["cdt"], indicator=True,
                                             how='left')
            .pipe(lambda dx: dx[dx["_merge"] == 'left_only'])
            .groupby(assortment_idx)["transference_sales"].sum()
            .reset_index(name="transference_sales_category")
            )

        # 3. Apply the transference effect to items sharing the same lv1 in existing items; For lv1 does not exists in any existing items, apply that into the whole cdt
        df_scaled_adjusted = (df_scaled_adjusted.merge(new_sku_transference_sales_assigned_to_lv1,
                                                       on=assortment_idx + ["cdt", "lvl1_attribute"], how="left")
                              .merge(new_sku_transference_sales_assigned_to_cdt,on=assortment_idx + ["cdt"], how="left")
                              .merge(new_sku_transference_sales_assigned_to_category,  on=assortment_idx, how="left")
                              .assign(lv1_new_sku_transference=lambda dx: dx["sales_ratio_lv1"] * dx["transference_sales_lvl1"])
                              .assign(cdt_new_sku_transference=lambda dx: dx["sales_ratio_cdt"] * dx["transference_sales_cdt"])
                              .assign(category_new_sku_transference=lambda dx: dx["sales_ratio_category"] * dx["transference_sales_category"])
                              .assign(new_sku_transference=lambda dx: dx["lv1_new_sku_transference"].fillna(0) + dx["cdt_new_sku_transference"].fillna(0) + dx["category_new_sku_transference"].fillna(0))
                              # at most apply 50% of its current optimal sales as sales transference
                              .assign(new_sku_transference_adj=lambda dx: np.minimum(dx["new_sku_transference"], dx["n_optimal_scaled_adjusted_projected_sales_n_stores"] * context.scaling_sales.transference_factors.max_adj_proportion)
                                      )
                              )

        new_sku_transference_sales_value = new_sku_transference_sales_assigned_to_lv1['transference_sales_lvl1'].sum() + new_sku_transference_sales_assigned_to_cdt['transference_sales_cdt'].sum() + new_sku_transference_sales_assigned_to_category['transference_sales_category'].sum()
        log.info(f"sales transferred to new items: {new_sku_transference_sales_value}")
        log.info(f"sales transferred from existing items(origin -> adjusted): {df_scaled_adjusted['new_sku_transference'].sum()} -> {df_scaled_adjusted['new_sku_transference_adj'].sum()}")

        # 4. Append unadjusted row
        keep_cols = keep_cols + ["new_sku_transference_adj"]
        df_scaled_adjusted = pd.concat([df_scaled_adjusted, df_scaled_unadjusted])[keep_cols]
        df_scaled_adjusted["new_sku_transference_adj"] = df_scaled_adjusted["new_sku_transference_adj"].fillna(0)

        # 5. Adjust the optimal sales for existing items
        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_n_stores"] - df_scaled_adjusted["new_sku_transference_adj"]
        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_units_sold_w_transference_n_stores"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_units_sold_n_stores"] * np.where(df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"] > 0,
                                                                                                                df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"] / df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_n_stores"],0
                                                                                                                )
        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_dnp_w_transference_n_stores"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"] * df_scaled_adjusted["dnp_ratio"]

        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"]/df_scaled_adjusted['n_stores']
        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_units_sold_w_transference"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_units_sold_w_transference_n_stores"]/df_scaled_adjusted['n_stores']
        df_scaled_adjusted["n_optimal_scaled_adjusted_projected_dnp_w_transference"] = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_dnp_w_transference_n_stores"]/df_scaled_adjusted['n_stores']

        curr_sales_adj_scaled = df_scaled_adjusted["n_current_scaled_adjusted_projected_sales_n_stores"].sum()
        opt_sales_adj_scaled = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_n_stores"].sum()
        opt_sales_adj_scaled_w_transference = df_scaled_adjusted["n_optimal_scaled_adjusted_projected_sales_w_transference_n_stores"].sum()

        log.info(f"Lift after considering transference: {round(opt_sales_adj_scaled/curr_sales_adj_scaled - 1, 3)} -> {round(opt_sales_adj_scaled_w_transference/curr_sales_adj_scaled - 1, 3)}")

        # 6. rename the columns to avoid the output columns mismatch
        for metrics in ["sales","units_sold","dnp"]:
            col_mapping = {
                f"n_optimal_scaled_adjusted_projected_{metrics}_n_stores": f"n_optimal_scaled_adjusted_projected_{metrics}_wo_transference_n_stores",
                f"n_optimal_scaled_adjusted_projected_{metrics}_w_transference_n_stores": f"n_optimal_scaled_adjusted_projected_{metrics}_n_stores",
                f"n_optimal_scaled_adjusted_projected_{metrics}":                f"n_optimal_scaled_adjusted_projected_{metrics}_wo_transference",
                f"n_optimal_scaled_adjusted_projected_{metrics}_w_transference": f"n_optimal_scaled_adjusted_projected_{metrics}",
            }
            df_scaled_adjusted.rename(columns=col_mapping, inplace=True)

        df_scaled_adjusted = df_scaled_adjusted.drop(columns=["new_sku_transference_adj"])


        return df_scaled_adjusted