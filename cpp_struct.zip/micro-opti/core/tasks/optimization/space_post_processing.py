import pandas as pd
from oxygen.conf.context import context
import numpy as np

import logging

log = logging.getLogger(__name__)


# Function to explode rows based on facings increment from current to optimal
def vectorized_explode_rows(df: pd.DataFrame) -> pd.DataFrame:
    """
    Vectorizes the row explosion by generating multiple rows based on the incremental change in facings from
    the current facings (`n_current_facings_sku`) to the optimal facings (`n_optimal_facings_sku`). For each
    increment, new columns are created for `n_previous_facings_sku`, `n_next_facings_sku`, and
    `space_prod_increase`.

    Args:
        df (pd.DataFrame): DataFrame containing the following columns:
            - `n_current_facings_sku` (int): The current facings for the SKU.
            - `n_optimal_facings_sku` (int): The optimal facings for the SKU.
            - `is_protect_items` (int): A flag indicating whether the item is protected.
            - `n_space_prod_fit_facings_*` (int): Space productivity for different numbers of facings.

    Returns:
        pd.DataFrame: A new DataFrame with exploded rows for each facing increment, containing:
            - `n_current_facings_sku`: The current facings for the SKU.
            - `n_optimal_facings_sku`: The optimal facings for the SKU.
            - `n_previous_facings_sku`: The previous number of facings in the exploded row.
            - `n_next_facings_sku`: The next number of facings in the exploded row.
            - `space_prod_increase`: The incremental increase in space productivity between facings.

    Example Input:
        row = pd.Series({
            'n_current_facings_sku': 2,
            'n_optimal_facings_sku': 3,
            'n_space_prod_fit_facings_0': 0,
            'n_space_prod_fit_facings_1': 10,
            'n_space_prod_fit_facings_2': 13,
            'n_space_prod_fit_facings_3': 14,
            'n_space_prod_fit_facings_4': 15
        })

    Example Output:
        exploded_rows = vectorized_explode_rows(row)

        Output:
        [
            {'n_previous_facings_sku': 0, 'n_next_facings_sku': 1, 'space_prod_increase': 10, ...},
            {'n_previous_facings_sku': 1, 'n_next_facings_sku': 2, 'space_prod_increase': 3, ...},
            {'n_previous_facings_sku': 2, 'n_next_facings_sku': 3, 'space_prod_increase': 1, ...}
        ]
    """

    # Step 1: Create a DataFrame with repeated indices based on the number of facings to be exploded
    optimal_repeats = df["n_optimal_facings_sku"]
    repeated_indices = np.repeat(df.index, optimal_repeats)

    # Step 2: Create the 'n_previous_facings_sku' and 'n_next_facings_sku' columns
    exploded_df = df.loc[repeated_indices].copy()  # Exploded DataFrame by index
    exploded_df["n_previous_facings_sku"] = exploded_df.groupby(
        exploded_df.index
    ).cumcount()
    exploded_df["n_next_facings_sku"] = exploded_df["n_previous_facings_sku"] + 1

    # Step 3: Calculate the space_prod_increase for each exploded row
    exploded_df["space_prod_increase"] = exploded_df.apply(
        lambda row: row[f"n_space_prod_fit_facings_{int(row['n_next_facings_sku'])}"]
        - row[f"n_space_prod_fit_facings_{int(row['n_previous_facings_sku'])}"],
        axis=1,
    )

    # Step 4: Handle cases where n_optimal_facings_sku == 0
    # Filter out rows where n_optimal_facings_sku == 0, and reset those manually
    zero_optimal_rows = df[df["n_optimal_facings_sku"] == 0].copy()
    zero_optimal_rows["n_previous_facings_sku"] = 0
    zero_optimal_rows["n_next_facings_sku"] = 0
    zero_optimal_rows[
        "space_prod_increase"
    ] = 999999  # we will keep the row as is if the n_optimal_facings_sku = 0, TODO also add protected ones as well

    # Append these rows back to the exploded DataFrame
    exploded_df = pd.concat([exploded_df, zero_optimal_rows], ignore_index=True)

    return exploded_df


def fetch_total_linear_space_dept_fixture_ft(
    df_opti_modeling_output_: pd.DataFrame, df_store_space_characteristics: pd.DataFrame
) -> pd.DataFrame:
    """
    Fetches and merges total linear space department fixture feet data from the store space characteristics
    DataFrame into the optimization modeling output DataFrame. If the column `n_total_linear_space_dept_fixture_ft`
    exists in the `df_opti_modeling_output_` DataFrame, it is dropped before the merge. The function then merges
    the store space characteristics with the modeling output based on the optimizer's grouping granularity and
    additional aggregation levels defined in the context.

    Args:
        df_opti_modeling_output_ (pd.DataFrame): A DataFrame containing the optimization modeling output.
        df_store_space_characteristics (pd.DataFrame): A DataFrame containing the store space characteristics
            including the total linear space department fixture feet (`n_total_linear_space_dept_fixture_ft`).

    Returns:
        pd.DataFrame: A merged DataFrame with total linear space department fixture feet included.

    Raises:
        Logs a warning if any records in the resulting DataFrame have missing `n_total_linear_space_dept_fixture_ft`.
    """
    df_opti_modeling_output = df_opti_modeling_output_.copy()
    if "n_total_linear_space_dept_fixture_ft" in df_opti_modeling_output.columns:
        df_opti_modeling_output = df_opti_modeling_output.drop(
            columns=["n_total_linear_space_dept_fixture_ft"]
        )

    df_store_space_characteristics = df_store_space_characteristics[
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_store_level
        + ["n_total_linear_space_dept_fixture_ft"]
    ]

    df_opti_modeling_output = df_opti_modeling_output.merge(
        df_store_space_characteristics,
        on=context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_store_level,
        how="left",
    )

    # available linear space should exclude the space reserved for local items
    df_opti_modeling_output["available_linear_space"] = df_opti_modeling_output[
        "n_total_linear_space_dept_fixture_ft"
    ] * (1 - context.optimization.model_formulation.local_items_reserved_space_pct)

    df_opti_modeling_output_null_n_total_linear_space_dept_fixture_ft = (
        df_opti_modeling_output[
            df_opti_modeling_output["n_total_linear_space_dept_fixture_ft"].isna()
        ]
    )

    # if n_total_linear_space_dept_fixture_ft not exist should report a warning
    if df_opti_modeling_output_null_n_total_linear_space_dept_fixture_ft.empty is False:
        log.error(f"Store space characteristics missing...")
        log.info(df_opti_modeling_output_null_n_total_linear_space_dept_fixture_ft)

    return df_opti_modeling_output


def update_item_no_optimal_facings(
    df_opti_modeling_output_: pd.DataFrame,
    df_protected_items: pd.DataFrame,
    groupby_cols_: list,
) -> pd.DataFrame:
    """
    Updates the optimal facings for each sku (`item_no_nbr`) in the dataframe by exploding rows,
    calculating productivity increase per unit of linear space, and aggregating based on available space.

    This function first filters the relevant columns from the input dataframe, explodes rows for each sku
    based on the range of facings, calculates space productivity increase, ranks skus based on productivity
    per linear space, and then allocates space while ensuring it does not exceed the available space. Finally,
    the optimal facings are aggregated back to the original granularity.

    Args:
        df_opti_modeling_output_ (pd.DataFrame): Input dataframe containing the optimization modeling output.
            It must contain the following columns:
            - `item_no_nbr`: The sku identifier.
            - `new_item_item_no_nbr`: A new item sku identifier.
            - `n_current_facings_sku`: Current facings for the SKU.
            - `n_optimal_facings_sku`: Optimal facings for the SKU.
            - `n_current_linear_space_per_facing_sku`: Current linear space occupied per facing of the SKU.
            - `available_linear_space`: Available linear space for allocation.
            - `n_total_linear_space_dept_fixture_ft`: Total linear space in the department fixture.
            - `n_space_prod_fit_facings_*`: Columns that store space productivity for different facings.
        df_protected_items (pd.DataFrame): DataFrame containing the protected items that should not be removed.
        groupby_cols_ (list): List of columns to group by when processing the dataframe (e.g., `store`, `department`).

    Returns:
        pd.DataFrame: A de-exploded dataframe where the optimal facings (`n_optimal_facings_sku`) are updated based
        on the available space and the space productivity increase.

    Notes:
        - The function logs the size of intermediate dataframes and potential discrepancies between the input
          and output dataframe sizes.
    """
    df_opti_modeling_output = df_opti_modeling_output_.copy()
    groupby_cols = groupby_cols_

    df_protected_items_filter = df_protected_items[
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level
        + ["is_protect_items", "is_protect_items_conservative"]
    ].rename(columns={"item_no_nbr": "new_item_item_no_nbr"})
    merge_on_cols = [
        col
        for col in context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level
        if col != "item_no_nbr"
    ] + ["new_item_item_no_nbr"]

    df_opti_modeling_output = df_opti_modeling_output.merge(
        df_protected_items_filter,
        on=merge_on_cols,
        how="left",
    )

    df_opti_modeling_output_filter = df_opti_modeling_output[
        groupby_cols
        + [
            "item_no_nbr",
            "new_item_item_no_nbr",
            "n_current_facings_sku",
            "n_optimal_facings_sku",
            "n_current_linear_space_per_facing_sku",
            "available_linear_space",
            "n_total_linear_space_dept_fixture_ft",
            "is_protect_items",
            "is_protect_items_conservative",
        ]
        + [col for col in df_opti_modeling_output if "n_space_prod_fit_facings_" in col]
    ]

    # available linear space should exclude the space reserved for local items
    exploded_df = vectorized_explode_rows(df_opti_modeling_output_filter)
    exploded_df["space_prod_increase"] = np.where(
        exploded_df["is_protect_items"] == 1,
        # (exploded_df["is_protect_items"] == 1) & (exploded_df["n_previous_facings_sku"] == 0),
        999999,
        exploded_df["space_prod_increase"],
    )

    exploded_df["prod_increase_per_linear_space"] = (
        exploded_df["space_prod_increase"]
        / exploded_df["n_current_linear_space_per_facing_sku"]
    )

    exploded_df["prod_per_linear_space_rank"] = (
        exploded_df.sort_values(
            ["prod_increase_per_linear_space", "n_next_facings_sku"],
            ascending=[False, True],
        )
        .groupby(groupby_cols)
        .cumcount()
        + 1
    )

    exploded_df = exploded_df.sort_values(
        by=groupby_cols + ["prod_per_linear_space_rank", "item_no_nbr"]
    )

    exploded_df["space_reserved"] = np.where(
        exploded_df["n_optimal_facings_sku"] > 0,
        exploded_df["n_current_linear_space_per_facing_sku"],
        0,
    )

    exploded_df["cumulative_space_reserved"] = exploded_df.groupby(groupby_cols)[
        "space_reserved"
    ].cumsum()

    exploded_df["keep_in_store"] = (
        exploded_df["cumulative_space_reserved"]
        <= exploded_df["available_linear_space"]
    ).astype(int)

    # override the keep_in_store for protected items
    exploded_df["keep_in_store"] = np.where(
        exploded_df["space_prod_increase"] > 999999 - 1e-6,
        1,
        exploded_df["keep_in_store"],
    )

    def aggregate_func(group):
        if (
            group["keep_in_store"] == 0
        ).all():  # If all rows in the group have keep_in_store == 0
            return pd.Series({"n_optimal_facings_sku": 0})
        else:  # If there are rows with keep_in_store == 1, take max
            group_with_keep = group[group["keep_in_store"] == 1]

            # Return n_optimal_facings_sku to be max for n_next_facings_sku from the rows where keep_in_store == 1
            return pd.Series(
                {
                    "n_optimal_facings_sku": group_with_keep[
                        "n_next_facings_sku"
                    ].max(),
                }
            )

    # Step 2: Apply the aggregation logic on the groups
    df_deexploded = (
        exploded_df.groupby(groupby_cols + ["item_no_nbr", "new_item_item_no_nbr"])
        .apply(aggregate_func)
        .reset_index()
    )

    if len(df_opti_modeling_output_) != len(df_deexploded):
        log.error(
            f"Warning: Length of original dataframe (df) is {len(df_opti_modeling_output_)}, but length of de-exploded dataframe (df_deexploded) is {len(df_deexploded)}."
        )

    return df_deexploded


def report_under_or_over_utilized_stores_percentage(
    df_grouped: pd.DataFrame,
    underutilized_or_overutilized: str,
    threshold: float,
) -> None:
    """
    Reports the percentage of stores where the space utilization falls below/above a given threshold. This function calculates
    the space utilization ratio for each store by comparing the optimal linear space used for SKUs to the total linear
    space available. If a store's utilization ratio is below/above the threshold, it is considered underutilized/overutilized.

    Args:
        df_grouped (pd.DataFrame): A DataFrame grouped by store, containing the following columns:
            - `n_optimal_linear_space_used_sku` (float): The optimal linear space used for SKUs.
            - `n_total_linear_space_dept_fixture_ft` (float): The total available linear space in the department fixture.
        underutilized_or_overutilized (str): The type of stores to report, either 'underutilized' or 'overutilized'.
        threshold (float): The space utilization threshold, where stores with a utilization ratio below this value
            are considered underutilized.

    Returns:
        None: This function logs the number and percentage of underutilized/overutilized stores but does not return any value.

    Notes:
        - The space utilization ratio is calculated as:
          `n_optimal_linear_space_used_sku / n_total_linear_space_dept_fixture_ft`.
    """
    # Calculate the utilization ratio
    df_grouped["space_utilization_ratio"] = (
        df_grouped["n_optimal_linear_space_used_sku"]
        / df_grouped["n_total_linear_space_dept_fixture_ft"]
    )

    if underutilized_or_overutilized == "underutilized":
        stores = df_grouped[df_grouped["space_utilization_ratio"] <= threshold]
        num_stores_fixture = stores.shape[0]
    elif underutilized_or_overutilized == "overutilized":
        stores = df_grouped[df_grouped["space_utilization_ratio"] > threshold]
        num_stores_fixture = stores.shape[0]
    else:
        raise ValueError(
            "The parameter 'underutilized_or_overutilized' must be either 'underutilized' or 'overutilized'."
        )

    total_stores_fixture = df_grouped.shape[0]
    percentage = (num_stores_fixture / total_stores_fixture) * 100

    # Report the number and percentage of underutilized/overutilized stores
    log.info(
        f"Number of {underutilized_or_overutilized} stores fixture with {threshold} threshold: {num_stores_fixture} ({percentage:.2f}%) out of {total_stores_fixture} total stores fixture."
    )


def check_space_violations(
    df_opti_modeling_output_w_total_linear_space: pd.DataFrame,
) -> [pd.DataFrame, pd.DataFrame]:
    """
    This function checks for space violations by summing up 'n_optimal_facings_sku' for each group defined by
    'groupby_cols' and compares the sum with the 'available_linear_space'. It returns two DataFrames:
    1. One where the sum of 'n_optimal_facings_sku' exceeds 'available_linear_space'.
    2. One where the sum of 'n_optimal_facings_sku' is less than or equal to 'available_linear_space'.

    Args:
        df_opti_modeling_output_w_total_linear_space (pd.DataFrame): The input DataFrame containing 'n_optimal_facings_sku'
        and 'available_linear_space' along with other relevant columns.

    Returns:
        tuple: A tuple containing two DataFrames:
        - df_exceeds_space: DataFrame where the sum of 'n_optimal_facings_sku' exceeds 'available_linear_space'.
        - df_within_space: DataFrame where the sum of 'n_optimal_facings_sku' is within 'available_linear_space'.
    """
    groupby_cols = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_store_level
    )

    df_grouped = (
        df_opti_modeling_output_w_total_linear_space.groupby(groupby_cols)
        .agg(
            {
                "n_optimal_linear_space_used_sku": "sum",
                "available_linear_space": "first",
                "n_total_linear_space_dept_fixture_ft": "first",
            }
        )
        .reset_index()
    )

    report_under_or_over_utilized_stores_percentage(df_grouped, "overutilized", 1.0)
    log.info(
        "Actual overutilized stores fixture after reserving space for local items: "
    )
    report_under_or_over_utilized_stores_percentage(
        df_grouped,
        "overutilized",
        1 - context.optimization.model_formulation.local_items_reserved_space_pct,
    )
    report_under_or_over_utilized_stores_percentage(df_grouped, "underutilized", 0.985)

    # Step 2: Identify groups where 'n_optimal_facings_sku' exceeds or is within 'available_linear_space'
    groups_exceeding_space = df_grouped[
        df_grouped["n_optimal_linear_space_used_sku"]
        > df_grouped["available_linear_space"]
    ][groupby_cols]
    groups_within_space = df_grouped[
        df_grouped["n_optimal_linear_space_used_sku"]
        <= df_grouped["available_linear_space"]
    ][groupby_cols]

    # Step 3: Filter the original DataFrame to get subsets based on these groups
    df_exceeds_space = df_opti_modeling_output_w_total_linear_space.merge(
        groups_exceeding_space, on=groupby_cols, how="inner"
    )
    df_within_space = df_opti_modeling_output_w_total_linear_space.merge(
        groups_within_space, on=groupby_cols, how="inner"
    )

    return df_exceeds_space, df_within_space


def remove_item_from_space(
    df_opti_modeling_output_: pd.DataFrame,
    df_store_space_characteristics: pd.DataFrame,
    df_protected_items: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adjusts the optimal facings of skus in a store's space allocation to ensure that no skus exceed the
    available space. If any skus exceed the available space, their facings are reduced based on space productivity,
    and the space allocations are updated accordingly.

    This function first checks if any skus exceed the available space, adjusts their facings if necessary,
    and updates the related space productivity metrics. It handles the following steps:
    - Fetches and updates the total linear space per department fixture.
    - Identifies if store assortment has exceeded the available space.
    - Reduces the facings of skus that exceed the space based on their productivity.
    - Updates the linear space and space productivity for each sku.

    Args:
        df_opti_modeling_output_ (pd.DataFrame): Input dataframe containing the optimization modeling output. It
            should contain the following columns:
            - `item_no_nbr`: Planning number for each sku.
            - `new_item_item_no_nbr`: A flag indicating whether the item is a new planning number.
            - `n_current_facings_sku`: The current number of facings for the SKU.
            - `n_optimal_facings_sku`: The optimal number of facings for the SKU.
            - `n_current_linear_space_per_facing_sku`: Current linear space occupied per facing.
            - `available_linear_space`: The available linear space for the store.
            - `n_space_prod_fit_facings_*`: Space productivity for different numbers of facings.

        df_store_space_characteristics (pd.DataFrame): DataFrame containing information about store-specific
            space characteristics, such as the total linear space available for each department fixture.

        df_protected_items (pd.DataFrame): DataFrame containing the protected items that should not be removed.

    Returns:
        pd.DataFrame: A dataframe with updated optimal facings and space allocations for the skus, ensuring
        no store assortment exceed the available space.

    Notes:
        - The function works by identifying store sku's that exceed their allocated space, adjusting their facings
          based on productivity, and updating space allocations.
        - It uses intermediate checks to ensure the facings are reduced properly without violating space constraints.
        - If a store's space is not exceeded, the function returns the input dataframe without modifications.
        - If some rows from the exploded dataframe are missing after adjustment, an error log is generated.

    Raises:
        ValueError: If the number of rows in the adjusted dataframe does not match the number in the input dataframe.
    """
    df_opti_modeling_output = fetch_total_linear_space_dept_fixture_ft(
        df_opti_modeling_output_, df_store_space_characteristics
    )

    groupby_cols = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_store_level
    )

    # filter the violated ones and good ones
    (df_exceeds_space, df_within_space) = check_space_violations(
        df_opti_modeling_output
    )

    if len(df_exceeds_space) == 0:
        return df_opti_modeling_output

    else:
        df_deexploded = update_item_no_optimal_facings(
            df_exceeds_space, df_protected_items, groupby_cols
        )

        df_opti_modeling_output_adjusted_facings = df_exceeds_space.merge(
            df_deexploded,
            on=groupby_cols + ["item_no_nbr", "new_item_item_no_nbr"],
            how="left",
            suffixes=("", "_updated"),
        )

        # SHOULD have n_optimal_facings_sku_updated for eacc
        # h row!
        na_report = df_opti_modeling_output_adjusted_facings[
            df_opti_modeling_output_adjusted_facings[
                "n_optimal_facings_sku_updated"
            ].isna()
        ]

        # If there are NaNs, report them
        if len(na_report) > 0:
            log.error(
                "Warning: The following rows in the original dataframe were not found in the de-exploded dataframe:"
            )
            log.error(
                na_report[
                    groupby_cols
                    + [
                        "item_no_nbr",
                        "new_item_item_no_nbr",
                        "n_current_facings_sku",
                        "n_optimal_facings_sku",
                    ]
                ]
            )

        df_opti_modeling_output_adjusted_facings[
            "n_optimal_facings_sku"
        ] = df_opti_modeling_output_adjusted_facings["n_optimal_facings_sku_updated"]

        # Drop the _updated columns (they were only needed temporarily for the merge)
        df_opti_modeling_output_adjusted_facings = (
            df_opti_modeling_output_adjusted_facings.drop(
                columns=["n_optimal_facings_sku_updated"]
            )
        )

        # update n_optimal_linear_space_used_sku and n_optimal_space_productivity
        df_opti_modeling_output_adjusted_facings["n_optimal_linear_space_used_sku"] = (
            df_opti_modeling_output_adjusted_facings["n_optimal_facings_sku"]
            * df_opti_modeling_output_adjusted_facings[
                "n_current_linear_space_per_facing_sku"
            ]
        )

        def calculate_space_productivity(row):
            f = row["n_optimal_facings_sku"]
            return row[f"n_space_prod_fit_facings_{int(f)}"]

        # Apply the function to update n_optimal_space_productivity
        df_opti_modeling_output_adjusted_facings[
            "n_optimal_space_productivity"
        ] = df_opti_modeling_output_adjusted_facings.apply(
            calculate_space_productivity, axis=1
        )

        df_opti_modeling_output_after = pd.concat(
            [df_opti_modeling_output_adjusted_facings, df_within_space],
            ignore_index=True,
        )

        (df_exceeds_space_after, df_within_space_after) = check_space_violations(
            df_opti_modeling_output_after
        )

        if len(df_exceeds_space_after) > 0:
            log.info("The following store fixture were exceeding the space\n")
            log.error(df_exceeds_space_after[groupby_cols].drop_duplicates())

        return df_opti_modeling_output_after
