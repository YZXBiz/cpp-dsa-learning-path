from core.modules.optimization.determine_protected_items import (
    determine_protected_items,
)
import re
from core.utils.optimizer_helpers import *
from core.schemas.optimization import ProtectedItems
from core.utils.scope_helpers import (
    get_filtered_category_level_plano_cat_and_depts_in_scope,
    create_optimization_scope_tuple,
    get_store_space_characteristics_path_and_root,
)
from core.utils.storage import save_multi_tab_excel
from core.utils.space_context.run_versioning import complete_file_path
from core.utils.elasticity_helpers import (
    root_with_run_id,
)
import pandas as pd

from oxygen.conf.context import context
from oxygen.exec.task import Task
import logging

log = logging.getLogger(__name__)


def summarize_item_POD(df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarizes the POD for items by calculating POD constraints and
    the current/optimal assortment POD.

    Args:
        df (pd.DataFrame): Input DataFrame containing item-level data, including store counts,
                           facings, and POD-related information.

    Returns:
        pd.DataFrame: A DataFrame with POD constraint details and the current and optimal
                      assortment POD for each item and planogram.

    The output includes:
    - POD constraints (`min_POD`, `max_POD`, `POD_feasible`) for each item.
    - Aggregated current and optimal assortment PODs based on facings.
    """
    df_optimization_item_POD_constraints = df[
        context.groupby_granularity.optimizer
        + [
            "item_no_nbr",
            "brand_name",
            "POD_enforce",
            "is_regional_item",
            "min_POD",
            "max_POD",
            "n_stores_item_no_exist_total",
            "n_stores_item_no_forced_exist",
            "n_stores_item_no_exist_after_forced_drop",
            "POD_feasible",
            "min_POD_active",
            "max_POD_active",
        ]
    ].drop_duplicates()

    df_item_POD_report = (
        df.groupby(context.groupby_granularity.optimizer + ["item_no_nbr"])
        .agg(
            current_assortment_item_POD=(
                "n_stores",
                lambda x: x[df["n_current_facings_sku"] > 0].sum(),
            ),
            optimal_assortment_item_POD=(
                "n_stores",
                lambda x: x[df["n_optimal_facings_sku"] > 0].sum(),
            ),
        )
        .reset_index()
    )
    df = df_optimization_item_POD_constraints.merge(
        df_item_POD_report,
        on=context.groupby_granularity.optimizer + ["item_no_nbr"],
        how="left",
    )
    return df


def summarize_brand_POD(
    df: pd.DataFrame, df_item_POD_summary: pd.DataFrame
) -> pd.DataFrame:
    """
    Summarizes POD for brands

    Args:
        df (pd.DataFrame): Input DataFrame containing item-level data with columns:
            - 'brand_name'
            - 'min_brand_POD'
            - 'max_brand_POD'
            - 'n_current_facings_sku'
            - 'n_optimal_facings_sku'
            - Other columns from `context.groupby_granularity.optimizer`.

    Returns:
        pd.DataFrame: DataFrame with col `current_assortment_brand_POD` and `optimal_assortment_brand_POD` for each brand.
    """
    df_optimization_brand_POD_constraints = df[
        context.groupby_granularity.optimizer
        + [
            "brand_name",
            "brand_POD_enforce",
            "min_brand_POD",
            "max_brand_POD",
            "n_stores_brand_forced_exist",
            "n_stores_brand_exist_after_forced_drop",
            "brand_POD_feasible",
            "min_brand_POD_active",
            "max_brand_POD_active",
        ]
    ].drop_duplicates()

    df_brand_POD_report = (
        df_item_POD_summary.groupby(
            context.groupby_granularity.optimizer + ["brand_name"]
        )
        .agg(
            current_assortment_brand_POD=("current_assortment_item_POD", "sum"),
            optimal_assortment_brand_POD=("optimal_assortment_item_POD", "sum"),
        )
        .reset_index()
    )

    df = df_optimization_brand_POD_constraints.merge(
        df_brand_POD_report,
        on=context.groupby_granularity.optimizer + ["brand_name"],
        how="left",
    )
    return df


def summarize_assortment(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregates assortment metrics and calculates percentage changes in space and productivity.

    Args:
        df (pd.DataFrame): Input DataFrame containing assortment data with columns like
        'representative_store_nbr', 'n_optimal_linear_space_used_sku', 'n_current_linear_space_used_sku',
        'n_optimal_space_productivity', and 'need_state_unique_id'.

    Returns:
        pd.DataFrame: A summarized DataFrame with aggregated metrics, including:
            - optimal/current linear space and productivity
            - unique need states and SKUs
            - counts of discontinued, new, fake new, and forced facings SKUs
            - percentage change in space and productivity
            - labels for linear space and productivity status.
    """
    df = df.rename(columns={"representative_store_nbr": "store_nbr"})
    df_1 = (
        df.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_store_representative
        )
        .agg(
            optimal_linear_space_used=("n_optimal_linear_space_used_sku", "sum"),
            current_linear_space_used=("n_current_linear_space_used_sku", "sum"),
            optimal_space_productivity=("n_optimal_space_productivity", "sum"),
            current_space_productivity=("n_current_space_productivity", "sum"),
            n_need_states=("need_state_unique_id", pd.Series.nunique),
            n_skus=("item_no_nbr", pd.Series.nunique),
            n_discontinued_skus=("is_discontinued_sku", "sum"),
            n_new_skus=("is_net_new_sku", "sum"),
            n_fake_new_skus=("is_fake_new_sku", "sum"),
            n_forced_positive_facing_skus=(
                "item_no_nbr",
                lambda x: x[df["min_forced_facings_guardrails"] > 0].nunique(),
            ),
            n_forced_positive_facing_need_states=(
                "need_state_unique_id",
                lambda x: x[df["min_forced_facings_guardrails"] > 0].nunique(),
            ),
            n_current_skus_w_facings=(
                "item_no_nbr",
                lambda x: x[df["n_current_facings_sku"] > 0].nunique(),
            ),
            n_optimal_skus_w_facings=(
                "item_no_nbr",
                lambda x: x[df["n_optimal_facings_sku"] > 0].nunique(),
            ),
            n_current_need_states_w_facings=(
                "need_state_unique_id",
                lambda x: x[df["n_current_facings_sku"] > 0].nunique(),
            ),
            n_optimal_need_states_w_facings=(
                "need_state_unique_id",
                lambda x: x[df["n_optimal_facings_sku"] > 0].nunique(),
            ),
        )
        .reset_index()
    )

    # Adding additional calculated columns
    df_1["productivity_percentage_change"] = (
        (df_1["optimal_space_productivity"] - df_1["current_space_productivity"])
        / df_1["current_space_productivity"]
    ) * 100

    df_1["space_percentage_change"] = (
        (df_1["optimal_linear_space_used"] - df_1["current_linear_space_used"])
        / df_1["current_linear_space_used"]
    ) * 100

    df_1["linear_space_label"] = df_1.apply(
        lambda row: "Optimal Linear Space Used Below 90%"
        if row["optimal_linear_space_used"] < 0.9 * row["current_linear_space_used"]
        else "Optimal Linear Space Used Above 90%",
        axis=1,
    )

    df_1["productivity_label"] = df_1.apply(
        lambda row: "Optimal Productivity Below 90%"
        if row["optimal_space_productivity"] < 0.9 * row["current_space_productivity"]
        else "Optimal Productivity Above 90%",
        axis=1,
    )
    df_1 = df_1.rename(columns={"store_nbr": "representative_store_nbr"})

    return df_1


def load_dept_category_level_sol_dict() -> dict:
    """
    Load the optimization results for each department in the scope
    Returns:
        dict: A dictionary with department-plano_cat_desc-category_level name as key and optimization results as value
    """
    dept_category_level_sol = {}
    category_level_output_schema = select_OptimizationMasterModelingOutput_schema(
        context.groupby_granularity.optimizer
    )
    dict_category_level_plano_cat_desc_and_depts = (
        get_filtered_category_level_plano_cat_and_depts_in_scope()
    )
    list_tuples_optimizer = create_optimization_scope_tuple(
        dict_category_level_plano_cat_desc_and_depts=dict_category_level_plano_cat_desc_and_depts,
        optimizer_granularity=context.groupby_granularity.optimizer,
    )

    for dependent_var in list(
        dict(context.optimization.data_prep.objective_functions).values()
    ):
        for tuple_optimizer in list_tuples_optimizer:
            category_level_dept_nbr, plano_cat_desc, department = tuple_optimizer
            df_dept = category_level_output_schema.load(
                file_path=complete_file_path(
                    context.data_stores.optimization.root_path,
                    context.data_stores.optimization.modeling.optimization_master_output_dept_df,
                    at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    run_id_folder=context.run_id.optimization_run_id,
                    dependent_var=dependent_var,
                    category_level_dept_nbr=category_level_dept_nbr,
                    plano_cat_desc=plano_cat_desc,
                    department=department,
                ),
                root=root_with_run_id(
                    context.run_id.optimization_run_id,
                    context.data_stores.optimization.save_to_datastores_root.modeling,
                ),
            )
            invalid_chars = r"[\\/*?:\[\]]"
            sanitized_name = re.sub(
                invalid_chars,
                "_",
                str(department) + "_" + str(plano_cat_desc) + "_" + str(category_level_dept_nbr),
            )
            sanitized_name = sanitized_name[:31]
            dept_category_level_sol[sanitized_name] = df_dept

    return dept_category_level_sol


def summarize_at_dept_level(
    dept_category_level_sol: dict,
    dependent_var: str,
):
    """
    Summarizes the assortment optimization results at the dept level
    Args:
        dept_category_level_sol (dict): A dictionary with department-plano_cat_desc-category_level name as key and optimization results as value
        dependent_var (str): The dependent variable for the optimization
    Returns: None
    """
    dept_summary_dict = {}
    for key, df_dept in dept_category_level_sol.items():
        df_dept_summary = summarize_assortment(df_dept)
        dept_summary_dict[key] = df_dept_summary

    dept_summary_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_summary,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
        dependent_var=dependent_var,
    )
    save_multi_tab_excel(
        save_dict=dept_summary_dict,
        path=dept_summary_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )


def summarize_POD_and_save_summary(
    dept_category_level_sol: dict,
    dependent_var: str,
):
    """
    Summarizes the POD for items and brands and saves the summary to excel
    Args:
        dept_category_level_sol (dict): A dictionary with department-plano_cat_desc-category_level name as key and optimization results as value
        dependent_var (str): The dependent variable for the optimization
    Returns: None
    """

    item_POD_summary_dict = {}
    df_brand_POD_summary_dict = {}
    for key, df_dept in dept_category_level_sol.items():
        df_item_POD_summary = summarize_item_POD(df_dept)
        df_brand_POD_summary = summarize_brand_POD(
            df_dept, df_item_POD_summary
        )  # take the 'current_assortment_item_POD', 'optimal_assortment_item_POD' from previous
        item_POD_summary_dict[key] = df_item_POD_summary
        df_brand_POD_summary_dict[key] = df_brand_POD_summary

    item_POD_summary_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_item_POD_summary,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
        dependent_var=dependent_var,
    )
    save_multi_tab_excel(
        save_dict=item_POD_summary_dict,
        path=item_POD_summary_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )

    brand_POD_summary_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_brand_POD_summary,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
        dependent_var=dependent_var,
    )
    save_multi_tab_excel(
        save_dict=df_brand_POD_summary_dict,
        path=brand_POD_summary_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )


def tag_protected_items_at_optimizers_granularity(
    dept_category_level_sol: dict,
    dept_store_space_utilization_dict: dict,
):
    """
    Tags the protected items at the optimizer's granularity
    Args:
        dept_category_level_sol (dict): A dictionary with department-plano_cat_desc-category_level name as key and optimization results as value
        dept_store_space_utilization_dict (dict): A dictionary with department-plano_cat_desc-category_level name as key and store space utilization as value
    Returns: None
    """
    df_dept_protected_items_dict = {}

    for key, df_dept in dept_category_level_sol.items():
        # determine the protected items from post processing removal
        df_store_characteristics = dept_store_space_utilization_dict[key]

        df_dept_protected_items = determine_protected_items(
            df_dept, df_store_characteristics
        )
        df_dept_protected_items_dict[key] = df_dept_protected_items

    # save protected items parquet and excel
    combined_df = pd.concat(df_dept_protected_items_dict.values(), ignore_index=True)
    protected_item_parquet_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_protected_items_parquet,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    ProtectedItems.save(
        df=combined_df,
        file_path=protected_item_parquet_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    protected_item_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_protected_items,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    save_multi_tab_excel(
        save_dict=df_dept_protected_items_dict,
        path=protected_item_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )


def load_dept_store_characteristics() -> dict:
    """
    Load the store characteristics for each department in the scope
    Returns:
        pd.DataFrame: A DataFrame with store characteristics
    """
    dept_store_characteristics_dict = {}
    (
        path_store_space_characteristics,
        root_store_space_characteristics,
    ) = get_store_space_characteristics_path_and_root()

    if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
        schema = StoreSpaceCharacteristicsSchema
    else:
        schema = StoreSpaceCharacteristicsWithCategoryLevelSchema
    df_store_space_characteristics = schema.load(
        file_path=path_store_space_characteristics,
        root=root_store_space_characteristics,
    )

    invalid_chars = r"[\\/*?:\[\]]"

    def sanitize_name(row, groupby_granularity):
        if "category_level_dept_nbr" in groupby_granularity:
            sanitized_name = re.sub(
                invalid_chars,
                "_",
                f"{row['dept_id']}_{row['plano_cat_desc']}_{row['category_level_dept_nbr']}",
            )
        else:
            sanitized_name = re.sub(
                invalid_chars, "_", f"{row['dept_id']}_{row['plano_cat_desc']}_{-1}"
            )

        return sanitized_name[:31]

    df_store_space_characteristics[
        "sanitized_name"
    ] = df_store_space_characteristics.apply(
        lambda row: sanitize_name(row, context.groupby_granularity.optimizer), axis=1
    )

    for sanitized_name in df_store_space_characteristics["sanitized_name"].unique():
        df_dept_store = df_store_space_characteristics[
            df_store_space_characteristics["sanitized_name"] == sanitized_name
        ]
        dept_store_characteristics_dict[sanitized_name] = df_dept_store

    return dept_store_characteristics_dict


def summarize_store_space_utilization(
    dept_category_level_sol: dict,
    dept_store_characteristics_dict: dict,
) -> dict:
    """
    Summarizes the store space utilization for each department
    Args:
        dept_category_level_sol (dict): A dictionary with department-plano_cat_desc-category_level name as key and optimization results as value
        dept_store_characteristics_dict (dict): A dictionary with department-plano_cat_desc-category_level name as key and store characteristics as value
    Returns:
        dict: A dictionary with department-plano_cat_desc-category_level name as key and store space utilization
    """
    dept_store_space_utilization_dict = {}
    for key, df_dept in dept_category_level_sol.items():
        df_store_characteristics = dept_store_characteristics_dict[key]
        df_dept = df_dept.rename(columns={"representative_store_nbr": "store_nbr"})
        df_cluster_plano_used = (
            df_dept.groupby(
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_optimizer_level
            )
            .agg(
                n_optimal_linear_space_used_sku=(
                    "n_optimal_linear_space_used_sku",
                    "sum",
                ),
            )
            .reset_index()
        )

        df_store_characteristics = df_store_characteristics.merge(
            df_cluster_plano_used,
            on=context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_level,
            how="left",
        )
        df_store_characteristics["available_linear_space"] = df_store_characteristics[
            "n_total_linear_space_dept_fixture_ft"
        ] * (1 - context.optimization.model_formulation.local_items_reserved_space_pct)

        df_store_characteristics["is_exceeding_space"] = (
            df_store_characteristics["n_optimal_linear_space_used_sku"]
            > df_store_characteristics["available_linear_space"]
        ).astype(int)

        dept_store_space_utilization_dict[key] = df_store_characteristics

    store_space_util_path = complete_file_path(
        context.data_stores.optimization.root_path,
        context.data_stores.optimization.modeling.optimization_store_space_utilization,
        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    save_multi_tab_excel(
        save_dict=dept_store_space_utilization_dict,
        path=store_space_util_path,
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    return dept_store_space_utilization_dict


class AssortmentSummary(Task):
    def run(self):
        """
        This task summarizes the assortment optimization results at the dept level
        Returns:
            saving an excel file with the dept summary at optimizer's granularity, each tab is a dept
            saving an excel file with the item POD summary at item's granularity, each tab is a dept
            saving an excel file with the brand POD summary at brand's granularity, each tab is a dept
            saving a parquet and excel file with the protected items at optimizer's granularity, each tab is a dept
        """
        dept_category_level_sol = load_dept_category_level_sol_dict()

        # get the dependent_var
        objective_functions = dict(context.optimization.data_prep.objective_functions)
        assert (
            len(objective_functions.keys()) == 1
        ), "Only one objective function is supported"
        dependent_var = next(iter(objective_functions.keys()))

        # summarize the assortment optimization results at the dept level
        summarize_at_dept_level(dept_category_level_sol, dependent_var)
        summarize_POD_and_save_summary(dept_category_level_sol, dependent_var)

        # summarize the store characteristics at the optimizer's granularity
        dept_store_characteristics_dict = load_dept_store_characteristics()
        dept_store_space_utilization_dict = summarize_store_space_utilization(
            dept_category_level_sol, dept_store_characteristics_dict
        )

        # tag the protected items at the optimizer's granularity
        tag_protected_items_at_optimizers_granularity(
            dept_category_level_sol, dept_store_space_utilization_dict
        )
