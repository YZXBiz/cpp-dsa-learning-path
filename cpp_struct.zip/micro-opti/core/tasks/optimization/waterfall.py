from core.utils.space_context.run_versioning import complete_file_path
from core.utils.storage import save_multi_tab_excel

# Snowflake specific imports
from snowflake.connector.pandas_tools import write_pandas

from oxygen.conf.settings import settings
from oxygen.conf.context import context
from oxygen.exec.task import Task

import pandas as pd
import numpy as np
import logging
from io import BytesIO
        

import pdb

log = logging.getLogger(__name__)


class OptimizationWaterfall(Task):  

    def run(self):
        """
        This task will take the adjusted ouputs from the scaled optimization modeling and calculate lift by facing change categories
        """

        log.info("Fetching scaled optimization data...")
        df_scaled_opti = self.fetch_scaled_optimization_data()

        log.info("Prep Data Sheet...")
        df_waterfall_base = self.prep_baseline_data_output(df_scaled_opti)

        log.info("Creating waterfall table...")
        df_waterfall = self.create_waterfall_data(df_waterfall_base)

        log.info("Saving to folder...")
        plano_cat_desc = df_waterfall_base['plano_cat_desc'][0]

        # pdb.set_trace()
        
        final_output_path = complete_file_path(
            context.data_stores.optimization.root_path,
            context.data_stores.optimization.scaling.waterfall_output,
            at_datastores_root= context.data_stores.optimization.save_to_datastores_root.modeling,
            plano_cat_desc=plano_cat_desc,
        )

        output_dfs={
                "Waterfall": df_waterfall,
                "Base Data": df_waterfall_base
            }

        save_multi_tab_excel(
            save_dict=output_dfs,
            path=final_output_path,
            root=context.data_stores.optimization.save_to_datastores_root.modeling,
        )

        log.info(F"Saving to Waterfall table {context.scaling_sales.output_tables.waterfall_snowflake}...")
        write_pandas(
            settings.SNOWFLAKE_CONNECTION, 
            df_waterfall, 
            context.scaling_sales.output_tables.waterfall_snowflake, 
            database="DL_FSCA_SLFSRV", 
            schema="TWA07",
            overwrite=False,
            auto_create_table=True
        )
        
        log.info("Waterfall Task Complete...")

    def fetch_scaled_optimization_data(self):
        query = f"""
        SELECT * 
        FROM DL_FSCA_SLFSRV.TWA07.{context.scaling_sales.output_tables.final_opti_output_scaled}
        WHERE run_id = '{context.meta.run_id}'
        """

        df = settings.SNOWFLAKE_CONNECTION.cursor().execute(query).fetch_pandas_all()
        df.columns = map(str.lower, df.columns)

        # Format columns
        df['n_current_scaled_adjusted_projected_sales_n_stores'] = df['n_current_scaled_adjusted_projected_sales_n_stores'].astype(float)
        df['n_optimal_scaled_adjusted_projected_sales_n_stores'] = df['n_optimal_scaled_adjusted_projected_sales_n_stores'].astype(float)

        if 'n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores' in df.columns:
            df['n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores'] = df['n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores'].astype(float)

        return df
    
    # def determine_current_or_upcoming_as_baseline(self, df):
    #     special_plano_ids = [9414, 9770, 9090, 9570, 9640, 9260, 9150, 9360, 9400, 9616]

    #     # Determine baseline adjusted sales
    #     df['baseline_projected_sales'] = np.where(df['plano_id'].isin(special_plano_ids), 'upcomming','current')

    #     df['baseline_scaled_adjusted_projected_sales_n_stores'] = df['n_current_scaled_adjusted_projected_sales_n_stores']
    #     df['baseline_scaled_adjusted_projected_sales_n_stores'] = np.where(
    #         df['baseline_projected_sales']=='upcoming',
    #         df['n_upcoming_scaled_adjusted_projected_sales_n_stores'],
    #         df['baseline_scaled_adjusted_projected_sales_n_stores']
    #     )
        
    #     df['scaled_opti_sales_diff_to_baseline'] = df['n_optimal_scaled_adjusted_projected_sales_n_stores'] - df['baseline_scaled_adjusted_projected_sales_n_stores']
    #     return df

    def prep_baseline_data_output(self, df):
        
        # Calculate differences betwwen Optimal and current results for lift calculation
        df['opti_diff_to_current_scaled_adj_sales_n_stores'] = df['n_optimal_scaled_adjusted_projected_sales_n_stores'] - df['n_current_scaled_adjusted_projected_sales_n_stores']

        # if 'n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores' in df.columns:
        df['opti_diff_to_current_scaled_adj_sales_wo_transference_n_stores'] = df['n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores'] - df['n_current_scaled_adjusted_projected_sales_n_stores']
        df['opti_transference_effect'] = df['n_optimal_scaled_adjusted_projected_sales_n_stores'] - df['n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores']


        output_cols = [
            'final_cluster_labels',
            'store_nbr',
            'plano_cat_desc',
            'plano_cat_id',
            'plano_id',
            'fixture_desc',
            'plano_ft',
            'fixture_size',
            'cluster',
            'volume',
            'risk',
            'need_state_unique_id',
            'item_no_nbr',
            'item_no_desc',
            'brand_name',
            'vendor_name',
            'seg_dsc',
            'discontinue_item',
            'new_item',
            'need_state_unique_id',
            'n_stores',
            'store_cluster',
            'normalization_factor',
            'total_sales',
            'n_current_adjusted_projected_sales',
            'n_optimal_adjusted_projected_sales',
            'n_current_scaled_adjusted_projected_sales',
            'n_optimal_scaled_adjusted_projected_sales',
            'opti_diff_to_current_scaled_adj_sales_wo_transference_n_stores',
            'opti_transference_effect',
            'n_current_scaled_adjusted_projected_sales_n_stores',
            'n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores',
            'n_optimal_scaled_adjusted_projected_sales_n_stores',
            'new_to_store_flag',
            'removed_from_store_flag',
            'increased_facings_flag',
            'decreased_facings_flag',
            'no_facings_change_flag',
            'cat_val_check',
            'facings_change_category', 
            'opti_diff_to_current_scaled_adj_sales_n_stores',
        ]

        return df[output_cols]

    def create_waterfall_data(self, df):

        # Group by plano_id and facings_change_category and sum relevant columns before transference
        grouped = df.groupby(['plano_id', 'facings_change_category'])[
            ['n_current_scaled_adjusted_projected_sales_n_stores',
             'n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores',
             'opti_diff_to_current_scaled_adj_sales_wo_transference_n_stores']
        ].sum().reset_index().rename(
            columns = {"n_optimal_scaled_adjusted_projected_sales_wo_transference_n_stores":"n_optimal_scaled_adjusted_projected_sales_n_stores",
                       "opti_diff_to_current_scaled_adj_sales_wo_transference_n_stores":"opti_diff_to_current_scaled_adj_sales_n_stores"}
        )

        # Create transference rows for each plano_id
        transference = df.groupby(['plano_id'])['opti_transference_effect'].sum().reset_index().rename(
            columns={"opti_transference_effect": "n_optimal_scaled_adjusted_projected_sales_n_stores"})
        transference['facings_change_category'] = 'new_to_chain_transference_effect'
        transference['n_current_scaled_adjusted_projected_sales_n_stores'] = 0
        transference['opti_diff_to_current_scaled_adj_sales_n_stores'] = transference[
            'n_optimal_scaled_adjusted_projected_sales_n_stores']

        # Create subtotal rows for each plano_id
        subtotals = df.groupby('plano_id')[
            ['n_current_scaled_adjusted_projected_sales_n_stores',
             'n_optimal_scaled_adjusted_projected_sales_n_stores',
             'opti_diff_to_current_scaled_adj_sales_n_stores']
        ].sum().reset_index()
        subtotals['facings_change_category'] = 'Total'



        # Append subtotal rows to grouped data
        grouped_with_subtotals = pd.concat([grouped, transference, subtotals], ignore_index=True)
    
        # Create overall total row
        overall_total = grouped_with_subtotals[
            grouped_with_subtotals['facings_change_category'] == 'Total'
        ][['n_current_scaled_adjusted_projected_sales_n_stores',
           'n_optimal_scaled_adjusted_projected_sales_n_stores',
           'opti_diff_to_current_scaled_adj_sales_n_stores']].sum().to_frame().T
        overall_total['plano_id'] = 1000
        overall_total['facings_change_category'] = 'Total'
    
        # Append overall total row
        grouped_with_total = pd.concat([grouped_with_subtotals, overall_total], ignore_index=True)
    
        # Calculate percent_lift using the current total per plano_id
        current_totals = grouped_with_total[
            grouped_with_total['facings_change_category'] == 'Total'
        ][['plano_id', 'n_current_scaled_adjusted_projected_sales_n_stores']].set_index('plano_id')

        def compute_percent_lift(row):
            plano_id = row['plano_id']
            if plano_id in current_totals.index and current_totals.loc[plano_id, 'n_current_scaled_adjusted_projected_sales_n_stores'] != 0:
                return (row['opti_diff_to_current_scaled_adj_sales_n_stores'] /
                        current_totals.loc[plano_id, 'n_current_scaled_adjusted_projected_sales_n_stores']) * 100
            else:
                return None
        
        grouped_with_total['percent_lift'] = grouped_with_total.apply(compute_percent_lift, axis=1)
    
        # Round for readability
        grouped_with_total = grouped_with_total.round(2)
    
        # Sort so that each plano_id group ends with its subtotal, and overall total is at the bottom
        grouped_with_total['sort_order'] = grouped_with_total['facings_change_category'].apply(
            lambda x: 99 if x == 'Total' else 0
        )
        grouped_with_total = grouped_with_total.sort_values(by=['plano_id', 'sort_order']).drop(columns='sort_order')
    
        # Reset index for output
        final_df = grouped_with_total.reset_index(drop=True)
    
        # Add run id and cat desc
        final_df['run_id'] = context.meta.run_id
        plano_cat_desc = df['plano_cat_desc'][0]
        final_df['plano_cat_desc'] = plano_cat_desc
    
        # Reorder
        col_order = ['run_id', 'plano_cat_desc'] + [col for col in final_df.columns if col not in ['run_id', 'plano_cat_desc']]
        final_df = final_df[col_order]
        final_df['plano_id'] = final_df['plano_id'].astype(str)
    
        return final_df


