from core.modules.optimization.store_representatives import (
    calculate_abs_difference_with_median_store,
    get_store_representative_with_median_total_space,
)
from core.schemas.optimization import (
    PrioritizedStoreRepresentativeSchema,
    PrioritizedStoreRepresentativeWithCategoryLevelSchema,
    StoreSpaceCharacteristicsWithCategoryLevelSchema,
)
from core.utils.optimizer_helpers import *
from core.utils.scope_helpers import (
    get_store_space_characteristics_path_and_root,
)
from core.utils.space_context.run_versioning import complete_file_path
from core.utils.elasticity_helpers import (
    keep_extra_original_clusters_based_on_config,
)
from oxygen.conf.context import context
from oxygen.exec.task import Task
import logging

log = logging.getLogger(__name__)


class OptimizationStoreRepresentative(Task):
    def run(self):
        """
        This task will create a prioritized mapping of (plano_cat_id, plano_cat_desc, dept_id, final_cluster_labels,
        plano_ft, fixture_size) to store_nbr, which will correspond to the representative store of that grouping for the
        optimization module. The prioritization occurs in the sense that we will only optimize the plano_ft sizes that
        are in this dataframe, since the other existing ones for that plano_cat_desc were dropped as they cover a
        very small number of store only (e.g. <5%, config-driven parameter)
        """
        df_final_clusters = keep_extra_original_clusters_based_on_config(
            context.cluster_labels_based_on.optimizer
        )

        SpaceDataFtSchema = select_space_schema_ft(
            context.groupby_granularity.optimizer
        )

        latest_space_data_path = complete_file_path(
            context.data_stores.store_clustering.root_path,
            context.data_stores.store_clustering.final.latest_space_data_path_df,
            at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            run_id_folder=context.run_id.clustering_run_id,
        )

        df_latest_space_data = SpaceDataFtSchema.load(
            file_path=latest_space_data_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )

        log.info(
            f"Defining store representative per [plano_cat_id, plano_cat_desc, dept_id, "
            f"plano_ft, final_cluster_labels]..."
        )
        (
            path_store_characteristics_master,
            root_path_store_characteristics_master,
        ) = get_store_space_characteristics_path_and_root()
        if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
            schema = StoreSpaceCharacteristicsSchema
        else:
            schema = StoreSpaceCharacteristicsWithCategoryLevelSchema
        df_linear_space_plano_dept_fixture = schema.load(
            file_path=path_store_characteristics_master,
            root=root_path_store_characteristics_master,
        )

        # Calculating the median sum of linear space per (plano_cat, dept_id, final_cluster_labels, plano_ft, fixture_size)
        # across stores and only keeping the store closest to that median, which will be our store representative
        df_abs_difference_with_median_store = (
            calculate_abs_difference_with_median_store(
                df_latest_space_data=df_latest_space_data,
                df_final_clusters=df_final_clusters,
            )
        )
        df_prioritized_store_representatives = (
            get_store_representative_with_median_total_space(
                df_linear_space_plano_dept_fixture=df_linear_space_plano_dept_fixture,
                df_abs_difference_with_median_store=df_abs_difference_with_median_store
            )
        )

        prioritized_store_representatives_path = complete_file_path(
            context.data_stores.optimization.root_path,
            context.data_stores.optimization.store_representatives.prioritized_store_representatives_df,
            at_datastores_root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
            run_id_folder=context.run_id.clustering_run_id,
        )
        if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
            PrioritizedStoreRepresentativeSchema.save(
                df=df_prioritized_store_representatives,
                file_path=prioritized_store_representatives_path,
                root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
            )
        else:
            PrioritizedStoreRepresentativeWithCategoryLevelSchema.save(
                df=df_prioritized_store_representatives,
                file_path=prioritized_store_representatives_path,
                root=context.data_stores.optimization.save_to_datastores_root.store_representatives,
            )
