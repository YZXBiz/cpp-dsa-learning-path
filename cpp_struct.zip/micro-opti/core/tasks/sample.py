import logging
import os

import pandas as pd
from oxygen.exec.task import Task
from oxygen.files.readers import reader

logger = logging.getLogger(__name__)


class SampleTask(Task):
    """Example of a Task that is part of a DAG.

    Each Task owns the responsibility of a separate task within
    a pipeline/dag. It allows you to separate your business logic into
    logical chunks of code.

    """

    def run(self):
        """
        Sample task that checks if Lighthouse data is configured as a SQL connection.
        If there is Lighthouse connection, it retrieves the first 20 likes of CAI table
        and logs them to showcase how can data be accessed.
        """
        logger.debug("Executing SampleTask")
        if not os.environ.get("LIGHTHOUSE_USER", ""):
            return
        cai = reader.read(
            file_path="CAI.CAI",
            data_format="sql",
            sql="SELECT top 20 * from CAI.CAI where \"Country\" like 'sweden'",
        )
        logger.debug(f"\n{cai.head(20)}")


class UploadTestTask(Task):
    """Test for synapse sql upload."""

    def run(self):
        df = pd.DataFrame({"a": [1, 2, 3], "b": list("xyz")})
        reader.write(
            "upload_test",
            df,
            data_format="sql",
            database="dedicated",
            if_exists="replace",
        )
