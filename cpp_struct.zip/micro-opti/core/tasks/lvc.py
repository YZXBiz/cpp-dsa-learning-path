import pandas as pd
import logging
from oxygen.conf.settings import settings
from oxygen.conf.context import context
from oxygen.exec.task import Task

from snowflake.connector.pandas_tools import write_pandas

from core.modules.lvc_analysis.data_prep import get_vendor_mapping, prepare_lvc_file
from core.tasks.optimization import OptimizationDataPull, OptimizationStoreRepresentative, OptimizationDataPrep, \
    OptimizationModeling
from core.utils.df import format_dataframe_print

log = logging.getLogger(__name__)
class LvcAnalysis(Task):
    def run(self):
        category = context.lvc_analysis.category
        pay_vendor_names = context.lvc_analysis.pay_vendor_names
        bound = context.lvc_analysis.bound
        plano_ids = context.lvc_analysis.plano_ids

        # run baseline
        # tasks = [
        #     OptimizationDataPull,
        #     OptimizationStoreRepresentative,
        #     OptimizationDataPrep,
        #     OptimizationModeling,
        # ]

        # run scenarios
        vendor_mapping = get_vendor_mapping(category, pay_vendor_names)

        lvc_file_path = prepare_lvc_file(category, bound, vendor_mapping, plano_ids)

        context.optimization_config.model_formulation.enable_global_linear_space_change_constraints = True

        raw_id = context.meta.run_id

        scenario_df = pd.DataFrame(columns=["PAY_VENDOR_NAME","SCENARIO","MIN_BOUND","MAX_BOUND","RUN_ID"])

        for idx, (key ,path) in enumerate(lvc_file_path.items()):
            context.optimization_config.model_formulation.global_linear_space_change_path = path
            updated_raw_id = raw_id + '_' + str(idx)
            context.meta.run_id = updated_raw_id

            # Run tasks
            OptimizationDataPull().run()
            OptimizationStoreRepresentative().run()
            OptimizationDataPrep().run()
            OptimizationModeling().run()

            scenario_df.loc[len(scenario_df)] = [key[0],key[1],key[2],key[3],updated_raw_id]

        log.info(f"output scenario output df: {format_dataframe_print(scenario_df)}")

        scenario_table_name = f"CPI_{category.replace(' ','_')}_RUN_ID_test"

        write_pandas(settings.SNOWFLAKE_CONNECTION, scenario_df,scenario_table_name,
                     database="DL_FSCA_SLFSRV",schema="TWA07", auto_create_table=True, overwrite=True)

        log.info(f"successfully save sceanrio run_id table into: DL_FSCA_SLFSRV.TWA07.{scenario_table_name}, baseline run_id: {raw_id}")