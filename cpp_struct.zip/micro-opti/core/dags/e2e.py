from core.tasks.optimization import (
    OptimizationDataPrep,
    OptimizationModeling,
    OptimizationStoreRepresentative,
    AssortmentSummary,
)
from oxygen.exec.dag import DAG


class E2EDAG(DAG):
    """
    This dag can be executed using `python run.py dag optimization_user_input_data`
    This runs the pre-processing, modeling and post-processing of the optimization module, which creates and solves
    the micro space optimization problem using the space elasticity curves generated previously
    """

    label = "e2e"
    tasks = [
        ### Please refer to the coresponding folders for details on the tasks 6-9 below
        ### 6. space_elasticity
        # SpaceElasticityDataPrep,
        # SpaceElasticityModeling,
        # SpaceElasticityOverrides,
        # SkuLevelElasticity,
        # SpaceElasticityVisualization,
        # NeedStateSpaceElasticityModeling,
        # # NewItemForecast, # only add back if classic team explicitly wants a new item forecast run
        ### 7. optimization
        OptimizationStoreRepresentative,
        OptimizationDataPrep,
        OptimizationModeling,
        AssortmentSummary,
        ### 9. financial_projection
        # OptimizationFinancialProjections,
        # AggregateFinancialProjections,

        ### 10. AOT Push
        #PlanoMoveSummary,
        #CreateClientOutput,
    ]
