from oxygen.exec.dag import DAG

import logging

from core.tasks.lvc import LvcAnalysis

log = logging.getLogger(__name__)

class LvcDAG(DAG):
    label = "lvc"

    tasks = [LvcAnalysis]