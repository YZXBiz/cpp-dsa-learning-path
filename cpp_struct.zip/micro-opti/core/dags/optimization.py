from core.tasks.optimization import (
    OptimizationDataPull,
    OptimizationDataPrep,
    OptimizationModeling,
    OptimizationStoreRepresentative,
    AssortmentSummary,
    Optimization345Output,
    OptimizationScaling,
    OptimizationWaterfall
)
from oxygen.exec.dag import DAG
from oxygen.conf.settings import settings
from oxygen.conf.context import context
from core.utils.misc import is_running_in_kubeflow
from core.utils.run_parameter import (
    load_configs_from_snowflake,
    get_scenario_ids,
    update_scenario_error,
    update_scenario_column,
    json_serializer
) 

import logging
import traceback
import json
import os
import yaml
import datetime
import tempfile
import ipdb
log = logging.getLogger(__name__)

class OptimizationDAG(DAG):
    """
    This dag can be executed using `python run.py dag optimization`
    This runs the pre-processing, modeling and post-processing of the optimization module, which creates and solves
    the micro space optimization problem using the space elasticity curves generated previously
    """
    label = "optimization"
    
    # Set connections so they are only done once per session
    if is_running_in_kubeflow():
        from fsutils import run_sf_sql as rp
        snowflake_connection, _ = rp.get_connection(settings.SNOWFLAKE_CONFIGMAPNAME)

        # Set the parameter as a setting to be available across
        settings.SNOWFLAKE_CONNECTION = snowflake_connection

        if context.run_scenario_mode:
            # Get scenarios to run
            list_scenarios = get_scenario_ids()

            # Load configs from snowflake
            if len(list_scenarios) == 0:
                log.info(f"Scenario ID enabled, but no scenario to run. Assure either "
                         f"A scenario ID is set in context.meta.scenario_id OR the table "
                         f"{context.data_stores.raw_data.constraint_parameters.scenario_status} has a scenario "
                         f"with the status 'Not Yet Started'"
                )

            for scenario_id in list_scenarios:
                try:
                    load_configs_from_snowflake(scenario_id)

                    log.info(f"Running opti for scenario: {scenario_id}")

                    try:
                        run_folder = context.meta.run_folder

                        yaml_file_path = os.path.join("output" + run_folder, "context.yaml")

                        if not os.path.exists(yaml_file_path):
                            raise FileNotFoundError(f"context.yaml not found in {yaml_file_path}")

                        with open(yaml_file_path, 'r') as yaml_file:
                            yaml_content = yaml.safe_load(yaml_file)

                        json_content = json.dumps(yaml_content, indent=4, default=json_serializer)

                        json_file_path = os.path.join("output" + run_folder,  f"scenario_{scenario_id}.json")
                        with open(json_file_path, 'w') as json_file:
                            json_file.write(json_content)
                        log.info(f"Config saved as JSON file: {json_file_path}")

                        update_scenario_column(scenario_id, "CONFIG_USED", json_content)
                        log.info(f"Config successfully saved to CONFIG_USED for scenario: {scenario_id}")
                    
                        # Delete the JSON file after updating the column
                        # os.remove(json_file_path)
                        # log.info(f"Deleted temporary JSON file: {json_file_path}")
                    
                    except Exception as config_error:
                        log.warning(f"Failed to save config for scenario {scenario_id}: {str(config_error)}")
                        error_config = {
                            "error": f"Configuration save failed: {str(config_error)}",
                            "scenario_id": scenario_id,
                            "timestamp": datetime.datetime.now().isoformat()
                        }
                        update_scenario_column(scenario_id, "CONFIG_USED", json.dumps(error_config))

                    # Run tasks
                    OptimizationDataPull().run()
                    OptimizationStoreRepresentative().run()
                    OptimizationDataPrep().run()
                    OptimizationModeling().run()
                    Optimization345Output().run()
                    if context.scaling_sales.run_scaling:
                        OptimizationScaling().run()
                    if context.scaling_sales.run_scaling and context.scaling_sales.run_waterfall:
                        OptimizationWaterfall().run()
                    
                    # Update status to completed if all tasks succeed
                    update_scenario_column(scenario_id, "STATUS", "COMPLETED")
                    log.info(f"Successfully completed scenario: {scenario_id}")
                    
                except Exception as e:
                    error_message = f"Error in scenario {scenario_id}: {str(e)}"
                    log.error(error_message)
                    log.error(f"Full traceback: {traceback.format_exc()}")
                    
                    # Update scenario with error details
                    update_scenario_error(scenario_id, str(e))

                    continue
        else:
            log.info(f"Running opti outside of scenario mode. Using local configs for input")
            tasks = [
                OptimizationDataPull,
                OptimizationStoreRepresentative,
                OptimizationDataPrep,
                OptimizationModeling,
                Optimization345Output,
            ] 
            if context.scaling_sales.run_scaling:
                tasks.append(OptimizationScaling)
            if context.scaling_sales.run_scaling and context.scaling_sales.run_waterfall:
                tasks.append(OptimizationWaterfall)
    else:
        tasks = [
            OptimizationDataPull,
            OptimizationStoreRepresentative,
            OptimizationDataPrep,
            OptimizationModeling,
            Optimization345Output
        ]

        if context.scaling_sales.run_scaling:
                tasks.append(OptimizationScaling)
        if context.scaling_sales.run_scaling and context.scaling_sales.run_waterfall:
                tasks.append(OptimizationWaterfall)
