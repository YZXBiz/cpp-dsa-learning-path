import pandas as pd
import shap
import logging

from core.schemas.baseline_forecaster import ProphetOutputSchema
from core.schemas.forecaster import (
    BoostTrainingSchema,
)
from core.modules.forecaster.demand_forecaster import DemandForecaster
from core.utils.misc import merge_schema_fields
from core.utils.storage import write_figure
from oxygen.conf.context import context

F = merge_schema_fields(BoostTrainingSchema, ProphetOutputSchema)
logger = logging.getLogger(__name__)


class ObtainShapPlots:
    def __init__(
        self,
        forecaster: DemandForecaster,
        df_train: pd.DataFrame,
        config: dict,
        digital_pipeline: bool = False,
    ):
        # Define forecaster
        self.forecaster = forecaster
        self.digital_pipeline = digital_pipeline
        self.config = config
        # Init shap
        shap.initjs()
        self.df_shap, self.df_train_set = self.forecaster.fit_shap(df_train)

        # Fix format
        if digital_pipeline:
            for var in [F.is_promo]:
                self.df_train_set[var] = self.df_train_set[var].astype(int)
        else:
            for var in [F.is_promo, F.is_page_front]:
                self.df_train_set[var] = self.df_train_set[var].astype(int)

    def run(self):
        # Obtain summary plot
        self.obtain_summary_plot()

        # Obtain feature importance
        self.obtain_feature_importance_plot()

        # Obtain dependence plot
        self.obtain_dependence_plot()

        # Obtain waterfall plot
        self.obtain_waterfall_plot()

    def obtain_summary_plot(self):
        if context.forecaster.shap_params.plots.shap_summary:
            shap.summary_plot(
                shap_values=self.df_shap.values,
                features=self.df_train_set[self.forecaster.features],
                feature_names=(self.df_train_set[self.forecaster.features].columns),
                show=False,
            )
            write_figure(
                path=context.data.forecaster.shap_summary_plot, fig_format="png"
            )

    def obtain_feature_importance_plot(self):
        if self.config.shap_params.plots.feature_importance:
            shap.summary_plot(
                shap_values=self.df_shap.values,
                features=self.df_train_set[self.forecaster.features],
                feature_names=(self.df_train_set[self.forecaster.features].columns),
                show=False,
                plot_type="bar",
            )
            write_figure(
                path=context.data.forecaster.shap_feature_importance_plot,
                fig_format="png",
            )

    def obtain_dependence_plot(self):
        shap_features_list = self.config.shap_params.plots.dependence_plot.features

        dependence_plot_features = self.forecaster.features
        df_shap = self.df_shap.values
        if self.digital_pipeline:
            categorical_vars_to_exclude = []
            indices_to_include = []
            for i in range(len(self.forecaster.features)):
                c = self.forecaster.features[i]
                if c in self.config.features.categorical:
                    categorical_vars_to_exclude.append(c)
                else:
                    indices_to_include.append(i)

            if len(categorical_vars_to_exclude) > 0:
                dependence_plot_features = [
                    c
                    for c in self.forecaster.features
                    if c not in categorical_vars_to_exclude
                ]
                df_shap = self.df_shap.values[:, indices_to_include]

        if shap_features_list:
            for feature in shap_features_list:
                if feature in self.config.features.all:
                    try:
                        shap.dependence_plot(
                            feature,
                            shap_values=df_shap,
                            features=self.df_train_set[dependence_plot_features],
                            feature_names=(
                                self.df_train_set[dependence_plot_features].columns
                            ),
                            show=False,
                        )
                        write_figure(
                            path=(
                                context.data.forecaster.shap_dependence_plot
                                + f"shap_dependence_{feature}_plot.png"
                            ),
                            fig_format="png",
                        )
                    except ValueError:
                        logger.warning(
                            f"Dependence plot for {feature} could not be plotted"
                        )
                else:
                    logger.warning(f"Feature {feature} not used in forecaster model")
        else:
            logger.warning("List of features to plot shap dependence is empty")

    def obtain_waterfall_plot(self):
        if self.digital_pipeline:
            waterfall_plot_path = (
                context.digital_forecaster.shap_params.plots.waterfall_plot
            )

            item_identifier = "item_no"
            if waterfall_plot_path.list_items:
                df_items_waterfall = pd.DataFrame(
                    waterfall_plot_path.list_items,
                    columns=[item_identifier, F.date, "channel"],
                )

                for index, row in df_items_waterfall.iterrows():
                    item_value = row[item_identifier]
                    date_value = row[F.date]
                    channel_value = row["channel"]

                    query_string = (
                        f"{item_identifier} == '{item_value}' and "
                        + f"date == '{date_value}' and channel == '{channel_value}'"
                    )

                    print(f"fitting SHAP waterfall on following sample: {query_string}")

                    item_idx = self.df_train_set.query(query_string).index

                    try:
                        shap.waterfall_plot(
                            shap.Explanation(
                                values=self.df_shap.loc[item_idx[0]],
                                base_values=self.forecaster.explainer.expected_value,
                                data=self.df_train_set.loc[
                                    item_idx[0], self.forecaster.features
                                ].values,
                                feature_names=(
                                    self.df_train_set[
                                        self.forecaster.features
                                    ].columns.tolist()
                                ),
                            ),
                            show=False,
                        )
                        write_figure(
                            path=(
                                context.data.forecaster.shap_waterfall_plot
                                + f"_{row[item_identifier]}_{row[F.date]}_{row['channel']}.png"
                            ),
                            fig_format="png",
                        )
                        logger.info(
                            "completed waterfall chart for "
                            f"{row[item_identifier]}_{row[F.date]}_{row['channel']}"
                        )
                    except IndexError:
                        logger.warning(
                            f"Item {row[item_identifier]} or date {row[F.date]} or channel {row['channel']} "
                            f"not present in train sample"
                        )
            else:
                logger.warning(
                    "Item, date, or channel not available in shap train data set"
                )

        else:
            waterfall_plot_path = context.forecaster.shap_params.plots.waterfall_plot

            item_identifier = "sku_id"

            if waterfall_plot_path.list_items:
                df_items_waterfall = pd.DataFrame(
                    waterfall_plot_path.list_items, columns=[item_identifier, F.date]
                )

                for index, row in df_items_waterfall.iterrows():
                    item_idx = self.df_train_set.query(
                        f"{item_identifier} == {row[item_identifier]} and "
                        f"date == '{row[F.date]}'"
                    ).index

                    try:
                        shap.waterfall_plot(
                            shap.Explanation(
                                values=self.df_shap.loc[item_idx[0]],
                                base_values=self.forecaster.explainer.expected_value,
                                data=self.df_train_set.loc[
                                    item_idx[0], self.forecaster.features
                                ].values,
                                feature_names=(
                                    self.df_train_set[
                                        self.forecaster.features
                                    ].columns.tolist()
                                ),
                            ),
                            show=False,
                        )
                        write_figure(
                            path=(
                                context.data.forecaster.shap_waterfall_plot
                                + f"_{row[item_identifier]}_{row[F.date]}.png"
                            ),
                            fig_format="png",
                        )
                    except IndexError:
                        logger.warning(
                            f"Item {row[item_identifier]} or date {row[F.date]} "
                            f"not present in train sample"
                        )
            else:
                logger.warning("Item or date not available in shap train data set")
