import logging
import os
import uuid

import numpy as np
import pandas as pd
import time

from core.utils.storage import delete_recursive
from oxygen.conf.context import context
from oxygen.conf.settings import settings
from oxygen.files.readers import PandasReader
from oxygen.files.storages import storage
from sqlalchemy import create_engine, inspect
from io import BytesIO
import pyarrow as pa
import pyarrow.parquet as pq
from concurrent.futures import ThreadPoolExecutor
from func_timeout import func_timeout, FunctionTimedOut

logger = logging.getLogger(__name__)

TYPE_CONVERSION = {
    "INTEGER": "BIGINT",
    "REAL": "FLOAT(53)",
    "TEXT": "VARCHAR(128)",
    "TIMESTAMP": "DATE",
}


class SynapsePandasReader(PandasReader):
    def _read_parquet(self, file_path, root=False, timeout_time=None, *args, **kwargs):
        """Read parquet either from file or from directory.
        Some times .parquet files are defined as a single file, and other times
        they are split into multiple parts stored in a .parquet/ directory.
        This function will check if the file_path points to a directory
        or a single file, and concatenate the parts if necessary.
        Overwrite to enable function time out and retry
        """
        # TODO: We could add the functionality to read in partitions
        # Currently, users need to add something like
        # `partitions = storage.listdir(data_path)[0]`
        # and loop through each partition in partitions when calling reader.read()
        file_path = self.format_path(file_path, root=root, ignore_host=True)
        if not storage.is_remote:
            logger.info(f"Attempting to read parquet file from '{file_path}'")
            df = pd.read_parquet(file_path, *args, **kwargs)

        else:
            logger.info(f"Attempting to read parquet file from '{file_path}'")
            files = (
                storage.listdir(file_path)[1]
                if storage.isdir(file_path)
                else [file_path]
            )
            df = pd.DataFrame()
            # Ensure that only .parquet files from directory is fetched.
            # This will ignore files such as _SUCCESS.
            files = list(
                filter(lambda x: os.path.splitext(x)[1] in {".pq", ".parquet"}, files)
            )

            if timeout_time:
                success = False
                while not success:
                    try:
                        parts = func_timeout(
                            timeout_time,
                            self._read_parquet_parts,
                            args=(files, *args),
                            kwargs=kwargs,
                        )
                        success = True
                    except FunctionTimedOut:
                        logger.warning(
                            f"Function _read_parquet_parts with arg {file_path} failed "
                            f"to return a result in {timeout_time} seconds. "
                            f"Waiting 30 seconds and then trying again."
                        )
                        time.sleep(30)
            else:
                # Read in data in multithreadded manner.
                parts = self._read_parquet_parts(files, *args, **kwargs)
            df = pd.concat([df, *parts])
            logger.info(
                "Retrieve and concatenate all parts in from multi-threading. "
                "Go into schema operations if presented."
            )

        return df

    def _write_parquet_partition_part(
        self, file_path, repartition_i, each_partition_df
    ):
        handler = BytesIO()
        each_partition_file_path = f"{file_path}/rand_{repartition_i}.parquet"
        table = pa.Table.from_pandas(each_partition_df)
        pq.write_table(table, handler)
        handler.seek(0)
        storage.touch(each_partition_file_path, handler)

    def _write_parquet_partition_parts(
        self, file_path, df, repartition, rand_append=False
    ):
        """Write Dataframe to parquet file with multiple files"""
        # Create a temporary column to partition
        # TODO: We could have leveraged indexes instead of using the random
        df["temp"] = np.floor(repartition * np.random.rand(len(df)) % repartition)

        # Create repartition list
        repartition_ls = list(range(repartition))

        if rand_append:
            all_files = storage.listdir(file_path)[1]
            if len(all_files) > 0:
                max_rand_num = max(
                    [
                        int(x.split("/")[-1].split(".")[-2].split("_")[-1])
                        for x in all_files
                    ]
                )
                repartition_ls = list(np.array(repartition_ls) + max_rand_num + 1)
                df["temp"] = df["temp"] + max_rand_num + 1
                logger.info("Naive append on random repartition is selected.")

        # Make dataframe into pieces
        logger.debug("Creating data_to_write list...")
        data_to_write = [
            df.query(f"temp == {repartition_i}").drop(columns="temp")
            for repartition_i in repartition_ls
        ]
        logger.debug("Cleaning up the df...")
        df = None
        logger.debug("Creating file path list...")
        file_path_ls = [file_path] * repartition
        logger.debug("Ready for multi-threading...")

        num_cpu = context.num_cpu if context.num_cpu else os.cpu_count()
        with ThreadPoolExecutor(max_workers=num_cpu) as pool:
            pool.map(
                self._write_parquet_partition_part,
                file_path_ls,
                repartition_ls,
                data_to_write,
            )

    def _write_parquet(
        self,
        file_path,
        df,
        root=False,
        partition_col=None,
        repartition=32,
        *args,
        **kwargs,
    ):
        """Write Dataframe to parquet file
        Overwrite default behavior to allow writing in partition
        """
        file_path = self.format_path(file_path, root=root, ignore_host=True)

        if not storage.is_remote:
            logger.info(f"Attempting to write parquet file to '{file_path}'")
            df.to_parquet(file_path, *args, **kwargs)
        else:
            # If partition column exists, partition by the column,
            # then for each partition create
            if partition_col:
                list_of_partition = df[partition_col].unique()
                for each_partition in list_of_partition:
                    logger.info(
                        f"Attempting to write parquet file to "
                        f"{file_path}/{partition_col}={each_partition}"
                    )
                    each_partition_df = df.query(
                        f"{partition_col} == '{each_partition}'"
                    ).reset_index(drop=True)
                    each_partition_file_path = (
                        f"{file_path}/{partition_col}={each_partition}"
                    )
                    # With partition, we always do naive append
                    # [todo] make it more sophisticated
                    self._write_parquet_partition_parts(
                        each_partition_file_path,
                        each_partition_df,
                        repartition,
                        rand_append=True,
                    )
                    # self._write_parquet_partition_parts(
                    #     each_partition_file_path, each_partition_df, repartition
                    # )
            elif repartition is False:
                # file path is formatted with run folder, so root=True
                super()._write_parquet(file_path, df, root=True, *args, **kwargs)
            # If a partition column is null, partition randomly in the path
            else:
                logger.info(
                    f"Attempting to write parquet file to "
                    f"'{file_path} with random {repartition} partitions'"
                )
                self._write_parquet_partition_parts(file_path, df, repartition)

    def _write_sql(self, table, df, path=None, *args, **kwargs):
        """Write data to SQL.
        Overwrite default behavior to use COPY INTO query
        rather than a standard DataFrame.to_sql().
        """
        assert getattr(
            settings, "SQL_CONNECTION", None
        ), "`SQL_CONNECTION` setting must be set to be able to write to SQL"
        engine = self._get_connection(**kwargs)
        is_tmp = bool(path is None)
        df = self.clean_df(df)
        # Store data as temporary .csv to later
        # be used by our COPY INTO statement.
        if not path:
            path = f"tmp/{uuid.uuid4()}.parquet"
            logger.debug(f"Generating a temporary file at '{path}'")
            self.write(
                path, df, schema=kwargs.get("schema"), repartition=False, root=False
            )
        else:
            logger.debug(f"Using existing file at '{path}'")

        # Strip SAS token from URL.
        file_url = storage.url(
            os.path.join(context.meta.run_folder, path).lstrip("/")
        ).split("?")[0]

        table_exists = inspect(engine).has_table(table)

        # if table doesn't exist, create
        if not table_exists:
            self._create_table(table, df, engine, **kwargs)

        # if table already exists, only replace if explicitly specified
        elif table_exists and kwargs.get("if_exists") == "replace":
            self._drop_table(table, engine)
            self._create_table(table, df, engine, **kwargs)

        # Use COPY INTO to copy data from file into table,
        # which in the case of Azure Synapse is much more efficient
        # than INSERT statements.
        with engine.connect() as conn:
            conn.execute(
                f"""
                COPY INTO {table}
                FROM '{file_url}'
                {self.get_sql_file_details(path, **kwargs)}
                """
            )

        # Cleanup temporary file.
        if is_tmp:
            logger.debug(f"Attempting to delete temp file at '{path}'")
            storage.rm(os.path.join(context.meta.run_folder, path))
            # also remove tmp folder, otherwise -cp fails
            delete_recursive(os.path.join(context.meta.run_folder, "tmp"))

    def _get_connection(self, **kwargs):
        """Get database engine/connection"""
        database = kwargs.pop("database") if "database" in kwargs else "default"
        # If we have a dictionary of multiple SQL connections, a user can
        # define which database connection to use with the `database` kwarg.
        if isinstance(settings.SQL_CONNECTION, dict):
            conn = settings.SQL_CONNECTION.get(database)
        else:
            conn = settings.SQL_CONNECTION
        logger.debug(f"Getting SQL connection for database '{database}'.")
        return create_engine(conn, fast_executemany=True)

    def _create_table(self, table, df, engine, **kwargs):
        """
        Create a new table based on schema from pandas DataFrame.
        """
        create_query = pd.io.sql.get_schema(df, table, dtype=kwargs.get("dtype"))
        for auto_type, synapse_type in TYPE_CONVERSION.items():
            create_query = create_query.replace(auto_type, synapse_type)
        print(create_query)
        logger.info(f"Creating table '{table}'.")
        with engine.connect() as conn:
            conn.execute(create_query)

    def get_sql_file_details(self, path, **kwargs):
        """
        Get the WITH block of a COPY INTO statement depending
        on what file type we're trying to write into table.
        """
        _, ext = os.path.splitext(path)
        if ext in {
            ".csv",
        }:
            return f"""
                WITH (
                    FIRSTROW=2,
                    FILE_TYPE='CSV',
                    CREDENTIAL = (
                        IDENTITY = 'Storage Account Key',
                        SECRET = '{settings.AZURE_STORAGE_KEY}'
                    )
                )
                """
        elif ext in {".pq", ".parquet"}:
            return f"""
                WITH (
                    FILE_TYPE='PARQUET',
                    CREDENTIAL = (
                        IDENTITY = 'Storage Account Key',
                        SECRET = '{settings.AZURE_STORAGE_KEY}'
                    )
                )
                """
        raise ValueError(f"File extension '{ext}' is not supported.")

    def _drop_table(self, table, engine):
        """Drop a database table"""
        logger.info(f"Dropping table '{table}'...")
        with engine.connect() as conn:
            conn.execute(f"DROP TABLE {table};")

    @staticmethod
    def clean_df(df):
        """
        Fix a pandas dataframe that might contain values that
        is not allowed or do not apply to a SQL database.
        """
        logger.info("Dropping index from DataFrame.")
        df = df.reset_index(drop=True)

        if df.isin([np.inf, -np.inf]).any().any():
            logger.warning("DataFrame contains infinite values (`np.inf`).")
            logger.info("Replacing infinite values of DataFrame.")
            df = df.replace([np.inf, -np.inf], np.nan)
        logger.info("Replacing `np.nan` values with `None` of DataFrame.")
        df = df.replace({np.nan: None})

        # convert bool to int
        bool_cols = df.select_dtypes(include=["bool"]).columns
        for bool_col in bool_cols:
            df[bool_col] = df[bool_col].astype(int)

        return df
