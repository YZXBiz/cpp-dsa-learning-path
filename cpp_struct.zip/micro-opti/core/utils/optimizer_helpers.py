from __future__ import annotations

import numpy as np
import pandas as pd
from core.schemas.schemas import (
    LatestSpaceDataSchema,
    LatestSpaceDataWithCategoryLevelSchema,
    LatestSpaceDataFtSchema,
    LatestSpaceDataWithCategoryLevelFtSchema,
    FilteredLatestSpaceDataSchema,
    FilteredLatestSpaceDataSchemaWithCategoryLevel,
    ForceFacingsItemNoClusterSchema,
    ForceFacingsItemNoClusterSchemaWithCategoryLevel,
)
from core.schemas.store_clustering import (
    FilteredTrxDnpProductSpaceForFinancial,
    FilteredTrxDnpProductSpaceForFinancialWithCategoryLevelSchema,
)
from core.schemas.space_elasticity import (
    SkuSpecificSpaceProductivityPerFacing,
)
from core.schemas.optimization import (
    OptimizationMasterModelingInput,
    OptimizationMasterModelingInputWCategoryLevel,
    SuppliersAndBrandsSpaceConstraints,
    SuppliersAndBrandsSpaceConstraintsWithCategoryLevel,
    LinearSpaceChangeGlobalConstraints,
    LinearSpaceChangeGlobalConstraintsWithCategoryLevel,
    LocalItemsSpaceConstraints,
    LocalItemsSpaceConstraintsWithCategoryLevel,
    ItemsForcedFacingsGuardrails,
    ItemsForcedFacingsGuardrailsWithCategoryLevel,
    ItemsAddedNotInData,
    ItemsAddedNotInDataWithCategoryLevel,
    OwnBrandSpaceConstraints,
    OwnBrandSpaceConstraintsWithCategoryLevel,
    MaxFacingsPerSkuInDeptConstraint,
    MaxFacingsPerSkuInDeptConstraintWithCategoryLevel,
    NeedStateMinMaxFacingsConstraint,
    NeedStateMinMaxFacingsConstraintWithCategoryLevel,
    PivotAndLinkedSkuPairsConstraint,
    PivotAndLinkedSkuPairsConstraintWithCategoryLevel,
    StoreSpaceCharacteristicsSchema,
    StoreSpaceCharacteristicsWithCategoryLevelSchema,
    PrioritizedStoreRepresentativeSchema,
    PrioritizedStoreRepresentativeWithCategoryLevelSchema,
    OptimizationMasterModelingOutput,
    OptimizationMasterModelingOutputWithCategoryLevel,
    OptimizationFinancialProjectionsClusterNeedState,
    OptimizationFinancialProjectionsClusterNeedStateWithCategoryLevel,
    OptimizationFinancialProjectionsClusterOnly,
    OptimizationFinancialProjectionsClusterOnlyWithCategoryLevel,
    OptimizationFinancialImpactPerStore,
    OptimizationFinancialImpactPerStoreWithCategoryLevel,
    OriginalClusterItemNoIOHCurves,
    OriginalClusterItemNoIOHCurvesWCategoryLevel,
    OriginalClusterIOHMinMaxPercentConstraints,
    OriginalClusterIOHMinMaxPercentConstraintsWCategoryLevel,
    OrientationMapping,
)
from oxygen.files.schemas import Schema
from core.utils.space_context.run_versioning import complete_file_path
from oxygen.conf.context import context
from oxygen.conf.settings import settings
from core.utils.elasticity_helpers import (
    root_with_run_id,
)
import logging
import math
import ipdb

log = logging.getLogger(__name__)

from oxygen.files.readers import reader

import logging

log = logging.getLogger(__name__)


def select_space_schema_ft(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return LatestSpaceDataFtSchema
    else:
        return LatestSpaceDataWithCategoryLevelFtSchema

def select_SuppliersAndBrandsSpaceConstraints_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return SuppliersAndBrandsSpaceConstraints
    else:
        return SuppliersAndBrandsSpaceConstraintsWithCategoryLevel


def select_LinearSpaceChangeGlobalConstraints_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return LinearSpaceChangeGlobalConstraints
    else:
        return LinearSpaceChangeGlobalConstraintsWithCategoryLevel


def select_LocalItemsSpaceConstraints_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return LocalItemsSpaceConstraints
    else:
        return LocalItemsSpaceConstraintsWithCategoryLevel


def select_OwnBrandSpaceConstraints_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return OwnBrandSpaceConstraints
    else:
        return OwnBrandSpaceConstraintsWithCategoryLevel


def select_MaxFacingsPerSkuInDeptConstraint_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return MaxFacingsPerSkuInDeptConstraint
    else:
        return MaxFacingsPerSkuInDeptConstraintWithCategoryLevel


def select_NeedStateMinMaxFacingsConstraint_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return NeedStateMinMaxFacingsConstraint
    else:
        return NeedStateMinMaxFacingsConstraintWithCategoryLevel


def select_PivotAndLinkedSkuPairsConstraint_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return PivotAndLinkedSkuPairsConstraint
    else:
        return PivotAndLinkedSkuPairsConstraintWithCategoryLevel


def select_StoreSpaceCharacteristicsSchema_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return StoreSpaceCharacteristicsSchema
    else:
        return StoreSpaceCharacteristicsWithCategoryLevelSchema


def select_StoreSpaceCharacteristicsSchema_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return PrioritizedStoreRepresentativeSchema
    else:
        return PrioritizedStoreRepresentativeWithCategoryLevelSchema


def select_category_level_input_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return OptimizationMasterModelingInput
    else:
        return OptimizationMasterModelingInputWCategoryLevel


def select_OptimizationMasterModelingOutput_schema(granularity: list) -> Schema:
    if "category_level_dept_nbr" not in granularity:
        return OptimizationMasterModelingOutput
    else:
        return OptimizationMasterModelingOutputWithCategoryLevel


def get_modified_dnp(df_elasticity: pd.DataFrame, scan_adjustment_list: list = None):
    # Get dnp dataframe
    df_dnp = df_elasticity[["item_no_nbr", "plano_id", "plano_cat_desc", "brand_name", "vendor_name", "vendor_number",
                            "dnp_component_fixed", "dnp_component_cost", "dnp_component_units_sold",
                            "dnp_component_allowance_coupon_co_op", "dnp_component_cost_purchases",
                            "dnp_component_total_sales", "dnp_component_tot_dnp_amt",
                            "sku_system_scan_spread", "sku_scan_final",
                            ]].drop_duplicates()

    # Get DNP modification
    df_dnp_modification = (
        pd.DataFrame
        .from_dict(context.optimization.data_prep.item_dnp_financial_adjustment, orient='index')
        .reset_index()
        .rename(columns={"index": "item_no_nbr"})
    )
    df_brand_vendor_dnp_modification = (
        pd.DataFrame(context.optimization.data_prep.brand_vendor_dnp_btl_rate)
    )

    # Assure column casing match merging table
    df_brand_vendor_dnp_modification.columns = map(str.lower, df_brand_vendor_dnp_modification.columns)
    df_dnp_modification.columns = map(str.lower, df_dnp_modification.columns)
    
    # Assure column types match merging table
    df_brand_vendor_dnp_modification["plano_id"] = df_brand_vendor_dnp_modification["plano_id"].astype(str)
    df_dnp_modification["plano_id"] = df_dnp_modification["plano_id"].astype(str)
    df_dnp_modification["item_no_nbr"] = df_dnp_modification["item_no_nbr"].astype(int)
    

    # Check that DNP are unique on an item (planogram) level
    if len(df_dnp_modification) != len(
            df_dnp_modification.drop_duplicates(subset=["item_no_nbr"])
    ):
        raise ValueError(
            f"Found duplicates in dnp_financial_adjustment. Each SKU can have at most one entry"
        )
    if len(df_dnp) != len(
            df_dnp.drop_duplicates(subset=["item_no_nbr", "plano_id"])
    ):
        raise ValueError(
            f"Found duplicates in DNP data. Each SKU/plano can have at most one entry"
        )

    # Transform brand & vendor to be upper case on both dataframes
    df_dnp["brand_name"] = df_dnp["brand_name"].str.upper()
    df_dnp["vendor_number"] = df_dnp["vendor_number"].str.upper()
    df_brand_vendor_dnp_modification["brand_name"] = df_brand_vendor_dnp_modification["brand_name"].str.upper()
    df_brand_vendor_dnp_modification["vendor_number"] = df_brand_vendor_dnp_modification["vendor_number"].str.upper()
    
    # Join modifications to actual DNP data
    df_dnp = df_dnp.merge(
        df_dnp_modification,
        on=["plano_id", "item_no_nbr"],
        how="left"
    )

    ## Merge brand & vendor depending on granularity
    # brand only
    df_brand_dnp_modification = (
        df_brand_vendor_dnp_modification[df_brand_vendor_dnp_modification["vendor_number"] == "ALL"]
        .rename(columns={"vendor_brand_btl_rate": "brand_btl_rate"})
    )
    df_brand_dnp_modification = df_brand_dnp_modification.drop(columns=["vendor_number"])
    df_dnp = df_dnp.merge(
        df_brand_dnp_modification,
        on=["plano_id", "brand_name"],
        how="left"
    )

    # brand & vendor
    df_vendor_dnp_modification = (
        df_brand_vendor_dnp_modification[df_brand_vendor_dnp_modification["vendor_number"] != "ALL"]
    )
    df_vendor_dnp_modification = df_vendor_dnp_modification.drop(columns=["brand_name"])
    df_dnp = df_dnp.merge(
        df_vendor_dnp_modification,
        on=["plano_id", "vendor_number"],
        how="left"
    )

    # Apply BTL modification
    for btl_col in ["vendor_brand_btl_rate", "brand_btl_rate", "btl_rate"]:
        df_dnp.loc[df_dnp[f"{btl_col}"].notna(), "dnp_component_allowance_coupon_co_op"] = (
            df_dnp[f"{btl_col}"] * df_dnp["dnp_component_cost_purchases"]
        )

    # Apply cost modification
    df_dnp.loc[df_dnp["new_cost"].notna(), "dnp_component_cost"] = (
        df_dnp["new_cost"] * df_dnp["dnp_component_units_sold"]
    )
    
    # Compute total DNP amount & fill missing values
    df_dnp["tot_dnp_amt_mod"] = (  
       df_dnp["dnp_component_fixed"] 
        - df_dnp["dnp_component_cost"] 
        + df_dnp["dnp_component_allowance_coupon_co_op"]   
    )  
    
    df_dnp["tot_dnp_amt_mod"] = df_dnp["tot_dnp_amt_mod"].fillna(0)  
    df_dnp["dnp_component_total_sales"] = df_dnp["dnp_component_total_sales"].fillna(0)  

    # Compute dnp adjustment
    if scan_adjustment_list:
        logging.info(f"Categories will be included scan DNP adjustment: {scan_adjustment_list}")
        df_dnp["tot_dnp_amt_mod"] = np.where(df_dnp["plano_cat_desc"].isin(scan_adjustment_list),
                                             df_dnp["tot_dnp_amt_mod"] - df_dnp["sku_system_scan_spread"] + df_dnp["sku_scan_final"],
                                             df_dnp["tot_dnp_amt_mod"]
                                             )


    # compute dnp ratio  
    df_dnp["dnp_ratio"] = df_dnp["tot_dnp_amt_mod"]/df_dnp["dnp_component_total_sales"]  
    df_dnp["original_dnp_ratio"] = df_dnp["dnp_component_tot_dnp_amt"]/df_dnp["dnp_component_total_sales"]  
    
    for col in ["dnp_ratio", "original_dnp_ratio"]:
        # Fill missing values at plano_id, vendor level, brand level
        df_dnp[col] = (
            df_dnp[col].fillna(
                df_dnp.groupby(["plano_id", "vendor_number", "brand_name"])[col].transform("median")
            )
        )

        df_dnp[col] = (
            df_dnp[col].fillna(
                df_dnp.groupby(["plano_id", "vendor_number"])[col].transform("median")
            )
        )

        df_dnp[col] = (
            df_dnp[col].fillna(
                df_dnp.groupby(["plano_id"])[col].transform("median")
            )
        )

        # Cap min dnp value to be zero
        df_dnp.loc[df_dnp[col] < 0, col] = 0
    
        # Cap max dnp at the Xth percentile
        dnp_95th = df_dnp[col].quantile(0.95)
        df_dnp.loc[df_dnp[col] > dnp_95th, col] = dnp_95th

    # keep relevant columns  
    df_dnp = df_dnp[["item_no_nbr", "dnp_ratio", "plano_id", "original_dnp_ratio"]].drop_duplicates()
    
    # Merge to elasticity dataframe
    df_elasticity = df_elasticity.merge(df_dnp, on=["item_no_nbr", "plano_id"], how="left")

    # Drop unused columns
    df_elasticity = df_elasticity.drop(columns=["plano_id", "brand_name", "vendor_number"])

    return df_elasticity




def override_dnp(df_elasticity, override_table):
    """
    Override DNP_ratio using the CM's input from new SKU_template.
    Args:
        df_elasticity: Original productivity table with imputed DNP
        override_table: new SKU table with DNP_ratio column, if there's data in the column, use that ratio to override the imputed DNP

    Returns: Productivity table with DNP override

    """
    if context.data_stores.raw_data.table_filters.need_state_timestamp is None:
        need_state_timestamp = 20601231235959
    else:
        need_state_timestamp = context.data_stores.raw_data.table_filters.need_state_timestamp

    override_dnp_sql = f"""
    SELECT DISTINCT product_id as item_no_nbr, sku_dnp_ratio as dnp_ratio_override
    FROM {override_table}
    WHERE sku_dnp_ratio IS NOT NULL
    AND TIMESTAMP = (
                SELECT MAX(TIMESTAMP)
                FROM {context.data_stores.raw_data.table_name.need_state_table}
                    WHERE TIMESTAMP <= {need_state_timestamp}
                    AND CASE
                        WHEN PLANOGRAM_DSC = 'HOUSEHOLD' THEN REPLACE(STANDARDIZED_DSC, 'LAUNDRY', 'HOUSEHOLD')
                        WHEN PLANOGRAM_DSC = 'BEVERAGE COOLER' THEN REPLACE(STANDARDIZED_DSC, 'SODA', 'BEVERAGES')
                        WHEN PLANOGRAM_DSC = 'COLD REMEDIES'
                        AND PRODUCT_ID IN (550147, 553771, 668672, 641986, 289586)
                        THEN REPLACE(STANDARDIZED_DSC, 'HOME DIAGNOSTICS', 'COLD REMEDIES')
                        ELSE STANDARDIZED_DSC
                    END IN ('{"', '".join(context.data_stores.raw_data.categories)}')
            )
    """
    override_dnp_df = settings.SNOWFLAKE_CONNECTION.cursor().execute(override_dnp_sql).fetch_pandas_all()

    override_dnp_df.columns = map(str.lower, override_dnp_df.columns)

    df_elasticity = (
        df_elasticity.merge(override_dnp_df,how='left', on=['item_no_nbr'])
                    .assign(dnp_ratio = lambda dx: dx["dnp_ratio_override"].combine_first(dx["dnp_ratio"]))
                    .drop(columns=["dnp_ratio_override"])
    )
    return df_elasticity



def load_sku_productivity_data_based_on_metric(
    metric_name: str,
    plano_cat_desc: list[str] | str,
    department: list[int] | int,
):
    # If plano_cat_desc_filter or dept_filter is a string, convert it to a list
    if isinstance(plano_cat_desc, str):
        plano_cat_desc = [plano_cat_desc]

    if isinstance(department, int):
        department = [department]

    dfs = []
    for _plano_cat_desc in plano_cat_desc:
        for _department in department:
            path_load_sku_level_space_productivity = complete_file_path(
                context.data_stores.space_elasticity.root_path,
                context.data_stores.space_elasticity.modeling.space_productivity_cluster_sku_df,
                at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                run_id_folder=context.run_id.elasticity_run_id,
                plano_cat_desc=str(_plano_cat_desc),
                department=str(_department),
                dependent_var=metric_name,
            )
            df_space_productivity_per_facing = SkuSpecificSpaceProductivityPerFacing.load(
                file_path=path_load_sku_level_space_productivity,
                root=root_with_run_id(
                    context.run_id.elasticity_run_id,
                    context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                ),
            )
            dfs.append(df_space_productivity_per_facing)

    if dfs:
        if context.optimization.model_formulation.dnp_multiplier < 0:
            raise ValueError(
                f"DNP multiplier must be greater or equal to 0, {context.optimization.model_formulation.dnp_multiplier} "
                f"is not a valid value."
                
            )
        elif context.optimization.model_formulation.sales_multiplier < 0:
            raise ValueError(
                f"Sales multiplier must be greater or equal to 0, {context.optimization.model_formulation.sales_multiplier} "
                f"is not a valid value."
                
            )
            
        df_concatenated = pd.concat(dfs, ignore_index=True)

        # Get DNP ratio
        df_concatenated = get_modified_dnp(df_concatenated, context.optimization.data_prep.categories_add_scan_adjustment)

        # Override DNP ratio per client input
        df_concatenated = override_dnp(df_concatenated, context.data_stores.raw_data.table_name.need_state_table)

        # Add a column for the dnp multiplier
        df_concatenated["dnp_mltp"] = context.optimization.model_formulation.dnp_multiplier
        df_concatenated["sales_mltp"] = context.optimization.model_formulation.sales_multiplier
        
        # Apply changes to objective productivity function
        for col in df_concatenated.columns:
            if "n_space_prod_fit_facing" in col:
                # Get facing number
                facing = int(col.split("_")[-1])

                # Create a sales at facing f column
                df_concatenated[f"n_sales_facing_{facing}"] = df_concatenated[col] * df_concatenated["sales_mltp"]

                # Create a BOH reduction factor column 
                # If BOH adjustment was false, set column to 0
                if context.optimization.data_prep.apply_boh_adjustment and facing > 0:
                    facing_ln_multiplier = math.log(facing)
                    
                    df_concatenated[f"n_boh_facings_{facing}"] = (
                        (df_concatenated["boh_param_a"] * facing_ln_multiplier +  df_concatenated["boh_param_b"])
                        * df_concatenated["unit_price"]
                        * 0.08
                    )
                else:
                    df_concatenated[f"n_boh_facings_{facing}"] = 0

                # Create a DNP at facing f column
                df_concatenated[f"n_dnp_facing_{facing}"] = (
                    (df_concatenated[col] * df_concatenated["dnp_ratio"] - df_concatenated[f"n_boh_facings_{facing}"])
                    * df_concatenated["dnp_mltp"]

                )

                # If DNP is below zero, set to zero
                df_concatenated.loc[df_concatenated[f"n_dnp_facing_{facing}"] < 0, 
                                    f"n_dnp_facing_{facing}"] = 0

                # Create the final productivity metric that will go into the optimizer
                df_concatenated[col] = (
                        (df_concatenated[f"n_sales_facing_{facing}"] + df_concatenated[f"n_dnp_facing_{facing}"] ) / 2
                )
        return df_concatenated
    else:
        log.error(
            f"Could not find {metric_name} sku productivity for {plano_cat_desc} and {department}"
        )
        return None


def load_sku_productivity_data_based_on_metric_df_input(
    metric_name: str,
    df_scope: pd.DataFrame,
):
    df_scope = df_scope.copy()

    dfs = []
    for index, row in df_scope.iterrows():
        _plano_cat_desc = row[
            "plano_cat_desc"
        ]  # Assign plano_cat_desc column value to _plano_cat_desc
        _department = row["dept_id"]

        path_load_sku_level_space_productivity = complete_file_path(
            context.data_stores.space_elasticity.root_path,
            context.data_stores.space_elasticity.modeling.space_productivity_cluster_sku_df,
            at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
            run_id_folder=context.run_id.elasticity_run_id,
            plano_cat_desc=str(_plano_cat_desc),
            department=str(_department),
            dependent_var=metric_name,
        )
        df_space_productivity_per_facing = SkuSpecificSpaceProductivityPerFacing.load(
            file_path=path_load_sku_level_space_productivity,
            root=root_with_run_id(
                context.run_id.elasticity_run_id,
                context.data_stores.space_elasticity.save_to_datastores_root.modeling,
            ),
        )
        dfs.append(df_space_productivity_per_facing)

    if dfs:
        df_concatenated = pd.concat(dfs, ignore_index=True)
        return df_concatenated
    else:
        log.error(f"Could not find {metric_name} sku productivity")
        return None


def load_need_state_productivity_based_on_metric(
    metric_name: str,
    plano_cat_desc: list[str] | str,
    department: list[int] | int,
):
    # If plano_cat_desc_filter or dept_filter is a string, convert it to a list
    if isinstance(plano_cat_desc, str):
        plano_cat_desc = [plano_cat_desc]

    if isinstance(department, int):
        department = [department]

    dfs = []
    for _plano_cat_desc in plano_cat_desc:
        for _department in department:
            path_need_state_saturation = complete_file_path(
                context.data_stores.space_elasticity.root_path,
                context.data_stores.space_elasticity.modeling.space_productivity_need_state_df,
                at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                run_id_folder=context.run_id.elasticity_run_id,
                plano_cat_desc=str(_plano_cat_desc),
                department=str(_department),
                dependent_var=metric_name,
            )
            df_space_productivity_need_state = reader.read(
                file_path=path_need_state_saturation,
                root=root_with_run_id(
                    context.run_id.elasticity_run_id,
                    context.data_stores.space_elasticity.save_to_datastores_root.modeling,
                ),
            )
            df_space_productivity_need_state = df_space_productivity_need_state[
                [
                    "category_level_dept_nbr",
                    "category_level_dept_name",
                    "plano_cat_id",
                    "plano_cat_desc",
                    "dept_id",
                    "need_state_unique_id",
                    "fixture_desc",
                    "final_cluster_labels",
                    "saturation_facings",
                ]
            ].drop_duplicates()

            dfs.append(df_space_productivity_need_state)

    if dfs:
        df_concatenated = pd.concat(dfs, ignore_index=True)
        return df_concatenated
    else:
        log.error(
            f"Could not find {metric_name} need states productivity for {plano_cat_desc} and {department}"
        )
        return None


def filter_based_on_granularity(
    df: pd.DataFrame,
    granularity: list,
    category_level_dept_nbr=None,
    plano_cat_desc=None,
    department=None,
) -> pd.DataFrame:
    """
    Filters the DataFrame based on the specified granularity.

    Args:
        df (pd.DataFrame): The DataFrame to be filtered.
        granularity (list): A list of column names that define the granularity of filtering.
                            Possible values: ["category_level_dept_nbr", "plano_cat_desc", "dept_id"].
        category_level_dept_nbr (optional): The value to filter the "category_level_dept_nbr" column. Only used if "category_level_dept_nbr" is in granularity.
        plano_cat_desc (optional): The value to filter the "plano_cat_desc" column. Only used if "plano_cat_desc" is in granularity.
        department (optional): The value to filter the "dept_id" column. Only used if "dept_id" is in granularity.

    Returns:
        pd.DataFrame: A filtered DataFrame based on the specified granularity.
    """
    # Initialize the filtering conditions
    conditions = []

    # Apply conditions based on granularity
    if (
        "category_level_dept_nbr" in granularity
        and category_level_dept_nbr is not None
        and "category_level_dept_nbr" in df.columns
    ):
        conditions.append(df["category_level_dept_nbr"] == category_level_dept_nbr)

    if (
        "plano_cat_desc" in granularity
        and plano_cat_desc is not None
        and "plano_cat_desc" in df.columns
    ):
        conditions.append(df["plano_cat_desc"] == plano_cat_desc)

    if "dept_id" in granularity and department is not None and "dept_id" in df.columns:
        conditions.append(df["dept_id"] == department)

    # Combine all conditions with the logical AND operator
    if conditions:
        combined_condition = conditions[0]
        for condition in conditions[1:]:
            combined_condition &= condition

        # Apply the combined condition to the DataFrame
        df = df[combined_condition]

    return df


def check_duplicates(df: pd.DataFrame, df_name: str, subset: list):
    """
    Checks for duplicate rows in the given DataFrame based on a specified subset of columns.

    If duplicates are found, the function saves the duplicate rows to a CSV file, prints them out,
    and raises a ValueError.

    Args:
        df (pd.DataFrame): The DataFrame to check for duplicates.
        df_name (str): The name of the DataFrame, used for labeling the output files and messages.
        subset (list): A list of column names to consider when identifying duplicates.

    Raises:
        ValueError: If duplicates are found in the DataFrame, a ValueError is raised with an appropriate message.
    """
    # Find duplicates in the subset
    duplicates = df[df.duplicated(subset=subset, keep=False)]

    if not duplicates.empty:
        # Save the duplicate rows to a CSV file for inspection
        duplicates.to_csv(f"{df_name}_duplicates.csv", index=False)

        # Print out the duplicate rows
        print(f"Duplicate rows found in {df_name}:\n")
        print(duplicates)

        # Raise an error with a message
        raise ValueError(
            f"Found duplicates in df {df_name}, please check data and pipeline"
        )


def get_updated_height_depth_orientation(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Redefines item dimensions (width, height, depth) based on SKU orientation.
    Orientation mapping is derived from a raw file that links orientations to equivalent dimensions.

    Args:
        df (pd.DataFrame): DataFrame containing SKU data with orientation and dimensions.

    Returns:
        pd.DataFrame: Updated DataFrame where item dimensions are adjusted so that width aligns with the linear facing.
    """
    # Load orientation_mapping
    df_orientation_mapping = OrientationMapping.load(
        file_path=complete_file_path(
            context.data_stores.raw_mapping.root_path,
            context.data_stores.raw_mapping.orientation_mapping.file_name,
        ),
        root=True,
    )

    # Remove potential duplicates in mapping
    df_orientation_mapping = (
        df_orientation_mapping.groupby("orientation")[
            [
                "equivalent_height_dimension",
                "equivalent_depth_dimension",
            ]
        ]
        .first()
        .reset_index()
    )

    col_spaces = ["height", "depth"]

    df.orientation.fillna("Front", inplace=True)

    df_mapped_orientation = df.merge(
        df_orientation_mapping, on="orientation", how="left"
    )
    for col_space in col_spaces:
        (
            df_mapped_orientation["equivalent_" + col_space + "_dimension"].fillna(
                col_space, inplace=True
            )
        )

    for col_space in col_spaces:
        df_mapped_orientation[
            "equivalent_prod_unit_" + col_space + "_ft"
        ] = df_mapped_orientation.apply(
            lambda x: x[
                "prod_unit_" + str(x["equivalent_" + col_space + "_dimension"]) + "_ft"
            ],
            axis=1,
        )

    dict_dimensions = {
        "equivalent_prod_unit_height_ft": "prod_unit_height_ft",
        "equivalent_prod_unit_depth_ft": "prod_unit_depth_ft",
    }

    df_mapped_orientation.drop(columns=list(dict_dimensions.values()), inplace=True)
    df_mapped_orientation.rename(columns=dict_dimensions, inplace=True)

    df_mapped_orientation.drop(
        columns={
            "equivalent_height_dimension",
            "equivalent_depth_dimension",
        },
        inplace=True,
    )

    return df_mapped_orientation


def explode_specified_cluster_granularity(
    granularity_split_dfs: dict[str, pd.DataFrame],
    df_cluster_details: pd.DataFrame,
    explode_from_cluster: str,
    explode_to_cluster: str,
    output_cols: list[str],
) -> pd.DataFrame:
    """
    Explodes and maps data from one cluster granularity to another.

    This function takes a dictionary of dataframes split by cluster granularity, extracts the dataframe
    corresponding to the `explode_from_cluster` granularity, and maps it to the `explode_to_cluster` granularity
    using the final cluster data. The resulting dataframe includes only the specified output columns
    and removes duplicate rows.

    Args:
        granularity_split_dfs (dict[str, pd.DataFrame]):
            A dictionary where the keys are granularity names (e.g., "all_cluster_labels", "original_cluster_labels")
            and the values are the corresponding dataframes.
        df_cluster_details (pd.DataFrame):
            A dataframe containing the cluster data, used to map and explode the clusters.
        explode_from_cluster (str):
            The cluster granularity to explode data from (e.g., "all_cluster_labels").
        explode_to_cluster (str):
            The target cluster granularity to map the data to (e.g., "final_cluster_labels").
        output_cols (list[str]):
            A list of column names to include in the final output dataframe.

    Returns:
        pd.DataFrame:
            A dataframe containing the exploded and mapped data, deduplicated and limited to the specified
            `output_cols`. If no data is found for the `explode_from_cluster` granularity, returns an empty
            dataframe with `output_cols` as columns.
    """
    df_granularity_split = granularity_split_dfs.get(
        explode_from_cluster, pd.DataFrame()
    )

    if df_granularity_split.empty:
        log.warning(
            f"No '{explode_from_cluster}' granularity data found. Returning empty DataFrame."
        )
        return pd.DataFrame(columns=output_cols)

    log.info(
        f"Exploding '{explode_from_cluster}' to '{explode_to_cluster}' cluster granularity data."
    )
    if explode_from_cluster in ["all_cluster_labels", explode_to_cluster]:
        cluster_cols_to_use = context.groupby_granularity.optimizer + [
            explode_to_cluster
        ]
    else:
        cluster_cols_to_use = context.groupby_granularity.optimizer + [
            explode_to_cluster,
            explode_from_cluster,
        ]

    if explode_from_cluster == "all_cluster_labels":
        merge_columns = ["dept_id"]
    else:
        merge_columns = ["dept_id", explode_from_cluster]

    df_exploded_final_cluster = (
        df_granularity_split.rename(columns={"cluster_labels": explode_from_cluster})
        .merge(
            df_cluster_details[cluster_cols_to_use].drop_duplicates(),
            on=merge_columns,
            how="inner",
        )[output_cols]
        .drop_duplicates()
    )

    log.info(
        f"Found {df_exploded_final_cluster.shape[0]} rows of '{explode_to_cluster}' granularity data in scope: \n{df_exploded_final_cluster}"
    )

    return df_exploded_final_cluster


def explode_to_selected_cluster(
    df_input_clusters: pd.DataFrame,
    df_cluster_details: pd.DataFrame,
    valid_granularity_types: list[str],
    explode_to_cluster: str,
    output_cols: list[str],
) -> pd.DataFrame:
    """
    Explodes input cluster granularity data to a specified cluster type.

    This function processes an input dataframe containing cluster granularity data, validates it,
    and maps the data from valid granularity clusters to the specified `explode_to_cluster`.
    The resulting dataframe includes only the specified output columns and ensures no duplicate rows.

    Args:
        df_input_clusters (pd.DataFrame):
            A dataframe containing input cluster data with granularity information.
            Expected columns include:
            - `cluster_granularity`: Specifies the type of cluster granularity (e.g., "all", "demand", "original", "final").
            - Additional columns necessary for merging and processing, such as `dept_id`, `item_no_nbr`, etc.
        df_cluster_details (pd.DataFrame):
            A dataframe containing detailed cluster information used to map input clusters to the specified
            `explode_to_cluster`. It must include columns required for merging and granularity mapping.
        valid_granularity_types (list[str]):
            A list of valid granularity types (e.g., `["all", "demand", "original", "final"]`) used to filter
            and split the input data into manageable subsets.
        explode_to_cluster (str):
            The target cluster type to which the data should be mapped (e.g., "final_cluster_labels").
        output_cols (list[str]):
            A list of column names to include in the final output dataframe.

    Returns:
        pd.DataFrame:
            A dataframe containing the exploded and mapped cluster data, deduplicated and limited to the specified
            `output_cols`. The output includes data corresponding to the specified `explode_to_cluster`.
    """

    # Ensure no duplicates in the input data
    df_input_clusters = df_input_clusters.drop_duplicates().copy()

    # Initialize the list of DataFrames to concatenate
    df_exploded_clusters = pd.DataFrame(columns=output_cols)

    # Get the total number of rows in the input DataFrame
    total_rows = df_input_clusters.shape[0]

    if total_rows > 0:
        # Split the input dataframe by granularity
        granularity_split_dfs = {
            f"{granularity}_cluster_labels": df_input_clusters[
                df_input_clusters["cluster_granularity"]
                .str.lower()
                .str.contains(granularity)
            ]
            for granularity in valid_granularity_types
        }

        # Validation: Ensure all rows fall into valid granularity categories
        processed_rows = sum(
            df_split.shape[0] for df_split in granularity_split_dfs.values()
        )
        unique_input_clusters = df_input_clusters["cluster_granularity"].unique()
        if total_rows != processed_rows:
            raise ValueError(
                "Invalid 'cluster_granularity' values in found 'df_input_clusters' DataFrame. "
                f"Valid values are {valid_granularity_types}, but values found are {unique_input_clusters}."
            )
        else:
            log.info(
                f"Detected {len(unique_input_clusters)} valid 'cluster_granularity' values: {unique_input_clusters}"
            )

        log.info(f"Found total of {total_rows} rows of cluster granularity data.")

        for cluster_granularity, df_split in granularity_split_dfs.items():
            log.info(
                f"Found {df_split.shape[0]} rows of '{cluster_granularity}' granularity data: \n{df_split}"
            )
            df_exploded_final_cluster = explode_specified_cluster_granularity(
                granularity_split_dfs=granularity_split_dfs,
                df_cluster_details=df_cluster_details,
                explode_from_cluster=cluster_granularity,
                explode_to_cluster=explode_to_cluster,
                output_cols=output_cols,
            )

            df_exploded_clusters = pd.concat(
                [df_exploded_clusters, df_exploded_final_cluster],
                axis=0,
                ignore_index=True,
            )

        log.info(
            f"Finalized {df_exploded_clusters.shape[0]} rows of '{explode_to_cluster}' in scope: \n{df_exploded_clusters}"
        )
    else:
        log.warning("No cluster granularity data found. Returning empty DataFrame.")

    return df_exploded_clusters
