import io
import os
import logging
from typing import Tuple, Union

import matplotlib.pyplot as plt

import dill  # like pickle, but allows pickling lambda function
import pandas as pd
import datetime
from azure.storage.blob import BlobServiceClient
import multiprocessing as mp
from itertools import repeat
from multiprocessing import Pool, cpu_count
from typing import Dict

from configs import settings
from oxygen.conf.context import context as oxy_context
from oxygen.files.readers import reader
from oxygen.files.storages import storage
from oxygen.files.schemas import Schema

from openpyxl import Workbook, load_workbook
from io import BytesIO
from tempfile import NamedTemporaryFile


from core.utils.calculations import calculate_sundays


# initialise logger
logger = logging.getLogger(__name__)


def write_object(path, obj, context=oxy_context, root=False):
    """Write an object to storage."""
    stream = io.BytesIO()
    dill.dump(obj, stream)
    if root:
        storage.touch(path, stream)
    else:
        storage.touch(os.path.join(context.meta.run_folder, path), stream)


def write_figure(path, fig_format="png", context=oxy_context, root=False):
    """Save a figure to storage."""
    stream = io.BytesIO()
    plt.savefig(stream, format=fig_format, dpi=150, bbox_inches="tight")
    if root:
        storage.touch(path, stream)
    else:
        storage.touch(os.path.join(context.meta.run_folder, path), stream)
    plt.clf()


def write_prophet_figure(
    figure, path, fig_format="png", context=oxy_context, root=False
):
    """Save a prophet figure to storage."""
    stream = io.BytesIO()
    figure.savefig(stream, format=fig_format, dpi=150, bbox_inches="tight")
    if root:
        storage.touch(path, stream)
    else:
        storage.touch(os.path.join(context.meta.run_folder, path), stream)
    plt.clf()


def write_text(
    text,
    path,
    append=False,
    context=oxy_context,
    root=False,
):
    """Write text to a storage text file."""

    if not root:
        path = os.path.join(context.meta.run_folder, path)

    if append:
        if storage.exists(path):
            with storage.open(path) as file:
                written = file.getvalue().decode("utf-8")
                text = written + text

    storage.touch(path, io.StringIO(text))


def read_text(path, context=oxy_context, root=False):
    """Read text file."""

    if not root:
        path = os.path.join(context.meta.run_folder, path)

    with storage.open(path) as file:
        text = file.getvalue().decode("utf-8")

    return text


def load_object(path, context=oxy_context, root=False):
    """Load an object from storage."""
    if root:
        obj = dill.load(storage.open(path))
    else:
        obj = dill.load(storage.open(os.path.join(context.meta.run_folder, path)))
    return obj


def load_file_local_first(path, context=oxy_context, **kwargs):
    if storage.exists(os.path.join(context.meta.run_folder, path)):
        logger.info(f"Loading {path} as part of current run")
        df = reader.read(path, **kwargs)

    elif context.forecaster.application.model_run_path is not None:
        logger.info(
            f"Loading {path} from previous run "
            f"{context.forecaster.application.model_run_path}"
        )
        df = reader.read(
            os.path.join(context.forecaster.application.model_run_path, path),
            root=True,
            **kwargs,
        )

    else:
        logger.info(f"Loading {path} from environment folder")
        df = reader.read(
            os.path.join(
                (context.data.environment_folder).replace(
                    "{environment}", context.environment
                ),
                path,
            ),
            root=True,
            **kwargs,
        )

    return df


def load_baseline_for_extrapolation(
    context=oxy_context,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Load train baseline and df with extrapolation factors for test baseline:
        - If these dfs were generated in the current run, return that
        - If not, load from default run folder specified in config
    """

    if storage.exists(
        os.path.join(
            context.meta.run_folder, context.data.forecaster.baseline_diff_train
        )
    ):
        logger.info("Loading baseline and extrapolation factors from this run")
        df_train_baselines = reader.read(context.data.forecaster.baseline_train)
        df_diff = reader.read(context.data.forecaster.baseline_diff_train)

    else:
        logger.info("Loading baseline and extrapolation factors from previous run")
        df_train_baselines = reader.read(
            os.path.join(
                context.forecaster.application.model_run_path,
                context.data.forecaster.baseline_train,
            ),
            root=True,
        )
        df_diff = reader.read(
            os.path.join(
                context.forecaster.application.model_run_path,
                context.data.forecaster.baseline_diff_train,
            ),
            root=True,
        )

    return df_train_baselines, df_diff


def delete_recursive(path):
    for d in storage.listdir(path)[0]:
        delete_recursive(d)

    for f in storage.listdir(path)[1]:
        storage.rm(f)

    storage.rm(path)


def copy_blob(
    blob,
    account_url,
    blob_service,
    origin,
    destination_file_name_list,
    overwrite,
    destination,
):
    """
    Copy single blob. User will pass the file path
    Args:
        blob: file path
        account_url: url of the account
        blob_service: azure object
        origin: original path
        destination_file_name_list: files already in destination
        overwrite: flag if function should override
        destination: destination path
    """

    # if a file already exists in the destination folder
    # and not to overwrite, then continue
    origin_file_name = blob.name.split(origin, 1)[1]
    if origin_file_name in destination_file_name_list:
        if not overwrite:
            return 0

    try:
        # print(blob.name)
        copied_blob = blob_service.get_blob_client(
            settings.AZURE_STORAGE_NAME,
            blob.name.replace(
                origin,
                destination,
            ),
        )
        copied_blob.start_copy_from_url(
            account_url + "/" + settings.AZURE_STORAGE_NAME + "/" + blob.name
        )
    except BaseException:
        return 1


def copy_blobs(origin: str, destination: str, overwrite: bool = True):
    """
    Copy all blobs listed under a selected folder to a new folder
    Args:
        origin: parent folder
        destination: new folder with the copied content
        overwrite: if file already exists in new folder, to overwrite or not
    """

    # Set up the storage access
    access_key = getattr(settings, "AZURE_STORAGE_KEY", None)
    account_url = "{}://{}.{}".format(
        "https", settings.AZURE_STORAGE_NAME, "blob.core.windows.net"
    )

    blob_service = BlobServiceClient(account_url=account_url, credential=access_key)
    container_client = blob_service.get_container_client(settings.AZURE_STORAGE_NAME)

    # Ensure origin and destination don't start with / to avoid error for split
    if origin.startswith("/"):
        origin = origin[1:]
    if destination.startswith("/"):
        destination = destination[1:]

    origin_blob_list = container_client.list_blobs(name_starts_with=origin)
    destination_blob_list = container_client.list_blobs(name_starts_with=destination)
    # get all file names in the destination folder
    destination_file_name_list = [
        blob.name.split(destination, 1)[1] for blob in destination_blob_list
    ]

    # TODO - change harcoded number of cores
    # Copying files in parallel
    with mp.Pool(4) as p:
        p.starmap(
            copy_blob,
            zip(
                origin_blob_list,
                repeat(account_url),
                repeat(blob_service),
                repeat(origin),
                repeat(destination_file_name_list),
                repeat(overwrite),
                repeat(destination),
            ),
        )


def write_png(path, fig, context=oxy_context, root=False):
    """Write an object to storage."""
    stream = io.BytesIO()
    fig.savefig(stream)
    stream.seek(0)
    if root:
        storage.touch(path, stream)
    else:
        storage.touch(os.path.join(context.meta.run_folder, path), stream)


def return_last_txn_dt(
    path: "str",
    partition_key: "str",
    exec_date=None,
    return_type="str",
    partition_sep="=",
    path_key_sep="/",
    suffix="",
) -> str:
    """Return last transaction date.
    Args:
        path: path of the transaction data
        partition_key: partition key of the transaction file.
        exec_date: last date to scan the files for.
        return_type: return type, "str" or "date"
        partition_sep: what goes between partition_key and date, like `=`
        path_key_sep: whether "/" exists, in some case, csv is directly under
            the path, like stock_date/stock.2022-01-01.csv
        suffix: suffix of each partition, like ".csv"
    Returns:
        The last date before or on exec_date with transaction data.
    """

    # get last date or today if not specified
    if exec_date is not None:
        exec_date = pd.to_datetime(exec_date).date()
    else:
        exec_date = datetime.datetime.today().date()

    # loop until partitioned folder found
    last_date = None
    count = 0
    while last_date is None:
        dt = (exec_date - pd.DateOffset(count)).date()
        logger.debug(dt)
        if storage.isdir(
            # path/dt=2022-01-01 where partition_level="/", partition_sep="-"
            f"{path}{path_key_sep}{partition_key}{partition_sep}{dt}{suffix}"
        ):
            last_date = dt
        elif storage.isfile(
            f"{path}{path_key_sep}{partition_key}{partition_sep}{dt}{suffix}"
        ):
            last_date = dt
        count += 1

        # safeguard so that it doesn't loop forever
        if count >= 100:
            raise ValueError(
                "cannot find partition after 100 searches, check path and partition key"
            )

    logger.info(f" Last txn date used: {last_date}")

    if return_type == "str":
        last_date = last_date.strftime("%Y-%m-%d")

    if return_type == "datetime":
        last_date = datetime.datetime(last_date.year, last_date.month, last_date.day)

    return last_date


def write_data_by_partition_digital(
    df: pd.DataFrame,
    file_path: str,
    start_date: str,
    end_date: str,
    partition_by: str = "date",
    root: bool = False,
    schema: Schema = None,
    fmt: str = ".pq",
):
    """
    writes data to parquet partitioned by partition_by column

    Args:
        df: dataframe to write
        file_path: path to write to
        partition_by: column to partition by. Must be a date column
        root: whether to write to root folder
        schema: (optional) the schema to save the data with
        fmt: (optional) the format of data to be written

    Returns:
        None
    """

    date_range = calculate_sundays(start_date, end_date)
    args = zip(
        repeat(df),
        repeat(file_path),
        repeat(partition_by),
        repeat(root),
        repeat(schema),
        repeat(fmt),
        date_range,
    )

    num_cpu = oxy_context.num_cpu if oxy_context.num_cpu else cpu_count()

    p = Pool(num_cpu)
    p.starmap(write_partition_digital, args)

    p.close()
    p.join()


def write_partition_digital(
    df: pd.DataFrame,
    file_path: str,
    partition_by: str,
    root: bool,
    schema: Schema,
    fmt: str,
    date: str,
):
    partition_df = df[df[partition_by] == pd.to_datetime(date)]
    if partition_df.empty:
        logger.info(f"Partition ({partition_by}={date}) is empty, skipping")
        return

    try:
        blob_name = f"{file_path}/{partition_by}={date}"

        reader.write(
            blob_name,
            partition_df,
            root=root,
            schema=schema,
            data_format=fmt,
        )

    except BaseException as e:
        logger.info(f"Unable to save partition ({partition_by}={date}), error: {e}")


def read_data_by_partition_digital(
    file_path: str,
    start_date: str,
    end_date: str,
    partition_by: str = "date",
    root: bool = False,
    schema: Schema = None,
    fmt: str = ".pq",
):
    """
    reads data from parquet partitioned by partition_by column

    Args:
        file_path: path to read from
        start_date: start date of date range
        end_date: end date of date range
        partition_by: column to partition by
        root: whether to write to root folder
        schema: (optional) the schema to load to data with
        fmt: (optional) the format of the data to be read
    """
    date_range = calculate_sundays(start_date, end_date)

    args = zip(
        repeat(file_path),
        repeat(partition_by),
        repeat(root),
        repeat(schema),
        repeat(fmt),
        date_range,
    )

    num_cpu = oxy_context.num_cpu if oxy_context.num_cpu else cpu_count()
    p = Pool(num_cpu)
    read_in_dfs = p.starmap(read_partition_digital, args)

    p.close()
    p.join()

    try:
        df = pd.concat(read_in_dfs)
        return df
    except ValueError:
        logger.warning("all loaded datasets are empty")
        return None


def read_partition_digital(
    data_path: str,
    partition_by: str,
    root: bool,
    schema: Schema,
    fmt: str,
    date: str,
) -> Union[None, pd.DataFrame]:
    sub_data_path = os.path.join(data_path, f"{partition_by}={date}")
    try:
        df = reader.read(
            sub_data_path,
            root=root,
            schema=schema,
            data_format=fmt,
        )
    except BaseException as e:
        logger.info(f"Partition ({partition_by}={date}) might be empty; error {e}")
        df = None
    return df


def save_multi_tab_excel(
    save_dict: Dict[str, pd.DataFrame], path: str, context=oxy_context, root=False
) -> None:
    """
    This function saves a multi-tab Excel to storage (currently leveraged to save space elasticity sense checks)

    Args:
        save_dict: Dictionary containing filenames mapped to the dataframes we want to save as separate tabs (e.g.
        {"tab1_name": tab1_df, "tab2_name": tab2_df, ...})
        path: Path in storage where we want to save the excel, based on a root path
        that is the `run_folder` specified in config

    Returns:
    Nothing
    """
    with io.BytesIO() as output:
        writer = pd.ExcelWriter(output, engine="xlsxwriter")
        for filename, dataframe in save_dict.items():
            dataframe.to_excel(writer, sheet_name=filename, index=False)

        writer.close()
        output.seek(0)
        if root:
            storage.touch(path, output)
        else:
            storage.touch(os.path.join(context.meta.run_folder, path), output)


def open_excel_template(path: str, context=oxy_context, root=False) -> Workbook:
    """Opens the Excel template from storage"""
    if root:
        obj = storage.open(path).getvalue()
    else:
        obj = storage.open(os.path.join(context.meta.run_folder, path)).getvalue()
    return load_workbook(filename=BytesIO(obj))


def save_excel_template(
    wb: Workbook, path: str, context=oxy_context, root=False
) -> None:
    """Saves the given Excel workbook to the cloud storage file path."""

    with NamedTemporaryFile() as tmp:
        wb.save(tmp.name)
        tmp.seek(0)
        output = BytesIO(tmp.read())
        if root:
            storage.touch(path, output)
        else:
            storage.touch(os.path.join(context.meta.run_folder, path), output)
