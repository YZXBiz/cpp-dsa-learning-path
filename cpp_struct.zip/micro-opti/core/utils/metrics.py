import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from typing import Tuple


def balanced_mean_absolute_percentage_error(
    y_true: pd.Series, y_pred: pd.Series, sample_weight: pd.Series = None
) -> float:
    """
    Calculate balanced mean absolute percentage error (BMAPE)

    Args:
        y_true: actual target values
        y_pred: predicted target values
        sample_weight: values for weighting observations in the mean

    Returns: balanced mean absolute percentage error
    """
    if sample_weight is not None:
        sample_weight = sample_weight if sample_weight.sum() > 0 else None

    y_true, y_pred = np.array(y_true), np.array(y_pred)
    denominator = np.maximum(y_true, y_pred)
    denominator = np.where(denominator == 0, 1, denominator)
    return np.average(np.abs(y_true - y_pred) / denominator, weights=sample_weight)


def symmetric_mean_absolute_error(
    y_true: pd.Series, y_pred: pd.Series, sample_weight: pd.Series = None
) -> float:
    """
    Calculate symmetric mean absolute percentage error (SMAPE)

    Args:
        y_true: actual target values
        y_pred: predicted target values
        sample_weight: values for weighting observations in the mean

    Returns: symmetric mean absolute percentage error
    """
    if sample_weight is not None:
        sample_weight = sample_weight if sample_weight.sum() > 0 else None
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    denominator = np.abs(y_true) + np.abs(y_pred)
    denominator = np.where(denominator == 0, 1, denominator)

    return np.average(
        np.abs(y_pred - y_true) / denominator,
        weights=sample_weight,
    )


def bias_score(
    y_true: pd.Series, y_pred: pd.Series, sample_weight: pd.Series = None, total=True
) -> float:
    """
    Calculate percentage bias of prediction;
        bias > 0 % => over-prediction
        bias < 0 % => under-prediction

    Args:
        y_true: actual target values
        y_pred: predicted target values
        sample_weight: values for weighting observations in the mean (only for total)
        total: Total or avg bias

    Returns:
        total or avg (relative) bias
    """
    if total is True:
        return (np.sum(y_pred) / np.sum(y_true)) - 1
    else:
        y_true, y_pred = np.array(y_true), np.array(y_pred)
        if sample_weight is not None:
            sample_weight = np.array(sample_weight)[y_true > 0]
        y_true, y_pred = y_true[y_true > 0], y_pred[y_true > 0]

        return np.average(
            np.abs(y_pred / y_true - 1),
            weights=sample_weight,
        )


def create_error_report(
    y_true: pd.Series,
    y_pred: pd.Series,
    label: str = None,
    weight: pd.Series = None,
) -> str:
    """
    Calculate multiple error metrics to measure model performance and returns formatted
    string: smape, bmape, r2, bias.

    Args:
        y_true: actual target values
        y_pred: predicted target values
        label: title for produced string report
        weight: relative weight during aggregation

    Returns:
        error_string; printable report of key metrics with label
    """

    if label is None:
        label = ""

    smape = symmetric_mean_absolute_error(
        y_true=y_true, y_pred=y_pred, sample_weight=weight
    )
    bmape = balanced_mean_absolute_percentage_error(
        y_true=y_true, y_pred=y_pred, sample_weight=weight
    )
    r2 = r2_score(y_true=y_true, y_pred=y_pred, sample_weight=weight)
    wmape = bias_score(y_true=y_true, y_pred=y_pred, sample_weight=weight, total=False)
    bias = bias_score(y_true=y_true, y_pred=y_pred, sample_weight=weight, total=True)
    error_string = f"""
    {label}
        SMAPE         {smape:.2%}
        BMAPE         {bmape:.2%}
        WMAPE         {wmape:.2%}
        Bias          {bias:.2%}
        R2            {r2:.2%}
    """

    return error_string


def create_digital_error_report(
    y_true: pd.Series,
    y_pred: pd.Series,
    label: str = None,
    weight: pd.Series = None,
) -> Tuple[str, pd.DataFrame]:
    """
    Calculate multiple error metrics to measure model performance and returns formatted
    string: smape, bmape, r2, bias.

    Args:
        y_true: actual target values
        y_pred: predicted target values
        label: title for produced string report
        weight: relative weight during aggregation

    Returns:
        error_string: printable report of key metrics with label
        metrics_df: dataframe of error metrics, with each metric as a column
    """
    if label is None:
        label = ""

    channel = (
        "SDD"
        if "SDD" in label
        else "SDP"
        if "SDP" in label
        else "SHIPPED"
        if "SHIPPED" in label
        else ""
    )

    weighted = "unweighted" if weight is None else "weighted"

    smape = symmetric_mean_absolute_error(
        y_true=y_true, y_pred=y_pred, sample_weight=weight
    )
    bmape = balanced_mean_absolute_percentage_error(
        y_true=y_true, y_pred=y_pred, sample_weight=weight
    )
    r2 = r2_score(y_true=y_true, y_pred=y_pred, sample_weight=weight)
    wmape = bias_score(y_true=y_true, y_pred=y_pred, sample_weight=weight, total=False)
    bias = bias_score(y_true=y_true, y_pred=y_pred, sample_weight=weight, total=True)
    error_string = f"""
    {label}
        SMAPE         {smape:.2%}
        BMAPE         {bmape:.2%}
        WMAPE         {wmape:.2%}
        Bias          {bias:.2%}
        R2            {r2:.2%}
    """

    data = {
        "label": [label],
        "channel": [channel],
        "weight": [weighted],
        "SMAPE": [f"{smape:.2%}"],
        "BMAPE": [f"{bmape:.2%}"],
        "WMAPE": [f"{wmape:.2%}"],
        "Bias": [f"{bias:.2%}"],
        "R2": [f"{r2:.2%}"],
    }

    metrics_df = pd.DataFrame(data)

    return error_string, metrics_df
