from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Union

from configs.settings import VERSION
from oxygen.conf.context import context
import logging

log = logging.getLogger(__name__)

# a regex pattern of the run id that we use
# used in validating if a particular folder is versioned using a run id
RUN_ID_PATTERN = "space_run_\d{8}\_\d{6}\_\d{6}"


def complete_file_path(
    root_path: str,
    file_name: str,
    at_datastores_root: bool = True,
    run_id_folder: bool | str = False,
    dependent_var: Union[None, str] = None,
    category_level_dept_nbr: Union[None, int] = None,
    plano_cat_desc: Union[None, str] = None,
    department: Union[None, int] = None,
    created_at_date: Union[None, str] = None,
    need_state_id: Union[None, str] = None,
    cluster_id: Union[None, str] = None,
    solver_name: Union[None, str] = None,
    plano_ft: Union[None, float, int, str] = None,
    fixture_size: Union[None, float] = None,
    store_scope: Union[None, str] = None,
    pilot_name: Union[None, float] = None,
    subcategory: Union[None, str] = None,
    dept_id_filter: Union[None, int] = None,
    metrix_granularity: Union[None, str] = None,
    prod_cat_id: Union[None, int] = None,
) -> str:
    """
    This helper function completes dynamic fields in our configured file paths
    Args:
        root_path: Rooth path to use for all file paths on top of the base root specified in config
        file_name: Filename to save from config
        dependent_var: Optional parameter, defaults to None; when specified and present in the path to be formatted,
        will be replace by a processed version of `dependent_var` so that folder structure isn't weird
        plano_cat_desc: Optional parameter, defaults to None; when specified and present in the path to be formatted,
        will be replace by a processed version of `plano_cat_desc` so that folder structure isn't weird
        department: Optional parameter, defaults to None; when specified, will populate department ID in path name
        created_at_date: parameter sometimes used for plots to know when they were generated, defaults to None
        need_state_id: parameter sometimes used for plots of specific need states, defaults to None
        cluster_id: parameter sometimes used to solve outputs at the cluster level, e.g. in optimization module
        solver_name: parameter sometimes used to solve outputs for a given solver name, e.g. in optimization module
        plano_ft: parameter used in the optimization module when optimizing at the plano_ft level
        fixture_size: parameter used in the optimization module when optimizing at fixture_size level
        store_scope: scope of stores for financial projections, can be "all_stores" or "rep_stores"
        pilot_name: parameter used for the name of the pilot being measured
        subcategory: subcategory used for fitting need state networks
        dept_id_filter: dept id filter for financial projections
        metrix_granularity: metrix granularity for financial projections

    Returns:
    A file path to feed to the `oxygen` reader so it can read/save a file
    """
    if at_datastores_root:
        root_path = f"{context.data_stores.root}{root_path}"
    else:
        if isinstance(run_id_folder, str):
            root_path = run_id_folder + root_path
        else:
            root_path = root_path

    file_path = str(Path(root_path, file_name))
    ts_ = context.meta.created_at.strftime("%Y%m%d%H%M%S")
    run_id = context.meta.run_id
    ver = VERSION
    # run_type = context.run_characteristics.run_type
    #
    # if "{run_type}" in file_path:
    #     file_path = file_path.replace("{run_type}", run_type)

    if "{code_version}" in file_path:
        file_path = file_path.replace("{code_version}", ver)

    if "{datetime}" in file_path:
        file_path = file_path.replace("{datetime}", ts_)

    if "{run_id}" in file_path:
        file_path = file_path.replace("{run_id}", run_id)

    if "{plano_cat_desc}" in file_path:
        if plano_cat_desc is None:
            file_path = file_path.replace("{plano_cat_desc}", str(""))
        else:
            plano_cat_desc_proc = plano_cat_desc.replace("/", "-").replace(" ", "_")
            file_path = file_path.replace(
                "{plano_cat_desc}",
                plano_cat_desc_proc,
            )

    if ("{dependent_var}" in file_path) and dependent_var:
        dependent_var_proc = dependent_var.split("_")[
            -1
        ]  # Will only take sales, or dnp
        file_path = file_path.replace(
            "{dependent_var}",
            dependent_var_proc,
        )

    if ("{created_at_date}" in file_path) and created_at_date:
        file_path = file_path.replace(
            "{created_at_date}",
            created_at_date,
        )

    if ("{need_state_id}" in file_path) and need_state_id:
        need_state_id_proc = need_state_id.replace("/", "-").replace(" ", "_")
        file_path = file_path.replace(
            "{need_state_id}",
            need_state_id_proc,
        )

    if ("{cluster_id}" in file_path) and cluster_id:
        file_path = file_path.replace(
            "{cluster_id}",
            cluster_id,
        )

    if ("{solver_name}" in file_path) and solver_name:
        file_path = file_path.replace(
            "{solver_name}",
            solver_name,
        )

    if ("{plano_ft}" in file_path) and plano_ft:
        if isinstance(plano_ft, int) or isinstance(plano_ft, float):
            file_path = file_path.replace(
                "{plano_ft}",
                str(int(plano_ft)),
            )
        elif isinstance(plano_ft, str):
            file_path = file_path.replace(
                "{plano_ft}",
                plano_ft,
            )

    if ("{fixture_size}" in file_path) and fixture_size:
        file_path = file_path.replace(
            "{fixture_size}",
            str(round(fixture_size, 2)),
        )

    if "{category_level_dept_nbr}" in file_path:
        if category_level_dept_nbr in [None, "None"]:
            file_path = file_path.replace("{category_level_dept_nbr}", str(""))
        else:
            file_path = file_path.replace("{category_level_dept_nbr}", f"_{str(category_level_dept_nbr)}")

    if "{department}" in file_path:
        if department in [None, "None"]:
            file_path = file_path.replace("{department}", str(""))
        else:
            file_path = file_path.replace("{department}", str(department))

    if ("{store_scope}" in file_path) and store_scope:
        file_path = file_path.replace("{store_scope}", store_scope)

    if ("{pilot_name}" in file_path) and pilot_name:
        file_path = file_path.replace("{pilot_name}", str(pilot_name))

    if ("{subcategory}" in file_path) and subcategory:
        file_path = file_path.replace("{subcategory}", subcategory)

    if ("{dept_id_filter}" in file_path) and dept_id_filter:
        file_path = file_path.replace("{dept_id_filter}", str(dept_id_filter))

    if ("{metrix_granularity}" in file_path) and metrix_granularity:
        file_path = file_path.replace("{metrix_granularity}", metrix_granularity)

    if ("{prod_cat_id}" in file_path) and prod_cat_id:
        file_path = file_path.replace("{prod_cat_id}", str(prod_cat_id))

    return file_path