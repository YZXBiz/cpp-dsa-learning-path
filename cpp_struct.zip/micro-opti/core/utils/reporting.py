import os
import git
import logging
from io import BytesIO

from oxygen.conf.context import context as context_default
from oxygen.conf.settings import settings
from oxygen.files.storages import storage


def get_git_hash() -> str:
    """
    Get current git hash and warn after git hash
    if uncommitted changes are applied.

    Returns:
        If clean repo: <git hash>
        If dirty repo: <git hash> (dirty)
        If not a repo: na
    """
    try:
        repo = git.Repo(search_parent_directories=True)

        git_hash = repo.head.object.hexsha
        if repo.is_dirty():
            git_hash += "(Warning: uncommitted changes applied)"

    except git.InvalidGitRepositoryError:
        git_hash = "Not a git repository - remote deployment expected"

    return git_hash


class WriteRemoteRunLog(logging.Filter):
    """
    Write all log output to run folder.

    Since run folders can live remotely (e.g. on Google Cloud Storage),
    it means that we want to extend the built in logging functionality
    to write logs to remote file systems.

    Here we use a Log `Filter` to hook into the logging mechanism
    and write each message to a remote log. This is a bit "hacky"
    and not really the intentional way to use filters, we don't
    actually filter anything. Every message is allowed.

    """

    def filter(self, record):
        """
        write new record to existing logger stream - filtering not applied

        Args:
            record: new record to be written to existing stream

        Returns:
            True - allows allow as we do not filter any messages
        """

        # Get first logger defined in logger config
        loggers = list(settings.LOGGING["loggers"].keys())

        # ff logging not setup correctly, then skip.
        if not loggers:
            return True

        # get  handler that allow us to access a formatter
        handlers = logging.getLoggerClass().manager.loggerDict[loggers[0]].handlers

        # if handlers not setup correctly, then skip.
        if not handlers:
            return True

        # recreate the full log on each write
        # as blobs (on GCP) are immutable / log not appendable)
        log_path = os.path.join(context_default.meta.run_folder, "run.log")
        stream = storage.open(log_path) if storage.exists(log_path) else BytesIO()

        # Normalize stream to BytesIO no matter what Storage we are using.
        if not isinstance(stream, BytesIO):
            stream = BytesIO(stream.read())

        # Write new record to existing stream
        msg = handlers[0].format(record)

        # Set file pointer to end to ensure we APPEND.
        stream.seek(0, 2)
        stream.write(bytes(f"{msg}\n\r".encode("utf-8")))
        storage.touch(log_path, stream)

        return True
