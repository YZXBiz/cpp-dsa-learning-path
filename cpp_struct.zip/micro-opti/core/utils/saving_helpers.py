import io
import os
import pickle
from typing import Any, Dict

import pandas as pd
import logging
from google.cloud import storage
from matplotlib.figure import Figure

log = logging.getLogger(__name__)

def save_image_to_gcs(
    fig_to_be_saved: Figure,
    path_in_gcs: str,
    gcs_connection_path: str,
) -> None:
    """
    This function takes in a matplotlib figure and saves it to a GCS path specified as parameter, and saves an temporary
    version of the figure locally (e.g. laptop or Docker container) which is deleted at the end of the function
    Args:
        fig_to_be_saved: Matplotlib figure to be saved to GCS
        path_in_gcs: Path in Google Cloud Storage where we want to save the image, supposedly based on a root path
        that is the `run_folder` specified in config
        gcs_connection_path: Path to GCS for connection to storage client

    Returns:
    Nothing
    """
    fig_to_be_saved.savefig(
        f"./temp_image_{path_in_gcs.replace('/', '_')}.png", format="png"
    )
    storage_client = storage.Client.from_service_account_json(gcs_connection_path)

    bucket = storage_client.get_bucket("crs-tenant147")
    blob = bucket.blob(path_in_gcs)
    log.info(f"Saving image {path_in_gcs} into GCS...")
    blob.upload_from_filename(
        f"./temp_image_{path_in_gcs.replace('/', '_')}.png", content_type="image/png"
    )
    os.remove(f"./temp_image_{path_in_gcs.replace('/', '_')}.png")


def save_pickle_to_gcs(
    pickle_object: Any,
    path_in_gcs: str,
    gcs_connection_path: str,
) -> None:
    """
    This function takes in an object and saves it as pickle to a GCS path specified as parameter, and saves a temporary
    version of the figure locally (e.g. laptop or Docker container) which is deleted at the end of the function
    Args:
        pickle_object: Object to be saved as a pickle
        path_in_gcs: Path in Google Cloud Storage where we want to save the image, supposedly based on a root path
        that is the `run_folder` specified in config
        gcs_connection_path: Path to GCS for connection to storage client

    Returns:
    Nothing, but saves the pickle file into GCS
    """
    with open(f"./temp_object_{path_in_gcs.replace('/', '_')}.pickle", "wb") as handle:
        pickle.dump(pickle_object, handle, protocol=pickle.HIGHEST_PROTOCOL)

    storage_client = storage.Client.from_service_account_json(gcs_connection_path)
    bucket = storage_client.get_bucket("crs-tenant147")
    blob = bucket.blob(path_in_gcs)
    log.info(f"Saving pickle {path_in_gcs} into GCS...")
    blob.upload_from_filename(
        f"./temp_object_{path_in_gcs.replace('/', '_')}.pickle", content_type="pickle"
    )
    os.remove(f"./temp_object_{path_in_gcs.replace('/', '_')}.pickle")


def save_other_objects_from_temp_to_gcs(
    path_in_gcs: str,
    local_temp_path: str,
    gcs_connection_path: str,
) -> None:
    """
    This function takes in a temp local location ofa file and saves it as is to a GCS path specified as parameter, and
    saves a temporary version of the figure locally (e.g. laptop or Docker container) which is deleted at the end of
    the function. This will e.g. be used when saving an MPS (Mathematical Programming System) format from the CBC solver
    Args:
        path_in_gcs: Path in Google Cloud Storage where we want to save the image, supposedly based on a root path
        that is the `run_folder` specified in config
        local_temp_path: Local path to which the original object has been saved
        gcs_connection_path: Path to GCS for connection to storage client

    Returns:
    Nothing, but saves the file into GCS
    """
    storage_client = storage.Client.from_service_account_json(gcs_connection_path)
    bucket = storage_client.get_bucket("crs-tenant147")
    blob = bucket.blob(path_in_gcs)
    log.info(f"Saving object from local {local_temp_path} to {path_in_gcs} in GCS...")
    blob.upload_from_filename(local_temp_path)
    os.remove(local_temp_path)


def load_pickle_from_gcs(
    path_in_gcs: str,
    gcs_connection_path: str,
) -> Any:
    """
    This function can load a pickle file from GCS
    Args:
        path_in_gcs: Path in Google Cloud Storage where we want to save the image, supposedly based on a root path
        that is the `run_folder` specified in config
        gcs_connection_path: Path to GCS for connection to storage client

    Returns:
    Nothing, but saves the pickle file into GCS
    """
    storage_client = storage.Client.from_service_account_json(gcs_connection_path)
    bucket = storage_client.get_bucket("crs-tenant147")
    blob = bucket.blob(path_in_gcs)
    log.info(f"Loading pickle {path_in_gcs} from GCS...")
    pickle_object = pickle.loads(blob.download_as_string())
    return pickle_object


def save_multi_tab_excel_to_gcs(
    save_dict: Dict[str, pd.DataFrame],
    path_in_gcs: str,
    gcs_connection_path: str,
) -> None:
    """
    This function saves a multi-tab Excel to GCS (currently leveraged to save space elasticity sense checks)

    Args:
        save_dict: Dictionary containing filenames mapped to the dataframes we want to save as separate tabs (e.g.
        {"tab1_name": tab1_df, "tab2_name": tab2_df, ...})
        path_in_gcs: Path in Google Cloud Storage where we want to save the excel, based on a root path
        that is the `run_folder` specified in config
        gcs_connection_path: Path to GCS for connection to storage client

    Returns:
    Nothing
    """
    storage_client = storage.Client.from_service_account_json(gcs_connection_path)
    bucket = storage_client.bucket("crs-tenant147")
    blob = bucket.blob(path_in_gcs)
    with io.BytesIO() as output:
        writer = pd.ExcelWriter(output, engine="xlsxwriter")
        for filename, dataframe in save_dict.items():
            dataframe.to_excel(writer, sheet_name=filename, index=False)

        writer.save()
        output.seek(0)
        blob.upload_from_file(
            output,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
