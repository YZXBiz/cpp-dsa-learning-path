import datetime
import pandas as pd
import numpy as np

from prophet.make_holidays import make_holidays_df


def create_us_holidays(year_list: list) -> pd.DataFrame:
    """
    Create a dataframe which returns list of US holidays
    adapted for client context (e.g. Easter etc)

    Args:
        year_list: list of years

    Returns:
        df_holiday: df with US holidays adapted for US client context
    """
    # get holidays
    df_holiday = make_holidays_df(year_list=year_list, country="US")

    # add holidays not in the us holiday list but relevant for client
    easters = make_holidays_df(year_list=year_list, country="UK").query(
        "holiday=='Good Friday'"
    )
    valentines = pd.DataFrame(
        {
            "ds": pd.date_range(
                datetime.date(year_list[0], 2, 14),
                periods=len(year_list),
                freq=pd.DateOffset(years=1),
            ),
            "holiday": "valentines",
        }
    )

    halloweens = pd.DataFrame(
        {
            "ds": pd.date_range(
                datetime.date(year_list[0], 10, 31),
                periods=len(year_list),
                freq=pd.DateOffset(years=1),
            ),
            "holiday": "halloween",
        }
    )

    df_holiday = pd.concat(
        [df_holiday, easters, valentines, halloweens], axis=0
    ).reset_index(drop=True)

    # clip holiday dates to sundays given weekly model
    df_holiday["ds"] = pd.to_datetime(df_holiday["ds"])
    df_holiday["ds"] = df_holiday["ds"].apply(
        lambda x: x - datetime.timedelta((x.weekday() + 1) % 7)
    )

    return df_holiday


def get_holiday_dates(years_list: list, exclude=["Washington's Birthday"]):
    """
    creates dataframe with the date-holiday mappings for all major US holidays
    exclude washington's birthday as it is not a major sales driver and
    the date occasionally coincides with valentine's
    """

    df_holidays = create_us_holidays(years_list)

    df_holidays = df_holidays[~df_holidays["holiday"].isin(exclude)]

    df_holidays["holiday"] = np.where(
        df_holidays["holiday"] == "valentines",
        "Valentine's Day",
        df_holidays["holiday"],
    )

    df_holidays["holiday"] = (
        df_holidays["holiday"].str.replace("(Observed)", "", regex=False).str.strip()
    )

    df_holidays = df_holidays.drop_duplicates()

    df_holidays = df_holidays.rename(columns={"ds": "date"})

    return df_holidays
