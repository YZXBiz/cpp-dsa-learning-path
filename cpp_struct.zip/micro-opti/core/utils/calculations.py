from typing import Union
from numbers import Number
# import Levenshtein
import logging
import pandas as pd

logger = logging.getLogger(__name__)


def calculate_discount_pct(
    base_price: Union[pd.Series, float],
    receipt_price: Union[pd.Series, float],
) -> Union[pd.Series, float]:
    """
    Calculate discount percentage given observed receipt price and list price, e.g.
        1 - (1.6$/2$) = 20 % discount
    """

    # Check receipt price is lower than base price
    if isinstance(base_price, Number) & isinstance(receipt_price, Number):
        if receipt_price > base_price:
            logger.warning(
                "Error when calculating discount; receipt_price > base_price"
            )
    else:
        if (receipt_price > base_price).any():
            logger.warning(
                "Error when calculating discount; receipt_price > base_price"
            )

    return 1 - (receipt_price / base_price)


def calculate_price_change_pct(
    base_price: Union[pd.Series, list, float],
    new_price: Union[pd.Series, list, float],
) -> Union[pd.Series, float]:
    """
    Calculate price change pct of new price vs base price, e.g.
        1.6$/2$ - 1 = -20 %
    """

    return (new_price / base_price) - 1


def calculate_sundays(start_date: str, end_date: str) -> list:
    """
    Calculate Sundays between start_date and end_date, including both ends.
    Return:
        date_range: List of Sundays in string of "%Y-%m-%d" format
    """
    date_range = (
        pd.date_range(start_date, end_date)
        .isocalendar()
        .astype({"day": int})
        .query("day == 7")
        .index.strftime("%Y-%m-%d")
    ).tolist()

    return date_range


# def calculate_string_similarity(s1: str, s2: str) -> float:
#     """
#     Calculates the similarity between two strings using the Levenshtein
#     distance algorithm.

#     Args:
#         s1 (str): The first string to compare
#         s2 (str): The second string to compare

#     Returns:
#         fvalue between 0 and 1 representing the similarity between the two strings.
#         - 1: strings are identical
#         - 0: strings are completely different
#     """

#     return 1 - Levenshtein.distance(s1, s2) / max(len(s1), len(s2))
