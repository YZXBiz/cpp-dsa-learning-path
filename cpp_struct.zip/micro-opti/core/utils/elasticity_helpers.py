import logging
import pandas as pd
import numpy as np
from core.schemas.store_clustering import (
    FilteredFinalClusterLabelsSchema,
    FilteredFinalClusterLabelsWithCategoryLevelSchema,
    FilteredFinalOriginalClusterLabelsSchema,
    FilteredFinalOriginalClusterLabelsWithCategoryLevelSchema,
    FilteredFinalOriginalDemandClusterLabelsSchema,
    FilteredFinalOriginalDemandClusterLabelsWithCategoryLevelSchema,
    FilteredFinalOriginalSegmentClusterLabelsWithCategoryLevelSchema,
)
from core.utils.space_context.run_versioning import complete_file_path
from oxygen.conf.context import context

log = logging.getLogger(__name__)


def root_with_run_id(run_id_folder, root_per_config) -> bool:
    """
    This function take a run_id config and a root config.
    If the run_id exists (i.e. of str type, not False). The function
    will return True, other otherwise, the function will return the root config.

    Args:
        run_id_folder: the run_id_folder set in config
        root_per_config: the root (True/False) set in config

    Returns:
        Boolean value for root parameter

    """
    if isinstance(run_id_folder, str):
        return True
    else:
        return root_per_config


def merge_dataframes(df1, df2, *args, **kwargs):
    """
    Wrapper function for pandas.merge to check duplicates before merge two dataframes.

    Args:
        df1 (pd.DataFrame): The first dataframe.
        df2 (pd.DataFrame): The second dataframe.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments passed to pd.merge.

    Returns:
        pd.DataFrame: The merged dataframe.
    """

    # Determine the key columns
    on = kwargs.get("on", None)
    left_on = kwargs.get("left_on", None)
    right_on = kwargs.get("right_on", None)
    how = kwargs.get("how", None)

    if on is not None:
        if not isinstance(on, list):
            on = [on]  # Ensure 'on' is a list for consistent handling
        keys_df1 = df1[on]
        keys_df2 = df2[on]

    elif left_on is not None and right_on is not None:
        if not isinstance(left_on, list):
            left_on = [left_on]
        if not isinstance(right_on, list):
            right_on = [right_on]
        keys_df1 = df1[left_on]
        keys_df2 = df2[right_on]

    else:
        log.error(
            "Key columns must be specified using 'on', 'left_on', and 'right_on'."
        )

    # Check for uniqueness
    if (keys_df1.duplicated(subset=on if on else left_on).any()) & (how != "left"):
        log.error("df1 is not unique in terms of the key columns.")
    elif (keys_df2.duplicated(subset=on if on else right_on).any()) & (how != "right"):
        log.error("df2 is not unique in terms of the key columns.")
    else:
        return pd.merge(df1, df2, *args, **kwargs)


def sql_helper_cols(input_ls) -> str:
    """
    Convert a list into string of cols to be selected in a SQL query

    Args:
        input_ls: List of cols

    Returns:
        str: concatenated string for use in sql
    """

    concatenated = ", ".join(map(str, input_ls))
    result = f"{concatenated}"

    return result


def sql_helper_acols(input_ls) -> str:
    """
    Convert a list into string of a.cols to be selected in a SQL query

    Args:
        input_ls: List of cols

    Returns:
        str: concatenated string for use in sql
    """

    concatenated = ", a.".join(map(str, input_ls))
    result = f"a.{concatenated}"

    return result


def sql_helper_abcols(input_ls) -> str:
    """
    Convert a list into string of a.cols = b.cols to be selected in a SQL query

    Args:
        input_ls: List of cols

    Returns:
        str: concatenated string for use in sql
    """
    formatted_list = [f"a.{x} = b.{x}" for x in input_ls]
    concatenated = " AND ".join(map(str, formatted_list))
    result = f"{concatenated}"

    return result


def load_cluster_data_based_on_agg_granularity(
    use_cluster_labels: str = "final_cluster_labels",
    include_segment_clusters: bool = False,
):
    """
    Load cluster data input based on the specified aggregation granularity.

    Args:
        use_original_cluster_labels (str): 'final_cluster_labels', 'original_cluster_labels' or 'demand_cluster_labels'.
        include_segment_clusters (bool): Whether to include segment clusters in the cluster data.

    Returns:
        pd.DataFrame: A DataFrame containing the cluster data based on the specified granularity and label selection.

    Notes:
        - The function determines the schema to use for loading the cluster data based on the presence of
          'category_level_dept_nbr' in the groupby granularity and the value of 'use_original_cluster_labels'.
        - The final_clusters_path is constructed using various context parameters, and the appropriate schema
          is applied to load the data from this path.
    """
    final_clusters_path = complete_file_path(
        context.data_stores.store_clustering.root_path,
        context.data_stores.store_clustering.final.clustering_final_labels_df,
        at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        run_id_folder=context.run_id.clustering_run_id,
    )

    if "category_level_dept_nbr" not in context.groupby_granularity.clustering:
        if use_cluster_labels == "final_cluster_labels":
            cluster_schema = FilteredFinalClusterLabelsSchema
        elif use_cluster_labels == "original_cluster_labels":
            cluster_schema = FilteredFinalOriginalClusterLabelsSchema
        elif use_cluster_labels == "demand_cluster_labels":
            cluster_schema = FilteredFinalOriginalDemandClusterLabelsSchema
    else:
        if use_cluster_labels == "final_cluster_labels":
            cluster_schema = FilteredFinalClusterLabelsWithCategoryLevelSchema
        elif use_cluster_labels == "original_cluster_labels":
            if include_segment_clusters:
                cluster_schema = (
                    FilteredFinalOriginalSegmentClusterLabelsWithCategoryLevelSchema
                )
            else:
                cluster_schema = FilteredFinalOriginalClusterLabelsWithCategoryLevelSchema
        elif use_cluster_labels == "demand_cluster_labels":
            cluster_schema = FilteredFinalOriginalDemandClusterLabelsWithCategoryLevelSchema

    df_final_clusters = cluster_schema.load(
        file_path=final_clusters_path,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
    )

    log.info(f"Loaded df_final_clusters with rows: {df_final_clusters.shape[0]}")

    return df_final_clusters


def keep_extra_original_clusters_based_on_config(cluster_labels_based_on: str):
    """
    Load and return cluster data using "original_cluster_labels" and update cluster labels based on configuration.

    This function loads cluster data with "original_cluster_labels" as the base and updates the `final_cluster_labels`
    column based on the value of `cluster_labels_based_on`. The function verifies that `cluster_labels_based_on`
    is a valid value before proceeding. If valid, the cluster labels are updated, and a new column
    `cluster_labels_based_on` is added to indicate the source of the cluster labels.

    Args:
        cluster_labels_based_on (str): Specifies which cluster labels to use.
            Must be one of "original_cluster_labels" or "final_cluster_labels".

    Returns:
        pd.DataFrame: A DataFrame with updated `final_cluster_labels` and an additional
        `cluster_labels_based_on` column indicating the label source.
    """
    if cluster_labels_based_on not in [
        "original_cluster_labels",
        "final_cluster_labels",
    ]:
        log.error(
            f"Invalid value for 'cluster_labels_based_on': {cluster_labels_based_on}. "
            f"Expected 'original_cluster_labels' or 'final_cluster_labels'."
        )

    df_final_clusters = load_cluster_data_based_on_agg_granularity(
        use_cluster_labels=context.cluster_labels_based_on.optimization_item_scope
    )

    log.info(
        f"Keeping extra original cluster labels based on {cluster_labels_based_on}..."
    )

    df_final_clusters["final_cluster_labels"] = df_final_clusters[
        cluster_labels_based_on
    ]
    df_final_clusters["cluster_labels_based_on"] = cluster_labels_based_on

    return df_final_clusters

