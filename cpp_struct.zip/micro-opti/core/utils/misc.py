import os
import git
import logging

import pandas as pd
from box import Box
from typing import TypeVar
import inspect
from oxygen.files.schemas import (
    FloatColumn,
    IntegerColumn,
    StringColumn,
    Schema,
)

# initialise logger
logger = logging.getLogger(__name__)

# set pandas object global variable
PD_OBJ = TypeVar("pd_ob", pd.DataFrame, pd.Series)


def merge_schema_fields(*schemas) -> Box:
    """Merge schema fields to get a fields variable."""

    fields = {}

    for schema in schemas:
        fields = {**fields, **schema.fields}

    return Box(fields)


def is_even_number(num: int):
    """
    Return True if integer is even number

    Args:
        num: an integer

    Returns:
        True if int is even
    """

    if num & 1:
        return False
    else:
        return True


def match_schema_before_saving(df: pd.DataFrame, schema: Schema) -> pd.DataFrame:
    """
    Match schema and update the df with given schema
    Args:
        df: input dataframe to udpate schema
        schema: the schema to save the df

    Returns:
        updated dataframe with correct schema
    """

    def list_integer_columns(class_instance):
        integer_columns = []
        for name, attribute in inspect.getmembers(class_instance):
            if isinstance(attribute, IntegerColumn):
                integer_columns.append(name)
        return integer_columns

    def list_float_columns(class_instance):
        float_columns = []
        for name, attribute in inspect.getmembers(class_instance):
            if isinstance(attribute, FloatColumn):
                float_columns.append(name)
        return float_columns

    def list_string_columns(class_instance):
        string_columns = []
        for name, attribute in inspect.getmembers(class_instance):
            if isinstance(attribute, StringColumn):
                string_columns.append(name)
        return string_columns

    # remove irrelevant cols
    all_output_columns = dir(schema)
    col_to_drop = [col for col in df.columns if col not in all_output_columns]
    df = df.drop(columns=col_to_drop)

    # cast integer & float cols
    integer_columns = list_integer_columns(schema)
    for col in integer_columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df[col] = df[col].replace("", None).fillna(-1).astype("Int64")

    float_columns = list_float_columns(schema)
    for col in float_columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df[col] = df[col].replace("", None).astype(float)

    string_columns = list_string_columns(schema)
    for col in string_columns:
        df[col] = df[col].astype(str)

    return df


def impute_predicted_outliers(df: pd.DataFrame, var_name: str) -> float:
    """
    Identifies upper limit for time series predictions. It returns a float above
    which predictions should be limited and consider outliers.

    Args:
        df: dataframe containint historical data (item, date and units_sold)
        var_name: name of the variable to calculate outliers

    Returns:
        upper_limit: float number above which all predictions
            are considered outliers

    """

    # Obtain Q1, Q3
    q5 = df[var_name].quantile(0.05)
    q95 = df[var_name].quantile(0.95)

    # Calculate interquartile range (IQR)
    iqr = q95 - q5

    # Calculate maximum upper value
    upper_limit = q95 + 1.5 * iqr

    return upper_limit


def get_outlier_threshold_by_channel(
    df: pd.DataFrame,
    var_name: str,
    iqr_multipliers: dict,
) -> float:
    """
    Identifies upper limit for target variable, segmented
    by channel. It returns a float above
    which predictions should be limited and consider outliers.

    Args:
        df: dataframe containing historical data (item, date and units_sold)
        var_name: name of the variable to calculate outliers
        iqr_multipliers: the values by which to multiply iqr to get upper bound
        of outliers, defined for each channel

    Returns:
        upper_limit: float number above which all predictions
            are considered outliers

    """

    def get_upper_limit(group):
        # Obtain Q1, Q3
        q5 = group[var_name].quantile(0.05)
        q95 = group[var_name].quantile(0.95)

        # Calculate interquartile range (IQR)
        iqr = q95 - q5

        channel = group.name
        multiplier = iqr_multipliers[channel]

        # Calculate maximum upper value
        upper_limit = q95 + multiplier * iqr

        return pd.Series({"upper_limit": upper_limit})

    thresholds = df.groupby("channel").apply(get_upper_limit).reset_index()

    return thresholds


def log_dataframe(dataframe):
    logger.info("\n\t" + dataframe.to_string().replace("\n", "\n\t"))


class GitInfo:
    def __init__(self, fallback="Not a repo"):
        try:
            repo = git.Repo(search_parent_directories=True)
        except git.InvalidGitRepositoryError:
            repo = None

        self.fallback = fallback
        self.repo = repo
        self.hash = self.get_hash()
        self.commit = self.get_commit()

    def get_hash(self):
        if self.repo is not None:
            git_hash = self.repo.head.object.hexsha

        elif os.environ.get("GIT_COMMIT") is not None:
            git_hash = os.environ.get("GIT_COMMIT")

        else:
            git_hash = self.fallback

        return git_hash

    def get_commit(self):
        if self.repo is not None:
            ref = self.repo.head.reference
            msg = ref.commit.message

        elif os.environ.get("GIT_BRANCH") is not None:
            msg = os.environ.get("GIT_BRANCH")

        else:
            msg = self.fallback

        return msg


def is_running_in_kubeflow():
    return any(var in os.environ for var in ["KUBEFLOW_RUN", "KFP_POD_NAME", "KUBERNETES_SERVICE_HOST"])


def root_with_run_id(run_id_folder, root_per_config) -> bool:
    """
    This function take a run_id config and a root config.
    If the run_id exists (i.e. of str type, not False). The function
    will return True, other otherwise, the function will return the root config.

    Args:
        run_id_folder: the run_id_folder set in config
        root_per_config: the root (True/False) set in config

    Returns:
        Boolean value for root parameter

    """
    if isinstance(run_id_folder, str):
        return True
    else:
        return root_per_config