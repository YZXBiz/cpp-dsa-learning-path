from typing import Dict, List, Tuple, Optional

from core.schemas.schemas import (
    PogCategoryMappingSchema,
)
from core.utils.space_context.run_versioning import complete_file_path
from oxygen.conf.context import context
import pandas as pd
from core.utils.elasticity_helpers import (
    root_with_run_id,
)
import logging

log = logging.getLogger(__name__)


def get_item_forced_facings_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the item forced facings data.
    """
    path_merged_forced_facings = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.forced_facings.merged_output_path,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )
    root_merged_forced_facings = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )
    return path_merged_forced_facings, root_merged_forced_facings


def get_exploded_item_POD_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the item POD raw data.
    """
    path_exploded_item_POD = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.manual_item_POD_constraints,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root_exploded_item_POD = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path_exploded_item_POD, root_exploded_item_POD


def get_exempt_item_POD_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the exempt item POD raw data.
    """
    path_exempt_item_POD = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.POD_exempt_items,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root_exempt_item_POD = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path_exempt_item_POD, root_exempt_item_POD


def get_exploded_brand_POD_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the brand POD raw data.
    """
    path_exploded_brand_POD = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.manual_brand_POD_constraints,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root_exploded_brand_POD = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path_exploded_brand_POD, root_exploded_brand_POD


def get_item_master_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the item master data.
    """
    path_item_master = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.item_master_file,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root_item_master = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path_item_master, root_item_master


def get_item_in_scope_per_cluster_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the item in scope per cluster data.
    """
    path_item_in_scope_per_cluster = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.item_scope_per_cluster,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root_item_in_scope_per_cluster = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path_item_in_scope_per_cluster, root_item_in_scope_per_cluster


def get_store_space_characteristics_path_and_root() -> Tuple[str, bool]:
    """
    Get the path to the store_space_characteristics data.
    """
    path = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.store_characteristics_master,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )

    root = root_with_run_id(
        context.run_id.client_input_process_run_id,
        context.data_stores.client_input_process.save_to_datastores_root,
    )

    return path, root


def get_filtered_category_level_plano_cat_and_depts_in_scope() -> (
        Dict[int, Dict[str, List[int]]]
):
    """
    Generate a dictionary where each category_level maps to a dictionary of filtered POG categories in scope,
    mapped to their in-scope departments using the `category_levels_pogs_and_departments` config.

    The structure of the returned dictionary is as follows:
    {
        category_level_id: {
            plano_cat_desc: [department_id_1, department_id_2, ...],
            ...
        },
        ...
    }

    Returns:
        dict_category_level_plano_cat_desc_and_depts_in_scope (dict): A dictionary where each key is an category_level ID,
        and the value is a dictionary mapping POG category descriptions to lists of in-scope department IDs.
    """
    if ( 
            context.data_stores.raw_data 
            and "categories" in context.data_stores.raw_data 
    ): 
        # get the plano_cat_desc and plano_cat_id mapping from df_pog_categories_in_scope_mapping file 
        path_pog_categories_in_scope_mapping = complete_file_path( 
            context.data_stores.etl.root_path, 
            context.data_stores.etl.etl_pog_category_mapping.file_name, 
        ) 
        df_pog_categories_in_scope_mapping = PogCategoryMappingSchema.load( 
            file_path=path_pog_categories_in_scope_mapping, 
            root=True, 
        ) 
     
        # Filter the data to only include POGs in context.data_stores.raw_data.categories 
        df_pog_categories_in_scope_mapping = ( 
            df_pog_categories_in_scope_mapping[ 
                df_pog_categories_in_scope_mapping["plano_cat_desc"].isin(context.data_stores.raw_data.categories) 
            ] 
        ) 
     
        dict_plano_id_cat_desc = dict( 
            zip( 
                df_pog_categories_in_scope_mapping["plano_cat_id"], 
                df_pog_categories_in_scope_mapping["plano_cat_desc"], 
            ) 
        ) 
     
        # Convert dept_id column to be a single value list column 
        df_pog_categories_in_scope_mapping["dept_id"] = ( 
            df_pog_categories_in_scope_mapping["dept_id"].values[:, None].tolist() 
        ) 
     
        # Crate dict of category id to dept id 
        category_levels_pogs_and_depts = { 
            1: df_pog_categories_in_scope_mapping[["plano_cat_id", "dept_id"]].set_index("plano_cat_id").to_dict()[ 
                "dept_id"] 
        } 
     
        dict_category_level_plano_cat_desc_and_depts_in_scope = {} 
     
        for category_level, pog_depts in category_levels_pogs_and_depts.items(): 
            # Get unique POGs for the current category_level 
            dict_category_level_plano_cat_desc_and_depts_in_scope[category_level] = {} 
            for plano_id in category_levels_pogs_and_depts[category_level]: 
                # Map POG IDs to descriptions 
                plano_cat_desc = dict_plano_id_cat_desc.get(plano_id, None) 
                if plano_cat_desc is not None: 
                    dict_category_level_plano_cat_desc_and_depts_in_scope[category_level][ 
                        plano_cat_desc 
                    ] = {} 
                    depts_in_scope = category_levels_pogs_and_depts[category_level][plano_id] 
                    dict_category_level_plano_cat_desc_and_depts_in_scope[category_level][ 
                        plano_cat_desc 
                    ] = sorted(depts_in_scope) 
     
        return dict_category_level_plano_cat_desc_and_depts_in_scope 


# TODO: add get_category_level_plano_cat_and_depts_in_scope, need another delta table.


def create_optimization_scope_tuple(
        dict_category_level_plano_cat_desc_and_depts: Dict[int, Dict[str, List[int]]],
        optimizer_granularity: List[str],
) -> List[Tuple[int, str, int]]:
    """
    Convert a nested dictionary structure into a list of tuples.

    This function takes a dictionary where the keys are `category_level_id`s,
    and the values are dictionaries where the keys are `plano_cat_desc`s
    and the values are lists of `department_id`s. It returns a list of tuples,
    where each tuple contains an `category_level_id`, a `plano_cat_desc`, and a `department_id`.

    Parameters:
    -----------
    dict_category_level_plano_cat_desc_and_depts : dict
        A dictionary of the form:
        {
            category_level_id_1: {
                plano_cat_desc_1: [department_id_1, department_id_2, ...],
                ...
            },
            ...
        }
    optimizer_granularity: List[str] containing optimizer granularity to help us decide
    whether to use category_level or not in the list of tuples (overridden with -1 if not)

    Returns:
    --------
    list of tuple
        A list of tuples where each tuple contains three elements:
        (category_level_id, plano_cat_desc, department_id).

    Example:
    --------
    >>> input_data = {
    ...     "category_level_id_1": {
    ...         "plano_cat_desc_1": ["department_id_1", "department_id_2"],
    ...         "plano_cat_desc_2": ["department_id_3"]
    ...     },
    ...     "category_level_id_2": {
    ...         "plano_cat_desc_3": ["department_id_4"]
    ...     }
    ... }
    >>> create_optimization_scope_tuple(input_data)
    [
        ('category_level_id_1', 'plano_cat_desc_1', 'department_id_1'),
        ('category_level_id_1', 'plano_cat_desc_1', 'department_id_2'),
        ('category_level_id_1', 'plano_cat_desc_2', 'department_id_3'),
        ('category_level_id_2', 'plano_cat_desc_3', 'department_id_4')
    ]
    """
    list_tuples = []
    seen_tuples = set()  # Set to track unique tuples

    for category_level_id, plano_cat_dict in dict_category_level_plano_cat_desc_and_depts.items():
        for plano_cat_desc, department_ids in plano_cat_dict.items():
            for department_id in department_ids:
                if "category_level_dept_nbr" in optimizer_granularity:
                    tuple_to_add = (category_level_id, plano_cat_desc, department_id)
                else:
                    tuple_to_add = (-1, plano_cat_desc, department_id)

                # Add the tuple only if it's not already in the set
                if tuple_to_add not in seen_tuples:
                    seen_tuples.add(tuple_to_add)
                    list_tuples.append(tuple_to_add)

    return list_tuples


def explode_cluster_to_final_clusters(
        df_constraint: pd.DataFrame,
        df_clusters_in_dept: pd.DataFrame,
):
    """
    Explodes the 'cluster' column in `df_constraint` by matching it with
    'final_cluster_labels' in `df_clusters_in_dept`. The function handles both exact and partial matches,
    with a special case for 'ALL'.

    If 'cluster' is found in the list ["All", "all", "ALL"], the corresponding
    'final_cluster_labels' will be set to 'ALL'. Otherwise, the function will find rows in
    `df_clusters_in_dept` where the 'final_cluster_labels' contains the value of 'cluster'.

    Args:
        df_constraint (pd.DataFrame): A DataFrame containing the 'cluster' column,
            which will be matched against 'final_cluster_labels' in `df_clusters_in_dept`.
        df_clusters_in_dept (pd.DataFrame): A DataFrame containing 'final_cluster_labels', which
            is matched against 'cluster' from `df_constraint`.

    Returns:
        pd.DataFrame: A DataFrame with 'final_cluster_labels' exploded based on matching
        clusters from `df_clusters_in_dept`. Rows with 'cluster' in ["All", "all", "ALL"]
        will have their 'final_cluster_labels' set to 'ALL'.
    """
    df_constraint = df_constraint[
        df_constraint["dept_id"].isin(df_clusters_in_dept["dept_id"].values)
    ]
    if "cluster" not in df_constraint.columns:
        return df_constraint
    else:
        # Define a function that checks for substring matches
        df_clusters_in_dept = df_clusters_in_dept.copy()

        def match_clusters(row):
            cluster = row["cluster"]
            dept_id = row["dept_id"]
            # Special case: if cluster is 'ALL', return it directly
            if cluster in ["All", "all", "ALL"] and dept_id:
                return ["ALL"]

            # Find the rows in df_clusters_in_dept where final_cluster_labels contains cluster
            matches = df_clusters_in_dept[
                (
                    df_clusters_in_dept["final_cluster_labels"].str.contains(
                        cluster, case=False, na=False
                    )
                )
                & (df_clusters_in_dept["dept_id"] == dept_id)
                ]
            # Return final_cluster_labels matches as a list
            return matches["final_cluster_labels"].tolist()

        # Apply the function to each row in df_constraint to get matching final_cluster_labels as a list
        if df_constraint.empty:
            df_exploded = df_constraint.rename(
                columns={"cluster": "final_cluster_labels"}
            )

        else:
            df_constraint["matching_clusters"] = df_constraint.apply(
                match_clusters, axis=1
            )

            # Explode the DataFrame based on the matching_clusters column
            df_exploded = df_constraint.explode("matching_clusters")

            # Rename the exploded column back to 'final_cluster_labels'
            df_exploded = df_exploded.rename(
                columns={"matching_clusters": "final_cluster_labels"}
            )

            # if cluster not found in df_clusters_in_dept, then can simply filter out the rows
            df_exploded = df_exploded[~df_exploded["final_cluster_labels"].isna()]

        return df_exploded


def explode_constraints_for_all_clusters(
        df_constraint: pd.DataFrame,
        df_clusters_in_dept: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function explodes a given constraint dataframe that is supposed to be at the cluster level; some constraints
    are more explicit when `final_cluster_labels = "All"` so we add this functionality where we process the input
    to explode into all the cluster labels available in that `(plano_cat_desc, dept_id)` for this pipeline run
    Args:
        df_constraint: Constraint dataframe we want to explode at the `final_cluster_labels` level
        df_clusters_in_dept: Mapping from (plano_cat_id, plano_cat_desc, dept_id) to all `final_cluster_labels`

    Returns:
    Constraint dataframe exploded at the `final_cluster_labels` level for the entries that had value "All"
    """
    df_constraint = explode_cluster_to_final_clusters(
        df_constraint, df_clusters_in_dept
    )

    if "final_cluster_labels" not in df_constraint.columns:
        return df_constraint
    else:
        df_constraint_all_clusters = df_constraint[
            df_constraint["final_cluster_labels"].isin(["All", "all", "ALL"])
        ].drop(columns=["final_cluster_labels"])
        df_constraint_specific_clusters = df_constraint[
            ~df_constraint["final_cluster_labels"].isin(["All", "all", "ALL"])
        ]
        if len(df_constraint_all_clusters) > 0:
            df_constraint_all_clusters_exploded = df_clusters_in_dept.merge(
                df_constraint_all_clusters,
                on=context.groupby_granularity.optimizer,
                how="inner",
            )
        else:
            df_constraint_all_clusters_exploded = pd.DataFrame(
                columns=df_constraint.columns
            )

        df_constraint_exploded = pd.concat(
            [df_constraint_specific_clusters, df_constraint_all_clusters_exploded]
        ).reset_index(drop=True)
        # drop "cluster" column and drop duplicates (in case not captured in input already)
        if "cluster" in df_constraint_exploded.columns:
            df_constraint_exploded = df_constraint_exploded.drop(
                columns=["cluster"]
            ).drop_duplicates()

        return df_constraint_exploded
