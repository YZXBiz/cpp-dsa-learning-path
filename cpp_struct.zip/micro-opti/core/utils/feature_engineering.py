import pandas as pd
from typing import List
import logging

log = logging.getLogger(__name__)


def one_hot_encode_df(
    df: pd.DataFrame,
    columns_to_encode: List[str],
    drop_first: bool = False
) -> pd.DataFrame:
    """
    One-hot encode categorical columns in pre-processed external data

    Inputs:
    - df: pandas DataFrame
    - columns_to_encode: list of strings, columns to one-hot encode
    - drop_first: bool, whether to drop the first dummy variable

    Returns:
    - df: original pandas DataFrame, with one-hot encoded columns
    """
    for col in columns_to_encode:
        log.info(f"Creating dummy variables for column {col}")
        df_dummies = pd.get_dummies(
            df[col],
            prefix=col,
            drop_first=drop_first
        )
        df = pd.concat(
            [df, df_dummies],
            axis=1
        ).reset_index(drop=True)
        df.drop(columns=col, inplace=True)
    # Rename all the new dummy columns to be snake case
    df.columns = [
        col.lower().replace(" ", "_") for col in df.columns
    ]
    # Log the column names after creating dummy variables
    log.info(f"Columns after creating dummy variables: {df.columns}")
    return df