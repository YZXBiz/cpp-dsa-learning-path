import logging

import pandas as pd
import os
from typing import Callable, List
from datetime import datetime
from multiprocessing import Pool, cpu_count
from tqdm import tqdm

from oxygen.conf.context import context

from core.utils.misc import merge_schema_fields
from core.utils.metrics import create_error_report, create_digital_error_report
from core.schemas.forecaster import (
    DateSkuAreaSchema,
    BoostOutputSchema,
)
from oxygen.files.readers import reader

F = merge_schema_fields(DateSkuAreaSchema, BoostOutputSchema)

logger = logging.getLogger(__name__)


def get_prophet_format(df: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Transforms df into prophet format to fit and predict model.
        * Renames columns to necessary strings
        * Creates a list of time series
    Args:
        df: DataFrame containing all time series and regressors at specific granularity

    Returns:
        list_df_ts: list of each time series with renamed variables
            at specific granularity

    """
    # Transform to prophet format
    df_model = df.rename(columns={F.date: "ds", F.units_sold: "y"})

    # Remove rows where target <=0
    df_model_set = df_model[df_model["y"] > 0].reset_index(drop=True)

    # Create list of time series
    list_df_ts = list(dict(tuple(df_model_set.groupby(F.sku_id))).values())

    return list_df_ts


def run_parallel_predictions(
    run_parallel: bool, func: Callable, list_series: List[pd.DataFrame]
) -> pd.DataFrame:
    """
    Run model predictions using parallel or linear processing.
    Args:
        run_parallel: whether to fit and predict time series in parallel or linear way
        func: function with model fit and predict
        list_series: list of time series

    Returns:
        df_predictions: df with predictions for each granularity

    """
    list_chunks = []
    step = context.baseline_forecaster.prophet.chunk_size
    for i in range(0, len(list_series), step):
        list_series_chunk = list_series[i : i + step]

        # If run parallel is selected
        if run_parallel:
            num_cpu = context.num_cpu if context.num_cpu else cpu_count()
            p = Pool(num_cpu)
            list_predictions = list(
                tqdm(p.imap(func, list_series_chunk), total=len(list_series_chunk))
            )
            p.close()
            p.join()

        else:
            list_predictions = list(
                map(lambda sku_id: func(sku_id), tqdm(list_series_chunk))
            )

        # Concatenate df from list in a single df
        df_predictions = pd.concat(list_predictions)

        # Append predictions for the chunks
        list_chunks.append(df_predictions)

    df_total_predictions = pd.concat(list_chunks)

    return df_total_predictions


def set_future_regressors(
    df: pd.DataFrame, list_regressors: List[str], future_value: int
) -> pd.DataFrame:
    """
    Set regressors to a specific value for predicting data.

    Args:
        df: df with historical data
        list_regressors: list of variables to add as regressors to prophet model
        future_value: constant value to impute regressors with (default 0)

    Returns:
        df_regressors: df with regressors' values imputed

    """

    # Create a copy of original df
    df_regressors = df.copy()

    # Impute future value of regressors to 0
    for regressor in list_regressors:
        df_regressors[regressor] = future_value
    return df_regressors


def get_future_df(
    last_date: datetime, date_freq: str, periods: int, date_var: str
) -> pd.DataFrame:
    """
    Generate future date range dataframe

    Args:
        last_date: maximum date of previous data sample
        date_freq: date granularity (set to 'W' in configs)
        periods: number of periods to generate based on frequency
        date_var: name of date variable

    Returns:
        df_future: future date range df

    """
    df_future = pd.DataFrame(
        data=(
            pd.date_range(
                last_date + pd.Timedelta(1, unit=date_freq),
                periods=periods,
                freq=date_freq,
            )
        ),
        columns=[date_var],
    )

    return df_future


class SuppressStdoutStderr(object):
    """
    A context manager for doing a "deep suppression" of stdout and stderr in
    Python, i.e. will suppress all print, even if the print originates in a
    compiled C/Fortran sub-function.
       This will not suppress raised exceptions, since exceptions are printed
    to stderr just before a script exits, and after the context manager has
    exited (at least, I think that is why it lets exceptions through).

    """

    def __init__(self):
        # Open a pair of null files
        self.null_fds = [os.open(os.devnull, os.O_RDWR) for x in range(2)]
        # Save the actual stdout (1) and stderr (2) file descriptors.
        self.save_fds = (os.dup(1), os.dup(2))

    def __enter__(self):
        # Assign the null pointers to stdout and stderr.
        os.dup2(self.null_fds[0], 1)
        os.dup2(self.null_fds[1], 2)

    def __exit__(self, *_):
        # Re-assign the real stdout/stderr back to (1) and (2)
        os.dup2(self.save_fds[0], 1)
        os.dup2(self.save_fds[1], 2)
        # Close the null files
        os.close(self.null_fds[0])
        os.close(self.null_fds[1])


def get_metrics_report_results(
    df: pd.DataFrame, mode: str, digital_pipeline: bool = False
):
    # Prepare data
    if mode == "train":
        # Define sample with promo and not promo
        df_set = df[
            (df[F.keep_training] == 1) & (df[F.predicted_demand].notna())
        ].reset_index(drop=True)
        # Define sample only for promo
        df_set_promo = df_set[df_set[F.is_promo] == 1].reset_index(drop=True)

    else:
        # Define sample with promo and not promo
        df_set = df[(df[F.predicted_demand].notna())].reset_index(drop=True)

        # drop cold start items in digital
        if digital_pipeline:
            df_set = df_set[df_set["cold_start"] != 1]

        # Define sample only for promo
        df_set_promo = df_set[df_set[F.is_promo] == 1].reset_index(drop=True)

    # Compute boost units
    df_set["boost_units"] = df_set[F.boost] * df_set[F.base_demand]
    df_set_promo["boost_units"] = df_set_promo[F.boost] * df_set_promo[F.base_demand]

    # Compute error reports at (item-date level)
    logger.debug("Model performance metrics")
    # Set names
    df_set.name = "all"
    df_set_promo.name = "only promo"

    if not digital_pipeline:
        # Fallback metrics
        logger.info("Fallback metrics")
        for fallback in ["ramp_down", "bad_corr", "new_item", "low_volume", "ramp_up"]:
            for df in [df_set, df_set_promo]:
                try:
                    df_fallback = df[df["fallback_reason"] == fallback].reset_index(
                        drop=True
                    )
                    metrics_boost_uplift = create_error_report(
                        df_fallback[F.units_sold],
                        df_fallback[F.predicted_demand],
                        weight=df_fallback[F.units_sold],
                        label="Boost + Uplift"
                        + f" - unit weighted ({df.name} - {fallback}) ",
                    )
                    logger.info(f"Boost + Uplift metrics: {metrics_boost_uplift}")
                except ValueError:
                    pass

    # General metrics
    logger.info("General metrics")
    for df in [df_set, df_set_promo]:
        try:
            metrics_base = create_error_report(
                df[F.units_sold],
                df[F.base_demand],
                label=f"Base demand - unweighted ({df.name})",
            )
            logger.debug(f"Base demand metrics: {metrics_base}")

            metrics_boost = create_error_report(
                df[F.units_sold],
                df["boost_units"],
                label=f"Boost - unweighted ({df.name})",
            )
            logger.debug(f"Boost metrics: {metrics_boost}")

            metrics_boost_uplift = create_error_report(
                df[F.units_sold],
                df[F.predicted_demand],
                label=f"Boost + Uplift  - unweighted ({df.name})",
            )
            logger.info(f"Boost + Uplift metrics: {metrics_boost_uplift}")

            if digital_pipeline:
                for channel in ["SDD", "SDP", "SHIPPED"]:
                    df_channel = df[df["channel"] == channel].copy().reset_index()

                    metrics_boost_channel = create_error_report(
                        df_channel[F.units_sold],
                        df_channel[F.predicted_demand],
                        label=f"Boost + Uplift  - unweighted ({df.name} - {channel})",
                    )
                    logger.info(
                        f"Boost + Uplift metrics for channel {channel}: "
                        + f"{metrics_boost_channel}"
                    )

            # Compute error reports at (item-date level) - weighted
            metrics_base = create_error_report(
                df[F.units_sold],
                df[F.base_demand],
                weight=df[F.units_sold],
                label=f"Base demand - unit weighted ({df.name})",
            )
            logger.debug(f"Base demand metrics: {metrics_base}")

            metrics_boost = create_error_report(
                df[F.units_sold],
                df["boost_units"],
                weight=df[F.units_sold],
                label=f"Boost - unit weighted ({df.name})",
            )
            logger.debug(f"Boost metrics: {metrics_boost}")

            metrics_boost_uplift = create_error_report(
                df[F.units_sold],
                df[F.predicted_demand],
                weight=df[F.units_sold],
                label=f"Boost + Uplift  - unit weighted ({df.name})",
            )
            logger.info(f"Boost + Uplift metrics: {metrics_boost_uplift}")

            if digital_pipeline:
                for channel in ["SDD", "SDP", "SHIPPED"]:
                    df_channel = df[df["channel"] == channel].copy().reset_index()

                    metrics_boost_channel = create_error_report(
                        df_channel[F.units_sold],
                        df_channel[F.predicted_demand],
                        weight=df_channel[F.units_sold],
                        label=f"Boost + Uplift  - unit weighted ({df.name} - {channel})",
                    )
                    logger.info(
                        f"Boost + Uplift metrics for channel {channel}: "
                        + f"{metrics_boost_channel}"
                    )
        except ValueError:
            pass


def get_digital_metrics_report_results(
    df: pd.DataFrame,
    mode: str,
) -> None:
    """
    Calculates the metrics for digital forecaster, including
    SMAPE, BMAPE, SMAPE, Bias, and R2, at various stages of prediction:
    base demand, boost, boost + promo uplift, and boost + promo uplift + shipping uplift

    Also calculates the metrics by various levels of aggregation, including by channel
    and for all observations vs. only promo observations.

    The resulting metrics tables are saved as .csv files

    Args:
        df: dataframe with predictions and actuals
        mode: current run mode (e.g. train, test)

    """
    # Prepare data
    if mode == "train":
        # Define sample with promo and not promo
        df_set = df[
            (df[F.keep_training] == 1)
            & (df[F.predicted_demand].notna())
            # filter out cases where the observed demand is 0 and our prediction
            # is smaller than or equal to 5 units
            & ~(
                (
                    df[F.units_sold]
                    <= context.digital_forecaster.error_metrics_units_exclusion_threshold
                )
                & (
                    df[F.predicted_demand]
                    <= context.digital_forecaster.error_metrics_units_exclusion_threshold
                )
            )
        ].reset_index(drop=True)
        # Define sample only for promo
        df_set_promo = df_set[df_set[F.is_promo] == 1].reset_index(drop=True)

    else:
        df = df[df["group_indicator"] == "group"]

        # remove cold start items
        df = df[df["cold_start"] != 1]

        # Define sample with promo and not promo
        df_set = df[
            (df[F.predicted_demand].notna())
            # filter out cases where the observed demand and our prediction
            # is smaller than or equal to 5 units
            & ~(
                (
                    df[F.units_sold]
                    <= context.digital_forecaster.error_metrics_units_exclusion_threshold
                )
                & (
                    df[F.predicted_demand]
                    <= context.digital_forecaster.error_metrics_units_exclusion_threshold
                )
            )
        ].reset_index(drop=True)
        # Define sample only for promo
        df_set_promo = df_set[df_set[F.is_promo] == 1].reset_index(drop=True)

    # Compute boost units
    df_set["boost_units"] = df_set[F.boost] * df_set[F.base_demand]
    df_set_promo["boost_units"] = df_set_promo[F.boost] * df_set_promo[F.base_demand]

    # split out BBU before adding shipping promo gradient
    df_set["boost_promo_units"] = (
        df_set[F.boost] * df_set[F.base_demand] * df_set[F.promo_multiplier]
    )
    df_set_promo["boost_promo_units"] = (
        df_set_promo[F.boost]
        * df_set_promo[F.base_demand]
        * df_set_promo[F.promo_multiplier]
    )

    df_category_level = df_set.groupby(
        ["category_level_code", "channel"],
        observed=True,
        as_index=False,
    ).agg(
        {
            "boost_promo_units": "sum",
            "boost_units": "sum",
            "base_demand": "sum",
            "units_sold": "sum",
            "predicted_demand": "sum",
        }
    )

    # Compute error reports at (item-date level)
    logger.debug("Model performance metrics")
    # Set names
    df_set.name = "all"
    df_set_promo.name = "only promo"
    df_category_level.name = "category_level"

    # General metrics
    logger.info("General metrics")
    for df in [df_set, df_set_promo, df_category_level]:
        # initiate metrics dfs list
        metrics_dfs = []

        try:
            metrics_base, metric_df = create_digital_error_report(
                df[F.units_sold],
                df[F.base_demand],
                label=f"Base demand - unweighted ({df.name})",
            )
            logger.debug(f"Base demand metrics: {metrics_base}")

            metrics_dfs.append(metric_df)

            metrics_boost, metric_df = create_digital_error_report(
                df[F.units_sold],
                df["boost_units"],
                label=f"Boost - unweighted ({df.name})",
            )
            logger.debug(f"Boost metrics: {metrics_boost}")

            metrics_dfs.append(metric_df)

            metrics_boost_promo, metric_df = create_digital_error_report(
                df[F.units_sold],
                df["boost_promo_units"],
                label=f"Boost + Uplift (Promo) - unweighted ({df.name})",
            )
            logger.debug(f"Boost + Uplift (Promo) metrics: {metrics_boost_promo}")

            metrics_dfs.append(metric_df)

            metrics_boost_uplift, metric_df = create_digital_error_report(
                df[F.units_sold],
                df[F.predicted_demand],
                label=f"Boost + Uplift (Promo + Shipping)  - unweighted ({df.name})",
            )
            logger.info(
                f"Boost + Uplift (Promo + Shipping) metrics: {metrics_boost_uplift}"
            )

            metrics_dfs.append(metric_df)

            # get channel level metrics
            metrics_dfs.extend(_get_channel_level_metrics(df, weighted_metrics=False))

            # Compute error reports at (item-date level) - weighted
            metrics_base, metric_df = create_digital_error_report(
                df[F.units_sold],
                df[F.base_demand],
                weight=df[F.units_sold],
                label=f"Base demand - unit weighted ({df.name})",
            )
            logger.debug(f"Base demand metrics: {metrics_base}")
            metrics_dfs.append(metric_df)

            metrics_boost, metric_df = create_digital_error_report(
                df[F.units_sold],
                df["boost_units"],
                weight=df[F.units_sold],
                label=f"Boost - unit weighted ({df.name})",
            )
            logger.debug(f"Boost metrics: {metrics_boost}")
            metrics_dfs.append(metric_df)

            metrics_boost_promo, metric_df = create_digital_error_report(
                df[F.units_sold],
                df["boost_promo_units"],
                weight=df[F.units_sold],
                label=f"Boost + Uplift (Promo) - unit weighted ({df.name})",
            )
            logger.debug(f"Boost + Uplift (Promo) metrics: {metrics_boost_promo}")
            metrics_dfs.append(metric_df)

            metrics_boost_uplift, metric_df = create_digital_error_report(
                df[F.units_sold],
                df[F.predicted_demand],
                weight=df[F.units_sold],
                label=f"Boost + Uplift (Promo + Shipping)  - unit weighted ({df.name})",
            )
            logger.info(
                f"Boost + Uplift (Promo + Shipping) metrics: {metrics_boost_uplift}"
            )
            metrics_dfs.append(metric_df)

            # get channel level metrics
            metrics_dfs.extend(_get_channel_level_metrics(df, weighted_metrics=True))

            metrics_dfs = pd.concat(metrics_dfs)
            reader.write(
                f"""/forecaster/metrics/{mode}_error_report_digital - {df.name}.csv""",
                metrics_dfs,
            )

        except ValueError as e:
            print(f"failed with error {e}")
            pass


def _get_channel_level_metrics(
    df: pd.DataFrame, weighted_metrics: bool = False
) -> List[pd.DataFrame]:
    """
    Calculates digital forecaster metrics by channel, for base demand,
    boost, boost + promo uplift, and boost + promo uplift + shipping uplift levels

    Args:
        df: dataframe with predictions and actuals
        weighted_metrics: whether to calculate metrics weighted by units sold

    Returns:
        channel_metric_dfs: list of dataframes with metrics by channel
    """

    channel_metric_dfs = []
    metric_levels = [
        "Base demand",
        "Boost",
        "Boost + Uplift (Promo)",
        "Boost + Uplift (Promo + Shipping)",
    ]

    col_to_check = [
        "base_demand",
        "boost_units",
        "boost_promo_units",
        "predicted_demand",
    ]

    for channel in ["SDD", "SDP", "SHIPPED"]:
        for i in range(len(metric_levels)):
            metric_level = metric_levels[i]
            col = col_to_check[i]

            df_channel = df[df["channel"] == channel].copy().reset_index()

            # add condition to check whether channel data is present
            # if not, pass
            if df_channel.shape[0] > 0:
                if weighted_metrics:
                    weight_label = "unit weighted"
                    metrics_boost_channel, metrics_df = create_digital_error_report(
                        y_true=df_channel[F.units_sold],
                        y_pred=df_channel[col],
                        label=f"{metric_level}  - {weight_label} ({df.name} - {channel})",
                        weight=df_channel[F.units_sold],
                    )
                    logger.info(
                        f"{metric_level} metrics for channel {channel}: "
                        + f"{metrics_boost_channel}"
                    )
                    channel_metric_dfs.append(metrics_df)
                else:
                    weight_label = "unweighted"
                    metrics_boost_channel, metrics_df = create_digital_error_report(
                        y_true=df_channel[F.units_sold],
                        y_pred=df_channel[col],
                        label=f"{metric_level}  - {weight_label} ({df.name} - {channel})",
                    )
                    logger.info(
                        f"{metric_level} metrics for channel {channel}: "
                        + f"{metrics_boost_channel}"
                    )
                    channel_metric_dfs.append(metrics_df)
            else:
                pass

    return channel_metric_dfs
