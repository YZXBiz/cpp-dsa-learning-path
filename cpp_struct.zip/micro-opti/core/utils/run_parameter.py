import logging
import pandas as pd
import numpy as np
import math
import ipdb
import json
import datetime
from typing import Union, Any

from oxygen.conf.settings import settings
from oxygen.conf.context import context

# initialise logger
log = logging.getLogger(__name__)


def set_run_category(scenario_id: str):
    sql_query = f"""
        SELECT DISTINCT "plano_cat_desc" AS RUN_CATEGORY
        FROM {context.data_stores.raw_data.constraint_parameters.scenario_to_run_table}
        WHERE "scenario_id" = '{scenario_id}'
    """
    df_run_categories = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Get list of categories
    run_categories = df_run_categories["RUN_CATEGORY"].unique().tolist()
    context.data_stores.raw_data.categories = run_categories

    log.info(f"Running categories: {run_categories}")


def update_scenario_column(scenario_id: str, column_name: str, value: Union[str, dict, list, Any]):
    """
    Update any column in the scenario status table for a given scenario ID.
    Handles both string values and JSON/VARIANT data types.
    
    Args:
        scenario_id (str): The scenario ID to update
        column_name (str): The column name to update
        value (Union[str, dict, list, Any]): The new value to set - can be string, dict, list, or other JSON-serializable types
    """
    
    # Handle different data types for Snowflake VARIANT columns
    if isinstance(value, (dict, list)):
        # For JSON objects/arrays, use PARSE_JSON function with proper escaping
        try:
            # Convert numpy types to native Python types
            def convert_numpy_types(obj):
                if isinstance(obj, (np.int64, np.float64)):
                    return obj.item()
                elif isinstance(obj, pd.Timestamp):
                    return obj.isoformat()
                elif isinstance(obj, np.ndarray):
                    return obj.tolist()
                return obj

            # First pass: convert numpy types
            json_str = json.dumps(value, default=convert_numpy_types, ensure_ascii=False, separators=(',', ':'))
            
            # Second pass: use the custom serializer to handle edge cases
            parsed_value = json.loads(json_str)
            sanitized_value = json_serializer(parsed_value)
            
            # Final JSON string with proper formatting
            final_json_str = json.dumps(sanitized_value, ensure_ascii=False, separators=(',', ':'), sort_keys=True)
            
            # Validate the final JSON is parseable
            json.loads(final_json_str)
            
            # Use Snowflake parameterized query with %s
            sql_query = f"""
                UPDATE {context.data_stores.raw_data.constraint_parameters.scenario_status}
                SET {column_name} = PARSE_JSON(%s)
                WHERE SCENARIO_ID = %s
            """
            
            # Execute with parameters
            settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query, (final_json_str, scenario_id))
            
        except (TypeError, ValueError, json.JSONDecodeError) as e:
            log.error(f"Failed to serialize JSON for scenario {scenario_id}, column {column_name}: {str(e)}")
            # Log the problematic data type for debugging
            log.error(f"Problematic value type: {type(value)}")
            
            # Fallback to string representation
            fallback_value = {
                "error": f"Serialization failed: {str(e)}",
                "value_type": str(type(value)),
                "scenario_id": scenario_id,
                "timestamp": datetime.datetime.now().isoformat()
            }
            json_str = json.dumps(fallback_value, ensure_ascii=False, separators=(',', ':'))
            sql_query = f"""
                UPDATE {context.data_stores.raw_data.constraint_parameters.scenario_status}
                SET {column_name} = PARSE_JSON(%s)
                WHERE SCENARIO_ID = %s
            """
            settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query, (json_str, scenario_id))
    elif value is None:
        # Handle NULL values
        sql_query = f"""
            UPDATE {context.data_stores.raw_data.constraint_parameters.scenario_status}
            SET {column_name} = NULL
            WHERE SCENARIO_ID = %s
        """
        settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query, (scenario_id,))
    else:
        # Handle string and other simple types using parameterized query
        sql_query = f"""
            UPDATE {context.data_stores.raw_data.constraint_parameters.scenario_status}
            SET {column_name} = %s
            WHERE SCENARIO_ID = %s
        """
        settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query, (str(value), scenario_id))

    log.info(f"Successfully updated scenario {scenario_id} {column_name}")



def set_objective_input(scenario_id: str):
    sql_query = f"""
        SELECT DISTINCT "sales_multiplier", "dnp_multiplier"
        FROM {context.data_stores.raw_data.constraint_parameters.objective_input_table}
        WHERE "scenario_id" = '{scenario_id}'
    """
    df_objective_input = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Check that there is one DNP value per scenario id
    assert (df_objective_input.shape[0] <= 1
           ), f"Expected 1 sales & DNP multiplier per scenario ID, got {df_objective_input.shape[0]}"

    if df_objective_input.shape[0] != 0:
        # Set sales multiplier
        new_sales_mltp_value = df_objective_input["sales_multiplier"].values[0]
        context.optimization.model_formulation.sales_multiplier = new_sales_mltp_value
        
        # Set DNP multiplier
        new_dnp_mltp_value = df_objective_input["dnp_multiplier"].values[0]
        context.optimization.model_formulation.dnp_multiplier = new_dnp_mltp_value
    
        log.info(f"Objective function value multipliers set to --> sales: {new_sales_mltp_value}, DNP: {new_dnp_mltp_value}")
    else:
        log.info(f"No Objective function value multipliers set, using current values")
    

def get_items_with_facings_bounds(scenario_id: str):
    sql_query = f"""
        SELECT 
            "sku" AS ITEM_NO_NBR,
            "plano_nbr" AS PLANO_ID,
            CONCAT("store_cluster", '-', "volume_flag", '_', "risk_flag") AS FINAL_CLUSTER_LABELS,
            SPLIT_PART("pog_size", 'x', 1) AS PLANO_FT,
            SPLIT_PART("pog_size", 'x', 2) AS FIXTURE_SIZE,
            CASE
                WHEN "min_nbr_of_facings" IS NOT NULL OR "max_nbr_of_facings" IS NOT NULL THEN 'ABSOLUTE'
                ELSE 'RELATIVE'
            END AS CHANGE_TYPE,
            COALESCE("min_nbr_of_facings", "min_nbr_change_of_facings") AS MIN_FORCED_FACINGS,
            COALESCE("max_nbr_of_facings", "max_nbr_change_of_facings") AS MAX_FORCED_FACINGS
        FROM {context.data_stores.raw_data.constraint_parameters.sku_input_table}
        WHERE SPLIT_PART("scenario_assortment_sku_id", '_', 1) = '{scenario_id}'
    """
    df_facings_with_specific_bound = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Check that there is one entry per sku/version combination
    if df_facings_with_specific_bound.shape[0] > 0:
        max_dimension_entries = (
            df_facings_with_specific_bound
            .groupby(["ITEM_NO_NBR", "FINAL_CLUSTER_LABELS", "PLANO_FT", "FIXTURE_SIZE", "PLANO_ID"])
            .size()
            .max()
        )

        assert (max_dimension_entries == 1
            ), f"Expected 1 entry per item & version combo for forced facings. Found instances with {max_dimension_entries} entries"

    # Save dict to context
    context.optimization.data_prep.item_with_forced_facings = df_facings_with_specific_bound.to_dict()
    log.info(f"Forced facings dictionary set in object optimization.data_prep.item_with_forced_facings")


def get_dimension_linear_space_bounds(scenario_id: str):
    sql_query = f"""
        SELECT 
            "plano_nbr" AS PLANO_ID,
            CASE
                WHEN UPPER("choice_map") != 'ALL' THEN 'choice_map'
                WHEN UPPER("need_state") != 'ALL' THEN 'need_states'
                WHEN UPPER("subcategory") != 'ALL' THEN 'subcat'
                WHEN UPPER("segment") != 'ALL' THEN 'segment'
                WHEN UPPER("brand") != 'ALL' THEN 'brand'
                WHEN UPPER("vendor") != 'ALL' THEN 'supplier'
                ELSE NULL
            END AS DIMENSION,
            CASE
                WHEN UPPER("choice_map") != 'ALL' THEN "choice_map"
                WHEN UPPER("need_state") != 'ALL' THEN "need_state"
                WHEN UPPER("subcategory") != 'ALL' THEN "subcategory"
                WHEN UPPER("segment") != 'ALL' THEN "segment"
                WHEN UPPER("brand") != 'ALL' THEN "brand"
                WHEN UPPER("vendor") != 'ALL' THEN "vendor"
                ELSE NULL
            END AS NAME,
            CASE
                WHEN "min_perc_share_of_linear_shelf_space" IS NOT NULL OR "max_perc_share_of_linear_shelf_space" IS NOT NULL THEN 'overall_share'
                ELSE 'dimension_current'
            END AS CONSTRAINT_RELATIVE_TO,
            COALESCE("min_perc_share_of_linear_shelf_space", "min_perc_change_share_of_linear_shelf_space") AS MIN_BOUND,
            COALESCE("max_perc_share_of_linear_shelf_space", "max_perc_change_share_of_linear_shelf_space") AS MAX_BOUND
        FROM {context.data_stores.raw_data.constraint_parameters.cumulative_level_constraint_input}
        WHERE "scenario_id" = '{scenario_id}' AND DIMENSION IS NOT NULL AND NAME IS NOT NULL
    """
    df_dimension_with_linear_space_bound = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Check that there is one entry per sku/version combination
    if df_dimension_with_linear_space_bound.shape[0] > 0:
        max_dimension_entries = (
            df_dimension_with_linear_space_bound
            .groupby(["PLANO_ID", "DIMENSION", "NAME"])
            ["MIN_BOUND"]
            .count()
            .reset_index()
            ["MIN_BOUND"]
            .max()
        )
    
        assert (max_dimension_entries <= 1
               ), f"Expected 1 entry per plano & dimension name for linear space change bounds. Found instances with {max_dimension_entries} entries"
        context.optimization_config.model_formulation.enable_global_linear_space_change_constraints=True
    # Save dict to context
    context.optimization.data_prep.global_linear_space_bounds = df_dimension_with_linear_space_bound.to_dict()
    log.info(f"Global linear space bound set in object optimization.data_prep.global_linear_space_bounds")


def get_non_enforced_need_states(scenario_id: str):
    sql_query = f"""
        SELECT DISTINCT 
            "need_state_id" AS NEED_STATE_UNIQUE_ID,
            "plano_nbr" AS PLANO_ID,
            CONCAT("store_cluster", '-', "volume_flag", '_', "risk_flag") AS FINAL_CLUSTER_LABELS,
            SPLIT_PART("pog_size", 'x', 1) AS PLANO_FT,
            SPLIT_PART("pog_size", 'x', 2) AS FIXTURE_SIZE,
            0 AS MIN_FORCED_FACINGS,
            99999 AS MAX_FORCED_FACINGS
        FROM {context.data_stores.raw_data.constraint_parameters.need_state_input_table}
        WHERE "scenario_id" = '{scenario_id}' AND "exclude_from_protection_flag" = True
    """
    df_non_enforced_need_states = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Save dict to context
    context.optimization.data_prep.non_enforced_need_states = df_non_enforced_need_states.to_dict()
    log.info(f"Non enforced need states dictionary set in object optimization.data_prep.non_enforced_need_states")


def set_assortment_expansion_reduction(scenario_id: str):
    """
    Load assortment expansion and reduction data from Snowflake.
    """
    log.info("Loading assortment expansion and reduction data from Snowflake")
    
    sql_query = f"""
        SELECT 
            "plano_nbr" AS "plano_id",
            SPLIT_PART("pog_size", 'x', 1) AS "plano_ft",
            SPLIT_PART("pog_size", 'x', 2) AS "fixture_size",
            "store_cluster",
            "risk_flag",
            "volume_flag",
            "target_sku_reduction_perc",
            "target_sku_expansion_perc"
        FROM {context.data_stores.raw_data.constraint_parameters.wb_assortment_input_table}
        WHERE "scenario_assortment_id" LIKE '{scenario_id}%'
    """
    
    df_assortment_expansion_reduction = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()
    
    if df_assortment_expansion_reduction.empty:
        log.info("No assortment expansion/reduction data found in Snowflake.")
        return
    
    context.optimization_config.model_formulation.enable_assortment_expansion_reduction = True
    # Convert DataFrame to dictionary format identical to the config
    dict_assortment_expansion_reduction = df_assortment_expansion_reduction.to_dict(orient="records")
    
    # Store the dictionary in the context
    context.optimization.model_formulation.dict_assortment_expansion_reduction = dict_assortment_expansion_reduction
    
    log.info(f"Assortment expansion/reduction data successfully loaded into context. Total rows: {len(dict_assortment_expansion_reduction)}")


def set_plano_sku_pods(scenario_id: str):
    """
    Set the PODs constraints for each SKU in the relevant plano_nbr.
    """
    log.info("Setting PODs constraints for each SKU in the relevant plano_nbr")
    
    sql_query = f"""
        SELECT DISTINCT
                    CAST("plano_nbr" AS STRING) AS "plano_id",
                    "sku" AS "item_no_nbr",
                    "min_door_count",
                    "min_change_of_store_count",
                    "max_door_count",
                    "max_change_of_store_count"
        FROM {context.data_stores.raw_data.constraint_parameters.plano_sku_constraint_input_table}
       WHERE "scenario_id" = '{scenario_id}'
        """
    df_plano_sku_pods = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()
    
    if df_plano_sku_pods.empty:
        log.info("No PODs constraints found in Snowflake.")
        return

    df_plano_sku_pods.loc[:, "item_no_nbr"] = df_plano_sku_pods["item_no_nbr"].astype(float)
    # Filter rows where values are not null
    df_min_store = df_plano_sku_pods[df_plano_sku_pods["min_door_count"].notnull()]
    df_max_store = df_plano_sku_pods[df_plano_sku_pods["max_door_count"].notnull()]
    df_min_change = df_plano_sku_pods[df_plano_sku_pods["min_change_of_store_count"].notnull()]
    df_max_change = df_plano_sku_pods[df_plano_sku_pods["max_change_of_store_count"].notnull()]

    # Ensure "min_door_count" and "min_change_of_store_count" are floats
    df_min_store.loc[:, "min_door_count"] = df_min_store["min_door_count"].astype(float)
    df_max_store.loc[:, "max_door_count"] = df_max_store["max_door_count"].astype(float)
    df_min_change.loc[:, "min_change_of_store_count"] = df_min_change["min_change_of_store_count"].astype(float)
    df_max_change.loc[:, "max_change_of_store_count"] = df_min_change["max_change_of_store_count"].astype(float)    

    # Create dict_item_POD_min_store: {plano_id: {sku: min_door_count}}
    dict_item_POD_min_store = (
        df_min_store.groupby("plano_id")
        .apply(lambda group: dict(zip(group["item_no_nbr"], group["min_door_count"])))
        .to_dict()
    )

    # Create dict_item_POD_max_store: {plano_id: {sku: max_door_count}}
    dict_item_POD_max_store = (
        df_max_store.groupby("plano_id")
        .apply(lambda group: dict(zip(group["item_no_nbr"], group["max_door_count"])))
        .to_dict()
    )    
    # Create dict_item_pod_min_change: {plano_id: {sku: min_change_of_store_count}}
    dict_item_pod_min_change = (
        df_min_change.groupby("plano_id")
        .apply(lambda group: dict(zip(group["item_no_nbr"], group["min_change_of_store_count"])))
        .to_dict()
    )

     # Create dict_item_pod_max_change: {plano_id: {sku: min_change_of_store_count}}
    dict_item_pod_max_change = (
        df_max_change.groupby("plano_id")
        .apply(lambda group: dict(zip(group["item_no_nbr"], group["max_change_of_store_count"])))
        .to_dict()
    )   
    # Store the dictionaries in the context
    context.optimization.model_formulation.dict_item_POD_min_store = dict_item_POD_min_store
    context.optimization.model_formulation.dict_item_POD_max_store = dict_item_POD_max_store
    context.optimization.model_formulation.dict_item_pod_min_change = dict_item_pod_min_change
    context.optimization.model_formulation.dict_item_pod_max_change = dict_item_pod_max_change

    # Enable minimum store per SKU constraints if dict_item_POD_min_store is not empty
    if dict_item_POD_min_store:
        context.optimization_config.model_formulation.enable_minimum_store_per_sku = True
    # Enable minimum store per SKU constraints if dict_item_POD_max_store is not empty
    if dict_item_POD_max_store:
        context.optimization_config.model_formulation.enable_maximum_store_per_sku = True
    # Enable minimum change of store count per SKU constraints if dict_item_pod_min_change is not empty
    if dict_item_pod_min_change:
        context.optimization_config.model_formulation.enable_item_store_count_change_min = True
    # Enable maximum change of store count per SKU constraints if dict_item_pod_max_change is not empty
    if dict_item_pod_max_change:
        context.optimization_config.model_formulation.enable_item_store_count_change_max = True
        
    
    log.info(f"PODs constraints successfully set. Total planos with min_door_count: {len(dict_item_POD_min_store)}, Total planos with max_door_count: {len(dict_item_POD_max_store)}, Total planos with min_change_of_store_count: {len(dict_item_pod_min_change)}, Total planos with max_change_of_store_count: {len(dict_item_pod_max_change)}")


def set_brand_btl_rate(scenario_id: str):
    """
    Load brand/vendor btl rate
    """
    log.info("Loading brand & vendor BTL data from Snowflake")
    
    sql_query = f"""
        SELECT
            "plano_nbr" AS PLANO_ID,
            "vendor" AS VENDOR_NUMBER,
            "brand" AS BRAND_NAME,
            "new_btl_rate" AS VENDOR_BRAND_BTL_RATE
        FROM {context.data_stores.raw_data.constraint_parameters.financial_adjustment_vendor_brand_input_table}
        WHERE "scenario_id" = '{scenario_id}'
    """
    
    df_brand_vendor_btl = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    if df_brand_vendor_btl.shape[0] != 0:
        # Save dict to context
        context.optimization.data_prep.brand_vendor_dnp_btl_rate = df_brand_vendor_btl.to_dict(orient="records")
        log.info(f"Brand & vendor updated BTL rates set in object optimization.data_prep.brand_vendor_dnp_btl_rate")
    else:
        log.info(f"No new Brand & vendor BTL rates found, using current values")
        


def set_item_btl_cost_rate(scenario_id: str):
    """
    Load item btl & cost rate
    """
    log.info("Loading item BTL data from Snowflake")
    
    sql_query = f"""
        SELECT
            "plano_nbr" AS PLANO_ID,
            "sku" AS SKU_NBR,
            "new_cost" AS NEW_COST,
            "new_btl_rate" AS BTL_RATE
        FROM {context.data_stores.raw_data.constraint_parameters.plano_sku_constraint_input_table}
        WHERE "scenario_id" = '{scenario_id}'
    """
    
    df_brand_item_dnp = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    if df_brand_item_dnp.shape[0] != 0:
        # Save dict to context
        context.optimization.data_prep.item_dnp_financial_adjustment = df_brand_item_dnp.set_index("SKU_NBR").to_dict(orient="index")
        log.info(f"Item updated BTL rates & cost set in object optimization.data_prep.item_dnp_financial_adjustment")
    else:
        log.info(f"No Item updated BTL rates & cos set, using current values.")


def load_configs_from_snowflake(scenario_id: str):

    log.info(f"Loading run parameters from Snowflake for scenario: {scenario_id}")
    # Set run category
    set_run_category(scenario_id)

    # Log start time
    start_time = pd.Timestamp.now().replace(tzinfo=None)
    update_scenario_column(scenario_id, "START_TIME", start_time)

    # Set scenario status to 'IN PROGRESS'
    update_scenario_column(scenario_id, "STATUS", "IN PROGRESS")

    # Clear any previous errors
    update_scenario_error(scenario_id, "None", False)

    # set sales & dnp multiplier
    set_objective_input(scenario_id)

    # Get facings change with specific bounds
    get_items_with_facings_bounds(scenario_id)

    # Get vendor, brand, need state, cdt, subcat, segment with linear space bounds
    get_dimension_linear_space_bounds(scenario_id)

    # Get need states which don't need to be enforced
    get_non_enforced_need_states(scenario_id)

    # Load assortment expansion/reduction data
    set_assortment_expansion_reduction(scenario_id)
    
    # Set PODs constraints for each SKU in the relevant plano_nbr
    set_plano_sku_pods(scenario_id)

    # Set brand dnp btl rate
    set_brand_btl_rate(scenario_id)

    # Set item btl & cost
    set_item_btl_cost_rate(scenario_id)


def get_scenario_ids():
    # If scenario ID is set in the config file, use this scenario to indicate a local test run
    if context.meta.scenario_id is not None:
        log.info(f"context.meta.scenario_id variable is set, using config parameter to determine scenario to run") 
        return [context.meta.scenario_id]
        
    sql_query = f"""
        SELECT DISTINCT SCENARIO_ID
        FROM {context.data_stores.raw_data.constraint_parameters.scenario_status}
        WHERE LOWER(STATUS) = 'not yet started'
    """
    df_scenarios = settings.SNOWFLAKE_CONNECTION.cursor().execute(sql_query).fetch_pandas_all()

    # Get the list of scenarios to run
    list_scenario_ids = df_scenarios["SCENARIO_ID"].unique().tolist()

    log.info(f"Found {len(list_scenario_ids)} scenarios to run")

    return list_scenario_ids


def update_scenario_error(scenario_id: str, error_message: str, update_status: bool=True):
    """
    Update the ERROR_MESSAGE column and set status to ERROR for a scenario.
    
    Args:
        scenario_id (str): The scenario ID to update
        error_message (str): The error message to set
    """
    # Escape single quotes in error message
    escaped_error = error_message.replace("'", "''")
    update_scenario_column(scenario_id, "ERROR_MSG", escaped_error)
    if update_status:
        update_scenario_column(scenario_id, "STATUS", "ERROR")


def save_slack_data_to_table(scenario_id, df_slack):
    """
    Save slack data to a separate table when it's too large for VARIANT column.
    
    Args:
        scenario_id (str): The scenario ID
        slack_data (list): List of slack records
        table_suffix (str): Suffix for the table name
    """
    try:
        # Create table name
        slack_table = context.data_stores.raw_data.constraint_parameters.constraints_used_table
        
        df_slack['SCENARIO_ID'] = scenario_id
        
        # Clear existing data for this scenario
        delete_sql = f"DELETE FROM {slack_table} WHERE SCENARIO_ID = %s"
        settings.SNOWFLAKE_CONNECTION.cursor().execute(delete_sql, (scenario_id,))
        
        # Insert new data in batches
        batch_size = 200000
        total_records = 0
        
        for i in range(0, len(df_slack), batch_size):
            batch_df = df_slack.iloc[i:i+batch_size]
            
            # Convert batch to insert statements
            values_list = []
            for _, row in batch_df.iterrows():
                # Extract fields based on actual DataFrame columns
                name = str(row.get('name', ''))
                type_field = str(row.get('type', ''))
                key = str(row.get('key', ''))
                sense_str = str(row.get('sense_str', ''))
                slack_amount = float(row.get('slack_amount', 0))
                slack_type = str(row.get('slack_type', ''))
                
                values_list.append((
                    scenario_id,
                    name,
                    type_field,
                    key,
                    sense_str,
                    slack_amount,
                    slack_type
                ))
            
            # Batch insert
            insert_sql = f"""
            INSERT INTO {slack_table} 
            (SCENARIO_ID, NAME, TYPE, KEY, SENSE_STR, SLACK_AMOUNT, SLACK_TYPE)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            
            settings.SNOWFLAKE_CONNECTION.cursor().executemany(insert_sql, values_list)
            total_records += len(values_list)
            
        log.info(f"Successfully saved {total_records} slack records to {slack_table}")
        
        # Update main scenario table with reference
        update_scenario_column(scenario_id, "SCANRIO_USED", f'"{slack_table}"')
        
    except Exception as e:
        log.error(f"Failed to save slack data to separate table: {str(e)}")
        # Fallback: save summary only
        summary = {
            "error": f"{str(e)}",
            "timestamp": datetime.datetime.now().isoformat()
        }
        update_scenario_column(scenario_id, "SCANRIO_USED", summary)


def json_serializer(obj):
    """
    Custom serializer and sanitizer for complex objects.
    Handles invalid JSON values like NaN, Infinity, and recursively serializes objects.
    Also removes escaped double quotes from strings.
    """
    import math
    if isinstance(obj, datetime.datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        # Recursively serialize and sanitize dictionary values
        sanitized_dict = {}
        for key, value in obj.items():
            try:
                sanitized_key = str(key) if not isinstance(key, str) else key
                sanitized_dict[sanitized_key] = json_serializer(value)
            except Exception as e:
                log.warning(f"Skipping problematic key-value pair: {key} -> {type(value)}: {str(e)}")
                sanitized_dict[str(key)] = f"<serialization_error: {str(e)}>"
        return sanitized_dict
    elif isinstance(obj, list):
        # Recursively serialize and sanitize list elements
        sanitized_list = []
        for item in obj:
            try:
                sanitized_list.append(json_serializer(item))
            except Exception as e:
                log.warning(f"Skipping problematic list item: {type(item)}: {str(e)}")
                sanitized_list.append(f"<serialization_error: {str(e)}>")
        return sanitized_list
    elif isinstance(obj, float):
        # Replace NaN and Infinity with None
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    elif isinstance(obj, str):
        # Clean up problematic characters that might break JSON
        cleaned = obj.replace('\\"', '"').replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        # Remove any control characters
        cleaned = ''.join(char for char in cleaned if ord(char) >= 32 or char in '\n\r\t')
        return cleaned
    elif isinstance(obj, (int, bool)):
        return obj
    elif obj is None:
        return None
    else:
        try:
            # Try to convert to string, but handle problematic cases
            str_repr = str(obj)
            # Clean the string representation
            cleaned = ''.join(char for char in str_repr if ord(char) >= 32 or char in '\n\r\t')
            return cleaned
        except Exception:
            return f"<{type(obj).__name__} object>"
    