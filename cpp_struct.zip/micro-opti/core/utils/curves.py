from typing import Union

import numpy as np
import pandas as pd


def linear_curve(
    x: pd.Series, a: pd.Series, b: Union[pd.Series, float] = 1
) -> pd.Series:
    """Equation of linear curve. Default b argument corresponds to y=1 when x=0"""
    y = a * x + b

    return y


def exponential_curve(
    x: pd.Series, a: pd.Series, b: Union[pd.Series, float] = 0
) -> pd.Series:
    """
    This curve is used to model discounts, meaning it's default b argument corresponds
    to y = 1 when x=0.
    """
    y = np.exp(a * x + b)

    return y


def logarithmic_curve(
    x: pd.Series, a: pd.Series, b: Union[pd.Series, float] = 0
) -> pd.Series:
    """Equation of logarithmic curve with value of x + 1 and inverse of np.expm1."""
    y = np.log1p(a * x + b)

    return y


def negative_exponential_curve(
    x: pd.Series, a: pd.Series, b: Union[pd.Series, float] = 0
) -> pd.Series:
    """
    Equation of negative exponential curve, used for price changes. Default b argument
    corresponds to y=1 when x=0.
    """
    y = np.exp(a * x * (-1) + b)

    return y


def reverse_sigmoid_curve(
    x: pd.Series, a: pd.Series, b: Union[pd.Series, float] = 0
) -> pd.Series:
    """
    Equation of (reversed) sigmoid curve. Default b argument corresponds to y=1
    when x=0.
    """
    y = (1 / (1 + np.exp(a * x * (-1) + b))) + 0.5

    return y
