import logging
import pandas as pd
import numpy as np

log = logging.getLogger(__name__)


def check_data_integrity(df: pd.DataFrame, cols_to_ignore: list = None) -> None:
    if cols_to_ignore is None:
        cols_to_ignore = []

    # TODO: uncomment after using actual data
    # for column in df.columns:
    #     if column not in cols_to_ignore:
    #         if df[column].isna().any():
    #             raise ValueError(f"Column '{column}' contains NaN values.")
    #         if (df[column] == np.inf).any():
    #             raise ValueError(
    #                 f"Column '{column}' contains positive infinity values."
    #             )
    #         if (df[column] == -np.inf).any():
    #             raise ValueError(
    #                 f"Column '{column}' contains negative infinity values."
    #             )


def roll_up_cluster_labels(
    df_opti_modeling_output_adjusted_dict: dict,
    config_financial_projection_cluster_labels_based_on: str,
    config_optimizer_cluster_labels_based_on: str,
):
    """
    Decide if roll up to `original_cluster_labels` or `demand_cluster_labels` (without operational cluster) or
    keep final_cluster_labels (with operational cluster).

    Args:
        df_opti_modeling_output_adjusted_dict (dict): Dictionary of DataFrames to be processed.
        use_original_cluster_labels (bool): Flag indicating whether to use original cluster labels.

    Returns:
        dict: Updated dictionary of DataFrames after processing cluster labels.
    """
    if config_financial_projection_cluster_labels_based_on == config_optimizer_cluster_labels_based_on:
        log.info(
            f"Selected {config_financial_projection_cluster_labels_based_on} to calculate financial metrics"
        )
        return df_opti_modeling_output_adjusted_dict

    if config_optimizer_cluster_labels_based_on == "final_cluster_labels":
        if config_financial_projection_cluster_labels_based_on in ["demand_cluster_labels", "original_cluster_labels"]:
            log.info(
                f"Roll up to {config_financial_projection_cluster_labels_based_on} when calculating financial metrics"
            )

            # Load the cluster data with original cluster labels
            df_final_clusters_w_original_cluster_labels = load_cluster_data_based_on_agg_granularity(
                use_cluster_labels=config_financial_projection_cluster_labels_based_on
            )

            # Process each DataFrame in the dictionary
            for key in df_opti_modeling_output_adjusted_dict.keys():
                df_add_other_cluster_labels = df_opti_modeling_output_adjusted_dict[
                    key
                ].copy()

                # Merge with original cluster labels
                df_add_other_cluster_labels = df_add_other_cluster_labels.merge(
                    df_final_clusters_w_original_cluster_labels,
                    on=context.groupby_granularity.clustering + ["final_cluster_labels"],
                    how="left",
                )

                # Drop the final_cluster_labels
                df_add_other_cluster_labels = df_add_other_cluster_labels.drop(
                    columns=["final_cluster_labels"]
                )
            if (df[column] == -np.inf).any():
                raise ValueError(
                    f"Column '{column}' contains negative infinity values."
                )
