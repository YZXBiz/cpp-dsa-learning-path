import logging
from typing import Optional, List

import numpy as np
import pandas as pd
from pandas.testing import assert_index_equal

logger = logging.getLogger(__name__)


def cross_join(
    df1: pd.DataFrame, df2: pd.DataFrame, key: Optional[str] = "_key"
) -> pd.DataFrame:
    """Cross join two DataFrames.

    Args:
        df1: A DataFrame.
        df2: Another DataFrame.
        key: Column name for outer join key. Should not be existing columns.

    Returns:
        A cross-joined DataFrame where len(df) = len(df1) * len(df2).

    """
    # input checks
    df1_cols, df2_cols = df1.columns, df2.columns
    if key in df1_cols or key in df2_cols:
        raise ValueError(
            f"Merge key already exists: `{key}` is already a column in input dfs."
        )
    if dupe_col := set(df1_cols).intersection(set(df2_cols)):
        raise ValueError(f"Duplicated column names: `{dupe_col}` in both input dfs.")
    if len(df1) * len(df2) == 0:
        raise ValueError("DataFrame empty: at least one of the input dfs is empty.")

    # copy so that we keep the input dataframes as they are (no adding cols)
    _df1 = df1.copy()
    _df2 = df2.copy()

    # add key column and cross join with outer merge
    _df1[key], _df2[key] = 0, 0
    df = _df1.merge(_df2, on=key, how="outer")
    df = df.drop(columns=key)

    # output checks
    assert len(df) == len(df1) * len(df2), "Output nrows should = PRODUCT(input nrows)"
    assert_index_equal(df1_cols, df1.columns), "Input df should be unchanged"
    assert_index_equal(df2_cols, df2.columns), "Input df should be unchanged"

    return df


def left_anti_join(
    df_left: pd.DataFrame, df_right: pd.DataFrame, key: list
) -> pd.DataFrame:
    """Left anti-join on two DataFrames.

    Returning the rows in df_left where columns 'key' are not present in df_right.

    Args:
        df_left: DataFrame to filter
        df_right: DataFrame containing keys to remove in df_left
        key: Column name(s) for anti-join. Should exist in both DataFrames

    Returns:
        Left anti-join of df_left where rows with 'key' present in df_right are removed

    """

    # If key is not list, make it list
    key = make_list_if_not_list(key)

    # input check
    for k in key:
        if (k not in df_left.columns) or (k not in df_right.columns):
            raise ValueError(f"Merge key `{k}` not present in either df")

    # perform left anti-join
    df = pd.merge(left=df_left, right=df_right, how="left", indicator=True, on=key)
    df = df.query('_merge=="left_only"').drop(columns="_merge")

    return df


def check_matching_key_rows(
    df_left: pd.DataFrame, df_right: pd.DataFrame, key: list
) -> None:
    """
    Check that rows between two dfs matches exactly (ignoring row order). This will
    check for both duplicates and dropped rows between the two dataframes, and
    checks that none of the values in 'key' has changed.

    Args:
        df_left: A DataFrame
        df_right: Another DataFrame
        key: Column name(s) for keys to check. Should exist in both DataFrames

    Raises:
        ValueError: If key is not present in either df, or if dtypes of key columns
            don't match
        InvalidIndexError: If rows of keys do not match exactly

    """

    # If key is not list, make it list
    if not pd.api.types.is_list_like(key):
        key = [key]

    # Check that keys are present in both dfs
    for col in key:
        if (col not in df_left.columns) or (col not in df_right.columns):
            raise ValueError(f"Key {key} not present in input df")

    # Copy and sort both dataframes
    df_left = df_left.sort_values(by=key).reset_index(drop=True).copy()
    df_right = df_right.sort_values(by=key).reset_index(drop=True).copy()

    # Check that dtypes of key cols matches
    if not df_left[key].dtypes.equals(df_right[key].dtypes):
        raise ValueError(f"dtypes of key {key} does not match")

    # Check that key rows are identical by merging dfs together; checking both left,
    # right, and inner joins
    left_equals = df_left.equals(df_left.merge(df_right[key], on=key, how="left"))
    right_equals = df_left.equals(df_left.merge(df_right[key], on=key, how="right"))
    inner_equals = df_left.equals(
        df_left.merge(df_right[key], on=key, how="inner")
    ) & df_right.equals(df_right.merge(df_left[key], on=key, how="inner"))
    if not (left_equals & right_equals & inner_equals):
        raise pd.errors.InvalidIndexError(
            f"df rows not matching with key {key}, due to duplicates or missing rows."
        )


def make_list_if_not_list(obj):
    """
    If passed object is not listlike, wrap it into a list

    Note that pd.DataFrame is considered listlike

    Args:
        obj: object to check and wrap in list

    Returns:
        either obj, or [obj] if obj is not list like
    """

    # If object is not list, make list
    if not pd.api.types.is_list_like(obj):
        obj = [obj]

    return obj


def make_date_dense(
    df: pd.DataFrame,
    date_col: str,
    granularity_col: list,
    volume_col: str,
    fill_method="zero",
) -> pd.DataFrame:
    """Takes dataframe with granularity, date, units_sold columns and checks for
    the min and max date the date column. Then expands the dataframe to cover the
    whole range between global min and max date for each granularity combination.
    Gives a logger warning in case the dataframe was not date-dense before.

    This produces NaN values for units_sold and all other columns that were
    additionally present at the date-granularity combinations that
    did not exist before.

    The NaN values of the units_sold column are filled by zeros or a
    specified fill-method. If there are additional columns, NaN values will remain!

    Args:
        df: dataframe with date_col, granularity_col, volume_col
        date_col: name of date column
        granularity_col: list of granularity columns
        volume_col: name of units_sold column
        fill_method: either "zero" (default, fill units_sold NaN with zeros) or
            "forward-backward" (fill first forward and then backward) or
            "backward-forward" (fill first backward and then forward)

    Returns:
        Dataframe that is date-dense and ordered by granularity, date. Furthermore
            NaNs in units_sold column are filled by fill method.

    todo: generalize volume_col as any set of columns to fill
    todo: add support for varying date frequency
    """

    # Check that granularity columns are in a list
    granularity_col = make_list_if_not_list(granularity_col)

    # Check that fill method is valid
    methods = ["zero", "forward-backward", "backward-forward"]
    if fill_method not in methods:
        raise ValueError(f"{fill_method} is not a valid fill method")

    # Check that all necessary columns are present
    for col in [*granularity_col, date_col, volume_col]:
        if col not in df.columns:
            raise ValueError(f"Column {col} is not present in the dataframe")

    # Convert date column to datetime64
    df[date_col] = pd.to_datetime(df[date_col])

    # Collect entire range of dates that df should cover
    dates_index = pd.DataFrame(
        {date_col: pd.date_range(df[date_col].min(), df[date_col].max(), freq="D")}
    )

    # Make dataframe date-dense
    dates_index = cross_join(df[granularity_col].drop_duplicates(), dates_index)
    df = df.merge(dates_index, how="outer", on=[*granularity_col, date_col])

    # Sort by granularity, date
    df = df.sort_values([*granularity_col, date_col])

    # Give warning and fill NaNs if dates were missing
    if np.isnan(df[volume_col]).sum() > 0:
        if fill_method == "zero":
            df[volume_col] = df[volume_col].fillna(0)
            logger.warning(
                "Information for certain dates is missing and got auto-filled with 0"
            )

        if fill_method == "forward-backward":
            df[volume_col] = df[volume_col].ffill()
            df[volume_col] = df[volume_col].bfill()
            logger.warning(
                "Information for certain dates is missing and got "
                "forward-backward-filled"
            )

        if fill_method == "backward-forward":
            df[volume_col] = df[volume_col].bfill()
            df[volume_col] = df[volume_col].ffill()
            logger.warning(
                "Information for certain dates is missing and got "
                "backward-forward-filled"
            )
    return df


def subset_df_from_date_range_list(
    df: pd.DataFrame, date_ranges: List[List[str]], date_var: str
) -> pd.DataFrame:
    """
    Remove rows from dataframe based on a list of date ranges that must be excluded.
    Args:
        df: dataframe with dates to be removed
        date_ranges: list of lists of date ranges to be excluded
        date_var: name of date variable

    Returns:
        df: dataframe without specified date ranges

    """
    for sku in date_ranges:
        df = df[
            ~df[date_var].between(pd.to_datetime(sku[0]), pd.to_datetime(sku[1]))
        ].copy()
    return df

def format_dataframe_print(df: pd.DataFrame) -> str:
    """
    Tabulate pandas dataframe for prettier printing/logging
    Parameters
    ----------
    df

    Returns
    -------
    String that is ready to print

    """

    def _max_len_in_lst(lst):
        return len(sorted(lst, reverse=True, key=len)[0])

    def _align_center(st, sz):
        return (
            "{0}{1}{0}".format(" " * (1 + (sz - len(st)) // 2), st)[:sz]
            if len(st) < sz
            else st
        )

    def _align_right(st, sz):
        return "{0}{1} ".format(" " * (sz - len(st) - 1), st) if len(st) < sz else st

    def _build_hline(row):
        return "+".join(["-" * col_sizes[col] for col in row]).join(["+", "+"])

    def _build_data(row, align):
        return "|".join(
            [align(str(val), col_sizes[df_columns[idx]]) for idx, val in enumerate(row)]
        ).join(["|", "|"])

    if not isinstance(df, pd.DataFrame):
        return
    elif len(df) == 0:
        logger.info("No data to show.")
        return
    df_columns = df.columns.tolist()
    max_col_len = _max_len_in_lst(df_columns)
    max_val_len_for_col = dict(
        [
            (col, _max_len_in_lst(df.iloc[:, idx].astype("str")))
            for idx, col in enumerate(df_columns)
        ]
    )
    col_sizes = dict(
        [
            (col, 2 + max(max_val_len_for_col.get(col, 0), max_col_len))
            for col in df_columns
        ]
    )
    hline = _build_hline(df_columns)
    out = [hline, _build_data(df_columns, _align_center), hline]
    for _, row in df.iterrows():
        out.append(_build_data(row.tolist(), _align_right))
    out.append(hline)

    return "\n".join(out)