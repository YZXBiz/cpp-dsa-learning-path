import logging
import pandas as pd
from oxygen.conf.settings import settings
from oxygen.files.readers import reader

from core.utils.df import format_dataframe_print
from core.utils.space_context.run_versioning import complete_file_path
from oxygen.conf.context import context

log = logging.getLogger(__name__)

def get_vendor_mapping(category, pay_vendor_names):
    pay_vendor_names = [name.replace("'", "''") for name in pay_vendor_names]
    vendor_mapping = f"""
    WITH items_per_planogram AS (
        SELECT DISTINCT
            plano_cat_desc as planogram_cat,
            fixture_desc AS planogram_name,
            item_no_nbr AS sku_nbr
        FROM DL_FSCA_SLFSRV.TWA07.MICRO_OPTI_RUNS_LATEST
    ),
    -- CTE 2: Stores in scope by category
    stores_in_scope AS (
        SELECT DISTINCT
            CAT_DSC AS planogram_cat,
            "store_nbr" AS store_nbr
        FROM DL_FSCA_SLFSRV.TWA07.ASSORTMENT_STORE_CLUSTERS_LATEST_BKP_7_28
    ), 
    -- CTE 3: Valid planogram & store combinations
    plano_in_store AS (
        SELECT DISTINCT
            PLANOGRAM_DSC as planogram_name,
            SKU_NBR,
            STORE_NBR
        FROM DL_FSCA_SLFSRV.TWA07.C835645_localization_pog_master_table_0304
        WHERE PLANO_CAT_DSC =  CASE
                                WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                                WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                                ELSE CAT_DSC
                                END 
            AND PLANOGRAM_NBR IN ('9605', '9200', '9600', '9584', '9350', '9330', 
                                  '9617', '9500', '9378', '9569', '9232', '9711', 
                                  '9380', '9576', '9136', '9040', '9061', '9030', 
                                  '9041', '9140', '9281', '9260', '9280', '9210', 
                                  '9640', '9542', '9544', '9700', '9677', '9751',
                                  '9414', '9770', '9090', '9310', '9570', '9150', 
                                  '9360', '9400', '9615', '9616', '9211', '9425')
    ),
    -- CTE 3.1: All valid store-SKU rows in scope
    in_scope AS (
        SELECT DISTINCT
            s.store_nbr,
            s.planogram_cat,
            i.planogram_name,
            i.sku_nbr
        FROM stores_in_scope s
        INNER JOIN items_per_planogram i ON i.planogram_cat = s.planogram_cat
        INNER JOIN plano_in_store p ON p.store_nbr = s.store_nbr 
            AND p.planogram_name = i.planogram_name 
            AND i.sku_nbr = p.sku_nbr
    )

    SELECT DISTINCT pv.pay_vendor_nm ,s.vendor_name
    FROM in_scope i
    LEFT JOIN CORE_FS.CURATED_PRODUCT.SKU s on i.sku_nbr = s.sku_nbr
    LEFT JOIN CORE_FSSC.CURATED_PRODUCT.VENDOR v on s.vendor_nbr = v.vendor_nbr
    LEFT JOIN CORE_FSSC.CURATED_PRODUCT.PAY_VENDOR pv on v.pay_vendor_nbr = pv.pay_vendor_nbr
    WHERE 
    TRUE
    AND s.cat_dsc = '{category}'
    AND pv.pay_vendor_nm in ('{"', '".join(pay_vendor_names)}');
    """
    log.info("Loading vendor mapping from Snowflake")

    vendor_df = settings.SNOWFLAKE_CONNECTION.cursor().execute(vendor_mapping).fetch_pandas_all()

    log.info("vendor scope:")
    log.info(f"{format_dataframe_print(vendor_df)}")

    return vendor_df.drop_duplicates().groupby('PAY_VENDOR_NM')['VENDOR_NAME'].apply(list).to_dict()

def prepare_lvc_file(category, bound, vendor_mapping, plano_ids, dimension = 'supplier', constraint_relative_to = 'dimension_current'):
    lvc_file_path = dict()
    for min_bound, max_bound in bound:
        sign = "decrease" if min_bound < 0 else "increase"
        min_bound_str, max_bound_str = str(abs(min_bound * 10)).replace(".", "").zfill(3), str(
            abs(max_bound * 10)).replace(".", "").zfill(3)
        for pay_vendor, vendors in vendor_mapping.items():
            df = pd.DataFrame(
                columns=["plano_id", "dimension", "name", "constraint_relative_to", "min_bound", "max_bound"])
            for vendor in vendors:
                for plano_id in plano_ids:
                    df.loc[len(df)] = [plano_id, dimension, vendor, constraint_relative_to, min_bound, max_bound]
            pay_vendor = pay_vendor.replace(" ", "_")
            file_path = f"lvc analysis/{context.meta.run_id}/{category}/{category}_{pay_vendor}_{sign}_{min_bound_str}_{max_bound_str}.xlsx"
            output_path = complete_file_path(
                "",
                file_path,
                at_datastores_root=True,
            )
            logging.info(f"Writing {output_path}")
            reader.write(
                df=df,
                file_path=output_path,
                root=True,
            )

            lvc_file_path[(pay_vendor, sign, min_bound, max_bound)] = file_path


    return lvc_file_path


