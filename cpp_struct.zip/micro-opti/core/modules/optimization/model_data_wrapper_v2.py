"""
This is where we're going to create data class objects that will hold some information for the model, it will make
it easier to read and all class objects will be defined here
"""
from typing import Dict, Mapping, Tuple, Union, List

import numpy as np
from pulp import LpVariable


class OptimizationModelData:
    """
    an object that is used to hold the variable dictionaries that are inputs to the optimization.
    """

    def __init__(
        self,
        dependent_var: str,
        category_level_dept_nbr: int,
        plano_cat_desc: str,
        department: int,
        risk_flag: str,
        volume_flag: str,
        item_idx_to_item_no: Mapping[int, int],
        brand_idx_to_brand: Mapping[int, str],
        plano_idx_to_plano: Mapping[int, Union[str, float]],
        eligible_brand_cg: List[Tuple[int, int, int]],
        facings_per_item: np.array,
        facings_per_item_ineligible_max_incremental: Dict[
            Tuple[int, int, int], np.array
        ],
        facings_per_item_ineligible_max_decremental: Dict[
            Tuple[int, int, int], np.array
        ],
        facings_per_item_above_max_authorized_in_dept: Dict[
            Tuple[int, int, int], np.array
        ],
        facings_per_item_forced_guardrail: Dict[Tuple[int, int, int], np.array],
        dict_supplier_brand_constraints: Dict[
            str, Union[Dict[Tuple[int, int, int], Tuple[float, float]], Dict[Tuple[int, int, int], Tuple[int, int]]]
        ],
        min_facings_per_need_state: Dict[Tuple[int, int, int], int],
        max_facings_per_need_state: Dict[Tuple[int, int, int], int],
        need_states: np.array,
        suppliers: np.array,
        brands: np.array,
        clusters: np.array,
        all_plano_fixture: np.array,
        linear_space_only_constrained_planos: np.array,
        facing_only_constrained_planos: np.array,     
        plano_fixture_by_cluster: Dict[int, np.array],
        plano_fixture_mapping: Dict[int, Tuple[int, float]],
        store_count_by_cluster_plano: Dict[Tuple[int, int], int],
        regional_indicator_by_cluster: Dict[int, int],
        items_all: np.array,
        items_per_c_g: Dict[Tuple[int, int], np.array],
        items_per_c_g_r_v: Dict[Tuple[int, int, int, int], np.array],
        # items_per_c_g_r_v: Dict[Tuple[str, str, str, str], np.array],
        item_POD_enforce_type: Dict[int, str],
        item_POD_threshold_LB: Dict[int, float],
        item_POD_threshold_UB: Dict[int, float],
        brand_POD_threshold_LB: Dict[int, float],
        brand_POD_threshold_UB: Dict[int, float],
        smallest_non_regional_item_per_need_state_dict: Dict[int, int],
        ns_per_c_g: Dict[Tuple[int, int], np.array],
        items_per_need_state_c_g: Dict[Tuple[int, int, int], np.array],
        items_own_brand_only: np.array,
        items_own_brand_only_per_c_g: np.array,
        items_per_supplier: Dict[int, np.array],
        items_per_brand: Dict[int, np.array],
        items_per_need_states: Dict[int, np.array],
        items_per_cdt: Dict[int, np.array],
        items_per_segment: Dict[int, np.array],
        items_per_subcat: Dict[int, np.array],
        item_width_x_facings: Dict[Tuple[int, int, int, int], np.array],
        item_height: Dict[Tuple[int, int, int], np.array],
        item_depth: Dict[Tuple[int, int, int], np.array],
        current_facings_per_item: Dict[Tuple[int, int, int], np.array],
        item_productivity_per_facing: Dict[Tuple[int, int, int, int], float],
        item_productivity_current_facings: Dict[Tuple[int, int, int], np.array],
        item_transference: np.array,
        local_items_reserved_space_pct: Dict[Tuple[int, int], float],
        total_linear_space_in_dept: Dict[Tuple[int, int], float],
        total_linear_space_in_dept_for_own_brand: Dict[Tuple[int, int], float],
        total_facings_space_in_dept: Dict[Tuple[int, int], float],
        height_space_in_dept: Dict[Tuple[int, int], float],
        depth_space_in_dept: Dict[Tuple[int, int], float],
        max_pct_drop_own_brand_space: Dict[Tuple[int, int], float],
        min_pct_allocated_from_total_space_to_own_brands: Dict[Tuple[int, int], float],
        max_pct_allocated_from_total_space_to_own_brands: Dict[Tuple[int, int], float],
        dict_global_linear_space_change_constraints: Dict[int, Tuple[float, float]],
        dict_item_POD_min_store_idx: Dict[Union[str, int], Dict[int, float]],
        dict_item_POD_max_store_idx: Dict[Union[str, int], Dict[int, float]],
        dict_item_pod_min_change_idx: Dict[Union[str, int], Dict[int, float]],
        dict_item_pod_max_change_idx: Dict[Union[str, int], Dict[int, float]],
        current_store_count_per_items_all_idx: Dict[Union[str, int], Dict[int, float]],
        dict_assortment_expansion_reduction_idx: List[Dict[str, Union[int, float]]],
        unmapped_clusters_planos: Dict[str, List[str]],
        sku_increase_reduction_priority_order:List[str],
        original_idx_to_original_cluster: Mapping[int, str],
        final_cluster_by_original_cluster: Dict[int, int],
        # TODO: Re-add when IOD constraints are implemented
        # original_cluster_labels_ioh_constrained: List,
        # ioh_cost_per_facing: Dict[Tuple[int, int, int], float],
        # cluster_ioh_full_budget: Dict[int, float],
        # min_pct_ioh_constraint: Dict[int, float],
        # max_pct_ioh_constraint: Dict[int, float],
        dict_cluster_plano_pivot_to_linked_skus: Dict[int, np.array],
        need_state_space_presolve_calculation_method: str,
        need_states_top1_item_productivity_current_facing: Dict[int, float],
        dc_cluster_store_mapping: Dict[Tuple[int, int], Dict[str, int]],
        min_stores_per_dc: int,
        removal_penalty_per_item: Dict[int, float],
        x_vars: Union[None, Dict[Tuple[int, int, int, int], LpVariable]],
    ):
        # TODO remove data that's not required after introducing the eligible sets
        # Run Properties
        self.dependent_var = dependent_var
        self.category_level_dept_nbr = category_level_dept_nbr
        self.plano_cat_desc = plano_cat_desc
        self.department = department
        self.risk_flag = risk_flag
        self.volume_flag = volume_flag
        self.problem_id = f"{category_level_dept_nbr}_{dependent_var}_{plano_cat_desc.replace('/', '-').replace(' ', '_')}_dept_{department}"

        # Sets
        self.need_states = need_states  # indices: [n]
        self.suppliers = suppliers  # indices: [t]: Set of all supplier indices
        self.brands = brands  # indices: [b]: Set of all brand indices
        self.items_all = items_all  # indices: [i]: Set of all items indices
        self.clusters = clusters  # indices: [c], Set of all clusters indices
        self.all_plano_fixture = (
            all_plano_fixture  # Set of all the plano_fixture pairs, indices: [g]
        )
        self.linear_space_only_constrained_planos = linear_space_only_constrained_planos # [g]
        self.facing_only_constrained_planos = facing_only_constrained_planos # [g]   
        self.plano_fixture_by_cluster = plano_fixture_by_cluster  # Subset of all cluster specific plano_fixture pairs: {c: [g]}
        self.items_per_c_g = (
            items_per_c_g  # Set of all items indices that appears in [c, g]
        )
        self.items_per_c_g_r_v = (
            items_per_c_g_r_v  # Set of all items indices that appears in [c, g, r, v]
        )
        self.items_own_brand_only_per_c_g = items_own_brand_only_per_c_g  # Set of all own brand items indices that appears in [c, g]
        self.item_POD_enforce_type = (
            item_POD_enforce_type  # list of item and the POD enforce type
        )
        self.item_POD_threshold_LB = (
            item_POD_threshold_LB  # list of item and the POD threshold LB
        )
        self.item_POD_threshold_UB = (
            item_POD_threshold_UB  # list of item and the POD threshold UB
        )
        self.brand_POD_threshold_LB = (
            brand_POD_threshold_LB  # list of brand and the POD threshold LB
        )
        self.brand_POD_threshold_UB = (
            brand_POD_threshold_UB  # list of brand and the POD threshold UB
        )

        self.smallest_non_regional_item_per_need_state_dict = (
            smallest_non_regional_item_per_need_state_dict  # indices: [n]
        )

        self.ns_per_c_g = ns_per_c_g  # Set of all NS indices that appears in [c, g]

        # Sub Sets
        self.items_own_brand_only = items_own_brand_only  # indices: [i]
        self.items_per_supplier = items_per_supplier  # indices: [t, i]
        self.items_per_brand = items_per_brand  # indices: [b, i]
        self.items_per_need_states = items_per_need_states  # indices: [ns, i]
        self.items_per_cdt = items_per_cdt  # indices: [ct, i]
        self.items_per_segment = items_per_segment  # indices: [sg, i]
        self.items_per_subcat = items_per_subcat  # indices: [sc, i]
        # index mappping
        self.plano_fixture_mapping = (
            plano_fixture_mapping  # (plano ft, fixture size): g
        )
        self.store_count_by_cluster_plano = (
            store_count_by_cluster_plano  # indices: [c, g]
        )
        self.regional_indicator_by_cluster = (
            regional_indicator_by_cluster  # indices: [c]. 1/0 for regional/non-regional
        )
        self.non_regional_cluster_idx = [
            key for key in clusters if regional_indicator_by_cluster[key] == 0
        ]
        self.regional_cluster_idx = [
            key for key in clusters if regional_indicator_by_cluster[key] == 1
        ]

        self.item_idx_to_item_no = item_idx_to_item_no  # item index to item_no_nbr mapping
        self.brand_idx_to_brand = brand_idx_to_brand  # brand index to brand mapping
        self.plano_idx_to_plano = plano_idx_to_plano #plano index to plano_id mapping
        self.eligible_brand_cg = eligible_brand_cg  # indices: [brand, c, g]
        self.facings_per_item = facings_per_item  # indices: [i, f, c, g]
        self.facings_per_item_ineligible_max_incremental = (
            facings_per_item_ineligible_max_incremental  # indices: [i, f, c, g]
        )
        self.facings_per_item_ineligible_max_decremental = (
            facings_per_item_ineligible_max_decremental  # indices: [i, f, c, g]
        )
        self.facings_per_item_forced_guardrail = (
            facings_per_item_forced_guardrail  # indices: [i, c, g]
        )
        self.facings_per_item_above_max_authorized_in_dept = (
            facings_per_item_above_max_authorized_in_dept  # indices: [i, f, c, g]
        )
        self.min_facings_per_need_state = (
            min_facings_per_need_state  # indices: [n, c, g]
        )
        self.max_facings_per_need_state = (
            max_facings_per_need_state  # indices: [n, c, g]
        )
        self.items_per_need_state_c_g = items_per_need_state_c_g  # indices: [n, c, g]

        # Parameters & Data
        self.dict_bounds_constraint_supplier_space_pct_change_facings = (
            dict_supplier_brand_constraints["supplier_pct_change_facings"]
        )  # indices: [t, c, g]
        self.dict_bounds_constraint_supplier_space_total_number_facings = (
            dict_supplier_brand_constraints["supplier_total_number_facings"]
        )  # indices: [t, c, g]
        self.dict_bounds_constraint_supplier_space_pct_allocated_linear_space = (
            dict_supplier_brand_constraints["supplier_pct_allocated_linear_space"]
        )  # indices: [t, c, g]
        self.dict_bounds_constraint_brand_space_pct_change_facings = (
            dict_supplier_brand_constraints["brand_pct_change_facings"]
        )  # indices: [b, c, g]
        self.dict_bounds_constraint_brand_space_total_number_facings = (
            dict_supplier_brand_constraints["brand_total_number_facings"]
        )  # indices: [b, c, g]
        self.dict_bounds_constraint_brand_space_pct_allocated_linear_space = (
            dict_supplier_brand_constraints["brand_pct_allocated_linear_space"]
        )  # indices: [b, c, g]
        self.dict_brand_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["brand"]  # indices [b]
        )
        self.dict_supplier_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["supplier"]  # indices [t]
        )
        self.dict_need_states_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["need_states"]  # indices [n]
        )
        self.dict_cdt_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["choice_map"]  # indices [ct]
        )
        self.dict_subcat_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["subcat"]  # indices [sc]
        )
        self.dict_segment_global_linear_space_change_constraints = (
            dict_global_linear_space_change_constraints["segment"]  # indices [sg]
        )


        self.item_width_x_facings = item_width_x_facings  # indices: [i, f, c, g]
        self.item_height = item_height  # indices: [i, c, g]
        self.item_depth = item_depth  # indices: [i, c, g]
        self.current_facings_per_item = current_facings_per_item  # indices: [i]
        self.item_productivity_per_facing = (
            item_productivity_per_facing  # indices: [i, f, c, g]
        )
        self.item_productivity_current_facings = (
            item_productivity_current_facings  # indices: [i, c, g]
        )
        self.item_transference = item_transference  # indices: [i]

        self.local_items_reserved_linear_space = {
            (c, g): local_items_reserved_space_pct[(c, g)]
            * total_linear_space_in_dept[(c, g)]
            for (c, g) in local_items_reserved_space_pct.keys()
            & total_linear_space_in_dept.keys()
        }  # indices: [c, g]

        self.total_linear_space_in_dept = total_linear_space_in_dept
        self.total_linear_space_in_dept_for_own_brand = (
            total_linear_space_in_dept_for_own_brand  # indices: [c, g]
        )
        self.total_facings_space_in_dept = total_facings_space_in_dept # indices: [c, g]
        self.depth_space_in_dept = depth_space_in_dept
        self.height_space_in_dept = height_space_in_dept
        self.max_pct_drop_own_brand_space = max_pct_drop_own_brand_space
        self.min_pct_allocated_from_total_space_to_own_brands = (
            min_pct_allocated_from_total_space_to_own_brands  # indices: [c, g]
        )
        self.max_pct_allocated_from_total_space_to_own_brands = (
            max_pct_allocated_from_total_space_to_own_brands  # indices: [c, g]
        )
        self.dict_cluster_plano_pivot_to_linked_skus = dict_cluster_plano_pivot_to_linked_skus  # (c, g) : {i_pivot_item: [i_linked_item]}
        self.original_idx_to_original_cluster = (
            original_idx_to_original_cluster  # indices: [c_]. original cluster index
        )
        self.dict_item_POD_min_store_idx = dict_item_POD_min_store_idx
        self.dict_item_POD_max_store_idx = dict_item_POD_max_store_idx
        self.dict_item_pod_min_change_idx = dict_item_pod_min_change_idx
        self.dict_item_pod_max_change_idx = dict_item_pod_max_change_idx
        self.current_store_count_per_items_all_idx = current_store_count_per_items_all_idx
        self.dict_assortment_expansion_reduction_idx = dict_assortment_expansion_reduction_idx  # indices: [c, g, r, v i]. user sku constraints
        # DC Store Count Constraint Parameters
        self.dc_cluster_store_mapping = dc_cluster_store_mapping if dc_cluster_store_mapping is not None else {}
        self.min_stores_per_dc = min_stores_per_dc
        self.removal_penalty_per_item = removal_penalty_per_item   # indices: [i] only
        self.unmapped_clusters_planos = unmapped_clusters_planos
        self.sku_increase_reduction_priority_order = sku_increase_reduction_priority_order  # list of sku increase/reduction priority order
        self.final_cluster_by_original_cluster = (
            final_cluster_by_original_cluster  # indices: [c_]. original cluster index

        )
        # TODO: Re-add when IOD constraints are implemented
        # self.original_cluster_labels_ioh_constrained = original_cluster_labels_ioh_constrained  # indices: [c_]. original cluster label
        # self.ioh_cost_per_facing = (
        #     ioh_cost_per_facing  # indices: [i ,c_, g] where c_ = original cluster index
        # )
        # self.cluster_ioh_full_budget = (
        #     cluster_ioh_full_budget  # indices: [c_]. original cluster index
        # )
        # self.min_pct_ioh_constraint = (
        #     min_pct_ioh_constraint  # indices: [c_]. original cluster index
        # )
        # self.max_pct_ioh_constraint = (
        #     max_pct_ioh_constraint  # indices: [c_]. original cluster index
        # )
        self.need_state_space_presolve_calculation_method = (
            need_state_space_presolve_calculation_method
        )
        self.need_states_top1_item_productivity_current_facing = (
            need_states_top1_item_productivity_current_facing
        )
        # Decision Variables
        self.x_vars = x_vars  # indices: [i, f, c, g]
