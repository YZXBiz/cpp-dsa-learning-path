import pandas as pd
import numpy as np
from oxygen.conf.context import context
import logging

log = logging.getLogger(__name__)


def add_brand_POD_constraints(
    df_optimization_master_data: pd.DataFrame,
    df_brand_POD_active: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adds brand POD (Points of Distribution) constraints to the optimization master data.

    This function merges user-defined brand POD requirements into the optimization master
    data, tagging constraints as either "Hard_User_Input" or "Not_Enforced" based on the
    presence of minimum and maximum POD values. It also fills missing values for
    `min_brand_POD` with 0 and `max_brand_POD` with an arbitrarily large value
    (context.optimization.model_formulation.store_count_upper_bound * context.optimization.model_formulation.item_no_count_upper_bound_per_brand).
    After merging and tagging, it checks the feasibility of the brand POD constraints.

    Args:
        df_optimization_master_data (pd.DataFrame): The master data for optimization.
        df_brand_POD_active (pd.DataFrame): DataFrame containing active brand POD requirements.

    Returns:
        pd.DataFrame: The modified optimization master data with added brand POD constraints.
    """
    # Step 1: merge the User Input Brand POD requirements
    df_optimization_master_data_POD = df_optimization_master_data.merge(
        df_brand_POD_active,
        on=context.groupby_granularity.optimizer + ["brand_name"],
        how="left",
    )

    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD["min_brand_POD"].notna()
        | df_optimization_master_data_POD["max_brand_POD"].notna(),
        "brand_POD_enforce",
    ] = "Hard_User_Input"

    df_optimization_master_data_POD[
        "brand_POD_enforce"
    ] = df_optimization_master_data_POD["brand_POD_enforce"].fillna("Not_Enforced")

    # fillna with 0 for min_brand_POD and context.optimization.model_formulation.store_count_upper_bound * context.optimization.model_formulation.item_no_count_upper_bound_per_brand for max_brand_POD
    df_optimization_master_data_POD["min_brand_POD"] = df_optimization_master_data_POD[
        "min_brand_POD"
    ].fillna(0)
    df_optimization_master_data_POD["max_brand_POD"] = df_optimization_master_data_POD[
        "max_brand_POD"
    ].fillna(
        context.optimization.model_formulation.store_count_upper_bound
        * context.optimization.model_formulation.item_no_count_upper_bound_per_brand
    )

    unique_brand_POD_constraints_cols = context.groupby_granularity.optimizer + [
        "brand_name"
    ]
    # check feasibility of the brand POD constraints
    df_optimization_master_data_POD = tag_active_brand_POD_constraints(
        df_optimization_master_data_POD,
        unique_brand_POD_constraints_cols,
    )

    return df_optimization_master_data_POD


def tag_active_brand_POD_constraints(
    df_optimization_master_data_POD: pd.DataFrame,
    unique_brand_POD_constraints_cols: list,
):
    """
    Tags active brand POD constraints and updates the `min_brand_POD` and `max_brand_POD` statuses based on feasibility.

    Args:
        df_optimization_master_data_POD (pd.DataFrame): The DataFrame containing brand POD optimization data.
        unique_brand_POD_constraints_cols (list): List of columns to uniquely identify brand POD constraints.

    Returns:
        pd.DataFrame: Updated DataFrame with `brand_POD_feasible`, `min_brand_POD_active`, and `max_brand_POD_active` columns.
    """
    key = "brand"

    temp_df = df_optimization_master_data_POD[
        unique_brand_POD_constraints_cols
        + [
            "item_no_nbr",
            "n_stores_item_no_exist_after_forced_drop",
            "n_stores_item_no_forced_exist",
        ]
    ].drop_duplicates()

    assert len(temp_df) == len(
        temp_df[unique_brand_POD_constraints_cols + ["item_no_nbr"]].drop_duplicates()
    )

    temp_df[f"n_stores_{key}_exist_after_forced_drop"] = temp_df.groupby(
        unique_brand_POD_constraints_cols
    )["n_stores_item_no_exist_after_forced_drop"].transform("sum")

    temp_df[f"n_stores_{key}_forced_exist"] = temp_df.groupby(
        unique_brand_POD_constraints_cols
    )["n_stores_item_no_forced_exist"].transform("sum")

    df_optimization_master_data_POD = df_optimization_master_data_POD.merge(
        temp_df[
            [f"n_stores_{key}_exist_after_forced_drop", f"n_stores_{key}_forced_exist"]
            + unique_brand_POD_constraints_cols
        ].drop_duplicates(),
        on=unique_brand_POD_constraints_cols,
        how="left",
    )

    df_optimization_master_data_POD[f"{key}_POD_feasible"] = (
        (
            df_optimization_master_data_POD[f"min_{key}_POD"]
            <= df_optimization_master_data_POD[
                f"n_stores_{key}_exist_after_forced_drop"
            ]
        )
        & (
            df_optimization_master_data_POD[f"max_{key}_POD"]
            >= df_optimization_master_data_POD[f"n_stores_{key}_forced_exist"]
        )
        & (
            df_optimization_master_data_POD[f"min_{key}_POD"]
            <= df_optimization_master_data_POD[f"max_{key}_POD"]
        )
    ).astype(int)

    df_POD_not_feasible_unique = df_optimization_master_data_POD[
        df_optimization_master_data_POD[f"{key}_POD_feasible"] == 0
    ][
        unique_brand_POD_constraints_cols
        + [f"{key}_POD_enforce", f"min_{key}_POD", f"max_{key}_POD"]
    ].drop_duplicates()

    log.info(
        f"{len(df_POD_not_feasible_unique)} {key} are not feasible with the {key} POD constraints"
    )
    log.info(df_POD_not_feasible_unique)

    # Override min_brand_POD to 0 if brand_POD_feasible == 0
    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD[f"{key}_POD_feasible"] == 0, f"min_{key}_POD"
    ] = 0
    # Override max_brand_POD to a large number (context.optimization.model_formulation.store_count_upper_bound * context.optimization.model_formulation.item_no_count_upper_bound_per_brand) if brand_POD_feasible == 0
    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD[f"{key}_POD_feasible"] == 0, f"max_{key}_POD"
    ] = (
        context.optimization.model_formulation.store_count_upper_bound
        * context.optimization.model_formulation.item_no_count_upper_bound_per_brand
    )

    # label whether min_brand_POD and max_brand_POD is active
    df_optimization_master_data_POD[f"min_{key}_POD_active"] = (
        (df_optimization_master_data_POD[f"min_{key}_POD"] > 0)
        & (
            df_optimization_master_data_POD[f"min_{key}_POD"]
            > df_optimization_master_data_POD[f"n_stores_{key}_forced_exist"]
        )
        & (df_optimization_master_data_POD[f"{key}_POD_feasible"] == 1)
    ).astype(int)

    df_optimization_master_data_POD[f"max_{key}_POD_active"] = (
        (
            df_optimization_master_data_POD[f"max_{key}_POD"]
            < df_optimization_master_data_POD[f"n_stores_{key}_exist_after_forced_drop"]
        )
        & (df_optimization_master_data_POD[f"{key}_POD_feasible"] == 1)
    ).astype(int)

    cols_to_report = unique_brand_POD_constraints_cols + [
        f"{key}_POD_enforce",
        f"min_{key}_POD",
        f"max_{key}_POD",
    ]
    df_min_brand_POD_active = df_optimization_master_data_POD[
        df_optimization_master_data_POD[f"min_{key}_POD_active"] == 1
    ][cols_to_report].drop_duplicates()
    df_max_brand_POD_active = df_optimization_master_data_POD[
        df_optimization_master_data_POD[f"max_{key}_POD_active"] == 1
    ][cols_to_report].drop_duplicates()
    log.info(
        f"{len(df_min_brand_POD_active)} {key} are having an active min_{key}_POD constraints"
    )
    log.info(
        f"{len(df_max_brand_POD_active)} {key} are having an active max_{key}_POD constraints"
    )
    return df_optimization_master_data_POD
