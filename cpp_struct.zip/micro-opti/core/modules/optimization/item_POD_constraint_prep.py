import pandas as pd
import numpy as np
from core.utils.space_context.run_versioning import complete_file_path
from core.schemas.client_input.schemas import (
    ItemPODConstraintsAdded,
)
from oxygen.conf.context import context
import logging

log = logging.getLogger(__name__)


def calculate_n_stores_item_no_exist_after_forced_facings(
    df_optimization_master_input: pd.DataFrame,
) -> pd.DataFrame:
    """
    Calculates the total number of stores per `item_no_nbr` after accounting for forced positive facings based on the
    `min_forced_facings_guardrails`.
    Stores are included in the count if the item is forced to have a positive facings.

    Args:
        df_optimization_master_input (pd.DataFrame): The input DataFrame containing optimization data.

    Returns:
        pd.DataFrame: Updated DataFrame with the column `n_stores_item_no_forced_exist` added.
    """
    col_to_calculate_drop_store_num = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level
    )
    df_optimization_master_input_unique = df_optimization_master_input[
        col_to_calculate_drop_store_num
        + [
            "n_stores",
            "min_forced_facings_guardrails",
        ]
    ].drop_duplicates()

    assert len(df_optimization_master_input_unique) == len(
        df_optimization_master_input_unique[
            col_to_calculate_drop_store_num
        ].drop_duplicates()
    )

    df_optimization_master_input_unique[
        "n_stores_item_no_forced_in_cluster_fixture"
    ] = df_optimization_master_input_unique.apply(
        lambda x: x["n_stores"] if (x["min_forced_facings_guardrails"] > 0) else 0,
        axis=1,
    )

    df_optimization_master_input = df_optimization_master_input.merge(
        df_optimization_master_input_unique[
            col_to_calculate_drop_store_num + ["n_stores_item_no_forced_in_cluster_fixture"]
        ],
        on=col_to_calculate_drop_store_num,
        how="left",
    )

    df_optimization_master_input[
        "n_stores_item_no_forced_exist"
    ] = df_optimization_master_input.groupby(
        context.groupby_granularity.optimizer + ["item_no_nbr"]
    )[
        "n_stores_item_no_forced_in_cluster_fixture"
    ].transform(
        "sum"
    )
    df_optimization_master_input = df_optimization_master_input.drop(
        columns=["n_stores_item_no_forced_in_cluster_fixture"]
    )

    return df_optimization_master_input


def calculate_n_stores_item_no_exist_after_forced_drop(
    df_optimization_master_input: pd.DataFrame,
) -> pd.DataFrame:
    """
    Calculates the total number of stores per `item_no_nbr` after accounting for forced drops based on the
     `max_forced_facings_guardrails`=0.
    Stores are included in the count if the item is not forced to drop.

    Args:
        df_optimization_master_input (pd.DataFrame): The input DataFrame containing optimization data.

    Returns:
        pd.DataFrame: Updated DataFrame with the column `n_stores_item_no_exist_after_forced_drop` added.
    """
    col_to_calculate_drop_store_num = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level
    )
    df_optimization_master_input_unique = df_optimization_master_input[
        col_to_calculate_drop_store_num
        + [
            "n_stores",
            "min_forced_facings_guardrails",
            "max_forced_facings_guardrails",
        ]
    ].drop_duplicates()

    assert len(df_optimization_master_input_unique) == len(
        df_optimization_master_input_unique[
            col_to_calculate_drop_store_num
        ].drop_duplicates()
    )

    df_optimization_master_input_unique[
        "n_stores_item_no_exist_cluster_fixture"
    ] = df_optimization_master_input_unique.apply(
        lambda x: x["n_stores"]
        if (
            (
                (x["max_forced_facings_guardrails"] > 0)
                | pd.isna(x["max_forced_facings_guardrails"])
            )
        )
        else 0,
        axis=1,
    )

    df_optimization_master_input = df_optimization_master_input.merge(
        df_optimization_master_input_unique[
            col_to_calculate_drop_store_num + ["n_stores_item_no_exist_cluster_fixture"]
        ],
        on=col_to_calculate_drop_store_num,
        how="left",
    )

    df_optimization_master_input[
        "n_stores_item_no_exist_after_forced_drop"
    ] = df_optimization_master_input.groupby(
        context.groupby_granularity.optimizer + ["item_no_nbr"]
    )[
        "n_stores_item_no_exist_cluster_fixture"
    ].transform(
        "sum"
    )
    df_optimization_master_input = df_optimization_master_input.drop(
        columns=["n_stores_item_no_exist_cluster_fixture"]
    )

    return df_optimization_master_input


def determine_regional_items(
    df_optimization_master_input: pd.DataFrame,
) -> pd.DataFrame:
    # Add a True/False col to indicate whether final_cluster_labels is regional cluster or not
    """
    Determines whether an item is regional by analyzing `final_cluster_labels` and assigning a new column
    `is_regional_item` (1 for regional, 0 for non-regional).

    Args:
        df_optimization_master_input (pd.DataFrame): The input DataFrame containing optimization data, including cluster labels.

    Returns:
        pd.DataFrame: Updated DataFrame with the column `is_regional_item` added, indicating if an item is regional.
    """
    regional_clusters = context.store_clustering.regional_clusters.copy()
    df_optimization_master_input["is_regional_cluster"] = (
        df_optimization_master_input["final_cluster_labels"]
        .str.contains("|".join(regional_clusters), case=False)
        .astype(int)
    )

    df_optimization_master_input_filter = df_optimization_master_input[
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_sku_cluster_level
        + ["is_regional_cluster"]
    ].drop_duplicates()

    df_optimization_master_input_filter[
        "distinct_final_cluster_labels"
    ] = df_optimization_master_input_filter.groupby(
        context.groupby_granularity.optimizer + ["item_no_nbr"]
    )[
        "final_cluster_labels"
    ].transform(
        "nunique"
    )

    df_optimization_master_input_filter[
        "sum_is_regional_cluster"
    ] = df_optimization_master_input_filter.groupby(
        context.groupby_granularity.optimizer + ["item_no_nbr"]
    )[
        "is_regional_cluster"
    ].transform(
        "sum"
    )

    df_optimization_master_input_filter["is_regional_item"] = np.where(
        df_optimization_master_input_filter["sum_is_regional_cluster"]
        == df_optimization_master_input_filter["distinct_final_cluster_labels"],
        1,
        0,
    )

    df_optimization_master_input_filter = df_optimization_master_input_filter[
        context.groupby_granularity.optimizer + ["item_no_nbr", "is_regional_item"]
    ].drop_duplicates()

    df_optimization_master_input = df_optimization_master_input.merge(
        df_optimization_master_input_filter,
        on=context.groupby_granularity.optimizer + ["item_no_nbr"],
        how="left",
    )

    return df_optimization_master_input


def calculate_item_no_specific_store_count(
    df_optimization_master_data_POD: pd.DataFrame,
) -> pd.DataFrame:
    """
    Calculates the total number of stores for each `item_no_nbr`, accounting for regional and non-regional clusters,
    and updates the column `n_stores_item_no_exist_total`.

    Args:
        df_optimization_master_data_POD (pd.DataFrame): DataFrame containing POD data including store and cluster information.

    Returns:
        pd.DataFrame: Updated DataFrame with the calculated `n_stores_item_no_exist_total` column.
    """

    def calculate_item_no_store_count(group):
        if group["is_regional_item"].iloc[0] == 1:
            # If is_regional_item = 1, Sum n_stores_cluster_total for unique opti_item_scope_cluster, item_no_nbr where is_regional_cluster == 1
            regional_sum = (
                group[group["is_regional_cluster"] == 1]
                .drop_duplicates(subset=["opti_item_scope_cluster", "item_no_nbr"])[
                    "n_stores_cluster_total"
                ]
                .sum()
            )
            return regional_sum
        else:
            # If is_regional_item = 0
            if group["is_regional_cluster"].any() == 0:
                # No regional cluster, return n_stores_cluster_total for this group
                return group["n_stores_cluster_total"].iloc[0]
            else:
                # If there are regional clusters (is_regional_cluster == 1)
                # Step 1: Sum n_stores_cluster_total for rows where is_regional_cluster == 0
                non_regional_sum = group[group["is_regional_cluster"] == 0][
                    "n_stores_cluster_total"
                ].iloc[0]

                # Step 2: Sum n_stores_cluster_total for unique opti_item_scope_cluster, item_no_nbr where is_regional_cluster == 1
                regional_sum = (
                    group[group["is_regional_cluster"] == 1]
                    .drop_duplicates(subset=["opti_item_scope_cluster", "item_no_nbr"])[
                        "n_stores_cluster_total"
                    ]
                    .sum()
                )

                # Return the sum of non-regional and regional sums
                return non_regional_sum + regional_sum

    df_optimization_master_data_POD[
        "n_stores_item_no_exist_total"
    ] = df_optimization_master_data_POD.groupby(
        context.groupby_granularity.optimizer + ["item_no_nbr"]
    )[
        "n_stores_cluster_total"
    ].transform(
        lambda x: calculate_item_no_store_count(
            df_optimization_master_data_POD.loc[x.index]
        )
    )
    return df_optimization_master_data_POD


def tag_active_item_POD_constraints(
    df_optimization_master_data_POD: pd.DataFrame,
    unique_POD_constraints_cols: list,
):
    """
    Tags active item POD constraints and updates the `min_POD` and `max_POD` statuses based on feasibility.

    Args:
        df_optimization_master_data_POD (pd.DataFrame): The DataFrame containing POD optimization data.
        unique_POD_constraints_cols (list): List of columns to uniquely identify POD constraints.

    Returns:
        pd.DataFrame: Updated DataFrame with `POD_feasible`, `min_POD_active`, and `max_POD_active` columns.
    """
    df_optimization_master_data_POD["POD_feasible"] = (
        (
            df_optimization_master_data_POD["min_POD"]
            <= df_optimization_master_data_POD["n_stores_item_no_exist_after_forced_drop"]
        )
        & (
            df_optimization_master_data_POD["max_POD"]
            >= df_optimization_master_data_POD["n_stores_item_no_forced_exist"]
        )
        & (
            df_optimization_master_data_POD["min_POD"]
            <= df_optimization_master_data_POD["max_POD"]
        )
    ).astype(int)

    df_POD_not_feasible_unique = df_optimization_master_data_POD[
        df_optimization_master_data_POD["POD_feasible"] == 0
    ][
        unique_POD_constraints_cols + ["POD_enforce", "min_POD", "max_POD"]
    ].drop_duplicates()

    log.info(
        f"{len(df_POD_not_feasible_unique)} item_no are not feasible with the POD constraints"
    )
    log.info(df_POD_not_feasible_unique)

    # Override min_POD to 0 if POD_feasible == 0
    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD["POD_feasible"] == 0, "min_POD"
    ] = 0
    # Override max_POD to a large number (context.optimization.model_formulation.item_no_count_upper_bound_per_brand) if POD_feasible == 0
    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD["POD_feasible"] == 0, "max_POD"
    ] = context.optimization.model_formulation.store_count_upper_bound

    # label whether min_POD and max_POD is active
    df_optimization_master_data_POD["min_POD_active"] = (
        (df_optimization_master_data_POD["min_POD"] > 0)
        & (
            df_optimization_master_data_POD["min_POD"]
            > df_optimization_master_data_POD["n_stores_item_no_forced_exist"]
        )
        & (df_optimization_master_data_POD["POD_feasible"] == 1)
    ).astype(int)

    df_optimization_master_data_POD["max_POD_active"] = (
        (
            df_optimization_master_data_POD["max_POD"]
            < df_optimization_master_data_POD["n_stores_item_no_exist_after_forced_drop"]
        )
        & (df_optimization_master_data_POD["POD_feasible"] == 1)
    ).astype(int)

    df_min_POD_active = df_optimization_master_data_POD[
        df_optimization_master_data_POD["min_POD_active"] == 1
    ][
        unique_POD_constraints_cols + ["POD_enforce", "min_POD", "max_POD"]
    ].drop_duplicates()
    df_max_POD_active = df_optimization_master_data_POD[
        df_optimization_master_data_POD["max_POD_active"] == 1
    ][
        unique_POD_constraints_cols + ["POD_enforce", "min_POD", "max_POD"]
    ].drop_duplicates()
    log.info(f"{len(df_min_POD_active)} item_no are having an active min_POD constraints")
    log.info(f"{len(df_max_POD_active)} item_no are having an active max_POD constraints")
    return df_optimization_master_data_POD


def get_regional_and_non_regional_store_counts(
    df_optimization_master_data_POD: pd.DataFrame,
):
    """
    Calculates the total store counts (`n_stores_cluster_total`) for regional and non-regional clusters.

    Args:
        df_optimization_master_data_POD (pd.DataFrame): The input DataFrame containing POD data and store cluster information.

    Returns:
        pd.DataFrame: Updated DataFrame with the new column `n_stores_cluster_total` indicating the total store count for each cluster.
    """
    unique_cols = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_level
        + [
            "opti_item_scope_cluster",
            "is_regional_cluster",
        ]
    )
    store_count = df_optimization_master_data_POD[
        unique_cols + ["n_stores"]
    ].drop_duplicates()

    # Step 1: Calculate total n_stores where is_regional_cluster == 0
    n_stores_sum_non_regional = store_count.loc[
        store_count["is_regional_cluster"] == 0, "n_stores"
    ].sum()

    # Step 2: Calculate n_stores_sum based on the given conditions
    store_count["n_stores_cluster_total"] = store_count.apply(
        lambda row: n_stores_sum_non_regional
        if row["is_regional_cluster"] == 0
        else store_count.loc[
            (store_count["is_regional_cluster"] == 1)
            & (
                store_count["opti_item_scope_cluster"] == row["opti_item_scope_cluster"]
            ),
            "n_stores",
        ].sum(),
        axis=1,
    )

    df_optimization_master_data_POD = df_optimization_master_data_POD.merge(
        store_count[unique_cols + ["n_stores_cluster_total"]],
        on=unique_cols,
        how="left",
    )

    return df_optimization_master_data_POD


def override_POD_constraints_for_exempted_items(
    df_optimization_master_data_POD: pd.DataFrame,
    df_item_POD_exempt: pd.DataFrame,
) -> pd.DataFrame:
    """
    Overrides POD constraints for items that are exempt from POD rules.

    This function updates specified columns in `df_optimization_master_data_POD` for rows that match
    entries in `df_item_POD_exempt`. The matching is based on a set of keys defined in
    `context.groupby_granularity.optimizer` plus "item_no_nbr". For matching rows, the following updates
    are applied:
        - Sets "POD_enforce" to "Exempt".
        - Sets "min_POD_active" to 0. So constraints are not added to the optimization model.
        - Sets "max_POD_active" to 0. So constraints are not added to the optimization model.

    Args:
        df_optimization_master_data_POD (pd.DataFrame): DataFrame containing item POD constraints with
                                                        columns like "POD_enforce", "min_POD_active",
                                                        "max_POD_active".
        df_item_POD_exempt (pd.DataFrame): DataFrame containing a list of items exempt from POD
                                           constraints, including matching columns for identification.

    Returns:
        pd.DataFrame: The updated `df_optimization_master_data_POD` DataFrame with POD constraints
                      overridden for exempted items.
    """
    merge_keys = context.groupby_granularity.optimizer + ["item_no_nbr"]

    # Perform a left merge to identify rows in df_optimization_master_data_POD that match df_item_POD_exempt
    df_merged = df_optimization_master_data_POD.merge(
        df_item_POD_exempt, on=merge_keys, how="left", indicator=True
    )

    # Report/Log rows to be updated based on the "_merge" column
    rows_to_update = df_merged[df_merged["_merge"] == "both"]
    if not rows_to_update.empty:
        log.info(
            "The following rows will have POD constraints overridden as 'Exempt': "
        )
        log.info(rows_to_update[merge_keys].drop_duplicates().to_string(index=False))
    else:
        log.info("No rows found for POD exemption.")
        return df_optimization_master_data_POD

    # Update the POD_enforce, min_POD_active, max_POD_active columns for rows found in df_item_POD_exempt
    override_values = {
        "POD_enforce": "Exempt",
        "min_POD_active": 0,
        "max_POD_active": 0,
    }

    for col, override_value in override_values.items():
        df_optimization_master_data_POD[col] = df_merged.apply(
            lambda row: override_value if row["_merge"] == "both" else row[col], axis=1
        )

    return df_optimization_master_data_POD


def add_item_POD_constraints(
    df_optimization_master_data: pd.DataFrame,
    df_item_POD_active: pd.DataFrame,
    df_item_POD_exempt: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adds and calculates item-level POD constraints (min_POD and max_POD) and tags their feasibility for each item.

    This function performs the following steps:
    1. Merges the user-defined POD constraints from `df_item_POD_active` into the optimization data.
    2. Determines the appropriate `min_POD_threshold` for each item based on whether it's a regional or non-regional item.
    3. Calculates the total store count for regional and non-regional clusters and updates the total store count for items appearing in both.
    4. Fills in missing `min_POD` and `max_POD` values using default thresholds if enabled by the configuration.
    5. Validates the uniqueness of POD constraints.
    6. Tags and checks the feasibility of POD constraints, determining active constraints for each item.
    7. If item are exempted from POD constraints, the `min_POD` and `max_POD` are set to 0 and 999999 (config) and the item is tagged as exempt.

    Args:
        df_optimization_master_data (pd.DataFrame): The main DataFrame containing optimization data.
        df_item_POD_active (pd.DataFrame): The DataFrame containing user-input POD constraints.
        df_item_POD_exempt (pd.DataFrame): The DataFrame containing exempted items from POD constraints.

    Returns:
        pd.DataFrame: Updated DataFrame with calculated and tagged POD constraints.
    """
    # Step 1: merge the User Input Item POD requirements
    df_optimization_master_data_POD = df_optimization_master_data.merge(
        df_item_POD_active,
        on=(context.groupby_granularity.optimizer + ["item_no_nbr"]),
        how="left",
    )
    df_optimization_master_data_POD.loc[
        df_optimization_master_data_POD["min_POD"].notna()
        | df_optimization_master_data_POD["max_POD"].notna(),
        "POD_enforce",
    ] = "Hard_User_Input"

    # Step 2: calculate the default POD and the min_POD/max_POD for each dept - item_no
    # Get the regional items and non-regional items POD threshold
    df_optimization_master_data_POD[
        "min_POD_threshold"
    ] = df_optimization_master_data_POD.apply(
        lambda row: context.optimization_config.model_formulation.regional_item_POD_threshold
        if row["is_regional_item"] == 1
        else context.optimization_config.model_formulation.non_regional_item_POD_threshold,
        axis=1,
    )

    df_optimization_master_data_POD = get_regional_and_non_regional_store_counts(
        df_optimization_master_data_POD
    )
    # for a non-regional item, store count needs an update if the item exist in both regional cluster and non-regional cluster
    df_optimization_master_data_POD = calculate_item_no_specific_store_count(
        df_optimization_master_data_POD
    )

    # adopt the Hard_User_Input rather than default POD assumption, so fill na min_POD/max_POD here
    if (
        context.optimization_config.model_formulation.enable_default_POD_constraints
        == True
    ):
        df_optimization_master_data_POD["min_POD"] = df_optimization_master_data_POD[
            "min_POD"
        ].fillna(
            df_optimization_master_data_POD["min_POD_threshold"]
            * df_optimization_master_data_POD["n_stores_item_no_exist_total"]
        )
        df_optimization_master_data_POD["max_POD"] = df_optimization_master_data_POD[
            "max_POD"
        ].fillna(df_optimization_master_data_POD["n_stores_item_no_exist_total"])
        df_optimization_master_data_POD[
            "POD_enforce"
        ] = df_optimization_master_data_POD["POD_enforce"].fillna("Soft_Default_Config")
    else:
        df_optimization_master_data_POD["min_POD"] = df_optimization_master_data_POD[
            "min_POD"
        ].fillna(0)
        df_optimization_master_data_POD["max_POD"] = df_optimization_master_data_POD[
            "max_POD"
        ].fillna(df_optimization_master_data_POD["n_stores_item_no_exist_total"])
        df_optimization_master_data_POD[
            "POD_enforce"
        ] = df_optimization_master_data_POD["POD_enforce"].fillna("Soft_Default_Config")

    unique_POD_constraints_cols = context.groupby_granularity.optimizer + ["item_no_nbr"]

    assert len(
        df_optimization_master_data_POD[unique_POD_constraints_cols].drop_duplicates()
    ) == len(
        df_optimization_master_data_POD[
            unique_POD_constraints_cols + ["POD_enforce", "min_POD", "max_POD"]
        ].drop_duplicates()
    )

    # check feasibility of the POD constraints
    df_optimization_master_data_POD = tag_active_item_POD_constraints(
        df_optimization_master_data_POD,
        unique_POD_constraints_cols,
    )

    # Override POD constraints for exempted items -> set min_POD_active and max_POD_active to 0
    df_optimization_master_data_POD = override_POD_constraints_for_exempted_items(
        df_optimization_master_data_POD,
        df_item_POD_exempt,
    )

    df_optimization_item_POD_constraints = df_optimization_master_data_POD[
        context.groupby_granularity.optimizer
        + [
            "item_no_nbr",
            "POD_enforce",
            "is_regional_item",
            "min_POD",
            "max_POD",
            "n_stores_item_no_exist_total",
            "n_stores_item_no_forced_exist",
            "n_stores_item_no_exist_after_forced_drop",
            "POD_feasible",
            "min_POD_active",
            "max_POD_active",
        ]
    ].drop_duplicates()

    path_items_POD_constraints_added = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.manual_item_POD_constraints_final,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
    )
    ItemPODConstraintsAdded.save(
        df=df_optimization_item_POD_constraints,
        file_path=path_items_POD_constraints_added,
        root=context.data_stores.client_input_process.save_to_datastores_root,
    )

    return df_optimization_master_data_POD
