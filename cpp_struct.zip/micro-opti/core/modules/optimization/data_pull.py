import pandas as pd
import numpy as np
from glob import glob
import warnings

from oxygen.conf.settings import settings
from oxygen.conf.context import context

import logging
import ipdb

log = logging.getLogger(__name__)
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")


def get_ignore_items() -> str:
    ls_skus_to_ignore = []

    for file_name in glob(f"{context.data_stores.raw_data.file_path.ignore_items}/*.xlsx"):
        df = pd.read_excel(file_name, engine="openpyxl")
        ls_skus_to_ignore.append(df)

    df_skus_to_ignore = pd.concat(ls_skus_to_ignore, ignore_index=True)
    df_skus_to_ignore["indcator"] = 1

    # Make sure columns are in the right order
    df_skus_to_ignore = df_skus_to_ignore[["product_id", "POG ID", "indcator"]]
    return ', '.join(str(tuple(sublist)) for sublist in df_skus_to_ignore.values)


def pull_snowflake_data():
    # If need state timestamp is Null, set to large value in the future
    if context.data_stores.raw_data.table_filters.need_state_timestamp is None:
        need_state_timestamp = 20601231235959
    else:
        need_state_timestamp = context.data_stores.raw_data.table_filters.need_state_timestamp
    
    # If need curves timestamp is Null, set to large value in the future
    if context.data_stores.raw_data.table_filters.curves_timestamp is None:
        curves_timestamp = 20601231235959
    else:
        curves_timestamp = context.data_stores.raw_data.table_filters.curves_timestamp

    # Get linear space adjustment values
    if context.optimization.data_prep.apply_slow_moving_lin_space_adjustment:
        linear_space_to_keep = 1 - context.optimization.data_prep.slow_moving_lin_space_adjustment
    else:
        linear_space_to_keep = 1
        
    # Create lists for in scope planograms
    in_scope_pogs = tuple([str(x) for x in context.optimization.data_prep.in_scope_pogs])

    df_base_sql_query = f"""
        WITH LATEST_NS_DATA AS (
            SELECT * ,
            PRODUCT_ID AS ITEM_NO_NBR,
            TIMESTAMP AS ID
            FROM {context.data_stores.raw_data.table_name.need_state_table}
            WHERE TIMESTAMP = (
                SELECT MAX(TIMESTAMP)
                FROM {context.data_stores.raw_data.table_name.need_state_table}
                    WHERE TIMESTAMP <= {need_state_timestamp}
                    AND CASE
                        WHEN PLANOGRAM_DSC = 'HOUSEHOLD' THEN REPLACE(STANDARDIZED_DSC, 'LAUNDRY', 'HOUSEHOLD')
                        WHEN PLANOGRAM_DSC = 'BEVERAGE COOLER' THEN REPLACE(STANDARDIZED_DSC, 'SODA', 'BEVERAGES')
                        WHEN PLANOGRAM_DSC = 'COLD REMEDIES'
                        AND PRODUCT_ID IN (550147, 553771, 668672, 641986, 289586)
                        THEN REPLACE(STANDARDIZED_DSC, 'HOME DIAGNOSTICS', 'COLD REMEDIES')
                        ELSE STANDARDIZED_DSC
                    END IN ('{"', '".join(context.data_stores.raw_data.categories)}')
            )
        ), SUB_PLANO_MAPPING AS (
            SELECT DISTINCT
                PV.STORE_NBR,
                PV.PLANOGRAM_NBR,
                PV.SPECIAL_VERSION_ID,
                ISC.SKU_NBR,
                CASE
                    WHEN PV.PLANOGRAM_NBR = 9751 AND ISC.SUB_PLANO IS NULL THEN '_SHELVE'
                    WHEN ISC.SUB_PLANO IS NOT NULL THEN CONCAT('_', ISC.SUB_PLANO)
                    ELSE ''
                END AS SUB_PLANO
            FROM {context.data_stores.raw_data.table_name.planogram_store_version} PV
            LEFT JOIN {context.data_stores.raw_data.table_name.planogram_item_scope} ISC
            ON PV.PLANOGRAM_NBR = ISC.PLANOGRAM_NBR 
               AND PV.SPECIAL_VERSION_ID = ISC.SPECIAL_VERSION_ID
            WHERE ISC.SKU_NBR IS NOT NULL
        ), MODIFIED_PLANO AS (
            SELECT PM.*,
                CASE 
                    WHEN PM.PLANO_CAT_DSC = 'HOUSEHOLD' THEN REPLACE(CAT_DSC, 'LAUNDRY', 'HOUSEHOLD')
                    WHEN PM.PLANO_CAT_DSC = 'BEVERAGES' THEN REPLACE(CAT_DSC, 'SODA', 'BEVERAGES')
                    WHEN PM.PLANO_CAT_DSC = 'COLD REMEDIES' 
                         AND PM.SKU_NBR IN (550147, 553771, 668672, 641986, 289586) 
                         THEN REPLACE(PM.CAT_DSC, 'HOME DIAGNOSTICS', 'COLD REMEDIES')
                    ELSE CAT_DSC
                END AS CLEAN_CAT_DSC
            FROM {context.data_stores.raw_data.table_name.planogram_table} PM
            WHERE TRUE
            AND (planogram_dsc, planogram_version_id) not in (('SHAVING NEEDS', 602))
            AND risk_flag not in ('ERS')
        ), DISC_ITEMS AS (
            SELECT DISTINCT 
                CAST(D."sku" AS INTEGER) AS ITEM_NO_NBR,
                P.PLANOGRAM_NBR AS PLANO_ID,
                1 AS DISC_ITEM
                FROM {context.data_stores.raw_data.constraint_parameters.disc_table} D
                LEFT JOIN {context.data_stores.raw_data.table_name.planogram_table} P
                ON D."sku" = P.SKU_NBR
            UNION
            SELECT DISTINCT
                ITEM_NO_NBR,
                PLANOGRAM_NBR AS PLANO_ID,
                1 as DISC_ITEM
            FROM LATEST_NS_DATA
            WHERE "to_be_dropped" = True
            UNION
            SELECT DISTINCT
                SKU_NBR AS ITEM_NO_NBR,
                PLANOGRAM_NBR AS PLANO_ID,
                1 as DISC_ITEM
            FROM MODIFIED_PLANO
            LEFT JOIN {context.data_stores.raw_data.table_name.sku_hist_table}
            USING (SKU_NBR)
            WHERE PLANO_CAT_DSC = CLEAN_CAT_DSC AND PLANOGRAM_NBR IN {in_scope_pogs} 
                  AND DISCON_IND = 'Y' AND CURR_IND = 'Y'
            UNION
            SELECT DISTINCT
                ITEM_NO_NBR,
                PLANOGRAM_NBR AS PLANO_ID,
                1 as DISC_ITEM
            FROM LATEST_NS_DATA a
            LEFT JOIN {context.data_stores.raw_data.table_name.sku_hist_table} b
            on a.ITEM_NO_NBR = b.SKU_NBR
            WHERE PLANOGRAM_NBR IN {in_scope_pogs} 
                  AND DISCON_IND = 'Y' AND CURR_IND = 'Y'
        ), IGNORE_ITEMS AS (
            SELECT DISTINCT 
                COLUMN1 AS ITEM_NO_NBR,
                COLUMN2 AS PLANO_ID,
                COLUMN3 AS IGNORE_ITEM,
            FROM (
                VALUES {get_ignore_items()}
            )
        ), CLEAN_NS AS (
            SELECT DISTINCT
                ITEM_NO_NBR, 
                PLANOGRAM_NBR AS PLANO_ID,
                NEED_STATE,
                CDT,
                ID
            FROM LATEST_NS_DATA
        ), CLEAN_CLUSTERS AS (
            SELECT DISTINCT
                "store_nbr" AS STORE_NBR,
                CASE
                    WHEN "category" = 'ACNE_HSC' THEN 'ACNE/HSC'
                    WHEN "category" = 'DIET_NUTRITION' THEN 'DIET/NUTRITION'
                ELSE REPLACE("category", '_', ' ')
                END AS PLANO_CAT_DESC,
                "demand_cluster_labels" AS DEMAND_CLUSTER_LABELS,
                "rebalanced_demand_cluster_labels" AS ORIGINAL_CLUSTER_LABELS,
                "rebalanced_demand_cluster_labels" AS FINAL_CLUSTER_LABELS,
                V.PLANOGRAM_NBR,
                V.SPECIAL_VERSION_ID
            FROM {context.data_stores.raw_data.table_name.cluster_table} C
            LEFT JOIN {context.data_stores.raw_data.table_name.planogram_store_version} V
            ON C.CAT_DSC = V.PLANO_CAT_DSC AND C."store_nbr" = V.STORE_NBR
        ), PLANOGRAM_VERSION_MAP AS (
            SELECT DISTINCT
                PLANOGRAM_NBR,
                SPECIAL_VERSION_ID
            FROM {context.data_stores.raw_data.table_name.planogram_store_version}
            WHERE PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  AND PLANOGRAM_NBR IN {in_scope_pogs}
        ), ITEM_BASE AS (
            SELECT DISTINCT
                a.ITEM_NO_NBR,
                b.PLANOGRAM_NBR,
                b.SPECIAL_VERSION_ID,
                coalesce(c.REPLACED_SKU_NUMBER, a.ITEM_NO_NBR) AS CLONE_ITEM_ITEM_NO_NBR,
                CASE
                    WHEN a.ITEM_NO_NBR IN (SELECT DISTINCT UPC 
                                         FROM {context.data_stores.raw_data.table_name.new_skus_table})
                         THEN 'new'
                    ELSE 'existing'
                END AS SOURCE,
                'clone' as CLONE_TYPE,
                1 as CLONE_PCT
            FROM LATEST_NS_DATA a
            LEFT JOIN PLANOGRAM_VERSION_MAP b USING (PLANOGRAM_NBR)
            LEFT JOIN (SELECT DISTINCT UPC AS ITEM_NO_NBR, REPLACED_SKU_NUMBER
                        FROM {context.data_stores.raw_data.table_name.new_skus_table}) c USING (ITEM_NO_NBR)
            LEFT JOIN {context.data_stores.raw_data.table_name.planogram_item_scope} ISC
            ON a.ITEM_NO_NBR=ISC.SKU_NBR
            AND a.PLANOGRAM_NBR=ISC.PLANOGRAM_NBR
            WHERE "New Item" = True
            AND (
                (ISC.SPECIAL_VERSION_ID IS NOT NULL AND b.SPECIAL_VERSION_ID=ISC.SPECIAL_VERSION_ID)
                OR (ISC.SPECIAL_VERSION_ID IS NULL)
            )
            UNION
            SELECT DISTINCT 
                SKU_NBR AS ITEM_NO_NBR,
                PLANOGRAM_NBR,
                SPECIAL_VERSION_ID,
                SKU_NBR AS CLONE_ITEM_ITEM_NO_NBR,
                'existing' AS SOURCE,
                'existing' AS CLONE_TYPE,
                1 AS CLONE_PCT,
            FROM {context.data_stores.raw_data.table_name.planogram_item_scope}
            WHERE PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  AND PLANOGRAM_NBR IN {in_scope_pogs}
                  AND SKU_NBR IN (
                      SELECT DISTINCT SKU_NBR
                      FROM MODIFIED_PLANO
        
                      UNION ALL
        
                      SELECT DISTINCT REPLACED_SKU_NUMBER AS SKU_NBR
                      FROM {context.data_stores.raw_data.table_name.new_skus_table}
                      WHERE CATEGORY IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  )
                  AND SKU_NBR NOT IN (SELECT DISTINCT UPC AS ITEM_NO_NBR FROM {context.data_stores.raw_data.table_name.new_skus_table})
        ), ITEM_PLANO_BASE AS (
            SELECT DISTINCT 
                IB.ITEM_NO_NBR,
                IB.CLONE_ITEM_ITEM_NO_NBR,
                IB.SOURCE,
                IB.CLONE_PCT,
                IB.CLONE_TYPE,
                CC.FINAL_CLUSTER_LABELS,
                CC.ORIGINAL_CLUSTER_LABELS,
                CC.DEMAND_CLUSTER_LABELS,
                CC.SPECIAL_VERSION_ID,
                PM.STORE_NBR,
                PM.PLANOGRAM_VERSION_ID,
                COALESCE(SPM.SUB_PLANO, '') AS SUB_PLANO,
                CAST(PM.PLANOGRAM_NBR AS VARCHAR) AS PLANO_ID,
                PM.FIXTURE_WIDTH_NBR AS PLANO_FT,
                PM.FIXTURE_HEIGHT_NBR AS FIXTURE_SIZE,
                PM.PLANO_CAT_DSC AS PLANO_CAT_DESC,
                PM.CAT_NBR AS PLANO_CAT_ID,
                PM.CAT_NBR AS CATEGORY_LEVEL_DEPT_NBR,
                PM.PLANO_CAT_DSC AS CATEGORY_LEVEL_DEPT_NAME,
                PM.RISK_FLAG,
                PM.VOLUME_FLAG,
                PM.HORIZONTAL_FACINGS_NBR,
                CASE 
                    WHEN PM.PLANO_MDSE_GRP_DSC = 'CONSUMER HEALTH CARE' THEN 1
                    WHEN PM.PLANO_MDSE_GRP_DSC = 'GENERAL MERCHANDISE' THEN 2
                    WHEN PM.PLANO_MDSE_GRP_DSC = 'BEAUTY CARE' THEN 3
                    WHEN PM.PLANO_MDSE_GRP_DSC = 'EDIBLES' THEN 4
                    WHEN PM.PLANO_MDSE_GRP_DSC = 'PERSONAL CARE' THEN 5
                    ELSE NULL
                END AS DEPT_ID,
                UPPER(PM.PLANOGRAM_DSC) AS FIXTURE_DESC,
                COALESCE(CONCAT(PM.VOLUME_FLAG, '_', PM.RISK_FLAG), 'NONE_NONE') AS LP_FLAGS,
            FROM ITEM_BASE IB
            LEFT JOIN CLEAN_CLUSTERS CC
            ON IB.PLANOGRAM_NBR = CC.PLANOGRAM_NBR AND IB.SPECIAL_VERSION_ID = CC.SPECIAL_VERSION_ID
            LEFT JOIN MODIFIED_PLANO PM
            ON CC.STORE_NBR = PM.STORE_NBR AND CC.PLANO_CAT_DESC = PM.PLANO_CAT_DSC AND CC.PLANOGRAM_NBR = PM.PLANOGRAM_NBR
            LEFT JOIN SUB_PLANO_MAPPING SPM
            ON CC.STORE_NBR = SPM.STORE_NBR 
            AND CC.PLANOGRAM_NBR = SPM.PLANOGRAM_NBR 
            AND CC.SPECIAL_VERSION_ID = SPM.SPECIAL_VERSION_ID
            AND IB.ITEM_NO_NBR = SPM.SKU_NBR
            WHERE PM.PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  AND PM.PLANOGRAM_NBR IN {in_scope_pogs}
        ), CLEAN_PGM AS (
            SELECT DISTINCT 
                STORE_NBR,
                SKU_NBR AS ITEM_NO_NBR,
                PLANOGRAM_NBR AS PLANO_ID,
                HORIZONTAL_FACINGS_NBR AS HFACINGS,
                TOTAL_SALES,
            FROM MODIFIED_PLANO
            WHERE PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  AND PLANOGRAM_NBR IN {in_scope_pogs}
        ), LINEAR_SPACE AS (
            SELECT
                MP.STORE_NBR,
                MP.PLANOGRAM_NBR AS PLANO_ID,
                MP.FIXTURE_WIDTH_NBR AS PLANO_FT,
                MP.FIXTURE_HEIGHT_NBR AS FIXTURE_SIZE,
                SPM.SUB_PLANO AS SUB_PLANO,
                SUM(MP.HORIZONTAL_FACINGS_NBR * (CPS.SKU_WIDTH_NBR/12)) AS N_TOTAL_LINEAR_SPACE_DEPT_FIXTURE_FT 
            FROM MODIFIED_PLANO MP
            LEFT JOIN SUB_PLANO_MAPPING SPM
            USING (PLANOGRAM_NBR, STORE_NBR, SKU_NBR)
            LEFT JOIN {context.data_stores.raw_data.table_name.sku_table} CPS
            USING (SKU_NBR)
            LEFT JOIN IGNORE_ITEMS II
            ON MP.SKU_NBR = II.ITEM_NO_NBR AND MP.PLANOGRAM_NBR = II.PLANO_ID
            WHERE MP.PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                  AND II.IGNORE_ITEM IS NULL
                  AND MP.PLANOGRAM_NBR IN {in_scope_pogs}
            GROUP BY STORE_NBR, PLANOGRAM_NBR, FIXTURE_WIDTH_NBR, FIXTURE_HEIGHT_NBR, SUB_PLANO
        ), VENDOR_MAPPING AS (
            SELECT 
                VENDOR_NUMBER,
                VENDOR_NM AS VENDOR_NAME
            FROM (
                SELECT 
                    VENDOR_NBR AS VENDOR_NUMBER,
                    VENDOR_NM,
                    ROW_NUMBER() OVER (PARTITION BY VENDOR_NBR ORDER BY COUNT(*) DESC, VENDOR_NM) as rn
                FROM {context.data_stores.raw_data.table_name.vendor_table}
                WHERE VENDOR_NBR IS NOT NULL AND VENDOR_NM IS NOT NULL
                GROUP BY VENDOR_NBR, VENDOR_NM
            )
            WHERE rn = 1
        ), PRODUCT_INFO AS (
            SELECT DISTINCT 
                S.SKU_NBR AS ITEM_NO_NBR,
                S.SKU_DSC AS ITEM_NO_DESC,
                V.VENDOR_NM AS VENDOR_NAME,
                S.VENDOR_NBR AS VENDOR_NUMBER,
                S.BRAND_DSC AS BRAND_NAME,
                S.SEGMENT_DSC AS SEG_DSC,
                S.SUBCATEGORY_DSC AS SUBCAT_DSC,
                S.SKU_HEIGHT_NBR/12 AS PROD_UNIT_HEIGHT_FT,
                S.SKU_WIDTH_NBR/12 AS PROD_UNIT_WIDTH_FT,
                S.SKU_DEPTH_NBR/12 AS PROD_UNIT_DEPTH_FT,
                CASE 
                    WHEN S.PRIVATE_LABEL_IND = 'N' THEN 0
                    WHEN S.PRIVATE_LABEL_IND = 'Y' THEN 1
                    ELSE NULL
                END AS PRIVATE_LABEL_IND,
            FROM {context.data_stores.raw_data.table_name.sku_table} S
            LEFT JOIN {context.data_stores.raw_data.table_name.vendor_table} V
            ON S.VENDOR_NBR = V.VENDOR_NBR
            UNION
            SELECT DISTINCT
                UPC AS ITEM_NO_NBR,
                PRODUCT_NAME AS ITEM_NO_DESC,
                COALESCE(VM.VENDOR_NAME, CAST(NS.VENDOR_NUMBER AS VARCHAR)) AS VENDOR_NAME,
                NS.VENDOR_NUMBER,
                BRAND_NAME,
                SEGMENT AS SEG_DSC,
                SUBCATEGORY AS SUBCAT_DSC,
                NULL AS PROD_UNIT_HEIGHT_FT,
                SKU_WIDTH/12 AS PROD_UNIT_WIDTH_FT,
                NULL AS PROD_UNIT_DEPTH_FT,
                CASE 
                    WHEN PRIVATE_LABEL = 'No' THEN 0
                    WHEN PRIVATE_LABEL = 'Yes' THEN 1
                    ELSE NULL
                END AS PRIVATE_LABEL_IND,
            FROM {context.data_stores.raw_data.table_name.new_skus_table} NS
            LEFT JOIN VENDOR_MAPPING VM
            ON NS.VENDOR_NUMBER = VM.VENDOR_NUMBER
            WHERE UPC NOT IN (
                SELECT DISTINCT SKU_NBR 
                FROM {context.data_stores.raw_data.table_name.sku_table}
            )
        ), TRANSFERENCE AS (
            SELECT DISTINCT 
                SKU_ID AS ITEM_NO_NBR, 
                1 - MEDIAN(WALK_RATE) AS  N_TRANSFERENCE_SKU
            FROM {context.data_stores.raw_data.table_name.walk_rate_table}
            WHERE ANALYSIS_END_DATE = (SELECT MAX(ANALYSIS_END_DATE) FROM {context.data_stores.raw_data.table_name.walk_rate_table})
            GROUP BY SKU_ID
        ), UNIT_COST AS (
            SELECT DISTINCT
                SKU_NBR AS ITEM_NO_NBR,
                STORE_NBR,
                L52W_PRICE AS UNIT_PRICE
            FROM {context.data_stores.raw_data.table_name.ly_sales_table}
        ), NEW_SKU_PRICING AS (
            SELECT DISTINCT
                UPC AS ITEM_NO_NBR,
                SKU_MSRP AS UNIT_PRICE
            FROM {context.data_stores.raw_data.table_name.new_skus_table}
        ), BOH_CURVES AS (
            SELECT DISTINCT
                CLUSTER_LABEL AS FINAL_CLUSTER_LABELS,
                NEED_STATE_UNIQUE_ID AS NEED_STATE,
                "Final_Param_A" AS BOH_PARAM_A,
                "Final_Param_B" AS BOH_PARAM_B
            FROM {context.data_stores.raw_data.table_name.boh_curves}
        )

        SELECT DISTINCT
            IPB.ITEM_NO_NBR,
            IPB.CLONE_ITEM_ITEM_NO_NBR,
            IPB.STORE_NBR,
            IPB.PLANO_ID,
            IPB.PLANO_FT,
            IPB.FIXTURE_SIZE,
            IPB.FINAL_CLUSTER_LABELS,
            IPB.LP_FLAGS,
            IPB.PLANOGRAM_VERSION_ID,
            CAST(IPB.SPECIAL_VERSION_ID AS VARCHAR) AS SPECIAL_VERSION_ID,
            IPB.PLANO_CAT_ID,
            IPB.PLANO_CAT_DESC,
            IPB.DEPT_ID,
            IPB.RISK_FLAG,
            IPB.VOLUME_FLAG,
            IPB.CATEGORY_LEVEL_DEPT_NBR,
            IPB.CATEGORY_LEVEL_DEPT_NAME,
            CL.DEMAND_CLUSTER_LABELS,
            CL.ORIGINAL_CLUSTER_LABELS,
            IPB.FIXTURE_DESC,
            CPGM.HFACINGS,
            CPGM.TOTAL_SALES,
            PF.ITEM_NO_DESC,
            PF.VENDOR_NAME,
            CAST(PF.VENDOR_NUMBER AS VARCHAR) AS VENDOR_NUMBER,
            PF.BRAND_NAME,
            PF.SEG_DSC,
            PF.SUBCAT_DSC,
            PF.PRIVATE_LABEL_IND,
            PF.PROD_UNIT_HEIGHT_FT,
            PF.PROD_UNIT_WIDTH_FT,
            PF.PROD_UNIT_DEPTH_FT,
            IPB.SOURCE,
            IPB.CLONE_PCT,
            IPB.CLONE_TYPE,
            COALESCE(CPGM.HFACINGS, 0) AS N_CURRENT_FACINGS_SKU,
            COALESCE(N_CURRENT_FACINGS_SKU, 0) * PF.PROD_UNIT_WIDTH_FT AS N_CURRENT_LINEAR_SPACE_USED_SKU,
            COALESCE(CNS.NEED_STATE, CONCAT(LOWER(IPB.FIXTURE_DESC), '_-1')) AS NEED_STATE,
            COALESCE(CNS.NEED_STATE, CONCAT(LOWER(IPB.FIXTURE_DESC), '_-1')) AS NEED_STATE_UNIQUE_ID,
            CNS.ID AS NEED_STATE_RUN_ID,
            CASE
                WHEN IPB.FINAL_CLUSTER_LABELS ILIKE '%slow_%' THEN LP.N_TOTAL_LINEAR_SPACE_DEPT_FIXTURE_FT * {linear_space_to_keep}
                ELSE LP.N_TOTAL_LINEAR_SPACE_DEPT_FIXTURE_FT
            END AS N_TOTAL_LINEAR_SPACE_DEPT_FIXTURE_FT,
            TR.N_TRANSFERENCE_SKU,
            DI.DISC_ITEM,
            II.IGNORE_ITEM,
            COALESCE(UC.UNIT_PRICE, NSP.UNIT_PRICE) AS UNIT_PRICE,
            BOHC.BOH_PARAM_A,
            BOHC.BOH_PARAM_B,
            CASE
                WHEN IPB.PLANO_ID = '9751' AND IPB.SUB_PLANO IS NULL THEN '_SHELVE'
                WHEN IPB.SUB_PLANO IS NOT NULL THEN CONCAT('_', IPB.SUB_PLANO)
                ELSE ''
           END AS SUB_PLANO
        FROM ITEM_PLANO_BASE IPB
        LEFT JOIN CLEAN_PGM CPGM
        USING (ITEM_NO_NBR, STORE_NBR, PLANO_ID)
        INNER JOIN CLEAN_NS CNS
        USING (ITEM_NO_NBR, PLANO_ID)
        LEFT JOIN CLEAN_CLUSTERS CL
        USING (STORE_NBR, PLANO_CAT_DESC)
        LEFT JOIN PRODUCT_INFO PF
        USING (ITEM_NO_NBR)
        LEFT JOIN TRANSFERENCE TR
        USING (ITEM_NO_NBR) 
        LEFT JOIN LINEAR_SPACE LP
        USING (STORE_NBR, PLANO_ID, PLANO_FT, FIXTURE_SIZE, SUB_PLANO)
        LEFT JOIN IGNORE_ITEMS II
        USING (ITEM_NO_NBR, PLANO_ID)
        LEFT JOIN DISC_ITEMS DI
        USING (ITEM_NO_NBR, PLANO_ID)
        LEFT JOIN UNIT_COST UC
        USING (ITEM_NO_NBR, STORE_NBR)
        LEFT JOIN NEW_SKU_PRICING NSP
        ON IPB.ITEM_NO_NBR = NSP.ITEM_NO_NBR
        LEFT JOIN BOH_CURVES BOHC
        USING(FINAL_CLUSTER_LABELS, NEED_STATE)
        WHERE FINAL_CLUSTER_LABELS IS NOT NULL AND COALESCE(IGNORE_ITEM, 0) != 1
    """
    # print(df_base_sql_query)

    log.info("Loading base planogram table from Snowflake")
    df_base = settings.SNOWFLAKE_CONNECTION.cursor().execute(df_base_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_base.shape}")

    odd_items_sql_query = f"""
        WITH ITEM_BASE AS (
                SELECT DISTINCT 
                    SKU_NBR, 
                    PLANO_CAT_DSC,
                    CASE 
                        WHEN PLANOGRAM_NBR = 9677 THEN 9700
                        ELSE PLANOGRAM_NBR 
                    END AS PLANOGRAM_NBR
                FROM {context.data_stores.raw_data.table_name.planogram_table}
                WHERE PLANO_CAT_DSC = (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                                            WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                                            ELSE CAT_DSC
                                        END)
                    AND  PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                    AND PLANOGRAM_NBR IN {in_scope_pogs}
            ), MOST_COMMON_POG AS (
                SELECT 
                    SKU_NBR, 
                    MODE(PLANOGRAM_NBR) AS MOST_COMMON_POG
                FROM {context.data_stores.raw_data.table_name.planogram_table}
                WHERE SKU_NBR IN (SELECT DISTINCT SKU_NBR FROM ITEM_BASE)
                GROUP BY SKU_NBR
            ), ITEMS_WITH_DIFF_POGS AS (
                SELECT DISTINCT
                    SKU_NBR,
                    PLANOGRAM_NBR,
                FROM ITEM_BASE IB
                LEFT JOIN MOST_COMMON_POG MCP
                USING (SKU_NBR)
                WHERE PLANOGRAM_NBR != CASE 
                                        WHEN MOST_COMMON_POG = 9677 THEN 9700
                                        ELSE MOST_COMMON_POG
                                       END
            ), STORE_COVERAGE AS (
                SELECT SKU_NBR, PLANOGRAM_NBR,
                (COUNT(DISTINCT STORE_NBR) / 
                    (SELECT COUNT(DISTINCT STORE_NBR) FROM {context.data_stores.raw_data.table_name.planogram_table})) STORE_COVERAGE
                FROM {context.data_stores.raw_data.table_name.planogram_table}
                WHERE PLANOGRAM_NBR IN {in_scope_pogs}
                       AND PLANO_CAT_DSC = (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                                            WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                                            ELSE CAT_DSC
                                            END)
                GROUP BY SKU_NBR, PLANOGRAM_NBR
                HAVING STORE_COVERAGE < 0.3
            ), ITEMS_TO_LIMIT AS (
                SELECT SKU_NBR, PLANOGRAM_NBR FROM ITEMS_WITH_DIFF_POGS
                UNION
                SELECT SKU_NBR, PLANOGRAM_NBR FROM STORE_COVERAGE
            ), CLEAN_CLUSTERS AS (
                SELECT DISTINCT
                    "store_nbr" AS STORE_NBR,
                    CASE
                        WHEN "category" = 'ACNE_HSC' THEN 'ACNE/HSC'
                        WHEN "category" = 'DIET_NUTRITION' THEN 'DIET/NUTRITION'
                    ELSE REPLACE("category", '_', ' ')
                    END AS PLANO_CAT_DESC,
                    "demand_cluster_labels" AS DEMAND_CLUSTER_LABELS,
                    "rebalanced_demand_cluster_labels" AS ORIGINAL_CLUSTER_LABELS,
                    "rebalanced_demand_cluster_labels" AS FINAL_CLUSTER_LABELS,
                FROM {context.data_stores.raw_data.table_name.cluster_table}
            ), CLUSTER_ITEMS_MAX AS (
                SELECT DISTINCT 
                    FINAL_CLUSTER_LABELS, 
                    FIXTURE_WIDTH_NBR AS PLANO_FT,
                    FIXTURE_HEIGHT_NBR AS FIXTURE_SIZE,
                    CASE 
                        WHEN PLANOGRAM_NBR = 9677 THEN 9700
                        ELSE PLANOGRAM_NBR 
                    END AS PLANOGRAM_NBR,
                    SKU_NBR,
                    MAX(HORIZONTAL_FACINGS_NBR) AS MAX_FACINGS,
                FROM {context.data_stores.raw_data.table_name.planogram_table} PM
                LEFT JOIN CLEAN_CLUSTERS CL
                ON PM.STORE_NBR = CL.STORE_NBR AND PM.PLANO_CAT_DSC = CL.PLANO_CAT_DESC
                WHERE PLANOGRAM_NBR IN {in_scope_pogs}
                    AND PM.PLANO_CAT_DSC = PM.CAT_DSC
                    AND SKU_NBR IN (SELECT DISTINCT SKU_NBR FROM ITEMS_TO_LIMIT)
                GROUP BY FINAL_CLUSTER_LABELS, PLANO_FT, FIXTURE_SIZE, PLANOGRAM_NBR, SKU_NBR
            ), CLUSTER_POGS AS (
                SELECT DISTINCT 
                    FINAL_CLUSTER_LABELS,  
                    FIXTURE_WIDTH_NBR AS PLANO_FT,
                    FIXTURE_HEIGHT_NBR AS FIXTURE_SIZE,
                    CASE 
                        WHEN PLANOGRAM_NBR = 9677 THEN 9700
                        ELSE PLANOGRAM_NBR 
                    END AS PLANOGRAM_NBR,
                FROM {context.data_stores.raw_data.table_name.planogram_table} PM
                LEFT JOIN CLEAN_CLUSTERS CL
                ON PM.STORE_NBR = CL.STORE_NBR AND PM.PLANO_CAT_DSC = CL.PLANO_CAT_DESC
                WHERE PLANOGRAM_NBR IN {in_scope_pogs}
            ), CLUSTER_ITEM_CROSS AS (
                SELECT 
                    FINAL_CLUSTER_LABELS,
                    PLANO_FT,
                    FIXTURE_SIZE,
                    CP.PLANOGRAM_NBR,
                    SKU_NBR
                FROM CLUSTER_POGS CP
                CROSS JOIN ITEMS_TO_LIMIT ITL
                WHERE CP.PLANOGRAM_NBR = ITL.PLANOGRAM_NBR
            )

            SELECT 
                FINAL_CLUSTER_LABELS,
                PLANO_FT,
                FIXTURE_SIZE,
                CAST(PLANOGRAM_NBR AS VARCHAR) AS PLANO_ID, -- CHANGE HERE
                SKU_NBR AS ITEM_NO_NBR,
                COALESCE(MAX_FACINGS, 0) AS MAX_FACINGS
            FROM CLUSTER_ITEM_CROSS
            LEFT JOIN CLUSTER_ITEMS_MAX
            USING (FINAL_CLUSTER_LABELS, PLANO_FT, FIXTURE_SIZE, PLANOGRAM_NBR, SKU_NBR)
        """

    log.info("Loading odd items table from Snowflake")
    df_odd_items = settings.SNOWFLAKE_CONNECTION.cursor().execute(odd_items_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_odd_items.shape}")
    
    elasticity_sql_query = f"""
        WITH CATEGORY_TRANSFORMED AS (
            SELECT *,
                CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                    WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                    ELSE CAT_DSC
                END AS TRANSFORMED_CAT_DSC
            FROM {context.data_stores.raw_data.table_name.elasticity_curve_table}
            WHERE TIMESTAMP <= {curves_timestamp}
        ), LATEST_RUN AS (
            SELECT TRANSFORMED_CAT_DSC, MAX(TIMESTAMP) AS TIMESTAMP
            FROM CATEGORY_TRANSFORMED
            WHERE TRANSFORMED_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
            GROUP BY TRANSFORMED_CAT_DSC
        ), ACTIVE_AS AS (
            SELECT SKU_NBR AS ITEM_NO_NBR, MIN(FISCAL_MONTH_NBR) AS MIN_MONTH_SALE
            FROM {context.data_stores.raw_data.table_name.sku_features_table}
            WHERE FISCAL_MONTH_NBR >= '202401'
            GROUP BY SKU_NBR
        ), LATEST_CURVE AS (
            SELECT DISTINCT 
                CL.SKU_NBR AS ITEM_NO_NBR,
                CL.NEED_STATE AS NEED_STATE_UNIQUE_ID,
                CAST(CL.PLANOGRAM_DSC AS VARCHAR) AS FIXTURE_DESC,
                CL.TRANSFORMED_CAT_DSC AS PLANO_CAT_DESC,
                CL.CLUSTER AS FINAL_CLUSTER_LABELS,
                CL.IS_ELASTICITY_OVERRIDDEN,
                CL.ELASTICITY_OVERRIDE_GRANULARITY,
                CL.SHAPE_ENFORCED,
                CL.TIMESTAMP AS SKU_CURVES_ID,
                CL.N_SPACE_PROD_FIT_FACINGS_0,
                CL.N_SPACE_PROD_FIT_FACINGS_1,
                CL.N_SPACE_PROD_FIT_FACINGS_2,
                CL.N_SPACE_PROD_FIT_FACINGS_3,
                CL.N_SPACE_PROD_FIT_FACINGS_4,
                CL.N_SPACE_PROD_FIT_FACINGS_5,
                CL.N_SPACE_PROD_FIT_FACINGS_6,
                CL.N_SPACE_PROD_FIT_FACINGS_7,
                CL.N_SPACE_PROD_FIT_FACINGS_8,
                CL.N_SPACE_PROD_FIT_FACINGS_9,
                CL.N_SPACE_PROD_FIT_FACINGS_10,
                CL.N_SPACE_PROD_FIT_FACINGS_11,
                CL.N_SPACE_PROD_FIT_FACINGS_12,
                CL.N_SPACE_PROD_FIT_FACINGS_13,
                CL.N_SPACE_PROD_FIT_FACINGS_14,
                CL.N_SPACE_PROD_FIT_FACINGS_15,
                CL.N_SPACE_PROD_FIT_FACINGS_16,
                CL.N_SPACE_PROD_FIT_FACINGS_17
            FROM CATEGORY_TRANSFORMED CL
            INNER JOIN LATEST_RUN LR
            ON CL.TRANSFORMED_CAT_DSC = LR.TRANSFORMED_CAT_DSC 
            AND CL.TIMESTAMP = LR.TIMESTAMP
        ), FULL_ZERO_SALES AS (
            SELECT ITEM_NO_NBR, 
                FIXTURE_DESC, 
                SUM(N_SPACE_PROD_FIT_FACINGS_1) AS TOTAL_PROD_FIT_FACINGS_1
            FROM LATEST_CURVE
            GROUP BY ITEM_NO_NBR, FIXTURE_DESC
        )
        
        SELECT *
        FROM LATEST_CURVE
        LEFT JOIN ACTIVE_AS 
        USING (ITEM_NO_NBR)
        LEFT JOIN FULL_ZERO_SALES
        USING (ITEM_NO_NBR, FIXTURE_DESC)
        WHERE TOTAL_PROD_FIT_FACINGS_1 > 0 
        AND (MIN_MONTH_SALE < 202501
        OR ITEM_NO_NBR IN (SELECT DISTINCT PRODUCT_ID FROM {context.data_stores.raw_data.table_name.need_state_table} WHERE "New Item" = TRUE)
        OR ITEM_NO_NBR IN (SELECT DISTINCT REPLACED_SKU_NUMBER FROM {context.data_stores.raw_data.table_name.new_skus_table})
        ) -- 
    """
    
    log.info("Loading elasticity table from Snowflake")
    df_elasticity = settings.SNOWFLAKE_CONNECTION.cursor().execute(elasticity_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_elasticity.shape}")
    
    saturation_sql_query = f"""
        WITH LATEST_RUN AS (
            SELECT CAT_DSC , MAX(TIMESTAMP) AS TIMESTAMP
            FROM {context.data_stores.raw_data.table_name.saturation_table}
            WHERE TIMESTAMP <= {curves_timestamp}  
            GROUP BY CAT_DSC
        )
        SELECT DISTINCT
            * EXCLUDE(CLUSTER, PLANOGRAM_DSC, CAT_DSC, NEED_STATE),
            CLUSTER AS FINAL_CLUSTER_LABELS,
            PLANOGRAM_DSC AS FIXTURE_DESC,
            (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                ELSE CAT_DSC
            END) AS PLANO_CAT_DESC,
            NEED_STATE AS NEED_STATE_UNIQUE_ID,
            TIMESTAMP AS NS_CURVES_ID
        FROM {context.data_stores.raw_data.table_name.saturation_table}
        INNER JOIN LATEST_RUN
        USING(CAT_DSC, TIMESTAMP)
        WHERE (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                    WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                    ELSE CAT_DSC
            END) IN ('{"', '".join(context.data_stores.raw_data.categories)}')
    """
    log.info("Loading saturation table from Snowflake")
    df_saturation = settings.SNOWFLAKE_CONNECTION.cursor().execute(saturation_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_saturation.shape}")
    
    saturation_lvl1_sql_query = f"""    
        WITH MELT_NS AS (
            SELECT DISTINCT 
                PLANOGRAM_DSC, 
                CDT,
                NEED_STATE AS NEED_STATE_UNIQUE_ID, 
                "attribute_value" AS ATTRIBUTE_1, 
                TIMESTAMP 
            FROM {context.data_stores.raw_data.table_name.need_state_table}
            WHERE "attribute_key" = 'ATTRIBUTE_1' AND TIMESTAMP = (
                               SELECT MAX(TIMESTAMP) 
                               FROM {context.data_stores.raw_data.table_name.need_state_table}
                               WHERE TIMESTAMP <= {need_state_timestamp}    
                            )
        )

        SELECT A1.* EXCLUDE(CLUSTER, PLANOGRAM_DSC, CAT_DSC, NEED_STATE),
                A1.CLUSTER AS FINAL_CLUSTER_LABELS,
                A1.PLANOGRAM_DSC AS FIXTURE_DESC,
                (CASE WHEN A1.CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                    WHEN A1.CAT_DSC = 'SODA' THEN 'BEVERAGES'
                    ELSE A1.CAT_DSC
                END) AS PLANO_CAT_DESC,
                NS.NEED_STATE_UNIQUE_ID,
                REPLACE(LOWER(CONCAT(A1.CDT, '_', COALESCE(A1.ATTRIBUTE_1, ''))), ' ', '_') AS LVL1_NEED_STATE_UNIQUE_ID,
                NS.TIMESTAMP AS NS_CURVES_ID, 
        FROM {context.data_stores.raw_data.table_name.lvl1_saturation_table} A1
        LEFT JOIN MELT_NS NS
        USING (CDT, PLANOGRAM_DSC, ATTRIBUTE_1)
        WHERE (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                    WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                    ELSE CAT_DSC
                END) IN ('{"', '".join(context.data_stores.raw_data.categories)}')
    """
    log.info("Loading saturation level 1 table from Snowflake")
    df_saturation_lvl1 = settings.SNOWFLAKE_CONNECTION.cursor().execute(saturation_lvl1_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_saturation_lvl1.shape}")
    
    sales_sql_query = f"""
            SELECT DISTINCT
                SKU_NBR AS ITEM_NO_NBR,
                STORE_NBR,
                AVG(L52W_PRICE) AS ACTUAL_AVERAGE_PRICE
            FROM {context.data_stores.raw_data.table_name.ly_sales_table}
            WHERE
            SKU_NBR IN (SELECT DISTINCT SKU_NBR
                              FROM {context.data_stores.raw_data.table_name.planogram_table}
                              WHERE PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
                                AND PLANO_CAT_DSC = (CASE WHEN CAT_DSC = 'LAUNDRY' THEN 'HOUSEHOLD'
                                                          WHEN CAT_DSC = 'SODA' THEN 'BEVERAGES'
                                                          ELSE CAT_DSC
                                                    END)
                                AND PLANOGRAM_NBR IN {in_scope_pogs})
            GROUP BY SKU_NBR, STORE_NBR
    """
    log.info("Loading sales from Snowflake")
    df_sales = settings.SNOWFLAKE_CONNECTION.cursor().execute(sales_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_sales.shape}")

    # DC Store Mapping Query
    dc_store_mapping_sql_query = f"""
        SELECT DISTINCT
            DC_ID,
            STORE_NBR
        FROM {context.data_stores.raw_data.table_name.dc_store_mapping_table}
        WHERE STORE_NBR IN (
            SELECT DISTINCT STORE_NBR 
            FROM {context.data_stores.raw_data.table_name.planogram_table}
            WHERE PLANO_CAT_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
        )
    """

    log.info("Loading DC store mapping from Snowflake")
    df_dc_store_mapping = settings.SNOWFLAKE_CONNECTION.cursor().execute(dc_store_mapping_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_dc_store_mapping.shape}")

    # Get DNP data
    dnp_sql_query = f"""
        WITH L12M AS (
                    SELECT TOP 12 FISCAL_MONTH_NBR
                    FROM (
                        SELECT DISTINCT a.FISCAL_MONTH_NBR 
                        FROM {context.data_stores.raw_data.table_name.dnp_table} a
                        INNER JOIN
                        (SELECT DISTINCT FISCAL_MONTH_NBR 
                        FROM {context.data_stores.raw_data.table_name.scan_adjustment_table}) b 
                        on a.FISCAL_MONTH_NBR = b.FISCAL_MONTH_NBR
                    )
                    ORDER BY FISCAL_MONTH_NBR DESC
        ), 
        SCAN_DNP AS (
        SELECT SKU_NBR, a.FISCAL_MONTH_NBR,
        Sum(SKU_SYSTEM_SCAN_SPREAD) SKU_SYSTEM_SCAN_SPREAD
        , Sum(SKU_SCAN_FINAL) SKU_SCAN_FINAL
        FROM {context.data_stores.raw_data.table_name.scan_adjustment_table} a 
        where  FISCAL_MONTH_NBR IN (SELECT FISCAL_MONTH_NBR FROM L12M)
        GROUP BY ALL
        ) 
        ,
        BASE_DNP AS (
            SELECT FISCAL_MONTH_NBR, SKU_NBR,
                   (Nvl(SALES_CLEARANCE,0) + Nvl(SALES_PROMO,0) + Nvl(SALES_REG,0) + Nvl(SALES_TPR,0)
                   + Nvl(ALLOWANCE_DISCO,0) + Nvl(ALLOWANCE_OTHER,0)
                   + Nvl(CPN_MD,0) + Nvl(CPN_MD_CO_DEF,0)
                   + Nvl(PERM_MRKDN_CLS,0) + Nvl(PERM_MRKDN_SLMD_DMG,0) + Nvl(PERM_MRKDN_SLMD_OTR,0)
                   + Nvl(SHRINK_COST,0)
                   ) AS DNP_COMPONENT_FIXED,
                   (Nvl(COST_CLEARANCE,0) + Nvl(COST_PROMO,0) + Nvl(COST_REG,0) + Nvl(COST_TPR,0)) AS COST,
                   (Nvl(ALLOWANCE_COUPON,0) + Nvl(ALLOWANCE_CO_OP,0)) AS ALLOWANCE_COUPON_CO_OP,
                   (Nvl(UNITS_CLEARANCE,0) + Nvl(UNITS_PROMO,0) + Nvl(UNITS_REG,0) + Nvl(UNITS_TPR,0)) AS UNITS_SOLD,
                   COST_PURCHASES,
                   TOT_DNP_AMT, 
                   TOTAL_SALES,
                   Nvl(SKU_SYSTEM_SCAN_SPREAD,0) AS SKU_SYSTEM_SCAN_SPREAD,
                   Nvl(SKU_SCAN_FINAL,0) AS SKU_SCAN_FINAL
            FROM {context.data_stores.raw_data.table_name.dnp_table}
            LEFT JOIN SCAN_DNP USING(FISCAL_MONTH_NBR, SKU_NBR)
            WHERE  FISCAL_MONTH_NBR IN (SELECT FISCAL_MONTH_NBR FROM L12M)
        )
        , CLONE_SKU AS (SELECT DISTINCT UPC AS ITEM_NO_NBR, REPLACED_SKU_NUMBER
                        FROM {context.data_stores.raw_data.table_name.new_skus_table})
        , DNP_AGGREGATED AS (
        SELECT DISTINCT
            SKU_NBR AS ITEM_NO_NBR,
            SUM(DNP_COMPONENT_FIXED) AS DNP_COMPONENT_FIXED,
            SUM(COST) AS DNP_COMPONENT_COST,
            SUM(ALLOWANCE_COUPON_CO_OP) AS DNP_COMPONENT_ALLOWANCE_COUPON_CO_OP,
            SUM(UNITS_SOLD) AS DNP_COMPONENT_UNITS_SOLD,
            SUM(COST_PURCHASES) AS DNP_COMPONENT_COST_PURCHASES,
            SUM(TOTAL_SALES) AS DNP_COMPONENT_TOTAL_SALES,
            SUM(TOT_DNP_AMT) AS DNP_COMPONENT_TOT_DNP_AMT,
            SUM(SKU_SYSTEM_SCAN_SPREAD) AS SKU_SYSTEM_SCAN_SPREAD,
            SUM(SKU_SCAN_FINAL) AS SKU_SCAN_FINAL
        FROM BASE_DNP
        WHERE SKU_NBR NOT IN (SELECT ITEM_NO_NBR FROM CLONE_SKU)
        GROUP BY SKU_NBR
        )
        ,
        CLONE_DNP as (
        SELECT DISTINCT 
            a.ITEM_NO_NBR AS ITEM_NO_NBR,
            NVL(b.DNP_COMPONENT_FIXED, 0) as DNP_COMPONENT_FIXED,
            NVL(b.DNP_COMPONENT_COST, 0) as DNP_COMPONENT_COST,
            NVL(b.DNP_COMPONENT_ALLOWANCE_COUPON_CO_OP, 0) as DNP_COMPONENT_ALLOWANCE_COUPON_CO_OP,
            NVL(b.DNP_COMPONENT_UNITS_SOLD, 0) as DNP_COMPONENT_UNITS_SOLD,
            NVL(b.DNP_COMPONENT_COST_PURCHASES, 0) as DNP_COMPONENT_COST_PURCHASES,
            NVL(b.DNP_COMPONENT_TOTAL_SALES, 0) as DNP_COMPONENT_TOTAL_SALES,
            NVL(b.DNP_COMPONENT_TOT_DNP_AMT, 0) as DNP_COMPONENT_TOT_DNP_AMT,
            NVL(b.SKU_SYSTEM_SCAN_SPREAD, 0) as SKU_SYSTEM_SCAN_SPREAD,
            NVL(b.SKU_SCAN_FINAL, 0) as SKU_SCAN_FINAL
        FROM CLONE_SKU a
        LEFT JOIN DNP_AGGREGATED b on a.REPLACED_SKU_NUMBER = b.ITEM_NO_NBR
        )

        
        SELECT *
        FROM DNP_AGGREGATED
        UNION ALL
        SELECT *
        FROM CLONE_DNP

    """
    log.info("Loading DNP data from Snowflake")

    df_dnp = settings.SNOWFLAKE_CONNECTION.cursor().execute(dnp_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_dnp.shape}")


    # Load OTCH SKUs from Snowflake
    otch_sql_query = f"""
        SELECT CAST("sku" AS INT) AS item_no_nbr
        FROM {context.data_stores.raw_data.constraint_parameters.otch_table}
        WHERE "otchs_fp_flag_new" = TRUE
    """
    log.info("Loading OTCH SKUs from Snowflake")
    df_otch_skus = settings.SNOWFLAKE_CONNECTION.cursor().execute(otch_sql_query).fetch_pandas_all()
    log.info(f"    loaded dataframe size: {df_otch_skus.shape}")


    removal_penalty_query = f"""
        SELECT DISTINCT SKU_NBR AS ITEM_NO_NBR,
               AVG_STORE_PENALTY_VALUE AS REMOVAL_PENALTY
        FROM {context.data_stores.raw_data.table_name.removal_penalty_table}
        WHERE CATEGORY_DSC IN ('{"', '".join(context.data_stores.raw_data.categories)}')
    """

    log.info("Loading removal penalty data from Snowflake")
    df_removal_penalty = settings.SNOWFLAKE_CONNECTION.cursor().execute(removal_penalty_query).fetch_pandas_all()
    log.info(f"    loaded removal penalty data size: {df_removal_penalty.shape}")

    # Make column names lower case
    df_base.columns = map(str.lower, df_base.columns)
    df_odd_items.columns = map(str.lower, df_odd_items.columns)
    df_elasticity.columns = map(str.lower, df_elasticity.columns)
    df_saturation.columns = map(str.lower, df_saturation.columns)
    df_saturation_lvl1.columns = map(str.lower, df_saturation_lvl1.columns)
    df_sales.columns = map(str.lower, df_sales.columns)
    df_dc_store_mapping.columns = map(str.lower, df_dc_store_mapping.columns)
    df_dnp.columns = map(str.lower, df_dnp.columns)
    df_otch_skus.columns = map(str.lower, df_otch_skus.columns)
    df_removal_penalty.columns = map(str.lower, df_removal_penalty.columns)

    return df_base, df_odd_items, df_elasticity, df_saturation, df_saturation_lvl1, df_sales, df_dc_store_mapping, df_dnp, df_otch_skus, df_removal_penalty


def format_final_cluster_labels(df: pd.DataFrame):
    # Add special versio flag
    # TODO: When upstream steps (curves, clustering, constraint) code will be adjusted for special version, 
    # set special version here
    # df["final_cluster_labels"] = df["final_cluster_labels"] + "_" + df["special_version_id"]
    
    # Add lp flags to cluster labels
    if context.optimization.data_prep.add_lp_flags_to_cluster:
        df["final_cluster_labels"] = df["final_cluster_labels"] + "-" + df["lp_flags"]
    df = df.drop(columns="lp_flags").drop_duplicates()

    return df


def df_merge_categories(df_base: pd.DataFrame,
                        category_to_keep: dict) -> pd.DataFrame:
    
    df_non_merge_categories = df_base[~df_base["plano_cat_desc"].isin(category_to_keep.keys())]
    log.info(f"Base dataframe size before merging: {df_base.shape[0]}")

    for category in category_to_keep:
        log.info(f"Merging category: {category}")
        df_focus_category = df_base[df_base["plano_cat_desc"] == category].copy()

        facing_count = df_focus_category["n_current_facings_sku"].sum()
        linear_space = df_focus_category["n_current_linear_space_used_sku"].sum()

        log.info(f"Before merging {category}: facings: {facing_count}, space: {linear_space:.2f}")

        # Add pogsize
        df_focus_category.loc[:, "pog_size"] = df_focus_category["plano_ft"].astype(str) + "x" + df_focus_category["fixture_size"].astype(str)

        # Get stores with beacon
        stores_with_rep_pog = df_focus_category[df_focus_category["plano_id"].isin(category_to_keep[category]["pogs_to_merge"])]["store_nbr"].unique().tolist()

        df_plano_level_items = df_focus_category[[
            "item_no_nbr",
            "item_no_desc",
            "clone_item_item_no_nbr",
            "vendor_name",
            "vendor_number",
            "brand_name",
            "seg_dsc",
            "private_label_ind",
            "prod_unit_height_ft",
            "prod_unit_width_ft",
            "prod_unit_depth_ft",
            "source",
            "clone_pct",
            "clone_type",
            "need_state",
            "need_state_unique_id",
            "n_transference_sku",
            "disc_item",
            "ignore_item",
        ]].sort_values("disc_item").drop_duplicates(subset="item_no_nbr")
        
        df_plano_level_stores_agg = (
            df_focus_category[[
                "store_nbr",
                "plano_id",
                "lp_flags",
                "risk_flag",
                "volume_flag",
                "n_total_linear_space_dept_fixture_ft"
            ]]
            .drop_duplicates()
            .groupby(["store_nbr", "lp_flags", "risk_flag", "volume_flag"])
            .agg(
                n_total_linear_space_dept_fixture_ft=("n_total_linear_space_dept_fixture_ft", "sum"),
            ).reset_index()
        )

        df_plano_level_stores_pogs = df_focus_category[df_focus_category["plano_id"] == category_to_keep[category]["pogs_to_keep"]][[
            "store_nbr",
            "planogram_version_id",
            "plano_ft",
            "plano_id",
            "sub_plano",
            "special_version_id",
            "fixture_size",
            "fixture_desc",
        ]].sort_values("planogram_version_id").drop_duplicates(subset="store_nbr")

        df_plano_level_items_agg = df_focus_category.groupby(
            [
                "item_no_nbr",
                "store_nbr",
                "plano_cat_id",
                "plano_cat_desc",
                "dept_id",
                "category_level_dept_nbr",
                "category_level_dept_name",
                "demand_cluster_labels",
                "original_cluster_labels",
                "final_cluster_labels",
                "need_state_run_id",           
            ]).agg(
                hfacings=("hfacings", "sum"),
                n_current_facings_sku=("n_current_facings_sku", "sum"),
                n_current_linear_space_used_sku=("n_current_linear_space_used_sku", "sum"),
                total_sales=("total_sales", "first"),
                unit_price=("unit_price", "first")
        ).reset_index()

        df_cluster_needstate_agg = df_focus_category[[
            "final_cluster_labels",
            "need_state_unique_id",   
            "boh_param_a",
            "boh_param_b"
        ]].drop_duplicates()

        df_plano_level_final = df_plano_level_items_agg.merge(df_plano_level_stores_agg, on="store_nbr", how="left")
        df_plano_level_final = df_plano_level_final.merge(df_plano_level_stores_pogs, on="store_nbr", how="left")
        df_plano_level_final = df_plano_level_final.merge(df_plano_level_items, on="item_no_nbr", how="left")
        df_plano_level_final = df_plano_level_final.merge(df_cluster_needstate_agg, on=["final_cluster_labels", "need_state_unique_id"], how="left")

        df_plano_level_final.loc[df_plano_level_final["store_nbr"].isin(stores_with_rep_pog), "plano_ft"] = df_plano_level_final["plano_ft"] + 1000

        facing_count = df_plano_level_final["n_current_facings_sku"].sum()
        linear_space = df_plano_level_final["n_current_linear_space_used_sku"].sum()

        log.info(f"After mergin {category}: facings: {facing_count}, space: {linear_space:.2f}")

        df_non_merge_categories = pd.concat([df_plano_level_final, df_non_merge_categories], ignore_index=True)
    
    log.info(f"Base dataframe size after merging: {df_non_merge_categories.shape[0]}")

    return df_non_merge_categories


def df_pull_final_clusters(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base[[
        "store_nbr",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "final_cluster_labels",
        "original_cluster_labels",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "demand_cluster_labels",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()
    
    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def get_forced_facings(df_base: pd.DataFrame, df_otch_skus: pd.DataFrame) -> pd.DataFrame:
    # Get item current facings
    df_current_facings = df_base.groupby(["item_no_nbr", "final_cluster_labels", "lp_flags", 
                           "plano_id", "plano_ft", "fixture_size"]).agg(
        current_facings=("hfacings", "max")
    ).reset_index()
    df_current_facings["final_cluster_labels"] = (
        df_current_facings["final_cluster_labels"] + "-" + df_current_facings["lp_flags"]
    ) 
    df_current_facings[df_current_facings["current_facings"].notna()]
    df_current_facings = df_current_facings.drop(columns=["lp_flags"])

    # Get unique versions
    df_versions = df_base[["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"]].drop_duplicates()
    df_versions["cluster"] = df_versions["final_cluster_labels"]
    
    # Load core SKUs
    ls_core_skus = []
    for file_name in glob(f"{context.data_stores.raw_data.file_path.core_items}/*.xlsx"):
        df = pd.read_excel(file_name, engine="openpyxl")
        ls_core_skus.append(df)

    df_core_skus = pd.concat(ls_core_skus, ignore_index=True)

    df_otch_skus["item_no_nbr"] = df_otch_skus["item_no_nbr"].astype('int32')
    df_otch_skus["enforce_indcator"] = 1

    # Filter base df to only include the relevant columns
    df_base_filtered = (
        df_base[["item_no_nbr", "plano_cat_desc", "plano_id"]]
        .drop_duplicates()
    )
    df_otch_skus = df_otch_skus.merge(df_base_filtered, on=["item_no_nbr"], how="inner")
    
    # Drop rows with missing planogram nbr
    df_otch_skus = df_otch_skus[df_otch_skus["plano_id"].notna()]
    log.info(f"OTCH SKUs: {df_otch_skus.shape[0]} rows")
    
    # Keep relevant columns for both sources
    df_otch_skus = df_otch_skus[["item_no_nbr", "plano_id"]]
    df_otch_skus["type"] = "otch"
    df_core_skus = df_core_skus[["item_no_nbr", "plano_id"]]
    df_core_skus["type"] = "core"
    
    # Concat & dorp duplicates
    df_core_otch = pd.concat([df_core_skus, df_otch_skus], ignore_index=True)
    df_core_otch = df_core_otch.drop_duplicates()
    df_core_otch["min_forced_facings"] = 1
    df_core_otch["max_forced_facings"] = context.optimization.model_formulation.max_facings_opti - 1
    df_core_otch["final_cluster_labels"] = np.nan
    
    # Get items with specific min & max
    if "item_with_forced_facings" in context.optimization.data_prep.keys():
        df_fixed_facings_sku = pd.DataFrame.from_dict(context.optimization.data_prep.item_with_forced_facings)
        df_fixed_facings_sku.columns = map(str.lower, df_fixed_facings_sku.columns)

        # Assure plano_id is of the correct type
        df_fixed_facings_sku["plano_id"] = df_fixed_facings_sku["plano_id"].astype(str)

        # Merge current facing count
        df_fixed_facings_sku = df_fixed_facings_sku.astype({"plano_ft": "float", 
                                                            "fixture_size": "float",
                                                            "item_no_nbr": "int"})
        df_current_facings["item_no_nbr"] = df_current_facings["item_no_nbr"].astype(int)
        df_fixed_facings_sku = df_fixed_facings_sku.merge(
            df_current_facings,
            on=["item_no_nbr", "final_cluster_labels", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )

        # Fill current faings with zero if missing
        df_fixed_facings_sku["current_facings"] = df_fixed_facings_sku["current_facings"].fillna(0)

        # For relative facing counts, set the value
        df_fixed_facings_sku.loc[df_fixed_facings_sku["change_type"] == "RELATIVE", "min_forced_facings"] = (
            df_fixed_facings_sku["current_facings"] + df_fixed_facings_sku["min_forced_facings"]
        )
        df_fixed_facings_sku.loc[df_fixed_facings_sku["change_type"] == "RELATIVE", "max_forced_facings"] = (
            df_fixed_facings_sku["current_facings"] + df_fixed_facings_sku["max_forced_facings"]
        )

        # Set negative values to zero
        df_fixed_facings_sku.loc[df_fixed_facings_sku["min_forced_facings"] <0 , "min_forced_facings"] = 0

        # Handle null values for min/max forced facings
        df_fixed_facings_sku["min_forced_facings"] = df_fixed_facings_sku["min_forced_facings"].fillna(0)
        df_fixed_facings_sku["max_forced_facings"] = df_fixed_facings_sku["max_forced_facings"].fillna(context.optimization.model_formulation.max_facings_opti - 1)
        
        # Add type
        df_fixed_facings_sku["type"] = "fixed_facings"

    elif not context.run_scenario_mode:
        ls_fixed_facings_skus = []
        for file_name in glob(f"{context.data_stores.raw_data.file_path.item_fixed_facings}/*.xlsx"):
            df = pd.read_excel(file_name, engine="openpyxl")
            ls_fixed_facings_skus.append(df)

        df_fixed_facings_sku = pd.concat(ls_fixed_facings_skus, ignore_index=True)
        df_fixed_facings_sku["type"] = "fixed_facings"
        df_fixed_facings_sku = df_fixed_facings_sku[["final_cluster_labels", "item_no_nbr", "plano_id", 
                                                     "min_forced_facings", "max_forced_facings",
                                                     "type"]].rename(columns={
                                                                "final_cluster_labels": "cluster"})

        # Get unique cluster/pog size to merge to the dataframe
        df_fixed_facings_sku = df_fixed_facings_sku[df_fixed_facings_sku["plano_id"].notna()]
        df_fixed_facings_sku["plano_id"] = df_fixed_facings_sku["plano_id"].astype(int).astype(str)
        df_fixed_facings_sku = df_fixed_facings_sku.merge(
            df_versions,
            on=["cluster", "plano_id"],
            how="left"
        )

    else:
        df_fixed_facings_sku = pd.DataFrame(columns=["final_cluster_labels", "item_no_nbr", "plano_id", 
                                             "plano_ft", "fixture_size", 
                                             "min_forced_facings", "max_forced_facings", "type"])

    # Keep relevant columns
    df_fixed_facings_sku = df_fixed_facings_sku[["final_cluster_labels", "item_no_nbr", "plano_id", 
                                                 "plano_ft", "fixture_size",
                                                  "min_forced_facings", "max_forced_facings", "type"]]
    
    # Make sure max forced facings is within bounds
    df_fixed_facings_sku.loc[(df_fixed_facings_sku["max_forced_facings"] >= context.optimization.model_formulation.max_facings_opti) 
                             | (df_fixed_facings_sku["max_forced_facings"].isna()) , 
                                "max_forced_facings"
                            ] = context.optimization.model_formulation.max_facings_opti - 1
    
    # Get final table
    df_enforced_skus = pd.concat([df_fixed_facings_sku, df_core_otch], ignore_index=True)
    df_enforced_skus = df_enforced_skus.drop_duplicates()
    df_enforced_skus = df_enforced_skus[(df_enforced_skus["item_no_nbr"].notna()) & (df_enforced_skus["plano_id"].notna())]
    df_enforced_skus["item_no_nbr"] = df_enforced_skus["item_no_nbr"].astype(int)
    df_enforced_skus["plano_id"] = df_enforced_skus["plano_id"].astype(int).astype(str)

    # If a SKU is both OTCH, core or fixed_facings, only keep one record
    # accoring to a typr_ranking 
    df_enforced_skus.loc[df_enforced_skus["type"] == "otch", "type_ranking"] = 1
    df_enforced_skus.loc[df_enforced_skus["type"] == "core", "type_ranking"] = 2
    df_enforced_skus.loc[df_enforced_skus["type"] == "fixed_facings", "type_ranking"] = 3

    # Sort according to type ranking & drop duplicates
    df_enforced_skus = df_enforced_skus.sort_values("type_ranking")
    df_enforced_skus = df_enforced_skus.drop_duplicates(
        subset=["final_cluster_labels", "item_no_nbr", "plano_id", "plano_ft", "fixture_size"]
    )

    return df_enforced_skus


def get_facings_for_slow_moving(df_base: pd.DataFrame) -> pd.DataFrame:
    # If slow moving items are disabled, return an empty dataframe
    if not context.optimization.data_prep.restrict_slow_moving_items:
        df_slow_moving_count = pd.DataFrame(columns=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "item_no_nbr", "slow_moving"])
        log.info(f"Slow moving items disabled, dataframe size: {df_slow_moving_count.shape[0]}")
        return df_slow_moving_count
    
    # Load core SKUs
    ls_slow_moving_skus = []
    for file_name in glob(f"{context.data_stores.raw_data.file_path.slow_moving}/*.xlsx"):
        df = pd.read_excel(file_name, engine="openpyxl")
        ls_slow_moving_skus.append(df)

    # Concat dataframe & keep relevant columns
    df_slow_moving = pd.concat(ls_slow_moving_skus, ignore_index=True)
    df_slow_moving = df_slow_moving[["STORE_NBR", "SKU_NBR"]].rename(columns={"STORE_NBR": "store_nbr", 
                                                                              "SKU_NBR": "item_no_nbr"})    
    df_slow_moving = df_slow_moving[df_slow_moving["item_no_nbr"].notna()].drop_duplicates()

    
    # Get relevant columns from base datafram
    df_base = df_base[["final_cluster_labels", 
                       "special_version_id",
                       "lp_flags",
                       "plano_id",
                       "plano_ft", 
                       "fixture_size",
                       "store_nbr",
                       "item_no_nbr"]].drop_duplicates()
    
    # format final cluster label
    df_base["final_cluster_labels"] = df_base["final_cluster_labels"] + "_" + df_base["special_version_id"]
    df_base = format_final_cluster_labels(df_base)
    
    # Store count per cluster
    df_store_count = df_base.groupby(["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"]).agg(
        cluster_store_count=("store_nbr", "nunique")
    ).reset_index()
    
    # Get number of stores within a cluster that has this slow moving item
    df_slow_moving = df_base.merge(df_slow_moving,
                                   on=["store_nbr", "item_no_nbr"],
                                   how="inner")
    df_slow_moving_count = df_slow_moving.groupby(["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"]).agg(
        item_store_count=("store_nbr", "nunique")
    ).reset_index()
    
    # Add store count to the datafram
    df_slow_moving_count = df_slow_moving_count.merge(df_store_count,
                                                      on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"],
                                                      how="left")
    
    # Compute percentage in which slow moving items appear
    df_slow_moving_count["store_ratio"] = df_slow_moving_count["item_store_count"]/df_slow_moving_count["cluster_store_count"]
    
    # Filter it to only items included in X% of the stores within the cluster
    df_slow_moving_count = (
        df_slow_moving_count[df_slow_moving_count["store_ratio"] > context.optimization.data_prep.slow_moving_skus_store_threshold]
    )
    
    # Keep relevant columns and add indicator
    df_slow_moving_count = df_slow_moving_count[["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"]].drop_duplicates()
    df_slow_moving_count = df_slow_moving_count[(df_slow_moving_count["item_no_nbr"].notna()) & (df_slow_moving_count["plano_id"].notna())]
    df_slow_moving_count["item_no_nbr"] = df_slow_moving_count["item_no_nbr"].astype(int)
    df_slow_moving_count["plano_id"] = df_slow_moving_count["plano_id"].astype(int).astype(str)
    df_slow_moving_count["slow_moving"] = 1

    log.info(f"Slow moving items/versions: {df_slow_moving_count.shape[0]}")
    
    return df_slow_moving_count
    
    
def get_need_state_facings(df_base: pd.DataFrame) -> pd.DataFrame:
    if "non_enforced_need_states" in context.optimization.data_prep.keys():
        df_need_state_facings = pd.DataFrame.from_dict(context.optimization.data_prep.non_enforced_need_states)
        df_need_state_facings.columns = map(str.lower, df_need_state_facings.columns)

        # Assure correct data types
        df_need_state_facings = df_need_state_facings.astype({"plano_ft": "float", 
                                                              "fixture_size": "float",
                                                              "plano_id": "str"})

        return df_need_state_facings
    else:
        # Get unique versions
        df_versions = df_base[["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"]].drop_duplicates()
        df_versions["cluster"] = df_versions["final_cluster_labels"]
        df_versions["final_cluster_labels"] = df_versions["final_cluster_labels"] + "-" + df_versions["lp_flags"]
        df_versions = df_versions.drop(columns=["lp_flags"])
    
        # Load need states which are not enforced
        ls_need_state_facings = []
        for file_name in glob(f"{context.data_stores.raw_data.file_path.need_state_facings}/*.xlsx"):
            df = pd.read_excel(file_name, engine="openpyxl")
            df = df.drop(columns="planogram_dsc")
            ls_need_state_facings.append(df)
    
        df_need_state_facings = pd.concat(ls_need_state_facings, ignore_index=True)

        # Rename cluster column to match mergin dataframe
        df_need_state_facings = df_need_state_facings.rename(columns={"final_cluster_labels": "cluster"})

        # Get unique cluster/pog size to merge to the dataframe
        df_need_state_facings = df_need_state_facings[df_need_state_facings["plano_id"].notna()]
        df_need_state_facings["plano_id"] = df_need_state_facings["plano_id"].astype(int).astype(str)
        df_need_state_facings = df_need_state_facings.merge(
            df_versions,
            on=["cluster", "plano_id"],
            how="left"
        )

        # Drop unused columns 
        df_need_state_facings = df_need_state_facings.drop(columns=["cluster"])

    # Assure correct data types
    df_need_state_facings = df_need_state_facings.astype({"plano_ft": "float", 
                                                          "fixture_size": "float",
                                                          "plano_id": "str"})
  
    return df_need_state_facings


def get_linked_skus(df_base: pd.DataFrame) -> pd.DataFrame:
    # Load linked SKUs
    ls_linked_skus = []
    for file_name in glob(f"{context.data_stores.raw_data.file_path.linked_items}/*.xlsx"):
        df = pd.read_excel(file_name, engine="openpyxl")
        ls_linked_skus.append(df)

    df_linked_skus = pd.concat(ls_linked_skus, ignore_index=True)
    # Update column names based on new template format
    columns_to_rename = {
        "primary_sku_no": "pivot_item_no_nbr",
        "linked_sku_no": "linked_item_no_nbr",
        "pog_no": "plano_id",
        "category_desc": "planogram_dsc"
    }
    df_linked_skus = df_linked_skus.rename(columns={col: new_col for col, new_col in columns_to_rename.items() if col in df_linked_skus.columns})

    df_linked_skus["plano_id"] = df_linked_skus["plano_id"].astype(str)

    # Get discontinued items list
    df_disc_items = df_base[df_base["disc_item"] == 1][["item_no_nbr", "plano_id"]].drop_duplicates()
    disc_items_set = set(df_disc_items["item_no_nbr"].unique())
    
    # Filter out rows where either pivot or linked SKU is discontinued
    df_linked_skus = df_linked_skus[
        (~df_linked_skus["pivot_item_no_nbr"].isin(disc_items_set)) &
        (~df_linked_skus["linked_item_no_nbr"].isin(disc_items_set))
    ]
    
    df_plano_cat_map = df_base[[
        "category_level_dept_nbr", 
        "category_level_dept_name",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "plano_id",
        "sub_plano"
    ]]
    
    # Merge the two dataframe to get category nbr information
    df_final = df_linked_skus.merge(df_plano_cat_map, on="plano_id", how="left")
    
    # Keep relevant columns
    df_final = df_final[[
        "category_level_dept_nbr", 
        "category_level_dept_name",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "pivot_item_no_nbr",
        "linked_item_no_nbr"
    ]].drop_duplicates()
        
    # Verify amount of NaNs in columns
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_space_data(df_base: pd.DataFrame) -> pd.DataFrame:
    # Filter the dataframe to only include entries with a facing
    df_base = df_base[df_base["hfacings"] > 0]
    
    df_final = df_base[[
        "item_no_nbr",
        "store_nbr",
        "final_cluster_labels",
        "plano_cat_id",
        "plano_cat_desc",
        "plano_id",
        "sub_plano",
        "plano_ft",
        "fixture_size",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "fixture_desc",
        "hfacings",
        "prod_unit_width_ft",
        "prod_unit_height_ft",
        "prod_unit_depth_ft",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "n_current_facings_sku",
        "n_current_linear_space_used_sku",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    # Fill in orientation information
    df_final.loc[:, "orientation"] = "front"
    
    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    # Add sub plano to plano
    df_final["plano_id"] = df_final["plano_id"] + df_final["sub_plano"]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)
    
    return df_final


def df_pull_store_characteristics(df_base: pd.DataFrame) -> pd.DataFrame:
    # Filter the dataframe to only include entries with a facing
    df_base = df_base[df_base["hfacings"] > 0]

    df_final = df_base[[
        "store_nbr",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "original_cluster_labels",
        "final_cluster_labels",
        "plano_ft",
        "fixture_desc",
        "fixture_size",
        "plano_id",
        "sub_plano",
        "n_total_linear_space_dept_fixture_ft",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()
  
    # Fill in missing information
    df_final.loc[:, "post_split_plano_ft"] = df_final["plano_ft"]
    df_final.loc[:, "pre_split_plano_ft"] = df_final["plano_ft"]
    df_final.loc[:, "plano_ft_change"] = 0
    df_final.loc[:, "plano_ft_override_ratio"] = (
        df_final["post_split_plano_ft"] / df_final["pre_split_plano_ft"]
    )
    df_final.loc[:, "addtl_linear_ft_gained"] = 0
    df_final.loc[:, "n_total_linear_space_dept_fixture_ft_for_own_brand"] = 0
    df_final.loc[:, "cluster_labels_based_on"] = "final_cluster_labels"

    # # large value to avoid filtering out products based on depth or height
    df_final.loc[:, "height_space_dept_fixture_ft"] = 100
    df_final.loc[:, "depth_space_dept_fixture_ft"] = 100
    
    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    # Count stores per plano/cluster
    df_final.loc[:, "n_stores"] = (
        df_final
        .groupby(["final_cluster_labels", "plano_ft", "fixture_size", "plano_id"])
        ["store_nbr"].transform("nunique")
    )
    
    # Add sub plano to plano
    df_final["plano_id"] = df_final["plano_id"] + df_final["sub_plano"]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_pog_category_map(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base[[
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag"
    ]].drop_duplicates()

    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_cluster_item_scope(df_base) -> pd.DataFrame:
    df_final = df_base[[
        "item_no_nbr",
        "item_no_desc",
        "brand_name",
        "vendor_name",
        "vendor_number",
        "seg_dsc",
        "subcat_dsc",
        "private_label_ind",
        "source",
        "disc_item",
        "clone_item_item_no_nbr",
        "clone_pct",
        "need_state_unique_id",
        "fixture_desc",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "plano_id",
        "sub_plano",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "final_cluster_labels",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    # Fill in missing information
    df_final.loc[:, "opti_item_scope_cluster"] = 0

    # Create a cdt column
    df_final["cdt"] = df_final["need_state_unique_id"].str.rsplit("_", n=1).str[0]

    # Fill
    df_final["disc_item"] = df_final["disc_item"].fillna(0)

    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    # Add sub plano to plano
    df_final["plano_id"] = df_final["plano_id"] + df_final["sub_plano"]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_cluster_item_master(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base[[
        "item_no_nbr",
        "item_no_desc",
        "brand_name",
        "vendor_name",
        "vendor_number",
        "private_label_ind",
        "source",
        "clone_item_item_no_nbr",
        "clone_pct",
        "need_state",
        "need_state_unique_id",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "final_cluster_labels",
        "clone_type",
        "prod_unit_width_ft",
        "prod_unit_height_ft",
        "prod_unit_depth_ft",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    # Fill in missing information
    df_final.loc[:, "opti_item_scope_cluster"] = 0
    df_final.loc[:, "need_state_override"] = df_final["need_state"]
    df_final.loc[:, "prod_cat_name"] = df_final["plano_cat_desc"]
    df_final.loc[:, "n_current_linear_space_per_facing_sku"] = df_final["prod_unit_width_ft"]

    for col in ["brand_name", "vendor_name", "vendor_number"]:
        df_final.loc[
            (df_final["source"] == "new") & (df_final[col].isna()), col
        ] = "NEW SKU"  # To Do - MO: Check if still necessary


    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_sku_transference(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base[[
        "item_no_nbr",
        "need_state_unique_id",
        "n_transference_sku",
    ]].drop_duplicates()

    # Drop duplicates
    df_final = df_final.drop_duplicates()

    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_item_space_productivity(df_base: pd.DataFrame,
                                    df_elasticity: pd.DataFrame,
                                    df_dnp: pd.DataFrame) -> pd.DataFrame:
    # First fill unit price if the item appears in another store
    df_base["unit_price"] = (
        df_base["unit_price"].fillna(
            df_base.groupby(["item_no_nbr"])["unit_price"].transform("median")
        )
    )
    
    df_base = df_base[[
        "item_no_nbr",
        "fixture_desc",
        "plano_id",
        "brand_name",
        "vendor_name",
        "vendor_number",
        "need_state_unique_id",
        "final_cluster_labels",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "special_version_id",
        "lp_flags",
        "unit_price",
        "boh_param_a",
        "boh_param_b",
    ]].drop_duplicates()

    df_base["final_cluster_labels"] = df_base["final_cluster_labels"] + "-" + df_base["lp_flags"]

    df_elasticity = df_elasticity[[
        "item_no_nbr",
        "final_cluster_labels",
        "need_state_unique_id",
        "fixture_desc",
        "is_elasticity_overridden",
        "elasticity_override_granularity",
        "n_space_prod_fit_facings_0",
        "n_space_prod_fit_facings_1",
        "n_space_prod_fit_facings_2",
        "n_space_prod_fit_facings_3",
        "n_space_prod_fit_facings_4",
        "n_space_prod_fit_facings_5",
        "n_space_prod_fit_facings_6",
        "n_space_prod_fit_facings_7",
        "n_space_prod_fit_facings_8",
        "n_space_prod_fit_facings_9",
        "n_space_prod_fit_facings_10",
        "n_space_prod_fit_facings_11",
        "n_space_prod_fit_facings_12",
        "n_space_prod_fit_facings_13",
        "n_space_prod_fit_facings_14",
        "n_space_prod_fit_facings_15",
        "n_space_prod_fit_facings_16",
        "n_space_prod_fit_facings_17",
    ]].drop_duplicates()

    # Consolidate the unit price per version
    df_unit_cost = df_base.groupby(["item_no_nbr", "final_cluster_labels", "lp_flags", "fixture_desc"])["unit_price"].median().reset_index()
    df_base = df_base.drop(columns=["unit_price"]).drop_duplicates()
    df_base = df_base.merge(
        df_unit_cost,
        on=["item_no_nbr", "final_cluster_labels", "lp_flags", "fixture_desc"],
        how="left"
    )
    
    # Merge dnp data
    df_final = df_base.merge(
        df_dnp,
        on=["item_no_nbr"],
        how="left"
    )

    # Merge elasticity data
    df_final = df_final.merge(
        df_elasticity,
        on=["item_no_nbr", "final_cluster_labels", "need_state_unique_id", "fixture_desc"],
        how="left"
    )

    # Create a CDT column
    df_final["cdt"] = df_final["need_state_unique_id"].str.rsplit("_", n=1).str[0]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info("Missing values before filling")
        log.info(na_cols)
        
    # Fill non elasticity curves columns with missing values
    columns_to_fill = ["unit_price", "boh_param_a", "boh_param_b"]

    # Fill missing elasticity values first on a need state level, cdt level & lasty fixture level
    for col in df_final.columns:
        if "n_space_prod_fit_facing" in col or col in columns_to_fill:
            # Need state level & cluster
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby(["final_cluster_labels", "need_state_unique_id"])[col].transform("median")
                )
            )

            # CDT level & cluster
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby(["final_cluster_labels", "cdt"])[col].transform("median")
                )
            )

            # fixture level & cluster
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby(["final_cluster_labels", "fixture_desc"])[col].transform("median")
                )
            )

            # Need state level
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby("need_state_unique_id")[col].transform("median")
                )
            )

            # CDT level
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby("cdt")[col].transform("median")
                )
            )

            # fixture level & cluster
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby("fixture_desc")[col].transform("median")
                )
            )

    # Fill in missing values
    df_final["is_elasticity_overridden"] = df_final["is_elasticity_overridden"].fillna(0)
    df_final["elasticity_override_granularity"] = df_final["elasticity_override_granularity"].fillna("other")

    # format final cluster label
    df_final["final_cluster_labels"] = (
        df_final["final_cluster_labels"].str.split("-").str[0] + "_" 
        + df_final["special_version_id"] + "-"
        + df_final["final_cluster_labels"].str.split("-").str[1]
    )
    
    # Drop additional columns
    df_final = df_final.drop(columns="cdt")
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info("Missing values after filling")
        log.info(na_cols)
    return df_final


def df_pull_need_state_productivity(df_base: pd.DataFrame,
                                    df_saturation: pd.DataFrame) -> pd.DataFrame:
    df_base = df_base[[
        "item_no_nbr",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "need_state_unique_id",
        "fixture_desc",
        "final_cluster_labels",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    df_base["final_cluster_labels"] = df_base["final_cluster_labels"] + "-" + df_base["lp_flags"]

    df_saturation = df_saturation[[
        "final_cluster_labels",
        "need_state_unique_id",
        "fixture_desc",
        "saturation_facings"
    ]].drop_duplicates()

    
    df_final = df_base.merge(
        df_saturation,
        on=["final_cluster_labels", "need_state_unique_id", "fixture_desc"],
        how="left"
    )

    # Create a CDT column
    df_final["cdt"] = df_final["need_state_unique_id"].str.rsplit("_", n=1).str[0]

    # Fill missing elasticity values first on a cdt level & lasty fixture level
    for col in df_final.columns:
        if "n_space_prod_fit_facing" in col:
            # CDT level
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby(["final_cluster_labels", "cdt"])[col].transform("median")
                )
            )

            # fixture level
            df_final[col] = (
                df_final[col].fillna(
                    df_final.groupby(["final_cluster_labels", "fixture_desc"])[col].transform("median")
                )
            )

    # Fill missing saturation values
    # CDT level
    df_final["saturation_facings"] = (
        df_final["saturation_facings"].fillna(
            df_final.groupby(["final_cluster_labels", "cdt"])["saturation_facings"].transform("median")
        )
    )

    # fixture level
    df_final["saturation_facings"] = (
        df_final["saturation_facings"].fillna(
            df_final.groupby(["final_cluster_labels", "fixture_desc"])["saturation_facings"].transform("median")
        )
    )
    
    # fixture level
    df_final["saturation_facings"] = (
        df_final["saturation_facings"].fillna(
            df_final.groupby(["fixture_desc"])["saturation_facings"].transform("median")
        )
    )

    # Drop additional columns
    df_final = df_final.drop(columns="cdt")
    
    # format final cluster label
    df_final["final_cluster_labels"] = (
        df_final["final_cluster_labels"].str.split("-").str[0] + "_" 
        + df_final["special_version_id"] + "-"
        + df_final["final_cluster_labels"].str.split("-").str[1]
    )

    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_full_need_state_productivity(df_base: pd.DataFrame,
                                         df_saturation: pd.DataFrame,
                                         df_saturation_lvl1: pd.DataFrame) -> pd.DataFrame:
    if context.financial_projections.saturation_granularity == "need_state":
        df_saturation_granularity = df_saturation.copy()
        df_saturation_granularity["lvl1_need_state_unique_id"] = df_saturation_granularity["need_state_unique_id"]
    else:
        df_saturation_granularity = df_saturation_lvl1.copy()
        
    df_base = df_base[[
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    df_final = df_saturation_granularity.merge(
        df_base,
        on=["plano_cat_desc"],
        how="left"
    )
    
    df_final["saturation_facings"] = df_final["saturation_facings"].astype(int)
    
    # format final cluster label
    df_final["final_cluster_labels"] = (
        df_final["final_cluster_labels"].str.split("-").str[0] + "_" 
        + df_final["special_version_id"] + "-"
        + df_final["final_cluster_labels"].str.split("-").str[1]
    )


    na_counts = df_final.isna().sum() / df_final.shape[0]
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_local_item_space(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base[[
        "final_cluster_labels",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    df_final.loc[:, "pct_space_for_local_items"] = 0

    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_forced_facings(df_base: pd.DataFrame,
                           df_elasticity: pd.DataFrame,
                           df_odd_items: pd.DataFrame,
                           df_enforced_skus: pd.DataFrame,
                           df_slow_moving: pd.DataFrame) -> pd.DataFrame:
    
    # Only keep entries linked to a plano being ran
    df_enforced_skus = df_enforced_skus[df_enforced_skus["plano_id"].isin(df_base["plano_id"].unique().tolist())]
    df_slow_moving = df_slow_moving[df_slow_moving["plano_id"].isin(df_base["plano_id"].unique().tolist())]
    
    # Split enforcement by SKUs with cluster & non-cluster specific targets
    df_cluster_enforced = df_enforced_skus[df_enforced_skus["final_cluster_labels"].notna()]
    df_cluster_enforced = df_cluster_enforced.rename(columns={"min_forced_facings": "cluster_min_forced_facings",
                                                              "max_forced_facings": "cluster_max_forced_facings",
                                                              "type": "cluster_facing_type"})

    # Split enforcement by SKUs with lp-flag & non-lp_flag specific targets
    if not df_cluster_enforced.empty:
        df_cluster_lp_flag_enforced = df_cluster_enforced[(df_cluster_enforced["final_cluster_labels"].notna()) & (df_cluster_enforced["final_cluster_labels"].str.contains("-"))]
        df_cluster_lp_flag_enforced["lp_flags"] = df_cluster_lp_flag_enforced["final_cluster_labels"].str.split("-").str[1]
        df_cluster_lp_flag_enforced["final_cluster_labels"] = df_cluster_lp_flag_enforced["final_cluster_labels"].str.split("-").str[0]
    else:
        df_cluster_lp_flag_enforced = df_cluster_enforced.copy()
        df_cluster_lp_flag_enforced["lp_flags"] = np.nan

    df_cluster_lp_flag_enforced = df_cluster_lp_flag_enforced.rename(columns={"cluster_min_forced_facings": "cluster_lp_flag_min_forced_facings",
                                                                          "cluster_max_forced_facings": "cluster_lp_flag_max_forced_facings",
                                                                          "cluster_facing_type": "cluster_lp_flag_facing_type"})



    df_always_enforced = df_enforced_skus[df_enforced_skus["final_cluster_labels"].isna()]
    df_always_enforced = df_always_enforced.drop(columns=["final_cluster_labels", "plano_ft", "fixture_size"])
    
    # Get a list of core_products
    core_products = list(set(
        df_always_enforced[df_always_enforced["type"] == "core"]["item_no_nbr"].unique().tolist()
        + df_cluster_enforced["item_no_nbr"].unique().tolist()
    ))
    
    log.info(f"Items with overall facing specifications: {df_always_enforced['item_no_nbr'].unique()}")
    log.info(f"Items with cluster facing specifications: {df_cluster_enforced['item_no_nbr'].unique()}")
    log.info(f"Items with cluster/lp flags facing specifications: {df_cluster_lp_flag_enforced['item_no_nbr'].unique()}")
    
    df_final = df_base[[
        "item_no_nbr",
        "need_state_unique_id",
        "plano_ft",
        "fixture_size",
        "plano_id",
        "sub_plano",
        "fixture_desc",
        "final_cluster_labels",
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "source",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "disc_item",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()

    df_elasticity = df_elasticity[[
        "final_cluster_labels",
        "item_no_nbr",
        "fixture_desc",
        "shape_enforced"
    ]].drop_duplicates()
    df_unique_comobos = df_base[["final_cluster_labels", "lp_flags","plano_id", "plano_ft", "fixture_size"]].drop_duplicates()
    df_unique_comobos_item = df_base[["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"]].drop_duplicates()
   
  
    # Count min facing per cluster/plano
    df_store_count = (
        df_base
        .groupby(["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"])
        .agg(store_count=("store_nbr", "nunique"))
        .reset_index()
    )
    df_item_wfacing_count = (
        df_base[(df_base["hfacings"] > 0)]
        .groupby(["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"])
        .agg(store_wfacing_count=("store_nbr", "nunique"))
        .reset_index()
    )
    
    # Merge core item representation dataframes
    df_item_representation = (
        df_unique_comobos_item.merge(
            df_store_count,
            on=["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )
        .merge(
            df_item_wfacing_count,
            on=["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"],
            how="left"
        )
    )
    df_item_representation["item_representation"] = df_item_representation["store_wfacing_count"] / df_item_representation["store_count"]
    
    # Get current facing per need state
    df_need_state_max_facings = df_base.groupby(["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"]).agg(
        curr_need_state_max_facings=("hfacings", "max")
    ).reset_index()
    df_need_state_max_facings["ns_total_combos_represented"] = (
        df_need_state_max_facings
        .groupby(["need_state_unique_id"])["curr_need_state_max_facings"]
        .transform("sum")
    )
    
    # Count percent of combos for which the item currently has a facing
    df_core_item_count = (
        df_base[(df_base["item_no_nbr"].isin(core_products))]
        .groupby(["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"])
        .agg(core_item_count=("item_no_nbr", "nunique"))
        .reset_index()
    )
    df_core_item_wfacing_count = (
        df_base[(df_base["hfacings"] > 0) & (df_base["item_no_nbr"].isin(core_products))]
        .groupby(["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"])
        .agg(core_item_wfacing_count=("item_no_nbr", "nunique"))
        .reset_index()
    )
    
    # Merge core item representation dataframes
    df_core_representation = (
        df_unique_comobos.merge(
            df_core_item_count,
            on=["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )
        .merge(
            df_core_item_wfacing_count,
            on=["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )
    )
    
    # Compute core representation and drop unneeded columns
    df_core_representation["core_representation"] = (
        df_core_representation["core_item_wfacing_count"] / df_core_representation["core_item_count"]
    )
    df_core_representation = df_core_representation.drop(columns=["core_item_wfacing_count", "core_item_count"])
    
    
    # Initialize min & max values
    df_final.loc[:, "min_forced_facings_guardrails"] = 0
    df_final.loc[:, "max_forced_facings_guardrails"] = context.optimization.model_formulation.max_facings_opti - 1

    # Merge shape enforce information & set max to 1 where enforced
    df_final = df_final.merge(
        df_elasticity,
        on=["final_cluster_labels", "item_no_nbr", "fixture_desc"],
        how="left"
    )
    df_final.loc[df_final["shape_enforced"] == 1, "max_forced_facings_guardrails"] = 1
 
    # Remove new items from odd items
    ls_new_items = df_base[df_base["source"] == "new"]["item_no_nbr"].unique().tolist()
    df_odd_items = df_odd_items[~df_odd_items["item_no_nbr"].isin(ls_new_items)]
    
    # Merge odd items & set max to the current value where the value is not null
    df_final = df_final.merge(
        df_odd_items,
        on=["final_cluster_labels", "item_no_nbr", "plano_id", "plano_ft", "fixture_size"],
        how="left"
    )
    df_final.loc[(df_final["max_facings"].notna())
                 # & (df_final["plano_id"] != "9211") # Shares items with other pogs
                 , "max_forced_facings_guardrails"] = df_final["max_facings"]
    
    # Merge items which need to keep at least one facing
    df_final = (
        df_final.merge(
            df_item_representation,
            on=["final_cluster_labels", "lp_flags", "item_no_nbr", "plano_id", "plano_ft", "fixture_size", "item_no_nbr"],
            how="left"
        )
        .merge(
            df_need_state_max_facings,
            on=["final_cluster_labels", "lp_flags", "need_state_unique_id", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )
        .merge(
            df_core_representation,
            on=["final_cluster_labels", "lp_flags", "plano_id", "plano_ft", "fixture_size"],
            how="left"
        )
    )

    df_final = df_final.merge(
        df_always_enforced,
        on=["item_no_nbr", "plano_id"],
        how="left"
    )

    df_final = df_final.merge(
        df_cluster_enforced,
        on=["final_cluster_labels", "plano_ft", "fixture_size", "item_no_nbr", "plano_id"],
        how="left"
    )

    df_final = df_final.merge(
        df_cluster_lp_flag_enforced,
        on=["final_cluster_labels", "lp_flags", "plano_ft", "fixture_size", "item_no_nbr", "plano_id"],
        how="left"
    )
        
    # Count number of stores which have a facing for the item & the stores with zero sales
    item_store_count = df_base[df_base["hfacings"] > 0].groupby("item_no_nbr").agg(
        store_count=("store_nbr", "nunique")
    ).reset_index()
    item_no_sales = df_base[(df_base["total_sales"] == 0)
                            & (df_base["hfacings"] > 0)].groupby("item_no_nbr").agg(
        null_sales_store_cnt=("store_nbr", "nunique")
    ).reset_index()

    # Merge item count in store with zero sales to the store count
    item_store_count = item_store_count.merge(item_no_sales, on="item_no_nbr", how="left")
    item_store_count["null_sales_store_cnt"] = item_store_count["null_sales_store_cnt"].fillna(0)
    item_store_count["no_sales_pct"] = item_store_count["null_sales_store_cnt"] / item_store_count["store_count"]
    item_no_sales = item_store_count[item_store_count["no_sales_pct"] == 1]["item_no_nbr"].unique().tolist()
        
    # If item is core/otch & currently has a facing, set minimum to 1
    df_final.loc[(df_final["item_representation"] > 0) 
                 & (df_final["type"].isin(["core", "otch"]))
                 & (df_final["min_forced_facings"] > 0), 
                 "min_forced_facings_guardrails"] = df_final["min_forced_facings"]
    
    # If item is core & new & need state has no existing items, 
    # set minimum to 1 if cluster/plano/plano size combo holds at least X% of existing core items
    df_final.loc[(df_final["core_representation"] > 0.8) 
                 & (df_final["source"] == "new")
                 & (df_final["type"].isin(["core"]))
                 & (df_final["min_forced_facings"] > 0), 
                 "min_forced_facings_guardrails"] = df_final["min_forced_facings"]
    df_final.loc[(df_final["core_representation"] > 0.8) 
             & (df_final["source"] == "new")
             & (df_final["type"].isin(["core"]))
             & (df_final["min_forced_facings"] > 0), 
             "max_forced_facings_guardrails"] = context.optimization.model_formulation.max_facings_opti - 1
    
    # If item is enforced to fixed values, set min/max accordingly
    df_final.loc[(df_final["type"] == "fixed_facings"), "min_forced_facings_guardrails"] = df_final["min_forced_facings"]
    df_final.loc[(df_final["type"] == "fixed_facings"), "max_forced_facings_guardrails"] = df_final["max_forced_facings"]
    
    # If item is enforced on a cluster level, set min/max accordingly
    df_final.loc[(df_final["cluster_facing_type"] == "fixed_facings"), "min_forced_facings_guardrails"] = df_final["cluster_min_forced_facings"]
    df_final.loc[(df_final["cluster_facing_type"] == "fixed_facings"), "max_forced_facings_guardrails"] = df_final["cluster_max_forced_facings"]

    # If item is enforced on a cluster-lp flag level, set min/max accordingly
    df_final.loc[(df_final["cluster_lp_flag_facing_type"] == "fixed_facings"), "min_forced_facings_guardrails"] = df_final["cluster_lp_flag_min_forced_facings"]
    df_final.loc[(df_final["cluster_lp_flag_facing_type"] == "fixed_facings"), "max_forced_facings_guardrails"] = df_final["cluster_lp_flag_max_forced_facings"]

    # format final cluster label
    df_final["final_cluster_labels"] = df_final["final_cluster_labels"] + "_" + df_final["special_version_id"]
    df_final = format_final_cluster_labels(df_final)
    
    # Add slow moving items which are cluster specific
    df_final = df_final.merge(
        df_slow_moving,
        on=["final_cluster_labels", "item_no_nbr", "plano_id", "plano_ft", "fixture_size"],
        how="left"
    )
    df_final["slow_moving"] = df_final["slow_moving"].fillna(0)
    
    # If item is slow moving on a cluster level, set min/max to 0
    df_final.loc[(df_final["slow_moving"] == 1), "min_forced_facings_guardrails"] = 0
    df_final.loc[(df_final["slow_moving"] == 1), "max_forced_facings_guardrails"] = 0

    # # If item is core/otch & is slow moving/odd item, set it's max equal to the min
    df_final.loc[(df_final["type"].isin(["core", "otch"]))
             & (df_final["min_forced_facings_guardrails"] > df_final["max_forced_facings_guardrails"]),
             "max_forced_facings_guardrails"] = context.optimization.model_formulation.max_facings_opti - 1

    # Set discontinued items to 0
    df_final.loc[df_final["disc_item"] == 1, "max_forced_facings_guardrails"] = 0
    df_final.loc[df_final["disc_item"] == 1, "min_forced_facings_guardrails"] = 0

    # Verify if any constraint has conflicts
    conflict_df = df_final[df_final["min_forced_facings_guardrails"] > df_final["max_forced_facings_guardrails"]]
    if conflict_df.shape[0] > 0:
        # Get the conflicting items with relevant details
        conflict_items = conflict_df[["item_no_nbr", "plano_id", "final_cluster_labels", 
                                    "min_forced_facings_guardrails", "max_forced_facings_guardrails"]].drop_duplicates()
        
        # Create a detailed error message
        error_details = []
        for _, row in conflict_items.iterrows():
            error_details.append(
                f"Item {row['item_no_nbr']} in plano {row['plano_id']} "
                f"(cluster: {row['final_cluster_labels']}): "
                f"min={row['min_forced_facings_guardrails']}, max={row['max_forced_facings_guardrails']}"
            )
        
        ipdb.set_trace()
        raise ValueError(
            f"Found {conflict_df.shape[0]} conflicts in enforcing facing constraints. "
            f"Items have min facings greater than max facings:\n" + 
            "\n".join(error_details)
        )

    df_final = df_final.rename(columns={"type": "facing_type"})
    df_final["facing_type"] = df_final["facing_type"].fillna(df_final["cluster_facing_type"])
    
    # Drop unused columns
    df_final = df_final.drop(columns=["item_representation",
                                      "curr_need_state_max_facings",
                                      "min_forced_facings", 
                                      "max_forced_facings", 
                                      "cluster_min_forced_facings", 
                                      "cluster_max_forced_facings"])
    
    
    # Add sub plano to plano
    df_final["plano_id"] = df_final["plano_id"] + df_final["sub_plano"]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_max_sku_facings(df_base: pd.DataFrame) -> pd.DataFrame:
    df_final = df_base.groupby([
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "category_level_dept_nbr",
        "category_level_dept_name",
    ]).agg(
        max_facings_per_sku=("hfacings", "max")
    ).reset_index()

    df_final["max_facings_per_sku"] = (
        df_final["max_facings_per_sku"]
        + context.optimization.model_formulation.max_incremental_facings_sku
    ).astype(int)

    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final


def df_pull_max_ns_facings(df_base: pd.DataFrame,
                           df_odd_items: pd.DataFrame,
                           df_forced_facings: pd.DataFrame,
                           df_need_state_facings: pd.DataFrame) -> pd.DataFrame:

    # Split enforcement by SKUs with cluster & non-cluster specific targets
    df_cluster_enforced = df_need_state_facings[df_need_state_facings["final_cluster_labels"].notna()]
    df_cluster_enforced = df_cluster_enforced.rename(columns={"min_forced_facings": "cluster_min_forced_facings",
                                                              "max_forced_facings": "cluster_max_forced_facings"})
    
    df_always_enforced = df_need_state_facings[df_need_state_facings["final_cluster_labels"].isna()]
    df_always_enforced = df_always_enforced.drop(columns=["final_cluster_labels", "plano_ft", "fixture_size"])
    
    log.info(f"Need states with overall facing specifications: {df_always_enforced['need_state_unique_id'].unique()}")
    log.info(f"Need states with cluster facing specifications: {df_cluster_enforced['need_state_unique_id'].unique()}")
    
    df_final = df_base[[
        "plano_cat_id",
        "plano_cat_desc",
        "dept_id",
        "risk_flag",
        "volume_flag",
        "final_cluster_labels",
        "need_state_unique_id",
        "category_level_dept_nbr",
        "category_level_dept_name",
        "plano_id",
        "sub_plano",
        "plano_ft",
        "fixture_size",
        "item_no_nbr",
        "hfacings",
        "store_nbr",
        "disc_item",
        "special_version_id",
        "lp_flags"
    ]].drop_duplicates()
    
    # Merge need state information to forced facings
    # df_forced_facings = df_forced_facings.merge(
    #     df_base[["item_no_nbr", "need_state_unique_id", "plano_id"]].drop_duplicates(),
    #     on=["item_no_nbr", "plano_id"],
    #     how="left"
    # )
    
    df_forced_facings = df_forced_facings.groupby(
        ["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"]
    ).agg(
        max_facing=("max_forced_facings_guardrails", "max")
    ).reset_index()
    
    # Merge forced facings
    df_final = df_final.merge(
        df_forced_facings,
        on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"],
        how="left"
    )
    
    # Merge odd items
    df_final = df_final.merge(
        df_odd_items,
        on=["final_cluster_labels", "item_no_nbr", "plano_id", "plano_ft", "fixture_size"],
        how="left"
    )

    # Initialize min & max values
    df_final.loc[:, "min_facings_in_need_state_forced_guardrail"] = 0
    df_final.loc[:, "max_facings_in_need_state_forced_guardrail"] = 99999

    # Count number of stores which have a facing for the ns & the stores count
    store_count_per_cluster = df_final.groupby(
        ["plano_cat_desc", "final_cluster_labels", "plano_id", 
         "special_version_id", "sub_plano", "plano_ft", "fixture_size"]).agg(
        n_stores=("store_nbr", "nunique")
    ).reset_index()
    store_count_per_cluster_ns = df_final[(df_final["hfacings"] > 0)
                                       & ((df_final["max_facings"] > 0) | (df_final["max_facings"].isna()))
                                       & (df_final["disc_item"] != 1)
                                       ].groupby(
        ["plano_cat_desc", "final_cluster_labels", "plano_id", 
         "special_version_id", "sub_plano", "plano_ft", "fixture_size", "need_state_unique_id"]).agg(
        n_stores_w_ns=("store_nbr", "nunique")
    ).reset_index()

    # Merge ns count into store count & fill missing values
    store_count_per_cluster_ns = store_count_per_cluster.merge(
        store_count_per_cluster_ns,
        on=["plano_cat_desc", "final_cluster_labels", "plano_id", 
            "special_version_id", "sub_plano", "plano_ft", "fixture_size"],
        how="left"
    )

    # Merge item count in store with zero sales to the store count
    store_count_per_cluster_ns["n_stores_w_ns"] = store_count_per_cluster_ns["n_stores_w_ns"].fillna(0)
    store_count_per_cluster_ns["pct_store_w_ns"] = (
        store_count_per_cluster_ns["n_stores_w_ns"] /store_count_per_cluster_ns["n_stores"]
    )
    store_count_per_cluster_ns = store_count_per_cluster_ns.drop(columns=["n_stores", "n_stores_w_ns"])

    # Count items per need state & merge back
    need_state_size = df_final.groupby("need_state_unique_id").agg(
        ns_item_count=("item_no_nbr", "nunique")
    ).reset_index()
    df_final = df_final.merge(need_state_size, on="need_state_unique_id", how="left")

    # Drop non-relevant columns after counting store pct with need state
    df_final = df_final.drop(columns=["hfacings", "store_nbr", "item_no_nbr", "disc_item"]).drop_duplicates()
    df_final = df_final.drop_duplicates()

    # Merge need state pct coverage information
    df_final = df_final.merge(
        store_count_per_cluster_ns,
        on=["plano_cat_desc", "final_cluster_labels", "plano_id", 
            "special_version_id", "sub_plano", "plano_ft", "fixture_size", "need_state_unique_id"],
        how="left"
    )

    # Set forced facings to 1 if need state is in all stores
    if context.optimization_config.model_formulation.enable_min_max_need_state_facings_constraint_single_item_ns:
        df_final.loc[(df_final["pct_store_w_ns"] >= 1)
                     , "min_facings_in_need_state_forced_guardrail"] = 1
    else:
        df_final.loc[(df_final["pct_store_w_ns"] >= 1)
                     & (df_final["ns_item_count"] > 1)
                     & (df_final["max_facing"] > 0)
                     , "min_facings_in_need_state_forced_guardrail"] = 1
    
    # Change plano id type
    df_cluster_enforced["plano_id"] = df_cluster_enforced["plano_id"].astype(str)
    df_always_enforced["plano_id"] = df_always_enforced["plano_id"].astype(str)
    df_final["plano_id"] = df_final["plano_id"].astype(str)

    # format final cluster label
    df_final = format_final_cluster_labels(df_final)
    
    # Merge need state facings overrides
    df_final = df_final.merge(df_cluster_enforced, 
                              on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "need_state_unique_id"], 
                              how="left")
    df_final = df_final.merge(df_always_enforced, 
                          on=["plano_id", "need_state_unique_id"], 
                          how="left")
    
    # apply need state facings overrides
    df_final.loc[df_final["min_forced_facings"].notna(), "min_facings_in_need_state_forced_guardrail"] = df_final["min_forced_facings"]
    df_final.loc[(df_final["max_forced_facings"] != 99999) & (df_final["max_forced_facings"].notna()), "max_facings_in_need_state_forced_guardrail"] = df_final["max_forced_facings"]
    df_final.loc[df_final["cluster_min_forced_facings"].notna(), "min_facings_in_need_state_forced_guardrail"] = df_final["cluster_min_forced_facings"]
    df_final.loc[(df_final["cluster_max_forced_facings"] != 99999) 
    & (df_final["cluster_max_forced_facings"].notna()), "max_facings_in_need_state_forced_guardrail"] = df_final["max_forced_facings"]
    
    # Drop unused colums
    df_final = df_final.drop(columns=["min_forced_facings", 
                                      "max_forced_facings", 
                                      "cluster_min_forced_facings", 
                                      "cluster_max_forced_facings"])

    # Add special version flag to cluster
    df_final["final_cluster_labels"] = (
        df_final["final_cluster_labels"].str.split("-").str[0] + "_" 
        + df_final["special_version_id"] + "-"
        + df_final["final_cluster_labels"].str.split("-").str[1]
    )
    
    # Add sub plano to plano
    df_final["plano_id"] = df_final["plano_id"] + df_final["sub_plano"]
    
    na_counts = df_final.isna().sum() / df_final.shape[0] 
    na_cols = na_counts[na_counts > 0]
    if na_cols.shape[0] != 0:
        log.info(na_cols)

    return df_final
