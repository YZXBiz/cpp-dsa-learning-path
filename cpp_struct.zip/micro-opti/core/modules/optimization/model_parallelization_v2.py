import gc
from typing import Tuple, Union
from core.utils.misc import match_schema_before_saving
import pandas as pd
from datetime import datetime

from core.modules.optimization.data_prep import process_constraint_files
from core.modules.optimization.manual_constraints_processing import (
    add_need_state_facings_caps_information,
    add_pivot_and_linked_sku_pair_constraints,
    add_supplier_and_brand_space_constraints,
    add_global_linear_space_constraints,
    add_new_replacement_item_fixed_facing_constraint,
)
from core.modules.optimization.model_formulation_v2 import (
    define_optimization_model_v2,
    solve_model_cluster_plano_cat_dept_fixture_v2,
    run_optimization_qc
)
from core.modules.optimization.model_sets_and_params_v2 import (
    create_optimization_model_sets_and_params_v2,
)
from core.utils.optimizer_helpers import check_duplicates
from core.modules.optimization.post_processing_v2 import (
    post_process_solved_model,
    calculate_need_state_adjusted_space_productivity
)
from oxygen.files.readers import reader
from core.utils.storage import write_object
from core.utils.space_context.run_versioning import complete_file_path
from core.schemas.optimization import (
    OptimizationMasterModelingOutput,
    OptimizationMasterModelingOutputWithSlackVariables,
)
from core.modules.optimization.item_POD_constraint_prep import (
    calculate_n_stores_item_no_exist_after_forced_drop,
    calculate_n_stores_item_no_exist_after_forced_facings,
    determine_regional_items,
    add_item_POD_constraints,
)
from core.modules.optimization.brand_POD_constraint_prep import (
    add_brand_POD_constraints,
)
from core.utils.elasticity_helpers import (
    root_with_run_id,
)
from core.utils.run_parameter import (
    update_scenario_column,
    save_slack_data_to_table
)
from oxygen.conf.context import context
import logging
import ipdb 

log = logging.getLogger(__name__)


def formulate_and_solve_all_opti_problems_in_dept_v2(
        df_optimization_master_data_dept: pd.DataFrame,
        df_supplier_and_brand_requested_space: pd.DataFrame,
        df_global_linear_change_requested_space: pd.DataFrame,
        df_local_items_requested_space: pd.DataFrame,
        df_items_forced_facings_guardrails: pd.DataFrame,
        df_own_brand_space_constraints: pd.DataFrame,
        df_item_POD_active: pd.DataFrame,
        df_item_POD_exempt: pd.DataFrame,
        df_brand_POD_active: pd.DataFrame,
        df_max_facings_per_sku: pd.DataFrame,
        df_pivot_and_linked_sku_pair_constraints: pd.DataFrame,
        df_need_state_min_max_facings_constraints: pd.DataFrame,
        df_original_cluster_IOH_constraints: pd.DataFrame,
        df_full_ioh_curves_wide: pd.DataFrame,
        dependent_var: str,
        category_level_dept_nbr: int,
        plano_cat_desc: str,
        department: int,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    This function is a wrapper function meant to be used in API calls, as it will solve all optimization problems and
    assortments for all (final_cluster_labels, plano_ft, fixture_size) existing within a given (plano_cat_desc, dept_id)
    combination.
    Args:
        df_optimization_master_data_dept: Optimization master dataset for that specific POG Category over which we
        are looping and to which we want to add the manual constraints data
        df_supplier_and_brand_requested_space: comes from an API call, provides a % of linear space in a POG
        Category to be reserved by optimizer for a specific supplier / brand
        df_global_linear_change_requested_space: comes from an API call, provides a linear space range a brand or
        supplier occupies globally across all versions
        df_local_items_requested_space: comes from an API call, provides a % of linear space in a POG Category to be
        reserved by optimizer for local items only
        df_items_forced_facings_guardrails: comes from an API call, provides a list of items that we want to hold
        constant (i.e. that will keep their current number of facings)
        df_own_brand_space_constraints: comes from an API call, provides a max % drop of own brand space within a
        (POG Category, Department); e.g. if own brands have 100ft of total linear space, the minimum they can end up
        with post-optimizer is 90ft if that max percent drop is 10%
        df_item_POD_active: contains the active items for which we want to apply POD constraints
        df_item_POD_exempt: contains the exempt items for which we don't want to apply item POD constraints
        df_brand_POD_active: contains the active brands for which we want to apply POD constraints
        df_max_facings_per_sku: Constraint dataframe containing the max number of facings a SKU can have for a given
        dept (and applies to all SKUs in that department)
        df_pivot_and_linked_sku_pair_constraints: Constraint dataframe containing pairs of pivot and linked SKUs,
        where if the pivot SKU gets assigned >= 1 facing by optimizer then the linked SKU also needs to be assigned
        >= 1 facing by optimizer
        df_need_state_min_max_facings_constraints: Contains min and max facings for a need state, which can override
        our initial need state growth constraint based on e.g. need state saturation curves
        df_original_cluster_IOH_constraints: Constraint dataframe containing the original cluster IOH constraints
        df_full_ioh_curves_wide: Contains the full IOH curves data
        dependent_var: Dependent variable on which we're optimizing (can either be sales or dnp)
        category_level_dept_nbr: Category_level selected by CM
        plano_cat_desc: POG category for which we want to solve all optimization problems
        department: Department within the given `plano_cat_desc` for which we want to solve all optimization problems
        parameter) optimizations to keep the databricks cluster alive

    Returns:
    A pandas dataframe corresponding to the outputs from optimization all (final_cluster_labels, plano_ft,
    fixture_size) existing within a given (plano_cat_desc, dept_id) combination
    """
    (
        df_supplier_and_brand_requested_space,
        df_global_linear_change_requested_space,
        df_local_items_requested_space,
        df_items_forced_facings_guardrails,
        df_own_brand_space_constraints,
        df_max_facings_per_sku,
        df_pivot_and_linked_sku_pair_constraints,
        df_need_state_min_max_facings_constraints,
        df_original_cluster_IOH_constraints,
        df_full_ioh_curves_wide,
        df_item_POD_active,
        df_item_POD_exempt,
        df_brand_POD_active,
    ) = process_constraint_files(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        df_supplier_and_brand_requested_space=df_supplier_and_brand_requested_space,
        df_global_linear_change_requested_space=df_global_linear_change_requested_space,
        df_local_items_requested_space=df_local_items_requested_space,
        df_items_forced_facings_guardrails=df_items_forced_facings_guardrails,
        df_own_brand_space_constraints=df_own_brand_space_constraints,
        df_max_facings_per_sku=df_max_facings_per_sku,
        df_pivot_and_linked_sku_pair_constraints=df_pivot_and_linked_sku_pair_constraints,
        df_need_state_min_max_facings_constraints=df_need_state_min_max_facings_constraints,
        df_original_cluster_IOH_constraints=df_original_cluster_IOH_constraints,
        df_full_ioh_curves_wide=df_full_ioh_curves_wide,
        df_item_POD_active=df_item_POD_active,
        df_item_POD_exempt=df_item_POD_exempt,
        df_brand_POD_active=df_brand_POD_active,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    df_optimization_master_data_dept_w_manual_constraints = add_manual_constraints_to_opti_data(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        df_supplier_and_brand_requested_space=df_supplier_and_brand_requested_space,
        df_global_linear_change_requested_space=df_global_linear_change_requested_space,
        df_local_items_requested_space=df_local_items_requested_space,
        df_items_forced_facings_guardrails=df_items_forced_facings_guardrails,
        df_own_brand_space_constraints=df_own_brand_space_constraints,
        df_item_POD_active=df_item_POD_active,
        df_item_POD_exempt=df_item_POD_exempt,
        df_brand_POD_active=df_brand_POD_active,
        df_max_facings_per_sku=df_max_facings_per_sku,
        df_pivot_and_linked_sku_pair_constraints=df_pivot_and_linked_sku_pair_constraints,
        df_need_state_min_max_facings_constraints=df_need_state_min_max_facings_constraints,
        df_original_cluster_IOH_constraints=df_original_cluster_IOH_constraints,
        df_full_ioh_curves_wide=df_full_ioh_curves_wide,
    )

    # Drop duplicate rows
    df_optimization_master_data_dept_w_manual_constraints = (
        df_optimization_master_data_dept_w_manual_constraints.drop_duplicates()
    )

    check_duplicates(
        df_optimization_master_data_dept_w_manual_constraints,
        "df_optimization_master_data_dept_w_manual_constraints",
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level,
    )
    (
        df_optimization_master_data_filt_post_processed,
        is_problem_infeasible,
    ) = formulate_and_solve_optimization(
        df_optimization_master_data_dept_w_manual_constraints,
        dependent_var=dependent_var,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    reader.write(
        df=df_optimization_master_data_filt_post_processed,
        file_path=complete_file_path(
            context.data_stores.optimization.root_path,
            context.data_stores.optimization.modeling.optimization_data_input,
            at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
            dependent_var=dependent_var,
            category_level_dept_nbr=category_level_dept_nbr,
            plano_cat_desc=plano_cat_desc,
            department=department,
        ),
        root=context.data_stores.optimization.save_to_datastores_root.modeling,
    )
    log.info(
        f"Solving optimization for [{category_level_dept_nbr}, {plano_cat_desc}, {department}]"
    )

    if is_problem_infeasible == True:
        log.warning(
            f"No dataframes to concatenate. Returning an empty dataframe for "
            f"category_level_dept_nbr={category_level_dept_nbr},plano_cat_desc={plano_cat_desc},department={department}"
        )
        all_columns = dir(OptimizationMasterModelingOutput)
        df_save_department = pd.DataFrame(columns=all_columns)
        df_final = pd.DataFrame(columns=all_columns)
    else:
        df_save_department = df_optimization_master_data_filt_post_processed

        # TODO: Move this to a function
        config_grouping = (
                context.groupby_granularity.financial_projections
                + context.financial_projections.addtl_item_ranking_grouping_cols_all_stores
                + ["x_ifcg_optimal_value"]
        )

        relevant_columns = (
                config_grouping
                + [
                    "cdt",
                    "n_current_linear_space_per_facing_sku",
                    "n_optimal_facings_sku",
                    "n_current_facings_sku",
                ]
                + [
                    x
                    for x in df_save_department.columns
                    if "n_space_prod_fit_facings_" in x
                ]
        )

        path_need_state_saturation_curves = complete_file_path(
            context.data_stores.space_elasticity.root_path,
            context.data_stores.space_elasticity.modeling.space_productivity_need_state_full_df,
            at_datastores_root=context.data_stores.space_elasticity.save_to_datastores_root.modeling,
            run_id_folder=context.run_id.elasticity_run_id,
            category_level_dept_nbr=category_level_dept_nbr,
            plano_cat_desc=plano_cat_desc,
            department=department,
            dependent_var=dependent_var
        )
        df_all_need_state_curves = reader.read(
            file_path=path_need_state_saturation_curves,
            root=root_with_run_id(
                context.run_id.elasticity_run_id,
                context.data_stores.space_elasticity.save_to_datastores_root.modeling,
            ),
        )

        
        # Adjust column names
        df_save_department_mod = df_save_department.copy()
        df_save_department_mod["category_level_dept_nbr"] = category_level_dept_nbr
        df_save_department_mod["category_level_dept_name"] = plano_cat_desc
        df_save_department_mod["store_nbr"] = df_save_department_mod["representative_store_nbr"]
        
        # For categories that have a sub planogram ID, remove those
        df_save_department_mod["plano_id"] = df_save_department_mod["plano_id"].str.split("_").str[0]

        # Get the need_state to lvl1_need_state mapping
        need_state_levels_mapping = df_all_need_state_curves[[
            "plano_cat_desc",
            "fixture_desc",
            "need_state_unique_id",
            "lvl1_need_state_unique_id"
        ]].drop_duplicates()
        
        # Merge level 1 need state info
        df_save_department_mod = df_save_department_mod.merge(
            need_state_levels_mapping,
            on=["plano_cat_desc", "fixture_desc", "need_state_unique_id"],
            how="left"
        )

        # Fill missing lvl1_need_state_unique_id with need_state_unique_id
        df_save_department_mod["lvl1_need_state_unique_id"] = df_save_department_mod["lvl1_need_state_unique_id"].fillna(
            df_save_department_mod["need_state_unique_id"]
        )

        # Only apply post processing to chosen rows
        df_save_department_mod_ifcg0 = df_save_department_mod[df_save_department_mod["x_ifcg_optimal_value"] == 0]
        df_save_department_mod = df_save_department_mod[df_save_department_mod["x_ifcg_optimal_value"] == 1]
        
        # Apply post-processing adjusted space productivity
        (
            df_optimal_adjusted_value,
            df_current_adjusted_value,
        ) = calculate_need_state_adjusted_space_productivity(
            df_opti_modeling_output=df_save_department_mod[relevant_columns],
            df_all_need_state_curves=df_all_need_state_curves,
            item_ranking_grouping_cols=config_grouping,
        )
        
        df_save_department_mod = pd.concat([df_save_department_mod, df_save_department_mod_ifcg0], ignore_index=True)

        # Merge new columns
        df_final = df_save_department_mod.merge(
            df_optimal_adjusted_value,
            on=config_grouping,
            how="left",
        ).rename(
            columns={"adjusted_incremental_value": "n_adjusted_optimal_space_productivity"}
        )

        # Then, merge current adjusted value and ranking list to the original item-level data frame
        df_final = df_final.merge(
            df_current_adjusted_value,
            on=config_grouping,
            how="left",
        ).rename(
            columns={"adjusted_incremental_value": "n_adjusted_current_space_productivity"}
        )
        
        # ipdb.set_trace()
        
        df_final["n_adjusted_optimal_space_productivity"] = df_final["n_adjusted_optimal_space_productivity"].fillna(0)
        df_final["n_adjusted_current_space_productivity"] = df_final["n_adjusted_current_space_productivity"].fillna(0)

    # Match different schema depending on whether we set enable_enforce_as_many_need_states_as_possible_constraint to True or False
    if (
            context.optimization_config.model_formulation.enable_enforce_as_many_need_states_as_possible_constraint
            == False
    ):
        df_save_department = match_schema_before_saving(
            df_save_department, OptimizationMasterModelingOutput
        )
    else:
        df_save_department = match_schema_before_saving(
            df_save_department, OptimizationMasterModelingOutputWithSlackVariables
        )

    return df_save_department, df_final


def add_manual_constraints_to_opti_data(
        df_optimization_master_data_dept: pd.DataFrame,
        df_supplier_and_brand_requested_space: pd.DataFrame,
        df_global_linear_change_requested_space: pd.DataFrame,
        df_local_items_requested_space: pd.DataFrame,
        df_items_forced_facings_guardrails: pd.DataFrame,
        df_own_brand_space_constraints: pd.DataFrame,
        df_item_POD_active: pd.DataFrame,
        df_item_POD_exempt: pd.DataFrame,
        df_brand_POD_active: pd.DataFrame,
        df_max_facings_per_sku: pd.DataFrame,
        df_pivot_and_linked_sku_pair_constraints: pd.DataFrame,
        df_need_state_min_max_facings_constraints: pd.DataFrame,
        df_original_cluster_IOH_constraints: pd.DataFrame,
        df_full_ioh_curves_wide: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function will add the manual constraints (from flat file or directly from API call) such as net new SKUs,
    discontinued SKUs, space per brand/vendor, etc.
    Args:
        df_optimization_master_data_dept: Optimization master dataset for that specific POG Category over which we
        are looping and to which we want to add the manual constraints data
        df_supplier_and_brand_requested_space: comes from an API call, provides a % of linear space in a POG
        Category to be reserved by optimizer for a specific supplier / brand
        df_global_linear_change_requested_space: comes from an API call, provides a % of linear space a dimension
         occupies globally
        df_local_items_requested_space: comes from an API call, provides a % of linear space in a POG Category to be
        reserved by optimizer for local items only
        df_items_forced_facings_guardrails: comes from an API call, provides a list of items that we want to hold
        constant (i.e. that will keep their current number of facings)
        df_need_state_override: contains the need state overrides for a given item_no_nbr
        df_own_brand_space_constraints: comes from an API call, provides a max % drop of own brand space within a
        (POG Category, Department); e.g. if own brands have 100ft of total linear space, the minimum they can end up
        with post-optimizer is 90ft if that max percent drop is 10%
        df_max_facings_per_sku: Constraint dataframe containing the max number of facings a SKU can have for a given
        dept (and applies to all SKUs in that department)
        df_pivot_and_linked_sku_pair_constraints: Constraint dataframe containing pairs of pivot and linked SKUs,
        where if the pivot SKU gets assigned >= 1 facing by optimizer then the linked SKU also needs to be assigned
        >= 1 facing by optimizer
        df_need_state_min_max_facings_constraints: Contains min and max facings for a need state, which can override
        our initial need state growth constraint based on e.g. need state saturation curves
        df_original_cluster_IOH_constraints: Constraint dataframe containing the original cluster IOH constraints
        df_full_ioh_curves_wide: Contains the full IOH curves data

    Returns:
    df_optimization_master_data_dept_w_manual_constraints: Optimization master dataset for that specific POG Category
    over which we are looping, now containing the manual constraints
    """
    # Adding the net new SKUs from the manual constraint dataframes
    na_counts = df_optimization_master_data_dept.isna().sum()
    na_cols = na_counts[na_counts > 0]
    log.info(na_cols)

    if (
            df_optimization_master_data_dept[["item_no_nbr", "dept_id", "plano_id", "need_state_unique_id"]]
                    .drop_duplicates()[["item_no_nbr", "plano_id", "dept_id"]]
                    .duplicated()
                    .any()
    ):
        raise ValueError(
            "Duplicate need_state_unique_id found in df_optimization_master_data_dept"
        )

    # Joining sets and constraints data
    df_optimization_master_data_dept = (
        df_optimization_master_data_dept.merge(
            df_items_forced_facings_guardrails,
            on=(
                    context.groupby_granularity.optimizer
                    + context.optimization.data_prep.addtl_agg_optimizer_sku_level
            ),
            how="left",
        )
        .merge(
            df_own_brand_space_constraints,
            on=(context.groupby_granularity.optimizer + ["final_cluster_labels"]),
            how="left",
        )
        .merge(
            df_local_items_requested_space,
            on=(context.groupby_granularity.optimizer + ["final_cluster_labels"]),
            how="left",
        )
        .merge(
            df_max_facings_per_sku,
            on=context.groupby_granularity.optimizer,
            how="left",
        )
        .merge(
            df_need_state_min_max_facings_constraints,
            on=(
                    context.groupby_granularity.optimizer
                    + context.optimization.data_prep.addtl_agg_need_state_level_constraints
                    + ["plano_id", "plano_ft", "fixture_size"]
            ),
            how="left",
        )
        # TODO: uncomment after IOH data is available
        # .merge(
        #     df_original_cluster_IOH_constraints,
        #     on=(
        #         context.groupby_granularity.optimizer
        #         + context.optimization.data_prep.addtl_agg_wc_cluster_level
        #     ),
        #     how="left",
        # )
        # .merge(
        #     df_full_ioh_curves_wide,
        #     on=context.groupby_granularity.optimizer
        #     + ["original_cluster_labels", "item_no_nbr"],
        #     how="left",
        # )
    )

    # TODO: Remove once bug is fixed downstream
    df_optimization_master_data_dept["min_facings_in_need_state_forced_guardrail"] = df_optimization_master_data_dept[
        "min_facings_in_need_state_forced_guardrail"].fillna(0)
    df_optimization_master_data_dept["max_facings_in_need_state_forced_guardrail"] = df_optimization_master_data_dept[
        "max_facings_in_need_state_forced_guardrail"].fillna(9999)

    # SKUs that don't fit in height/depth the cluster x fixture are excluded from optimizer
    if context.optimization_config.model_data_prep.enable_height_depth_constraints:
        df_optimization_master_data_dept[
            [
                "fits_height_cluster_fixture_sku",
                "fits_depth_cluster_fixture_sku",
                "fits_height_depth_cluster_fixture_sku",
            ]
        ] = 1
        df_optimization_master_data_dept.loc[
            (
                    df_optimization_master_data_dept["prod_unit_height_ft"]
                    > df_optimization_master_data_dept["height_space_dept_fixture_ft"]
            ),
            "fits_height_cluster_fixture_sku",
        ] = 0

        df_optimization_master_data_dept.loc[
            (
                    df_optimization_master_data_dept["prod_unit_depth_ft"]
                    > df_optimization_master_data_dept["depth_space_dept_fixture_ft"]
            ),
            "fits_depth_cluster_fixture_sku",
        ] = 0

        df_optimization_master_data_dept.loc[
            (
                    (
                            df_optimization_master_data_dept["fits_depth_cluster_fixture_sku"]
                            == 0
                    )
                    | (
                            df_optimization_master_data_dept["fits_height_cluster_fixture_sku"]
                            == 0
                    )
            ),
            "fits_height_depth_cluster_fixture_sku",
        ] = 0

        condition_exclusion_not_fit = (
                (df_optimization_master_data_dept.include_in_optimizer_choices == 1)
                & (
                        df_optimization_master_data_dept.fits_height_depth_cluster_fixture_sku
                        == 0
                )
                & (df_optimization_master_data_dept.is_net_new_sku == 0)
        )

        df_optimization_master_data_dept["excluded_not_fit"] = 0
        df_optimization_master_data_dept.loc[
            condition_exclusion_not_fit,
            "excluded_not_fit",
        ] = 1

        excluded_skus_cluster_fixture = df_optimization_master_data_dept[
            condition_exclusion_not_fit
        ]["item_no_nbr"].unique()

        df_perc_excluded_per_c_g = (
            df_optimization_master_data_dept[
                df_optimization_master_data_dept.include_in_optimizer_choices == 1
                ]
            .groupby(
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_store_representative
            )
            .agg({"excluded_not_fit": "sum", "item_no_nbr": "count"})
            .reset_index()
        )
        df_perc_excluded_per_c_g["perc_excluded_per_cg"] = (
                                                                   df_perc_excluded_per_c_g.excluded_not_fit / df_perc_excluded_per_c_g.item_no_nbr
                                                           ) * 100

        df_optimization_master_data_dept.loc[
            condition_exclusion_not_fit,
            [
                "include_in_optimizer_choices",
                "min_forced_facings_guardrails",
                "max_forced_facings_guardrails",
            ],
        ] = 0

        non_excluded_skus = df_optimization_master_data_dept[
            df_optimization_master_data_dept.include_in_optimizer_choices == 1
            ].item_no_nbr.unique()
        excluded_skus_cluster_fixture = [
            item_no_nbr
            for item_no_nbr in excluded_skus_cluster_fixture
            if item_no_nbr not in non_excluded_skus
        ]

        log.info(
            f" {len(excluded_skus_cluster_fixture)} skus excluded from max depth/height constraint"
        )
        log.info(
            f" % of skus excluded from c_g based on max height/depth on average : {df_perc_excluded_per_c_g.perc_excluded_per_cg.mean()} %"
        )

    # add the item store count: n_stores_item_no_exist_after_forced_drop
    df_optimization_master_data_dept = calculate_n_stores_item_no_exist_after_forced_drop(
        df_optimization_master_data_dept
    )
    # add the item store count: n_stores_item_no_forced_exist
    df_optimization_master_data_dept = (
        calculate_n_stores_item_no_exist_after_forced_facings(
            df_optimization_master_data_dept
        )
    )

    # add the regional items cols: is_regional_item
    df_optimization_master_data_dept = determine_regional_items(
        df_optimization_master_data_dept
    )

    df_optimization_master_data_dept = add_item_POD_constraints(
        df_optimization_master_data_dept,
        df_item_POD_active,
        df_item_POD_exempt,
    )

    # Adding the brand POD constraints. Min/Max facings for a brand
    df_optimization_master_data_dept = add_brand_POD_constraints(
        df_optimization_master_data_dept,
        df_brand_POD_active,
    )

    df_optimization_master_data_dept[
        "max_facings_per_sku"
    ] = df_optimization_master_data_dept["max_facings_per_sku"].fillna(
        context.optimization.model_formulation.max_facings_opti - 1
    )

    # For SKUs that are being discontinued through df_items_forced_facings_guardrails, exclude from optimizer
    df_optimization_master_data_dept["is_discontinued_sku"] = 0
    df_optimization_master_data_dept.loc[
        (df_optimization_master_data_dept["min_forced_facings_guardrails"] == 0)
        & (df_optimization_master_data_dept["max_forced_facings_guardrails"] == 0),
        "is_discontinued_sku",
    ] = 1
    df_optimization_master_data_dept.loc[
        (df_optimization_master_data_dept["is_discontinued_sku"] == 1),
        "include_in_optimizer_choices",
    ] = 0

    df_optimization_master_data_dept = add_global_linear_space_constraints(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        df_global_linear_change_requested_space=df_global_linear_change_requested_space,
    )


    # Adding supplier and brand space constraints separately based on type of constraints
    df_optimization_master_data_dept = add_supplier_and_brand_space_constraints(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        df_supplier_and_brand_requested_space=df_supplier_and_brand_requested_space,
    )

    # Adding need state level facings information for need state growth caps constraints
    df_optimization_master_data_dept = add_need_state_facings_caps_information(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        config_max_facings_per_need_state=context.optimization.model_formulation.max_ns_total_increase_facings_bounds,
    )

    # Adding SKU pairs where if pivot SKU has >= 1 facing, then linked SKU also has >= 1 facing
    df_optimization_master_data_dept = add_pivot_and_linked_sku_pair_constraints(
        df_optimization_master_data_dept=df_optimization_master_data_dept,
        df_pivot_and_linked_sku_pair_constraints=df_pivot_and_linked_sku_pair_constraints,
    )

    if context.optimization_config.model_formulation.enable_forced_facings_for_new_replacement_items:
        df_optimization_master_data_dept = add_new_replacement_item_fixed_facing_constraint(
            df_optimization_master_data_dept=df_optimization_master_data_dept,
        )

    # Filling the SKU transference for any SKU we may have added
    df_optimization_master_data_dept[
        "n_transference_sku"
    ] = df_optimization_master_data_dept["n_transference_sku"].fillna(0.5)

    return df_optimization_master_data_dept


def formulate_and_solve_optimization(
        df_optimization_master_data_dept_w_manual_constraints: pd.DataFrame,
        dependent_var: str,
        category_level_dept_nbr: int,
        plano_cat_desc: str,
        department: int,
):
    """
    This function will solve an optimization problem for a given (plano_cat, dept_id, plano_ft, fixture_size, cluster)
    which is the lowest level of granularity for which we actually solve optimization problems.
    It will be used in the parallelized loop to solve multiple problems like these across CPUs
    Args:
        df_optimization_master_data_dept_w_manual_constraints: Optimization master dataset for that specific POG
        Category over which we are looping
        dependent_var: Dependent variable on which we're optimizing (can either be sales or dnp)
        category_level_dept_nbr: Category_level selected by CM
        plano_cat_desc: POG Category on which we're currently looping for optimization problems
        department: Department on which we're currently looping for optimization problems

    Returns:
    Either a None object if the cluster doesn't contain the plano_ft size in question, or a tuple of
    (df_optimization_master_data_filt_post_processed, cluster_id, plano_ft, fixture_size)
    """
    log.info(
        f"Formulating optimization model for dependent_var={dependent_var}, "
        f"category_level_dept_nbr={category_level_dept_nbr}, plano_cat_desc={plano_cat_desc}, dept_id={department}..."
    )
    df_optimization_master_data_filt = (
        df_optimization_master_data_dept_w_manual_constraints
    )

    (
        opti_data,
        df_optimization_master_data_filt,
    ) = create_optimization_model_sets_and_params_v2(
        df_optimization_master_data_filt=df_optimization_master_data_filt,
        dependent_var=dependent_var,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    if opti_data is None:
        return df_optimization_master_data_filt, True
    
    (
        opti_model,
        opti_data,
    ) = define_optimization_model_v2(
        opti_data=opti_data,
    )
    log.info(
        f"Solving optimization model for dependent_var={dependent_var}, "
        f"category_level_dept_nbr={category_level_dept_nbr}, plano_cat_desc={plano_cat_desc}, dept_id={department}..."
    )
    opti_model, is_problem_infeasible = solve_model_cluster_plano_cat_dept_fixture_v2(
        model_name=opti_data.problem_id,
        dependent_var=dependent_var,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
        opti_model=opti_model,
        opti_data=opti_data,
    )

    (
        opti_data,
        df_optimization_master_data_filt_post_processed,
    ) = post_process_solved_model(
        df_optimization_master_data_filt=df_optimization_master_data_filt,
        opti_model=opti_model,
        opti_data=opti_data,
        is_problem_infeasible=is_problem_infeasible,
    )

    # Running QC here as the gurobi API doesn't allow pickling of opti_data.
    if context.optimization.log_qc and not is_problem_infeasible:
        opti_data.model = opti_model
        hard_slack_df, soft_slack_df, unmapped_clusters_planos_df, opti_data = run_optimization_qc(opti_data)

        # Union hard_slack_df and soft_slack_df and save as JSON to scenario column
        if hard_slack_df is not None and soft_slack_df is not None:
            # Add a source column to distinguish between hard and soft slack
            hard_slack_df_copy = hard_slack_df.copy()
            soft_slack_df_copy = soft_slack_df.copy()
            hard_slack_df_copy['slack_type'] = 'hard'
            soft_slack_df_copy['slack_type'] = 'soft'
            
            # Union the dataframes
            combined_slack_df = pd.concat([hard_slack_df_copy, soft_slack_df_copy], ignore_index=True, sort=False)
            
            # Convert to JSON and save to scenario table
            if not combined_slack_df.empty:
                save_slack_data_to_table(context.meta.scenario_id, combined_slack_df)
                log.info(f"Combined slack data saved to SCENARIO_USED column. Total records: {combined_slack_df.shape[0]}")

        elif hard_slack_df is not None:
            # Only hard slack data available
            hard_slack_df_copy = hard_slack_df.copy()
            hard_slack_df_copy['slack_type'] = 'hard'
            save_slack_data_to_table(context.meta.scenario_id, hard_slack_df_copy)
            log.info(f"Hard slack data saved to SCENARIO_USED column. Total records: {combined_slack_df.shape[0]}")

        elif soft_slack_df is not None:
            # Only soft slack data available
            soft_slack_df_copy = soft_slack_df.copy()
            soft_slack_df_copy['slack_type'] = 'soft'
            save_slack_data_to_table(context.meta.scenario_id, soft_slack_df_copy)
            log.info(f"Soft slack data saved to SCENARIO_USED column. Total records: {combined_slack_df.shape[0]}")

        # Store unmapped_clusters_planos_df as JSON in UNMATCHED_INPUT column
        if unmapped_clusters_planos_df is not None and not unmapped_clusters_planos_df.empty:
            unmapped_json = unmapped_clusters_planos_df.to_dict(orient='records')
            update_scenario_column(context.meta.scenario_id, "UNMATCHED_INPUT", unmapped_json)
            log.info(f"Unmapped clusters/planos data saved to UNMATCHED_INPUT column. Total records: {len(unmapped_json)}")


    # Saving opti_data output as pickle file (post-solving)
    if (context.optimization.solver_parameters.save_opti_data
            and context.optimization.solver_parameters.solver_name != "GUROBI_API"):
        write_object(
            path=complete_file_path(
                context.data_stores.optimization.root_path,
                context.data_stores.optimization.modeling.optimization_data_output,
                at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                dependent_var=dependent_var,
                category_level_dept_nbr=category_level_dept_nbr,
                plano_cat_desc=plano_cat_desc,
                department=department,
            ),
            obj=opti_data,
            root=context.data_stores.optimization.save_to_datastores_root.modeling,
        )

    del opti_model
    del opti_data
    gc.collect()
    return (df_optimization_master_data_filt_post_processed, is_problem_infeasible)


def get_sales_dnp_from_producitivty(
        df_opti_output: pd.DataFrame,
        metric_period: str,
        adjusted_values: bool
) -> pd.DataFrame:
    # Create input & output column names based on given parameters
    if adjusted_values:
        productivity_column = f"n_adjusted_{metric_period}_space_productivity"
        sales_column = f"n_{metric_period}_adjusted_projected_sales"
        dnp_column = f"n_{metric_period}_adjusted_projected_dnp"
    else:
        productivity_column = f"n_{metric_period}_space_productivity"
        sales_column = f"n_{metric_period}_projected_sales"
        dnp_column = f"n_{metric_period}_projected_dnp"
        margin_column = f"n_{metric_period}_projected_margin"
        units_sold_column = f"n_{metric_period}_projected_units_sold"
    
    # Get columns independent of adjustment values
    boh_column_name = f"n_{metric_period}_boh_adjustment"
    facings_column = f"n_{metric_period}_facings_sku"
    
    # Get sales value
    df_opti_output[sales_column] = (
        ((df_opti_output[productivity_column] * 2) + (df_opti_output[boh_column_name] * df_opti_output["dnp_mltp"]))
        / ((df_opti_output["dnp_ratio"] * df_opti_output["dnp_mltp"]) + 1)
    ) / df_opti_output["sales_mltp"]

    # ==================== TEMP FIX SECTION START - Mo ====================
    # TEMPORARY FIX: For new items with optimal facings > 0, override adjusted sales with non-adjusted sales
    if adjusted_values and metric_period == "optimal":
        mask_new_items_with_facings = (
            (df_opti_output["new_item"] == 1) &
            (df_opti_output["n_optimal_facings_sku"] > 0) &
            (df_opti_output["x_ifcg_optimal_value"] > 0) &
            (df_opti_output["n_optimal_projected_sales"] > 0) &
            (df_opti_output["n_optimal_adjusted_projected_sales"]==0)
        )
        if mask_new_items_with_facings.sum() > 0:
            distinct_items = df_opti_output.loc[mask_new_items_with_facings, "item_no_nbr"].nunique()
            log.info(f"Overriding adjusted sales for {distinct_items} distinct new items with optimal facings > 0")
            df_opti_output.loc[mask_new_items_with_facings, sales_column] = (
                0.53 * df_opti_output.loc[mask_new_items_with_facings, "n_optimal_projected_sales"]
            )
    # ==================== TEMP FIX SECTION END ====================
    # Get DNP value
    df_opti_output[dnp_column] = (df_opti_output[sales_column] * df_opti_output["dnp_ratio"])


    # Get margin & units sold values
    if not adjusted_values:
        # Intialize margin to 0 & compute actuals when facings count is above 0
        df_opti_output[margin_column] = 0
        
        df_opti_output.loc[df_opti_output[facings_column] > 0, margin_column] = (
            df_opti_output[dnp_column] / df_opti_output[sales_column]
        )
        
        # Intialize units sold to 0 & compute actuals when facings count is above 0
        df_opti_output[units_sold_column] = 0
        
        df_opti_output.loc[df_opti_output[facings_column] > 0, units_sold_column] = (
            df_opti_output[sales_column] / df_opti_output["filled_average_price"]
        )
    
    return df_opti_output
    

def log_optimization_metrics(df_final_output: pd.DataFrame) -> None:
    # Log metrics
    df_final_output = df_final_output[df_final_output["x_ifcg_optimal_value"] == 1]
        
    # Get values for current
    for baseline in ["current"]:
        for metric in ["sales", "dnp"]:
            # Compute unadjusted uplift
            optimal_val = (df_final_output[f"n_optimal_projected_{metric}"] * df_final_output["n_stores"]).sum() 
            baseline_val = (df_final_output[f"n_{baseline}_projected_{metric}"] * df_final_output["n_stores"]).sum()
            metric_uplift = (optimal_val - baseline_val) / baseline_val * 100
            
            # Computed adjusted uplift
            optimal_val = (df_final_output[f"n_optimal_adjusted_projected_{metric}"] * df_final_output["n_stores"]).sum()
            baseline_val = (df_final_output[f"n_{baseline}_adjusted_projected_{metric}"] * df_final_output["n_stores"]).sum()
            adjusted_metric_uplift = (optimal_val - baseline_val) / baseline_val * 100
            
            log.info(f"{baseline} --> {metric} uplift: {metric_uplift:.2f}, adjusted {metric} uplift: {adjusted_metric_uplift:.2f}")

    
    # Log margin for optimal
    optimal_dnp = (df_final_output["n_optimal_adjusted_projected_dnp"] * df_final_output["n_stores"]).sum()
    optimal_sales = (df_final_output["n_optimal_adjusted_projected_sales"] * df_final_output["n_stores"]).sum()
    margin = optimal_dnp/optimal_sales
    
    log.info(f"Margin: {margin:.2f}") 
    
     
def format_output(
        df_final_adjusted: pd.DataFrame,
        df_latest_space_data: pd.DataFrame,
        df_sales: pd.DataFrame
) -> pd.DataFrame:
    """
    This function creates the final optimization output dataframe which is used downstream for analysis purposes
    Args:
        df_final_adjusted: Dataframe containing the optimization input & output data
        df_latest_space_data: Dataframe containing the current space data
        df_sales: Dataframe containing the sales from the previous year

   Returns:
    A pandas dataframe corresponding to the final outputs from optimization (final_cluster_labels, plano_ft,
    fixture_size) existing within a given (plano_cat_desc, dept_id) combination
    """
    # Fix plano_id in space data
    df_latest_space_data["plano_id"] = df_latest_space_data["plano_id"].str.split("_").str[0]
    
    # Get productivity value columns
    df_productivity = df_final_adjusted[[
        "item_no_nbr",
        "plano_id",
        "final_cluster_labels",
        "need_state_unique_id",
        ] + 
        [x for x in df_final_adjusted.columns if "n_space_prod_fit_facings_" in x] + 
        [x for x in df_final_adjusted.columns if "n_boh_facings_" in x]
    ].drop_duplicates()
    
    # Rename columns to prepare for wide to long
    df_productivity.columns = df_productivity.columns.str.replace("n_space_prod_fit_facings_", "sales_projection-", regex=False)
    df_productivity.columns = df_productivity.columns.str.replace("n_boh_facings_", "boh_adjustment-", regex=False)
    
    # Perform wide to long transformation
    df_productivity = pd.wide_to_long(df_productivity,
                                      stubnames=["sales_projection", "boh_adjustment"],
                                      i=["item_no_nbr", "need_state_unique_id", "final_cluster_labels", "plano_id"],
                                      j="hfacings",
                                      sep="-",
                                      suffix="\d+").reset_index()
    
    # Compute penalty
    df_final_adjusted["penalty"] = (
            df_final_adjusted["n_current_space_productivity"] * (1 - df_final_adjusted["n_transference_sku"])
    )

    # Compute optimal objective value per entry
    df_final_adjusted["adjusted_optimal_objective_value_contribution"] = (
            df_final_adjusted["optimal_objective_value_contribution"] - df_final_adjusted["penalty"]
    )

    # Create final master output
    df_final_output = (
        df_final_adjusted[[
            "item_no_nbr", "plano_cat_id", "final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "dnp_ratio",
            "need_state_unique_id", "lvl1_need_state_unique_id", "representative_store_nbr",
            "plano_cat_desc", "item_no_desc", "fixture_desc",
            "n_optimal_facings_sku", "n_optimal_linear_space_used_sku", 
            "n_transference_sku",
            "n_optimal_space_productivity", "n_total_linear_space_dept_fixture_ft",
            "optimal_objective_value", "adjusted_optimal_objective_value_contribution", "penalty",
            "x_ifcg_optimal_value", "n_current_facings_sku", "n_current_linear_space_used_sku",
            "n_adjusted_optimal_space_productivity", "n_adjusted_current_space_productivity", 
            "dnp_mltp", "sales_mltp",
            "brand_name", "supplier_name", "is_net_new_sku", "disc_item", "seg_dsc", "n_stores"
        ]]
        .drop_duplicates()
        .merge(df_productivity,
               left_on=["item_no_nbr", "need_state_unique_id", "final_cluster_labels", "plano_id",
                        "n_optimal_facings_sku"],
               right_on=["item_no_nbr", "need_state_unique_id", "final_cluster_labels", "plano_id",
                         "hfacings"],
               how="left",
               )
        .rename(
            columns={
                "representative_store_nbr": "store_nbr",
                "sales_projection": "n_optimal_space_productivity_validate",
                "boh_adjustment": "n_optimal_boh_adjustment",
                "supplier_name": "vendor_name",
                "is_net_new_sku": "new_item",
                "disc_item": "discontinue_item"
            }
        )
        .drop(columns=["hfacings"])
    )
    
    new_item_count = df_final_output[df_final_output["new_item"] == 1]["item_no_nbr"].nunique()
    disc_item_count = df_final_output[df_final_output["discontinue_item"] == 1]["item_no_nbr"].nunique()

    log.info(f"New item count in final output: {new_item_count}")
    log.info(f"Discontinue item count in final output: {disc_item_count}")
    
    # Add sales info for current
    df_final_output = (
        df_final_output
        .merge(df_productivity,
               left_on=["item_no_nbr", "need_state_unique_id", "final_cluster_labels", "plano_id",
                        "n_current_facings_sku"],
               right_on=["item_no_nbr", "need_state_unique_id", "final_cluster_labels", "plano_id", "hfacings"],
               how="left",
               validate="many_to_one"
               )
        .rename(columns={"sales_projection": "n_current_space_productivity",
                        "boh_adjustment": "n_current_boh_adjustment"})
        .drop(columns=["hfacings"])
    )
    
    
    # Split labels
    if context.optimization.data_prep.add_lp_flags_to_cluster:
        df_final_output["cluster"] = df_final_output["final_cluster_labels"].str.split("-").str[0]
        df_final_output["volume"] = df_final_output["final_cluster_labels"].str.split("-").str[1].str.split("_").str[0]
        df_final_output["risk"] = df_final_output["final_cluster_labels"].str.split("-").str[1].str.split("_").str[1]
    else:
        df_final_output["cluster"] = df_final_output["final_cluster_labels"]
        df_final_output["volume"] = "NONE"
        df_final_output["risk"] = "NONE"
    
    # Compute linear_space spread
    df_cluster_linear_space_spread = (
        df_latest_space_data
        .groupby(["final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "store_nbr"])
        .agg(store_linear_space=("n_current_linear_space_used_sku", "sum"))
        .reset_index()
        .groupby(["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"])
        .agg(
            min_linear_space=("store_linear_space", "min"),
            quantile_25_linear_space=("store_linear_space", lambda x: x.quantile(0.25)),
            median_linear_space=("store_linear_space", "median"),
            quantile_75_linear_space=("store_linear_space", lambda x: x.quantile(0.75)),
            quantile_90_linear_space=("store_linear_space", lambda x: x.quantile(0.90)),
            max_linear_space=("store_linear_space", "max"),
        )
        .reset_index()
    )
    
    # Merge linear space spread information
    df_final_output = df_final_output.merge(
        df_cluster_linear_space_spread,
        on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"],
        how="left"
    )
    
    # Add pog size metric
    df_final_output["pog_size"] = df_final_output["plano_ft"].astype(str) + "_" + df_final_output[
        "fixture_size"].astype(str)

    # Add walk rate
    df_final_output["walk_rate"] = 1 - df_final_output["n_transference_sku"]

    # Add run id
    df_final_output["run_id"] = context.meta.run_id
    
    # Compute coverage for current
    stores_in_grp = df_latest_space_data.groupby(
        ["plano_id", "plano_ft", "fixture_size"]).agg(
        current_plano_store_count=("store_nbr", "nunique")
    ).reset_index()
    item_in_stores = df_latest_space_data.groupby(
        ["plano_id", "plano_ft", "fixture_size", "item_no_nbr"]).agg(
        current_item_store_count=("store_nbr", "nunique")
    ).reset_index()
    
    # Compute coverage for optimal
    cluster_in_grp = df_final_output.groupby(["plano_id", "plano_ft", "fixture_size"]).agg(
        optimal_plano_cluster_count=("final_cluster_labels", "nunique")
    ).reset_index()
    item_in_clusters = df_final_output[(df_final_output["n_optimal_facings_sku"] > 0) 
                                       & (df_final_output["x_ifcg_optimal_value"] == 1)].groupby(
        ["plano_id", "plano_ft", "fixture_size", "item_no_nbr"]).agg(
        optimal_item_cluster_count=("final_cluster_labels", "nunique")
    ).reset_index()

    # merge coverage information into one dataframe
    df_core = item_in_stores.merge(item_in_clusters, on=["plano_id", "plano_ft", "fixture_size", "item_no_nbr"],
                                   how="outer")
    df_core["current_item_store_count"] = df_core["current_item_store_count"].fillna(0)
    df_core["optimal_item_cluster_count"] = df_core["optimal_item_cluster_count"].fillna(0)
    
    
    df_core = df_core.merge(stores_in_grp, on=["plano_id", "plano_ft", "fixture_size"], how="left")
    df_core = df_core.merge(cluster_in_grp, on=["plano_id", "plano_ft", "fixture_size"], how="left")
    df_core["current_core_coverage"] = df_core["current_item_store_count"] / df_core["current_plano_store_count"]
    df_core["optimal_core_coverage"] = df_core["optimal_item_cluster_count"] / df_core["optimal_plano_cluster_count"]

    # Merge coverage information to final dataframe
    df_final_output = df_final_output.merge(df_core, on=["plano_id", "plano_ft", "fixture_size", "item_no_nbr"],
                                            how="left")
        
    # Get price information
    df_item_store = df_final_output[["item_no_nbr", "store_nbr"]].drop_duplicates()
    df_price = (
        df_sales[["item_no_nbr", "store_nbr", "actual_average_price"]]
        .drop_duplicates()
        .rename(columns={"actual_average_price": "filled_average_price"})
    )
    df_item_price = df_price.groupby("item_no_nbr").agg(med_price=("filled_average_price", "median")).reset_index()
    
    df_price = df_item_store.merge(
        df_price,
        on=["item_no_nbr", "store_nbr"],
        how="left"
    )
    df_price = df_price.merge(
        df_item_price,
        on=["item_no_nbr"],
        how="left"
    )
    
    # If store has no previous sales, fill information with median price of item
    df_price["filled_average_price"] = df_price["filled_average_price"].fillna(df_price["med_price"])
    df_price["filled_average_price"] = df_price["filled_average_price"].astype(float)
    df_price = df_price.drop(columns=("med_price"))
    
    # Merge price information to final datafram
    df_final_output = df_final_output.merge(df_price, on=["item_no_nbr", "store_nbr"], how="left")

    df_final_output = fill_missing_price_for_new_items(df_final_output)
    # Merge sales infromation
    df_final_output = df_final_output.merge(df_sales, on=["item_no_nbr", "store_nbr"],
                                            how="left")

    # Add store count cluster
    store_count = df_latest_space_data.groupby(["plano_cat_desc", "final_cluster_labels"]).agg(
        cluster_store_count=("store_nbr", "nunique")
    ).reset_index()
    store_count["final_cluster_labels"] = store_count["final_cluster_labels"]
    df_final_output = df_final_output.merge(store_count, 
                                            left_on=["plano_cat_desc", "final_cluster_labels"], 
                                            right_on=["plano_cat_desc", "final_cluster_labels"], 
                                            how="left")
    
    # Add store cluster list
    df_store_cluster = df_latest_space_data.groupby(["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"]).agg(
        store_cluster=("store_nbr", "unique")
    ).reset_index()
    
    df_final_output = df_final_output.merge(df_store_cluster,
                                            on=["final_cluster_labels", "plano_id", "plano_ft", "fixture_size"],
                                            how="left")

    # df_final_output.to_pickle("df_final_output.pkl")
    # log.info("Intermediate output saved to df_final_output.pkl")
    # Get sales & DNP values
    for period in ["current", "optimal"]:
        df_final_output = get_sales_dnp_from_producitivty(df_final_output, period, adjusted_values=False)
        df_final_output = get_sales_dnp_from_producitivty(df_final_output, period, adjusted_values=True)
    
    # Drop filled average price
    df_final_output = df_final_output.drop(columns="filled_average_price")
    
    # Log optmization metric to the terminal 
    log_optimization_metrics(df_final_output)
        
    return df_final_output


def format_ranking_output(
        df_final_output: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function creates the optimization ranking output dataframe which is used to create the 345 output files
    Args:
        df_final_output: Dataframe containing the optimization output data used for analysis purposes

   Returns:
    A pandas dataframe corresponding to the final outputs from optimization (final_cluster_labels, plano_ft,
    fixture_size) existing within a given (plano_cat_desc, dept_id) combination
    """
    levels = ["run_id"] + context.optimization.data_prep.ranking_output_level

    # Get all the SKUs that have been selected
    skus_selected = df_final_output[df_final_output['n_optimal_facings_sku'] > 0].groupby(levels + ['item_no_nbr'])["x_ifcg_optimal_value"].sum().reset_index().rename({
        "x_ifcg_optimal_value": "selected_sku"
    }, axis=1)

    # Get linear space by SKU
    item_space = (
        df_final_output[df_final_output["n_optimal_facings_sku"] == 1]
        .groupby(["item_no_nbr"])["n_optimal_linear_space_used_sku"]
        .mean()
        .to_dict()
    )
    
    # Get cluster & LP flags
    df_levels_metadata = (
        df_final_output.groupby(levels).agg(
            cluster=("cluster", "first"),
            volume=("volume", "first"),
            risk=("risk", "first"),
            store_cluster=("store_cluster", "first")
        ).reset_index()
    )
    df_final_output = df_final_output.drop(columns=["cluster", "volume", "risk", "store_cluster"])
    
    df_final_output = df_final_output.sort_values(levels + ["item_no_nbr", "n_optimal_facings_sku"])

    # Fileter for Selected SKUs
    df_to_rank = df_final_output.merge(skus_selected, on=levels + ['item_no_nbr'], how='inner')
    df_to_rank = df_to_rank[df_to_rank['selected_sku'] > 0].copy()
    df_to_rank = df_to_rank.sort_values(levels + ["item_no_nbr", "n_optimal_facings_sku"])

    # Build an index to identify which output got selected
    df_to_rank["index_to_rank"] = df_to_rank.groupby(
        levels + ["item_no_nbr"]
    )["x_ifcg_optimal_value"].cumsum()

    # Concatenate  + selected facing
    df_to_rank = pd.concat([
        df_to_rank[df_to_rank["index_to_rank"] == 0].copy(),
        df_to_rank[df_to_rank["x_ifcg_optimal_value"] == 1].copy(),
    ])
    # 
    df_to_rank = df_to_rank.sort_values(
        levels + ["item_no_nbr", "n_optimal_facings_sku"]
    )

    #
    df_to_rank['index_to_rank'] = 1
    df_to_rank["Item_Facing"] = df_to_rank.groupby(
        levels + ["item_no_nbr"]
    )["index_to_rank"].cumsum() - 1

    # bug to fix - We wont have more than 17 facings by SKUs
    df_to_rank = df_to_rank[df_to_rank["n_optimal_facings_sku"] < 17].copy()

    df_to_rank["Is within shelf capacity"] = (
            df_to_rank.groupby(
                levels + ["item_no_nbr"]
            )["x_ifcg_optimal_value"].cumsum() == 0
    ) | (df_to_rank["x_ifcg_optimal_value"] == 1)

    df_to_rank = df_to_rank.sort_values(
        levels + ["item_no_nbr", "n_optimal_facings_sku"]
    )
    
    df_to_rank["avg_projected_sales"] = df_to_rank.groupby(
        levels + ["item_no_nbr"]
    )["n_optimal_projected_sales"].diff()
    
    df_to_rank["avg_projected_margin"] = df_to_rank.groupby(
        levels + ["item_no_nbr"]
    )["n_optimal_projected_dnp"].diff()
    
    df_to_rank["avg_projected_units"] = df_to_rank.groupby(
        levels + ["item_no_nbr"]
    )["n_optimal_projected_units_sold"].diff()
    
    df_to_rank = df_to_rank[df_to_rank["n_optimal_facings_sku"] > 0].copy()

    df_to_rank = df_to_rank.sort_values(
        levels + ["avg_projected_sales"],
        ascending=[True] * len(levels) + [False]
    )
    df_to_rank["Rank"] = df_to_rank.groupby(
        levels
    )["index_to_rank"].cumsum()
    df_to_rank["linear_width_ft"] = df_to_rank["item_no_nbr"].map(item_space)
    df_to_rank["cumulative_linear_width_ft"] = df_to_rank.groupby(levels)["linear_width_ft"].cumsum()

    df_to_rank["Rank at capacity"] = df_to_rank.groupby(levels)["Rank"].transform("max")
    
    # Add current timestamp
    df_to_rank["timestamp"] = datetime.now()
    
    # Add metadata
    df_to_rank = df_to_rank.merge(df_levels_metadata, on=levels, how="left")
    
    df_to_rank = df_to_rank[
        levels + [
            "timestamp",
            "item_no_nbr", 
            "item_no_desc", 
            "Item_Facing", 
            "linear_width_ft", 
            "avg_projected_sales", 
            "avg_projected_margin", 
            "avg_projected_units",
            "Rank", 
            "Rank at capacity", 
            "Is within shelf capacity",
            "cluster",
            "volume",
            "risk",
            "store_cluster"
        ]
    ]
    
    return df_to_rank


def fill_missing_price_for_new_items(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fill missing filled_average_price for new items using hierarchical fallback:
    1. Median price within (need_state_unique_id, final_cluster_labels, plano_id)
    2. Median price within (final_cluster_labels, plano_id)
    3. Median price within (final_cluster_labels)
    4. Overall median price

    Args:
        df: DataFrame containing the optimization output data

    Returns:
        DataFrame with filled_average_price filled for new items
    """
    # Check if required columns exist
    required_cols = ['new_item', 'filled_average_price', 'need_state_unique_id',
                     'final_cluster_labels', 'plano_id']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        log.warning(f"Missing required columns for price filling: {missing_cols}")
        return df

    df_result = df.copy()

    # Only process new items with missing prices
    mask_new_items_missing_price = (
        (df_result['new_item'] == 1) &
        (df_result['filled_average_price'].isna())
    )

    if mask_new_items_missing_price.sum() == 0:
        log.info("No new items with missing prices found")
        return df_result

    log.info(f"Found {mask_new_items_missing_price.sum()} new items with missing prices")

    # Create hierarchical mappings for fallback
    # Level 1: need_state + cluster + plano
    level1_map = (
        df_result[df_result['filled_average_price'].notna()]
        .groupby(['need_state_unique_id', 'final_cluster_labels', 'plano_id'])['filled_average_price']
        .median()
        .to_dict()
    )

    # Level 2: cluster + plano
    level2_map = (
        df_result[df_result['filled_average_price'].notna()]
        .groupby(['final_cluster_labels', 'plano_id'])['filled_average_price']
        .median()
        .to_dict()
    )

    # Level 3: cluster only
    level3_map = (
        df_result[df_result['filled_average_price'].notna()]
        .groupby(['final_cluster_labels'])['filled_average_price']
        .median()
        .to_dict()
    )

    # Level 4: overall median
    overall_median = df_result[df_result['filled_average_price'].notna()]['filled_average_price'].median()

    def fill_price_hierarchical(row):
        if row['new_item'] == 1 and pd.isna(row['filled_average_price']):
            # Level 1: Try need_state + cluster + plano
            level1_key = (row['need_state_unique_id'], row['final_cluster_labels'], row['plano_id'])
            if level1_key in level1_map:
                return level1_map[level1_key]

            # Level 2: Try cluster + plano
            level2_key = (row['final_cluster_labels'], row['plano_id'])
            if level2_key in level2_map:
                return level2_map[level2_key]

            # Level 3: Try cluster only
            level3_key = row['final_cluster_labels']
            if level3_key in level3_map:
                return level3_map[level3_key]

            # Level 4: Overall median
            if pd.notna(overall_median):
                return overall_median

            log.warning(f"Could not fill price for new item {row['item_no_nbr']} - all fallbacks failed")
            return row['filled_average_price']

        return row['filled_average_price']

    # Apply the hierarchical filling
    df_result['filled_average_price'] = df_result.apply(fill_price_hierarchical, axis=1)

    # Log results
    remaining_missing = (
        (df_result['new_item'] == 1) &
        (df_result['filled_average_price'].isna())
    ).sum()

    filled_count = mask_new_items_missing_price.sum() - remaining_missing
    log.info(f"Successfully filled prices for {filled_count} new items")
    if remaining_missing > 0:
        log.warning(f"{remaining_missing} new items still have missing prices after hierarchical filling")

    return df_result