import logging

import numpy as np
import pandas as pd

from oxygen.conf.context import context
from typing import List

from core.schemas.optimization.schemas import (
    OptimizationMasterModelingCollapsingOutput,
    OptimizationMasterModelingOutput,
)

from core.utils.space_context.run_versioning import complete_file_path
from core.utils.elasticity_helpers import (
    root_with_run_id,
)

log = logging.getLogger(__name__)


def calculate_overlap(df1, df2):
    """
    Calculates the overlap ratio and average difference between two DataFrames
    based on the 'item_no_nbr' and 'n_optimal_facings_sku' columns.

    The overlap ratio is defined as the number of matching rows (where 'item_no_nbr'
    and 'n_optimal_facings_sku' are the same in both DataFrames) divided by the
    total number of unique 'item_no_nbr' values in both DataFrames, excluding rows
    where 'n_optimal_facings_sku' is 0 in both DataFrames.

    Args:
        df1 (pd.DataFrame): First DataFrame containing 'item_no_nbr' and 'n_optimal_facings_sku' columns.
        df2 (pd.DataFrame): Second DataFrame containing 'item_no_nbr' and 'n_optimal_facings_sku' columns.

    Returns:
        tuple:
            - overlap_ratio (float): The ratio of matching rows between the two DataFrames.
            - avg_diff (float): The average difference of unmatched 'item_no_nbr' entries across both DataFrames.
    """

    # If the two DataFrames are the same, return 1 (100% overlap)
    if df1.equals(df2):
        return 1

    # Merge the two dataframes on 'item_no_nbr'
    merged = pd.merge(
        df1[["item_no_nbr", "n_optimal_facings_sku"]],
        df2[["item_no_nbr", "n_optimal_facings_sku"]],
        on="item_no_nbr",
        how="outer",
        suffixes=("_1", "_2"),
    )
    merged["n_optimal_facings_sku_1"] = merged["n_optimal_facings_sku_1"].fillna(0)
    merged["n_optimal_facings_sku_2"] = merged["n_optimal_facings_sku_2"].fillna(0)

    # Filter out rows where both have n_optimal_facings_sku == 0
    merged_filtered = merged[
        ~(
            (merged["n_optimal_facings_sku_1"] == 0)
            & (merged["n_optimal_facings_sku_2"] == 0)
        )
    ]

    # Numerator: Rows where both 'item_no_nbr' and 'n_optimal_facings_sku' match
    numerator = len(
        merged_filtered[
            merged_filtered["n_optimal_facings_sku_1"]
            == merged_filtered["n_optimal_facings_sku_2"]
        ]
    )

    # Denominator: Unique 'item_no_nbr' across both dataframes
    unique_item_no_nbrs = merged_filtered.item_no_nbr.nunique()

    overlap_ratio = numerator / unique_item_no_nbrs if unique_item_no_nbrs > 0 else 0
    avg_diff = (unique_item_no_nbrs - numerator) / 2

    return overlap_ratio, avg_diff


def calculate_overlap_ignore_facings(df1, df2):
    """
    Calculates the overlap ratio and average difference between two DataFrames
    based on the 'item_no_nbr' column while ignoring differences in 'n_optimal_facings_sku'.

    The overlap ratio is defined as the number of matching 'item_no_nbr' rows in both
    DataFrames where 'n_optimal_facings_sku' is greater than 0, divided by the total
    number of unique 'item_no_nbr' values in both DataFrames. Rows where 'n_optimal_facings_sku'
    is 0 in both DataFrames are excluded from the calculation.

    Args:
        df1 (pd.DataFrame): First DataFrame containing 'item_no_nbr' and 'n_optimal_facings_sku' columns.
        df2 (pd.DataFrame): Second DataFrame containing 'item_no_nbr' and 'n_optimal_facings_sku' columns.

    Returns:
        tuple:
            - overlap_ratio (float): The ratio of matching 'item_no_nbr' rows between the two DataFrames where 'n_optimal_facings_sku' > 0.
            - avg_diff (float): The average difference of unmatched 'item_no_nbr' entries across both DataFrames.
    """

    # If the two DataFrames are the same, return 1 (100% overlap)
    if df1.equals(df2):
        return 1

    # Merge the two dataframes on 'item_no_nbr'
    merged = pd.merge(
        df1[["item_no_nbr", "n_optimal_facings_sku"]],
        df2[["item_no_nbr", "n_optimal_facings_sku"]],
        on="item_no_nbr",
        how="outer",
        suffixes=("_1", "_2"),
    )
    merged["n_optimal_facings_sku_1"] = merged["n_optimal_facings_sku_1"].fillna(0)
    merged["n_optimal_facings_sku_2"] = merged["n_optimal_facings_sku_2"].fillna(0)

    # Filter out rows where both have n_optimal_facings_sku == 0
    merged_filtered = merged[
        ~(
            (merged["n_optimal_facings_sku_1"] == 0)
            & (merged["n_optimal_facings_sku_2"] == 0)
        )
    ]

    # Numerator: Rows where both 'item_no_nbr' match
    numerator = len(
        merged_filtered[
            (merged_filtered["n_optimal_facings_sku_1"] > 0)
            & (merged_filtered["n_optimal_facings_sku_2"] > 0)
        ]
    )

    # Denominator: Unique 'item_no_nbr' across both dataframes
    unique_item_no_nbrs = merged_filtered.item_no_nbr.nunique()

    overlap_ratio = numerator / unique_item_no_nbrs if unique_item_no_nbrs > 0 else 0
    avg_diff = (unique_item_no_nbrs - numerator) / 2

    return overlap_ratio, avg_diff


def replace_b_with_a(df_a, df_b, overlap):
    """
    Merges two DataFrames (`df_a` and `df_b`) on the specified key columns and selectively fills or replaces values
    from one DataFrame with values from the other. This process collapses assortments and handles discrepancies
    between the two DataFrames.

    - `unique_a_list`: Asserts that the column in `df_A` has only one unique value, and that value is used for merging.
    - `a_fill_b_list`: If a value is missing in `df_A`, fill it with the corresponding value from `df_B`.
    - `b_fill_a_list`: If a value is missing in `df_B`, fill it with the corresponding value from `df_A`.
    - `a_fill_0_list`: If a value is missing in `df_A`, fill it with `0`.
    - `b_fill_0_list`: If a value is missing in `df_B`, fill it with `0`.

    Args:
        df_a (pd.DataFrame): DataFrame representing assortment A.
        df_b (pd.DataFrame): DataFrame representing assortment B.

    Returns:
        pd.DataFrame: A merged DataFrame where values from `df_a` have been used to replace values in `df_b`,
        following the logic described for each column.
    """
    df_a = df_a.copy()
    df_b = df_b.copy()

    # First join on the primary key columns
    join_cols = context.assortment_collapsing.grouping_cols_no_collapse_groups + [
        "item_no_nbr"
    ]
    merged = pd.merge(df_a, df_b, on=join_cols, how="outer", suffixes=("_A", "_B"))

    # Keep all rows from b and additional rows from a if optimal facings in a is not zero
    merged = merged.query(
        "(n_optimal_facings_sku_A > 0) | (~@pd.isna(n_optimal_facings_sku_B))"
    ).copy()

    # Use A/B columns assuming unique values
    unique_a_list = [
        "final_cluster_labels",
    ]
    unique_b_list = [
        "representative_store_nbr",
        "total_stores_in_plano_cluster",
        "total_stores_in_cluster",
    ]
    a_fill_b_list = []
    b_fill_a_list = [
        "n_current_linear_space_per_facing_sku",
        "need_state_unique_id",
        "brand_name",
        "supplier_name",
        "item_no_desc",
        "private_label_ind",
        "is_net_new_sku",
        "is_discontinued_sku",
        "is_fake_new_sku",
    ]
    a_fill_0_list = ["n_optimal_facings_sku", "n_optimal_linear_space_used_sku"]
    b_fill_0_list = [
        "n_current_linear_space_used_sku",
        "n_current_facings_sku",
    ]

    for col in unique_a_list:
        assert (
            len(merged[col + "_A"].dropna().unique()) == 1
        ), f"Column {col} in df_A is not unique"
        merged.loc[:, col] = merged[col + "_A"].dropna().unique()[0]

    for col in unique_b_list:
        assert (
            len(merged[col + "_B"].dropna().unique()) == 1
        ), f"Column {col} in df_B is not unique"
        merged.loc[:, col] = merged[col + "_B"].dropna().unique()[0]

    assert (
        len(merged["final_cluster_labels_B"].dropna().unique()) == 1
    ), f"Column final_cluster_labels_B is not unique"
    merged.loc[:, "final_cluster_labels_before_collapsing"] = (
        merged["final_cluster_labels_B"].dropna().unique()[0]
    )

    for col in a_fill_b_list:
        merged.loc[:, col] = np.where(
            pd.isna(merged[col + "_A"]), merged[col + "_B"], merged[col + "_A"]
        )

    for col in b_fill_a_list:
        merged.loc[:, col] = np.where(
            pd.isna(merged[col + "_B"]), merged[col + "_A"], merged[col + "_B"]
        )

    for col in a_fill_0_list:
        merged.loc[:, col] = np.where(
            pd.isna(merged[col + "_A"]), 0, merged[col + "_A"]
        )

    for col in b_fill_0_list:
        merged.loc[:, col] = np.where(
            pd.isna(merged[col + "_B"]), 0, merged[col + "_B"]
        )

    merged.loc[:, "is_collapsed"] = 1
    merged.loc[:, "is_collapsed_target"] = 0
    merged.loc[:, "collapsed_overlap_ratio"] = overlap

    int_col_list = [
        "n_current_facings_sku",
        "n_optimal_facings_sku",
        "representative_store_nbr",
        "private_label_ind",
        "is_net_new_sku",
        "is_discontinued_sku",
        "is_fake_new_sku",
        "is_collapsed_target",
    ]

    for col in int_col_list:
        merged.loc[:, col] = merged[col].astype(int)

    # Dropping unnecessary columns
    merged = merged.drop(
        [col for col in merged.columns if col.endswith("_A") or col.endswith("_B")],
        axis=1,
    )

    return merged


def assortment_collapse_main(df_opti_modeling_output: pd.DataFrame) -> pd.DataFrame:
    """
    Performs assortment collapsing by grouping the DataFrame first.
    Assortments within each group are ranked by the number of total stores in the cluster and plano cluster,
    and collapsed based on predefined overlap thresholds.

    Assortments are replaced and collapsed based on their overlap ratio, and small assortments are handled
    separately with a lower threshold for replacement.

    Args:
        df_opti_modeling_output (pd.DataFrame): Input DataFrame containing assortment details, including `final_cluster_labels`,
                                                `total_stores_in_cluster`, and `total_stores_in_plano_cluster`.

    Returns:
        pd.DataFrame: A DataFrame with collapsed assortments based on the overlap ratio and predefined thresholds,
                      with redundant columns removed.
    """

    df_opti_modeling_output = df_opti_modeling_output.copy()

    # Group by 'operational_cluster_labels', 'plano_ft', 'fixture_size'
    grouped = df_opti_modeling_output.groupby(
        context.assortment_collapsing.grouping_cols_no_collapse_groups
    )
    final_dfs = []
    count_small_assortment_i = 0

    for group_name, group_df in grouped:
        # Separate the group into multiple dataframes by 'final_cluster_labels'
        separated_dfs = [
            group_df[group_df["final_cluster_labels"] == label]
            for label in group_df["final_cluster_labels"].unique()
        ]

        # Rank the separated dataframes by 'total_stores_in_cluster' in ascending order
        separated_dfs = sorted(
            separated_dfs,
            key=lambda x: (
                x["total_stores_in_plano_cluster"].iloc[0],
                x["total_stores_in_cluster"].iloc[0],
            ),
            reverse=False,
        )

        # List to track dataframes that are eligible to be replaced
        eligible_to_replace = [True] * len(separated_dfs)

        # Loop through the ranked separated dataframes and find overlaps
        for i in range(len(separated_dfs)):
            if not eligible_to_replace[i]:  # Skip if this dataframe was collapse target
                separated_dfs[i].loc[:, "is_collapsed_target"] = 1
                continue

            last_j = None  # Track the last j that gets replaced
            overlap_current = (
                context.assortment_collapsing.overlap_threshold
            )  # Track the current overlap value
            overlap_small_assortment = (
                context.assortment_collapsing.overlap_threshold_small_assortment
                # No initial threshold for small assortments
            )
            count_small_assortment = 0  # Count of small assortment replacements
            replaced_df = separated_dfs[i].copy()

            for j in range(i + 1, len(separated_dfs)):
                if context.assortment_collapsing.compare_facings:
                    overlap, avg_diff = calculate_overlap(
                        separated_dfs[i], separated_dfs[j]
                    )
                else:
                    overlap, avg_diff = calculate_overlap_ignore_facings(
                        separated_dfs[i], separated_dfs[j]
                    )
                avg_len = (len(separated_dfs[i]) + len(separated_dfs[j])) / 2

                # If both total_stores_in_cluster and total_stores_in_plano_cluster are equal, only replace if overlap is greater
                if (
                    separated_dfs[i]["total_stores_in_cluster"].iloc[0]
                    == separated_dfs[j]["total_stores_in_cluster"].iloc[0]
                    and separated_dfs[i]["total_stores_in_plano_cluster"].iloc[0]
                    == separated_dfs[j]["total_stores_in_plano_cluster"].iloc[0]
                ):
                    if (
                        overlap > overlap_current
                    ):  # Only replace if overlap is higher than current value
                        replaced_df = replace_b_with_a(
                            separated_dfs[j], separated_dfs[i], overlap
                        )

                        last_j = j  # Mark this as the last j replaced
                        overlap_current = overlap  # Update overlap for comparison
                    elif (
                        avg_len <= context.assortment_collapsing.no_item_no_small_assortment
                        and overlap > overlap_small_assortment
                    ):
                        replaced_df = replace_b_with_a(
                            separated_dfs[j], separated_dfs[i], overlap
                        )
                        last_j = j  # Mark this as the last j replaced
                        overlap_small_assortment = (
                            overlap  # Update overlap for comparison
                        )
                        count_small_assortment = count_small_assortment + 1

                # If overlap is above overlap_threshold, replace the lower-ranked dataframe
                elif overlap >= context.assortment_collapsing.overlap_threshold:
                    replaced_df = replace_b_with_a(
                        separated_dfs[j], separated_dfs[i], overlap
                    )

                    last_j = j  # Mark this as the last j replaced
                    overlap_current = overlap  # Update overlap for comparison

                elif (
                    avg_len <= context.assortment_collapsing.no_item_no_small_assortment
                    and overlap
                    >= context.assortment_collapsing.overlap_threshold_small_assortment
                ):
                    replaced_df = replace_b_with_a(
                        separated_dfs[j], separated_dfs[i], overlap
                    )
                    last_j = j  # Mark this as the last j replaced
                    overlap_small_assortment = overlap  # Update overlap for comparison
                    count_small_assortment = count_small_assortment + 1

            # Mark the last j that was replaced as not eligible to replace
            if last_j is not None:
                eligible_to_replace[last_j] = False

            if count_small_assortment > 0:
                count_small_assortment_i = count_small_assortment_i + 1

            separated_dfs[i] = replaced_df

        # Concatenate all the final separated DataFrames for this group
        final_group_df = pd.concat(separated_dfs, ignore_index=True)

        # Add to the list for final concatenation
        final_dfs.append(final_group_df)

    # Concatenate all final group DataFrames to form the original df back
    final_result_df = pd.concat(final_dfs, ignore_index=True)

    # Remove redundant columns
    final_result_df = final_result_df.drop(
        ["total_stores_in_plano_cluster", "total_stores_in_cluster"], axis=1
    )

    return final_result_df, count_small_assortment_i


def collapvio_load_and_prepare_collapsed_assortment(dependent_var: str):
    """
    Loads and prepares the collapsed assortment from the optimization modeling output.

    Args:
        dependent_var (str): The dependent variable used to identify the correct optimization output file.

    Returns:
        pd.DataFrame: A DataFrame containing the non-collapsed optimization output with unique
        combinations of the grouping columns and plan numbers.

    Raises:
        ValueError: If duplicates are found in the resulting DataFrame after filtering and processing.
    """

    df_opti_modeling_output = OptimizationMasterModelingCollapsingOutput.load(
        file_path=complete_file_path(
            context.data_stores.optimization.root_path,
            context.data_stores.optimization.modeling.optimization_master_output_df_all_collapsed,
            at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
            dependent_var=dependent_var,
            run_id_folder=context.run_id.optimization_run_id,
        ),
        root=root_with_run_id(
            context.run_id.optimization_run_id,
            context.data_stores.optimization.save_to_datastores_root.modeling,
        ),
    )

    df_opti_modeling_output = df_opti_modeling_output.query("is_collapsed == 0")[
        context.assortment_collapsing.grouping_cols_unique_assortment
        + ["item_no_nbr", "n_optimal_facings_sku"]
    ].drop_duplicates()

    if (
        df_opti_modeling_output[
            context.assortment_collapsing.grouping_cols_unique_assortment + ["item_no_nbr"]
        ]
        .duplicated()
        .any()
    ):
        raise ValueError("Duplicates found in df_opti_modeling_output")

    return df_opti_modeling_output


def collapvio_load_and_prepare_original_assortment(dependent_var: str):
    """
    Loads the original optimization modeling output for a given dependent variable.

    Args:
        dependent_var (str): The dependent variable used to identify the correct optimization output file.

    Returns:
        pd.DataFrame: A DataFrame containing the original optimization output, including all rows without collapsing.
    """

    df_opti_modeling_output_original = OptimizationMasterModelingOutput.load(
        file_path=complete_file_path(
            context.data_stores.optimization.root_path,
            context.data_stores.optimization.modeling.optimization_master_output_df_all,
            at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
            dependent_var=dependent_var,
            run_id_folder=context.run_id.optimization_run_id,
        ),
        root=root_with_run_id(
            context.run_id.optimization_run_id,
            context.data_stores.optimization.save_to_datastores_root.modeling,
        ),
    )
    return df_opti_modeling_output_original


def collapvio_check_pod_violation(
    df_opti_modeling_output: pd.DataFrame,
    df_opti_modeling_output_original: pd.DataFrame,
    df_store_space_characteristics: pd.DataFrame,
) -> pd.DataFrame:
    """
    Checks for POD violations in the optimization output.

    This function calculates the optimal POD values for items, compares them against
    the minimum and maximum POD constraints from the original optimization output,
    and identifies violations.

    Args:
        df_opti_modeling_output (pd.DataFrame): The optimization output after collapsing.
        df_opti_modeling_output_original (pd.DataFrame): The original optimization output.
        df_store_space_characteristics (pd.DataFrame): The store space characteristics data.

    Returns:
        pd.DataFrame: A DataFrame with the optimal POD values and a `violated` column
        indicating whether the constraints were breached.

    Raises:
        ValueError: If duplicates are found in `df_pod_bound` or if `POD_enforce`, `min_POD`,
        or `max_POD` contain missing values.

    Steps:
        1. Calculate the number of stores in each unique assortment.
        2. Extract `min_POD`, `max_POD`, and `POD_enforce` from the original optimization output.
        3. Calculate `optimal_POD` for each `plano_cat_id`, `plano_cat_desc`, `dept_id`, `item_no_nbr`
        4. Compare `optimal_POD` to the constraints and flag violations.
    """

    df_opti_modeling_output = df_opti_modeling_output.copy()
    df_opti_modeling_output_original = df_opti_modeling_output_original.copy()
    df_store_space_characteristics = df_store_space_characteristics.copy()

    # Calculate number of stores in each cluster and department
    df_total_stores_per_cluster_dept_pog = (
        df_store_space_characteristics.groupby(
            context.assortment_collapsing.grouping_cols_unique_assortment
        )
        .agg(n_stores_after_collapsing=("store_nbr", "nunique"))
        .reset_index()
    )

    pod_bound_merge_cols = ["plano_cat_id", "plano_cat_desc", "dept_id", "item_no_nbr"]

    # Get min_POD and max_POD from the original optimization output
    df_pod_bound = df_opti_modeling_output_original[
        pod_bound_merge_cols + ["POD_enforce", "min_POD", "max_POD"]
    ].drop_duplicates()
    if df_pod_bound[pod_bound_merge_cols].duplicated().any():
        raise ValueError("Duplicates found in df_pod_bound")

    # Calculate PODs item_no_nbr, min_POD, max_POD, POD_enforce, optimal_POD
    df_item_POD_assortment = df_opti_modeling_output.merge(
        df_total_stores_per_cluster_dept_pog,
        on=context.assortment_collapsing.grouping_cols_unique_assortment,
        how="left",
    )

    df_item_POD_assortment["n_stores_after_collapsing"] = np.where(
        df_item_POD_assortment["n_optimal_facings_sku"] > 0,
        df_item_POD_assortment["n_stores_after_collapsing"],
        0,
    )

    df_item_POD_optimal = (
        df_item_POD_assortment.groupby(pod_bound_merge_cols)
        .agg(optimal_POD=("n_stores_after_collapsing", "sum"))
        .reset_index()
    )

    df_item_POD_optimal = df_item_POD_optimal.merge(
        df_pod_bound,
        on=pod_bound_merge_cols,
        how="left",
    )

    if df_item_POD_optimal[["POD_enforce", "min_POD", "max_POD"]].isna().any().any():
        raise ValueError("NA found in df_item_POD_assortment")

    df_item_POD_optimal["violated"] = np.where(
        (
            (df_item_POD_optimal["optimal_POD"] >= df_item_POD_optimal["min_POD"])
            & (df_item_POD_optimal["optimal_POD"] <= df_item_POD_optimal["max_POD"])
        )
        | (
            (df_item_POD_optimal["POD_enforce"] == "Soft_Default_Config")
            & (df_item_POD_optimal["optimal_POD"] == 0)
        ),
        0,
        1,
    )

    return df_item_POD_optimal
