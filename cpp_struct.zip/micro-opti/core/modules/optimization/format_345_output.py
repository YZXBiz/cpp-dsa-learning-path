import pandas as pd
import numpy as np
from glob import glob
import warnings

from oxygen.conf.settings import settings
from oxygen.conf.context import context

import logging
import ipdb

log = logging.getLogger(__name__)
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")


def generate_assrt_id_mapping(df_final, scenario_id):
    """
    Generate a unique ASSRT_ID mapping from df_final based on planogram configuration.

    Unique key fields (for ASSRT_ID generation) are:
      - plano_cat_desc,
      - plano_id,
      - cluster,        (becomes CLUSTER_LABEL)
      - plano_ft,       (becomes FIXTURE_WIDTH)
      - fixture_size,   (becomes FIXTURE_SIZE)
      - risk,           (becomes LP_FLAG)
      - volume,         (becomes VOLUME_FLAG)
      - "Rank at capacity" (will be renamed to RANK_AT_CAPACITY)

    STORE_NBR is not used for uniqueness, but its aggregated value (from the store_cluster column)
    is retained in the final output.

    Additional fields run_id and timestamp are maintained for debugging.

    After generating sequential ASSRT_ID values and adding SCENARIO_ID,
    the function merges the mapping key back into df_final and then explodes the
    store_cluster column so that each store is on its own row.

    Final output columns (in order):
      run_id, timestamp, scenario_id, PLANO_NBR, PLANO_CAT_DESC, CLUSTER_LABEL, FIXTURE_WIDTH, FIXTURE_SIZE,
      LP_FLAG, VOLUME_FLAG, RANK_AT_CAPACITY, ASSRT_ID, STORE_NBR.
    """
    df = df_final.copy()

    # Define the unique key fields for configuration (ignoring store_nbr)
    key_cols = ["plano_cat_desc", "plano_id", "cluster", "plano_ft", "fixture_size", "risk", "volume", "Rank at capacity"]

    # Build a mapping key DataFrame from df_final using the unique configuration.
    mapping = df[key_cols + ["run_id", "timestamp"]].drop_duplicates().copy()

    # Sort stably.
    mapping = mapping.sort_values(
        by=["plano_id", "cluster", "plano_ft", "fixture_size", "risk", "volume", "Rank at capacity"],
        kind="mergesort"
    )

    # Fill missing "Rank at capacity" with 9999.
    mapping["Rank at capacity"] = mapping["Rank at capacity"].fillna(9999)

    # Generate sequential ASSRT_ID.
    mapping["ASSRT_ID"] = ["ASSRT_" + str(i).zfill(6) for i in range(1, len(mapping) + 1)]

    # Add SCENARIO_ID.
    mapping["SCENARIO_ID"] = scenario_id

    # Rename columns to final internal names.
    mapping.rename(columns={
        "plano_cat_desc": "PLANO_CAT_DESC",
        "plano_id": "PLANOGRAM_ID",
        "cluster": "CLUSTER_LABEL",
        "plano_ft": "VERSION_WIDTH",
        "fixture_size": "FIXTURE_SIZE",
        "risk": "LP_FLAG",
        "volume": "VOLUME_FLAG",
        "Rank at capacity": "RANK_AT_CAPACITY"
    }, inplace=True)
    mapping.rename(columns={"VERSION_WIDTH": "FIXTURE_WIDTH"}, inplace=True)

    # Merge this mapping key back into df using the original column names.
    merge_left = ["plano_cat_desc", "plano_id", "cluster", "plano_ft", "fixture_size", "risk", "volume", "Rank at capacity"]
    merge_right = ["PLANO_CAT_DESC", "PLANOGRAM_ID", "CLUSTER_LABEL", "FIXTURE_WIDTH", "FIXTURE_SIZE", "LP_FLAG", "VOLUME_FLAG", "RANK_AT_CAPACITY"]
    df_merged = pd.merge(df, mapping, left_on=merge_left, right_on=merge_right, how="left", suffixes=("", "_r"))

    # Retain run_id and timestamp from df for debugging.
    # Use the store_cluster column (assumed to be a string like "[ 450 10364]") for store info.
    df_merged["store_cluster"] = df_merged["store_cluster"].astype(str).str.strip("[]")
    df_merged["store_cluster"] = df_merged["store_cluster"].str.split()

    # Explode the store_cluster column so that each store appears in its own row.
    df_exploded = df_merged.explode("store_cluster")
    df_exploded.rename(columns={"store_cluster": "STORE_NBR"}, inplace=True)

    # Select final columns.
    final_cols = [
        "run_id", "timestamp", "SCENARIO_ID", "PLANOGRAM_ID", "PLANO_CAT_DESC", "CLUSTER_LABEL",
        "FIXTURE_WIDTH", "FIXTURE_SIZE", "LP_FLAG", "VOLUME_FLAG", "RANK_AT_CAPACITY", "ASSRT_ID", "STORE_NBR"
    ]
    result = df_exploded[final_cols].copy()

    # Rename PLANOGRAM_ID to PLANO_NBR.
    result.rename(columns={"PLANOGRAM_ID": "PLANO_NBR"}, inplace=True)

    # Final cleanup: drop duplicates and sort by PLANO_NBR, ASSRT_ID.
    result = result.drop_duplicates().sort_values(by=["PLANO_NBR", "ASSRT_ID"])

    # Rename the scenario column header to lowercase.
    result.rename(columns={"SCENARIO_ID": "scenario_id"}, inplace=True)

    return result


def build_item_type_flags_from_detailed(df_detailed):
    """
    From df_detailed (which now includes both new_item and discontinue_item flags at the
    store+planogram level), produce a distinct table of:
      - item_no_nbr
      - plano_id
      - need_state_unique_id
      - item_type_flag   ("NEW","DISC","EXISTING")
    """
    # Copy and select only the relevant columns
    df_flags = df_detailed[[
        "item_no_nbr",
        "plano_id",
        "need_state_unique_id",
        "new_item",
        "discontinue_item"
    ]].copy()

    # Build the ITEM_TYPE_FLAG
    def flag_row(row):
        if row["new_item"] == 1:
            return "NEW"
        elif row["discontinue_item"] == 1:
            return "DISC"
        else:
            return "EXISTING"
    df_flags["item_type_flag"] = df_flags.apply(flag_row, axis=1)

    # Keep only the four columns we need, and dedupe
    df_flags = df_flags[[
        "item_no_nbr",
        "plano_id",
        "need_state_unique_id",
        "item_type_flag"
    ]].drop_duplicates()

    return df_flags


def build_model_core_output(
    df_final,
    df_assrt_map,
    df_item_flags,
    scenario_id="SCENARIO_001",
    request_type="FINAL_APPROVED"
):
    """
    Build the MODEL_CORE_OUTPUT table using df_final.

    Key steps:
      1. Add constant columns (request_type, scenario_id).
      2. Merge in ASSRT_ID from df_assrt_map using key fields.
      3. Ensure SKU_NBR is properly named.
      4. Merge in item_type_flag from df_item_flags, joining on (SKU_NBR, PLANO_NBR).
      5. Convert linear_width_ft from feet to inches.
      6. Rename core columns.
      7. Compute NEED_STATE_RANK_FLAG per (ASSRT_ID, NEED_STATE).
      8. Divide financial metrics by 52.
      9. Reorder and clean up columns.
    """
    df = df_final.copy()

    # 1. Set constant columns.
    df["request_type"] = request_type
    df["scenario_id"]  = scenario_id

    # 2. Merge in ASSRT_ID from df_assrt_map.
    merge_left  = ["plano_cat_desc", "plano_id", "cluster", "plano_ft", "fixture_size", "risk", "volume", "Rank at capacity"]
    merge_right = ["PLANO_CAT_DESC",  "PLANO_NBR",   "CLUSTER_LABEL", "FIXTURE_WIDTH", "FIXTURE_SIZE", "LP_FLAG",  "VOLUME_FLAG", "RANK_AT_CAPACITY"]
    df = pd.merge(
        df,
        df_assrt_map,
        left_on=merge_left,
        right_on=merge_right,
        how="left",
        suffixes=("", "_r")
    )
    df.drop(columns=merge_left, inplace=True)

    # 3. Ensure the item identifier is named "SKU_NBR".
    if "item_no_nbr" in df.columns:
        df.rename(columns={"item_no_nbr": "SKU_NBR"}, inplace=True)
    elif "SKU_NBR" not in df.columns:
        raise KeyError("Neither 'item_no_nbr' nor 'SKU_NBR' found in df_final.")

    # 4. Merge in item_type_flag if provided (join on SKU_NBR & PLANO_NBR).
    if df_item_flags is not None:
        df_item_flags = df_item_flags.rename(columns={
            "item_no_nbr": "SKU_NBR",
            "plano_id":     "PLANO_NBR",
            "need_state_unique_id": "NEED_STATE"
        })
        df = pd.merge(
            df,
            df_item_flags[["SKU_NBR", "PLANO_NBR", "NEED_STATE", "item_type_flag"]],
            on=["SKU_NBR", "PLANO_NBR"],
            how="left"
        )
        df["item_type_flag"] = df["item_type_flag"].fillna("EXISTING")
    else:
        df["item_type_flag"] = "EXISTING"
        # df["NEED_STATE"] = None

    # 5. Convert linear_width_ft from feet to inches.
    if "linear_width_ft" in df.columns:
        df["linear_width_ft"] = df["linear_width_ft"].astype(float) * 12

    # 6. Rename core columns.
    df.rename(columns={
        "plano_id":                 "PLANO_NBR",
        "Item_Facing":              "TARGET_FACINGS",
        "linear_width_ft":          "LINEAR_WIDTH_IN",
        "Is within shelf capacity": "IS_WITHIN_SHELF_CAPACITY",
        "avg_projected_sales":      "AVG_PROJECTED_SALES_PER_STORE_WK",
        "avg_projected_units":      "AVG_PROJECTED_UNITS_PER_STORE_WK",
        "avg_projected_margin":     "AVG_PROJECTED_DNP_PER_STORE_WK",
        "Rank":                     "RANK_WITHIN_VERSION"
    }, inplace=True)

    # 7. Compute NEED_STATE_RANK_FLAG per (ASSRT_ID, NEED_STATE).
    if all(col in df.columns for col in ["ASSRT_ID", "NEED_STATE", "RANK_WITHIN_VERSION"]):
        min_rank = df.groupby(["ASSRT_ID", "NEED_STATE"])["RANK_WITHIN_VERSION"].transform("min")
        df["NEED_STATE_RANK_FLAG"] = (df["RANK_WITHIN_VERSION"] == min_rank).astype(int)
    else:
        df["NEED_STATE_RANK_FLAG"] = 0

    # 8. Divide financial metrics by 52.
    for col in [
        "AVG_PROJECTED_SALES_PER_STORE_WK",
        "AVG_PROJECTED_UNITS_PER_STORE_WK",
        "AVG_PROJECTED_DNP_PER_STORE_WK"
    ]:
        if col in df.columns:
            df[col] = df[col].replace(pd.NA, np.nan).astype(float).fillna(0) / 52

    # 9. Final column order and cleanup.
    final_cols = [
        "run_id",
        "timestamp",
        "scenario_id",
        "PLANO_NBR",
        "ASSRT_ID",
        "RANK_WITHIN_VERSION",
        "TARGET_FACINGS",
        "SKU_NBR",
        "LINEAR_WIDTH_IN",
        "IS_WITHIN_SHELF_CAPACITY",
        "AVG_PROJECTED_SALES_PER_STORE_WK",
        "AVG_PROJECTED_UNITS_PER_STORE_WK",
        "AVG_PROJECTED_DNP_PER_STORE_WK",
        "request_type",
        "item_type_flag",
        "NEED_STATE",
        "NEED_STATE_RANK_FLAG"
    ]

    # Ensure any missing final columns exist.
    for col in final_cols:
        if col not in df.columns:
            df[col] = None

    result = df[final_cols].drop_duplicates()
    result.sort_values(by=["PLANO_NBR", "ASSRT_ID"], inplace=True)

    return result


def build_planogram_item_attributes(df_final, df_product_attr, scenario_id):
    """
    Build the PLANOGRAM_ITEM_ATTR table from product attribute data using df_final for validation.

    Inputs:
      - df_product_attr: DataFrame containing product attribute data with columns such as:
            PRODUCT_ID, CATEGORY, NEED_STATE, CDT,
            ATTRIBUTE_1, ATTRIBUTE_2, ... (a variable number of ATTRIBUTE_* columns),
            TO_BE_DROPPED, PLANOGRAM_DSC, PLANOGRAM_NBR, NEW ITEM, etc.
      - df_final: DataFrame with final planogram data containing columns such as:
            plano_id, item_no_nbr, run_id, and timestamp.
      - scenario_id: A constant scenario identifier (e.g., "SCENARIO_001").

    Process:
      1. Rename key columns in df_product_attr:
           PRODUCT_ID -> sku_nbr,
           PLANOGRAM_NBR -> plano_nbr,
           NEED_STATE -> need_state,
           CDT -> cdt.
      2. Add a scenario_id column.
      3. Define id_vars as ["plano_nbr", "sku_nbr", "need_state", "cdt", "scenario_id"].
      4. Dynamically identify all columns starting with "ATTRIBUTE_" as value_vars.
      5. Melt the DataFrame into long format so that each attribute becomes a separate row.
      6. Filter out rows with missing or empty attribute_value.
      7. Build a key DataFrame from df_final for valid items using columns:
             "plano_id", "item_no_nbr", "run_id", and "timestamp",
         and rename:
             plano_id -> plano_nbr and item_no_nbr -> sku_nbr.
      8. Perform an inner join on ["plano_nbr", "sku_nbr"] so that only attributes for valid items are retained.
      9. Select and reorder the final columns as:
             run_id, timestamp, scenario_id, cdt, need_state, sku_nbr, attribute_name, attribute_value.
     10. Rename the columns so that the final header is:
             run_id, timestamp, scenario_id, CDT, NEED_STATE, SKU_NBR, ATTRIBUTE_NAME, ATTRIBUTE_VALUE.
     11. Sort the final output by CDT, NEED_STATE, SKU_NBR, and ATTRIBUTE_NAME.

    Returns:
      A DataFrame with the columns:
         run_id, timestamp, scenario_id, CDT, NEED_STATE, SKU_NBR, ATTRIBUTE_NAME, ATTRIBUTE_VALUE.
    """
    # 1. Copy melted product attribute DataFrame.
    df_melt = df_product_attr.copy()

    # 2. Add scenario ID
    df_melt["scenario_id"] = scenario_id

    # 3. Filter out rows with missing or empty attribute_value.
    df_melt = df_melt[df_melt["attribute_value"].notnull() & (df_melt["attribute_value"] != "")]

    # 4. Build a key DataFrame from df_final for valid items.
    df_final_key = df_final[["plano_id", "item_no_nbr", "run_id", "timestamp"]].drop_duplicates().copy()
    df_final_key.rename(columns={"plano_id": "plano_nbr", "item_no_nbr": "sku_nbr"}, inplace=True)

    # 5. Perform an inner join on ["plano_nbr", "sku_nbr"].
    df_final_attr = pd.merge(df_melt, df_final_key, on=["plano_nbr", "sku_nbr"], how="inner")

    # 6. Define final column order.
    final_cols = ["run_id", "timestamp", "scenario_id", "cdt", "need_state", "sku_nbr", "attribute_name", "attribute_value"]
    df_final_attr = df_final_attr[final_cols]

    # 7. Rename columns to the desired final header.
    df_final_attr.rename(columns={
        "cdt": "CDT",
        "need_state": "NEED_STATE",
        "sku_nbr": "SKU_NBR",
        "attribute_name": "ATTRIBUTE_NAME",
        "attribute_value": "ATTRIBUTE_VALUE"
    }, inplace=True)

    # 8. Sort the final output by CDT, NEED_STATE, SKU_NBR, and ATTRIBUTE_NAME.
    df_final_attr.sort_values(by=["CDT", "NEED_STATE", "SKU_NBR", "ATTRIBUTE_NAME"], inplace=True)

    return df_final_attr


def build_dictionary_df():
    """
    Build a DataFrame that documents the final output fields for each table.
    """
    data = [
        # MODEL_CORE_OUTPUT
        ["MODEL_CORE_OUTPUT", "run_id", "Unique identifier for the run"],
        ["MODEL_CORE_OUTPUT", "timestamp", "Timestamp of the run"],
        ["MODEL_CORE_OUTPUT", "scenario_id", "Scenario identifier"],
        ["MODEL_CORE_OUTPUT", "PLANO_NBR", "Planogram number"],
        ["MODEL_CORE_OUTPUT", "RANK_WITHIN_VERSION", "Rank of the item within the planogram version"],
        ["MODEL_CORE_OUTPUT", "TARGET_FACINGS", "Recommended facings for the item"],
        ["MODEL_CORE_OUTPUT", "SKU_NBR", "Unique SKU number (item identifier)"],
        ["MODEL_CORE_OUTPUT", "LINEAR_WIDTH_IN", "Linear width of the item in inches"],
        ["MODEL_CORE_OUTPUT", "IS_WITHIN_SHELF_CAPACITY", "Indicator if the item fits within shelf capacity"],
        ["MODEL_CORE_OUTPUT", "AVG_PROJECTED_SALES_PER_STORE_WK", "Average projected sales per store per week"],
        ["MODEL_CORE_OUTPUT", "AVG_PROJECTED_UNITS_PER_STORE_WK", "Average projected units per store per week"],
        ["MODEL_CORE_OUTPUT", "AVG_PROJECTED_DNP_PER_STORE_WK", "Average projected DNP per store per week"],
        ["MODEL_CORE_OUTPUT", "ASSRT_ID", "Unique assortment ID linking to the store mapping"],
        ["MODEL_CORE_OUTPUT", "request_type", "Request type (e.g., FINAL_APPROVED)"],
        ["MODEL_CORE_OUTPUT", "item_type_flag", "Item type flag (new, discontinued, or existing)"],

        # ASSRT_MAP
        ["ASSRT_MAP", "run_id", "Unique identifier for the run"],
        ["ASSRT_MAP", "timestamp", "Timestamp of the run"],
        ["ASSRT_MAP", "scenario_id", "Scenario identifier"],
        ["ASSRT_MAP", "PLANO_NBR", "Planogram number"],
        ["ASSRT_MAP", "PLANO_CAT_DESC", "Planogram category description"],
        ["ASSRT_MAP", "CLUSTER_LABEL", "Customer-driven cluster label"],
        ["ASSRT_MAP", "FIXTURE_WIDTH", "Shelf (fixture) width"],
        ["ASSRT_MAP", "FIXTURE_SIZE", "Fixture size in inches"],
        ["ASSRT_MAP", "LP_FLAG", "Loss prevention flag"],
        ["ASSRT_MAP", "VOLUME_FLAG", "Volume flag"],
        ["ASSRT_MAP", "RANK_AT_CAPACITY", "Rank at capacity threshold"],
        ["ASSRT_MAP", "ASSRT_ID", "Unique assortment ID"],
        ["ASSRT_MAP", "STORE_NBR", "Aggregated store numbers (exploded)"],

        # PLANOGRAM_ITEM_ATTR
        ["PLANOGRAM_ITEM_ATTR", "run_id", "Unique identifier for the run"],
        ["PLANOGRAM_ITEM_ATTR", "timestamp", "Timestamp of the run"],
        ["PLANOGRAM_ITEM_ATTR", "scenario_id", "Scenario identifier"],
        ["PLANOGRAM_ITEM_ATTR", "PLANO_NBR", "Planogram number"],
        ["PLANOGRAM_ITEM_ATTR", "CDT", "CDT attribute value"],
        ["PLANOGRAM_ITEM_ATTR", "NEED_STATE", "Need state for the item"],
        ["PLANOGRAM_ITEM_ATTR", "SKU_NBR", "Unique SKU number (item identifier)"],
        ["PLANOGRAM_ITEM_ATTR", "ATTRIBUTE_NAME", "Name of the product attribute"],
        ["PLANOGRAM_ITEM_ATTR", "ATTRIBUTE_VALUE", "Value of the product attribute"]
    ]
    df_dict = pd.DataFrame(data, columns=["Table", "Field", "Description"])
    return df_dict


def write_outputs(df_model, df_assrt_map, df_item_attr, df_dict, filename="output_tables.xlsx"):
    """
    Write output tables to an Excel workbook and CSV files.

    The Excel workbook will contain the following tabs (in this order):
      1. MODEL_CORE_OUTPUT
      2. ASSRT_MAP
      3. PLANOGRAM_ITEM_ATTR
      4. DICTIONARY

    Tab names are as specified.
    """
    with pd.ExcelWriter(filename) as writer:
        df_model.to_excel(writer, sheet_name="MODEL_CORE_OUTPUT", index=False)
        df_assrt_map.to_excel(writer, sheet_name="ASSRT_MAP", index=False)
        df_item_attr.to_excel(writer, sheet_name="PLANOGRAM_ITEM_ATTR", index=False)
        df_dict.to_excel(writer, sheet_name="DICTIONARY", index=False)

    # Also write CSV files for each tab if desired.
    df_model.to_csv("MODEL_CORE_OUTPUT.csv", index=False)
    df_assrt_map.to_csv("ASSRT_MAP.csv", index=False)
    df_item_attr.to_csv("PLANOGRAM_ITEM_ATTR.csv", index=False)
    df_dict.to_csv("DICTIONARY.csv", index=False)


def append_additional_recommendations(central_df: pd.DataFrame, max_recommendations: int = 20) -> pd.DataFrame:
    """
    Processes additional recommendations for each base group in the input DataFrame.

    Base recommendations are rows where "Is within shelf capacity" is True.
    These base rows are grouped by the context fields:
        ["plano_id", "final_cluster_labels", "plano_ft", "store_nbr", "store_cluster", "cluster", "Rank at capacity"]

    For each base group:
      1. The first row is used as the base context (to inherit most columns).
      2. The threshold sales is determined from the row where Rank equals Rank at capacity.
      3. Candidate rows are selected from the overall DataFrame that:
            - Belong to the same plano_id and cluster,
            - Have plano_ft greater than or equal to the base group's,
            - Have a different final_cluster_labels (i.e. are not base rows),
            - Have Item_Facing equal to 1,
            - Have avg_projected_sales > 0,
            - Are not already present in the base group (by item_no_nbr), and
            - Have avg_projected_sales below the threshold.
      4. Duplicate candidate rows (by item_no_nbr) are dropped, and candidates are sorted descending by avg_projected_sales.
      5. For each candidate, a new row is created:
            - Inherits the entire base context,
            - Updates only candidate-specific fields:
                  ["item_no_nbr", "item_no_desc", "Item_Facing", "linear_width_ft",
                   "avg_projected_sales", "avg_projected_margin", "avg_projected_units"],
            - Receives a new Rank (continuing after the base group) and is marked as not within shelf capacity.
      6. The number of appended rows per group is limited to max_recommendations.
      7. Finally, base rows and all appended rows are combined and sorted by:
            plano_id, final_cluster_labels, plano_ft, fixture_size, and Rank (all ascending).

    All other columns from the base context are preserved.
    """
    # Step 1: Extract base recommendations.
    base_df = central_df[central_df["Is within shelf capacity"] == True].copy()
    if base_df.empty:
        raise ValueError("No base recommendations found (Is within shelf capacity is True).")

    # Step 2: Define grouping key (context) for base rows.
    group_cols = ["plano_id", "final_cluster_labels", "plano_ft", "store_nbr", "store_cluster", "cluster", "Rank at capacity"]

    appended_rows_all = []  # To collect appended candidate-derived rows across all groups.
    base_groups = []        # To collect base groups.

    # Process each base group separately.
    for group_key, group in base_df.groupby(group_cols):
        # Unpack the group key.
        target_plano_id, target_final_cluster_labels, target_plano_ft, target_store_nbr, target_store_cluster, target_cluster, capacity = group_key

        # Step 3: Use the first row of the group as the base context.
        base_context = group.iloc[0].to_dict()

        # Step 4: Determine threshold sales from the row where Rank equals Rank at capacity.
        threshold_row = group[group["Rank"] == capacity]
        if threshold_row.empty:
            continue
        threshold_sales = threshold_row.iloc[0]["avg_projected_sales"]

        # Step 5: Identify candidate rows that may be appended.
        candidate_df = central_df[
            (central_df["final_cluster_labels"] != target_final_cluster_labels) &  # Must be a candidate row.
            (central_df["plano_id"] == target_plano_id) &                          # Same plano_id.
            # (central_df["cluster"] == target_cluster) &                             # Same cluster.
            (central_df["plano_ft"] >= target_plano_ft) &                           # Equal or larger planogram width.
            (central_df["Item_Facing"] == 1) &                                      # Candidate must have Item_Facing==1.
            (central_df["avg_projected_sales"] > 0)                                 # Sales must be > 0.
        ].copy()

        # Exclude candidates already in the base group and ensure sales are below the threshold.
        candidate_df = candidate_df[
            (~candidate_df["item_no_nbr"].isin(group["item_no_nbr"])) &
            (candidate_df["avg_projected_sales"] < threshold_sales)
        ]

        # Step 6: Remove duplicates based on item_no_nbr and sort by avg_projected_sales (descending).
        candidate_df = candidate_df.drop_duplicates(subset=["item_no_nbr"])
        candidate_df = candidate_df.sort_values(by="avg_projected_sales", ascending=False)

        # Step 7: Create new appended rows.
        max_group_rank = group["Rank"].max()
        new_rank = max_group_rank + 1

        group_new_rows = []  # To hold new rows for this group.
        # Candidate-specific columns that will be updated from candidate rows.
        candidate_cols = [
            "item_no_nbr", "item_no_desc", "Item_Facing", "linear_width_ft",
            "avg_projected_sales", "avg_projected_margin", "avg_projected_units"
        ]
        for _, candidate in candidate_df.iterrows():
            # Start with a copy of the base context.
            new_row = base_context.copy()
            # Overwrite candidate-specific fields.
            for col in candidate_cols:
                new_row[col] = candidate[col]
            # Assign new Rank and mark as not within shelf capacity.
            new_row["Rank"] = new_rank
            new_row["Rank at capacity"] = capacity
            new_row["Is within shelf capacity"] = False
            group_new_rows.append(new_row)
            new_rank += 1

        # Limit the number of appended rows for this group.
        if group_new_rows:
            group_new_rows = group_new_rows[:max_recommendations]
            appended_rows_all.extend(group_new_rows)

        # Save the base group for later combination.
        base_groups.append(group)

    # Step 8: Combine all base groups and all appended rows.
    base_all = pd.concat(base_groups, ignore_index=True) if base_groups else pd.DataFrame()
    appended_all = pd.DataFrame(appended_rows_all) if appended_rows_all else pd.DataFrame()
    final_df = pd.concat([base_all, appended_all], ignore_index=True)

    # Step 9: Sort the final DataFrame by plano_id, final_cluster_labels, plano_ft, fixture_size, and Rank (all ascending).
    final_df = final_df.sort_values(by=["plano_id", "final_cluster_labels", "plano_ft", "fixture_size", "Rank"]).reset_index(drop=True)

    return final_df