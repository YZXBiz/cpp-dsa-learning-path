import pandas as pd
from oxygen.conf.context import context
from core.utils.optimizer_helpers import check_duplicates
import logging

log = logging.getLogger(__name__)


def count_violated_stores(df_store_characteristics: pd.DataFrame) -> pd.DataFrame:
    """
    Count the number of stores that are exceeding space for each groupby level
    """
    groupby_cols = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_level
    )
    df_violated_stores = (
        df_store_characteristics.groupby(groupby_cols)
        .agg(
            n_stores_exceeding_space=("is_exceeding_space", "sum"),
        )
        .reset_index()
    )
    return df_violated_stores


def count_optimal_assortment_POD(df):
    """
    Count the optimal assortment POD for each item and brand
    As well as the POD reduction after resolving space violations
    """
    df_item_POD_summary = (
        df.groupby(context.groupby_granularity.optimizer + ["item_no_nbr", "brand_name"])
        .agg(
            optimal_assortment_item_POD=(
                "n_stores",
                lambda x: x[df["n_optimal_facings_sku"] > 0].sum(),
            ),
            max_item_POD_reduction_after_pp=(
                "n_stores_exceeding_space",
                lambda x: x[df["n_optimal_facings_sku"] > 0].sum(),
            ),
        )
        .reset_index()
    )
    df_item_POD_summary["item_POD_after_resolving_space_violations_pp"] = (
        df_item_POD_summary["optimal_assortment_item_POD"]
        - df_item_POD_summary["max_item_POD_reduction_after_pp"]
    )
    df_brand_POD_report = (
        df_item_POD_summary.groupby(
            context.groupby_granularity.optimizer + ["brand_name"]
        )
        .agg(
            optimal_assortment_brand_POD=("optimal_assortment_item_POD", "sum"),
            max_brand_POD_reduction_after_pp=("max_item_POD_reduction_after_pp", "sum"),
        )
        .reset_index()
    )
    df_brand_POD_report["brand_POD_after_resolving_space_violations_pp"] = (
        df_brand_POD_report["optimal_assortment_brand_POD"]
        - df_brand_POD_report["max_brand_POD_reduction_after_pp"]
    )
    df = df.merge(
        df_item_POD_summary,
        on=context.groupby_granularity.optimizer + ["item_no_nbr", "brand_name"],
        how="left",
    )
    df = df.merge(
        df_brand_POD_report,
        on=context.groupby_granularity.optimizer + ["brand_name"],
        how="left",
    )
    return df


def determine_protected_items(
    df_optimization_master_data: pd.DataFrame,
    df_store_characteristics: pd.DataFrame,
):
    """
    Determine the protected items based on 3 sets of constraints:
    1. Items with positive forced facings
    2. Items with min_POD constraints
    3. Items within brand with min_brand_POD constraints
    Returns:
        pd.DataFrame: DataFrame containing the protected items. (granularity is item and optimizers granularity)
    """

    # first create a skeleton of the protected items output

    groupby_cols = (
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_sku_level
        + ["brand_name"]
    )

    df_optimization_master_data_filter = df_optimization_master_data[
        groupby_cols
        + [
            "n_stores",
            "min_forced_facings_guardrails",
            "max_forced_facings_guardrails",
            "POD_enforce",
            "min_POD",
            "max_POD",
            "brand_POD_enforce",
            "min_brand_POD",
            "max_brand_POD",
            "n_optimal_facings_sku",
        ]
    ].drop_duplicates()

    df_violated_stores = count_violated_stores(df_store_characteristics)
    df_optimization_master_data_filter = df_optimization_master_data_filter.merge(
        df_violated_stores,
        on=context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_level,
        how="left",
    )

    df_optimization_master_data_filter = count_optimal_assortment_POD(
        df_optimization_master_data_filter
    )

    check_duplicates(
        df_optimization_master_data_filter,
        "df_optimization_master_data_determine_protected_items",
        groupby_cols,
    )

    # items with positive forced facings
    df_optimization_master_data_filter["is_protect_forced_pos_facings"] = (
        df_optimization_master_data_filter["min_forced_facings_guardrails"] > 0
    ).astype(int)

    # items with user input positive min POD
    df_optimization_master_data_filter["is_protect_user_input_min_POD"] = (
        (df_optimization_master_data_filter["min_POD"] > 0)
        & (df_optimization_master_data_filter["POD_enforce"] == "Hard_User_Input")
    ).astype(int)

    df_optimization_master_data_filter["is_protect_user_input_min_POD_in_pp"] = (
        (df_optimization_master_data_filter["is_protect_user_input_min_POD"] == 1)
        & (
            df_optimization_master_data_filter[
                "item_POD_after_resolving_space_violations_pp"
            ]
            < df_optimization_master_data_filter["min_POD"]
        )
    ).astype(int)

    # brands with user input positive min brand POD
    df_optimization_master_data_filter["is_protect_user_input_min_brand_POD"] = (
        (df_optimization_master_data_filter["min_brand_POD"] > 0)
        & (df_optimization_master_data_filter["brand_POD_enforce"] == "Hard_User_Input")
    ).astype(int)

    df_optimization_master_data_filter["is_protect_user_input_min_brand_POD_in_pp"] = (
        (df_optimization_master_data_filter["is_protect_user_input_min_brand_POD"] == 1)
        & (
            df_optimization_master_data_filter[
                "brand_POD_after_resolving_space_violations_pp"
            ]
            < df_optimization_master_data_filter["min_brand_POD"]
        )
    ).astype(int)

    df_optimization_master_data_filter["is_protect_items_conservative"] = (
        df_optimization_master_data_filter["is_protect_forced_pos_facings"]
        | df_optimization_master_data_filter["is_protect_user_input_min_POD"]
        | df_optimization_master_data_filter["is_protect_user_input_min_brand_POD"]
    ).astype(int)

    df_optimization_master_data_filter["is_protect_items"] = (
        df_optimization_master_data_filter["is_protect_forced_pos_facings"]
        | df_optimization_master_data_filter["is_protect_user_input_min_POD_in_pp"]
        | df_optimization_master_data_filter[
            "is_protect_user_input_min_brand_POD_in_pp"
        ]
    ).astype(int)

    return df_optimization_master_data_filter
