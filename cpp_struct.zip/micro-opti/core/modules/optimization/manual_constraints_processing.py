import pandas as pd
from box import Box
from oxygen.conf.context import context
import logging

log = logging.getLogger(__name__)
from core.utils.optimizer_helpers import (
    check_duplicates,
)

import ipdb


def add_need_state_facings_caps_information(
    df_optimization_master_data_dept: pd.DataFrame,
    config_max_facings_per_need_state: Box,
) -> pd.DataFrame:
    """
    Calculates statistics about the need state facings which will be useful for the need state growth caps constraint
    Args:
        df_optimization_master_data_dept: Optimization master input used by optimizer to create sets and other model
        parameters
        config_max_facings_per_need_state: configuration for how to create the max number of facings per need state
        based on the current number of facings per need state

    Returns:
    Optimization master input used by optimizer to create sets and other model parameters, containing new columns
    with statistics about the need state facings:
    - "n_current_facings_need_state": Sum of current SKU facings in a given need state
    - "n_forced_facings_need_state_not_in_current": Sum of net new forced SKU facings in a given need state
    (sum of forced-current at SKU level)
    - "n_forced_facings_all_need_state": Sum of all new forced SKU facings in a given need state (without comparing
    to current)
    - "n_current_and_forced_facings_unique_need_state": sum of n_current_facings_need_state and
    n_forced_facings_need_state_not_in_current since these 2 are mutually exclusive
    - "n_manually_adjusted_saturation_facings_need_state": manually adjusted saturation facings for the need state using
     config-driven manual rules in `config_max_facings_per_need_state`
    - "n_facings_middle_current_and_saturation_need_state": middle ground number of facings between current and
    saturation for the case where current >= saturation_facings
    """
    # Creating additional forced facings (compared to current facings) so we can sum those
    df_optimization_master_data_dept[
        "n_min_addtl_forced_facings_vs_current_facings"
    ] = 0
    df_optimization_master_data_dept.loc[
        (
            df_optimization_master_data_dept["min_forced_facings_guardrails"]
            - df_optimization_master_data_dept["n_current_facings_sku"]
            >= 0
        ),
        "n_min_addtl_forced_facings_vs_current_facings",
    ] = (
        df_optimization_master_data_dept["min_forced_facings_guardrails"]
        - df_optimization_master_data_dept["n_current_facings_sku"]
    )

    # Aggregating these facings stats for the need state growth caps constraints
    df_optimization_master_data_dept[
        "min_forced_facings_guardrails"
    ] = df_optimization_master_data_dept["min_forced_facings_guardrails"].fillna(0)
    df_optimization_master_data_dept[
        "max_forced_facings_guardrails"
    ] = df_optimization_master_data_dept["max_forced_facings_guardrails"].fillna(
        context.optimization.model_formulation.max_facings_opti - 1
    )
    df_facings_need_state_stats = (
        df_optimization_master_data_dept.groupby(
            (
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_optimizer_ns_level
            )
        )[
            [
                "n_current_facings_sku",
                "n_min_addtl_forced_facings_vs_current_facings",
                "min_forced_facings_guardrails",
            ]
        ]
        .sum()
        .reset_index()
        .rename(
            columns={
                "n_current_facings_sku": "n_current_facings_need_state",
                "n_min_addtl_forced_facings_vs_current_facings": "n_forced_facings_need_state_not_in_current",
                "min_forced_facings_guardrails": "n_forced_facings_all_need_state",
            }
        )
    )
    df_facings_need_state_stats["n_manually_adjusted_saturation_facings_need_state"] = 0
    # Creating manually adjusted saturation facings using the config-driven manual rules
    for lower_upper_bound_string in list(config_max_facings_per_need_state.keys()):
        (lower_bound, upper_bound) = [
            int(x)
            for x in lower_upper_bound_string.replace("(", "")
            .replace(")", "")
            .split(",")
        ]
        dict_ub = config_max_facings_per_need_state[lower_upper_bound_string]
        if dict_ub.type == "raw_facings":
            df_facings_need_state_stats.loc[
                (
                    df_facings_need_state_stats["n_current_facings_need_state"].between(
                        lower_bound, upper_bound
                    )
                ),
                "n_manually_adjusted_saturation_facings_need_state",
            ] = dict_ub.value
        elif dict_ub.type == "pct_increase":
            df_facings_need_state_stats.loc[
                (
                    df_facings_need_state_stats["n_current_facings_need_state"].between(
                        lower_bound, upper_bound
                    )
                ),
                "n_manually_adjusted_saturation_facings_need_state",
            ] = (1 + dict_ub.value) * df_facings_need_state_stats[
                "n_current_facings_need_state"
            ]
        else:
            log.warning(f"Expected 'raw_facings' or 'pct_increase', got {dict_ub.type}")
            raise NotImplementedError(
                f"Expected 'raw_facings' or 'pct_increase', got {dict_ub.type}"
            )

    df_facings_need_state_stats["n_manually_adjusted_saturation_facings_need_state"] = (
        df_facings_need_state_stats["n_manually_adjusted_saturation_facings_need_state"]
        .round(0)
        .astype(int)
    )
    # Joining back to opti master
    df_optimization_master_data_dept = df_optimization_master_data_dept.merge(
        df_facings_need_state_stats,
        on=(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_ns_level
        ),
        how="left",
    )
    for col in [
        "n_current_facings_need_state",
        "n_forced_facings_need_state_not_in_current",
        "n_forced_facings_all_need_state",
        "n_manually_adjusted_saturation_facings_need_state",
    ]:
        df_optimization_master_data_dept[col] = df_optimization_master_data_dept[
            col
        ].fillna(0)

    df_optimization_master_data_dept[
        "n_current_and_forced_facings_unique_need_state"
    ] = (
        df_optimization_master_data_dept["n_current_facings_need_state"]
        + df_optimization_master_data_dept["n_forced_facings_need_state_not_in_current"]
    )
    df_optimization_master_data_dept[
        "n_facings_middle_current_and_saturation_need_state"
    ] = df_optimization_master_data_dept["n_current_facings_need_state"]
    check_duplicates(
        df_optimization_master_data_dept[
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_ns_level
            + [
                "n_current_facings_need_state",
                "saturation_facings",
                "n_forced_facings_need_state_not_in_current",
                "n_forced_facings_all_need_state",
                "n_manually_adjusted_saturation_facings_need_state",
                "n_current_and_forced_facings_unique_need_state",
                "n_facings_middle_current_and_saturation_need_state",
            ]
        ].drop_duplicates(),
        "df_optimization_master_data_dept_add_need_state_facings_caps_information",
        context.groupby_granularity.optimizer
        + context.optimization.data_prep.addtl_agg_optimizer_ns_level,
    )
    return df_optimization_master_data_dept


def add_supplier_and_brand_space_constraints(
    df_optimization_master_data_dept: pd.DataFrame,
    df_supplier_and_brand_requested_space: pd.DataFrame,
) -> pd.DataFrame:
    """
    Joining the supplier and brand space requests based on the type of constraints (to avoid duplicates)
    and we have to coalesce columns after renaming them so that we don't have the same column multiple times
    Args:
        df_optimization_master_data_dept: Master optimization dataset which will be used to create sets, parameters,
        decision variables, constraints and objective function for the optimization model
        df_supplier_and_brand_requested_space: comes from an API call, provides a % of linear space in a POG
        Category to be reserved by optimizer for a specific supplier / brand

    Returns:
    Master optimization dataset which will be used to create sets, parameters, decision variables, constraints and
    objective function for the optimization model, including the data needed for supplier/brand space constraints
    """
    df_optimization_master_data_dept = df_optimization_master_data_dept.merge(
        df_supplier_and_brand_requested_space[
            df_supplier_and_brand_requested_space["constraint_type_supplier_or_brand"]
            .fillna("")
            .str.contains("supplier")
        ][
            (context.groupby_granularity.optimizer + ["final_cluster_labels"])
            + [
                "constraint_type_supplier_or_brand",
                "supplier_name",
                "lower_bound_constraint_supplier_or_brand",
                "upper_bound_constraint_supplier_or_brand",
            ]
        ],
        on=(context.groupby_granularity.optimizer + ["final_cluster_labels"])
        + [
            "supplier_name",
        ],
        how="left",
    ).merge(
        df_supplier_and_brand_requested_space[
            df_supplier_and_brand_requested_space["constraint_type_supplier_or_brand"]
            .fillna("")
            .str.contains("brand")
        ][
            (context.groupby_granularity.optimizer + ["final_cluster_labels"])
            + [
                "constraint_type_supplier_or_brand",
                "brand_name",
                "lower_bound_constraint_supplier_or_brand",
                "upper_bound_constraint_supplier_or_brand",
            ]
        ].rename(
            columns={
                "constraint_type_supplier_or_brand": "constraint_type_supplier_or_brand_brand_only",
                "lower_bound_constraint_supplier_or_brand": "lower_bound_constraint_supplier_or_brand_brand_only",
                "upper_bound_constraint_supplier_or_brand": "upper_bound_constraint_supplier_or_brand_brand_only",
            }
        ),
        on=(
            context.groupby_granularity.optimizer
            + ["final_cluster_labels", "brand_name"]
        ),
        how="left",
    )

    # Coalescing these 3 new columns
    df_optimization_master_data_dept["constraint_type_supplier_or_brand"] = (
        df_optimization_master_data_dept["constraint_type_supplier_or_brand"]
        .combine_first(
            df_optimization_master_data_dept[
                "constraint_type_supplier_or_brand_brand_only"
            ]
        )
    )
    df_optimization_master_data_dept["lower_bound_constraint_supplier_or_brand"] = (
        df_optimization_master_data_dept["lower_bound_constraint_supplier_or_brand"]
        .combine_first(
            df_optimization_master_data_dept[
                "lower_bound_constraint_supplier_or_brand_brand_only"
            ]
        )
    )

    df_optimization_master_data_dept["upper_bound_constraint_supplier_or_brand"] = (
        df_optimization_master_data_dept["upper_bound_constraint_supplier_or_brand"]
        .combine_first(
            df_optimization_master_data_dept[
                "upper_bound_constraint_supplier_or_brand_brand_only"
            ]
        )
    )
    return df_optimization_master_data_dept.drop(
        columns=[
            "constraint_type_supplier_or_brand_brand_only",
            "lower_bound_constraint_supplier_or_brand_brand_only",
            "upper_bound_constraint_supplier_or_brand_brand_only",
        ]
    )


def add_pivot_and_linked_sku_pair_constraints(
    df_optimization_master_data_dept: pd.DataFrame,
    df_pivot_and_linked_sku_pair_constraints: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function adds one column to the optimization input (`unique_linked_item_no_nbrs`), containing a string of all the
    `item_no_nbr` that are linked to the original `item_no_nbr` in the dataframe, separated by a comma
    Args:
        df_optimization_master_data_dept: Optimization master input used by optimizer to create sets and other model
        parameters
        df_pivot_and_linked_sku_pair_constraints: Constraint dataframe containing pairs of pivot and linked SKUs,
        where if the pivot SKU gets assigned >= 1 facing by optimizer then the linked SKU also needs to be assigned
        >= 1 facing by optimizer

    Returns:
    Optimization master data for a department with an extra column (`unique_linked_item_no_nbrs`), containing a string of
    all the `item_no_nbr` that are linked to the original `item_no_nbr` in the dataframe, separated by a comma
    """

    if len(df_pivot_and_linked_sku_pair_constraints) > 0:
        df_valid_item_no_cluster_pairs = (
            df_optimization_master_data_dept[
                context.groupby_granularity.optimizer + context.optimization.data_prep.addtl_agg_sku_cluster_level
            ]
            .rename(columns={"item_no_nbr" : "linked_item_no_nbr"})
            .drop_duplicates()
        )
        # Create a cartesian product between final_cluster_labels and the input pivot linked item pairs for clear logging
        df_pivot_and_linked_sku_pair_constraints = (
            df_pivot_and_linked_sku_pair_constraints[
                context.groupby_granularity.optimizer
                +  ["pivot_item_no_nbr", "linked_item_no_nbr"]
            ]
            .drop_duplicates()
        )
        log.info("Pivot linked item pairs from the input:")
        log.info("\n" + df_pivot_and_linked_sku_pair_constraints.to_string())

        df_final_clusters = df_optimization_master_data_dept["final_cluster_labels"].drop_duplicates()
        df_pivot_linked_clusters_combos = df_pivot_and_linked_sku_pair_constraints.merge(df_final_clusters, how="cross")
        # Add logging for checking
        n_cluster = df_final_clusters.shape[0]
        n_pivot_linked_pairs = df_pivot_and_linked_sku_pair_constraints.shape[0]
        n_cluster_pivot_linked_combos = df_pivot_linked_clusters_combos.shape[0]
        log.info(f"Count of unique final clusters: {n_cluster}")
        log.info(
            f"Count of unique pivot, linked items pairs from the inputs: {n_pivot_linked_pairs}"
        )
        log.info(
            f"Count of unique pivot, linked items, final cluster combinations assuming all pivot linked items exist in each cluster: "
            f"{n_cluster_pivot_linked_combos}"
        )
        df_merged_pivot_and_linked_sku_pair_constraints = (
            df_pivot_linked_clusters_combos
            .merge(
                df_valid_item_no_cluster_pairs,
                on=(context.groupby_granularity.optimizer + ["final_cluster_labels", "linked_item_no_nbr"]),
                how="left",
                indicator=True
            )
        )

        log.info("Excluding the following linked items since they don't appear in the corresponding cluster:")
        log.info(
            "\n" + (
            df_merged_pivot_and_linked_sku_pair_constraints[
                ["final_cluster_labels", "pivot_item_no_nbr", "linked_item_no_nbr", "_merge"]
            ]
            .query("_merge == 'left_only'")
            .sort_values(by=["final_cluster_labels", "pivot_item_no_nbr"])
            .drop("_merge", axis=1)
            .reset_index(drop=True)
            .to_string()
            )
        )
        df_valid_pivot_and_linked_sku_pair_constraints = (
            df_merged_pivot_and_linked_sku_pair_constraints
            .query("_merge == 'both'")
            .drop("_merge", axis=1)
        )
        n_valid_cluster_linked_item_pairs = df_valid_pivot_and_linked_sku_pair_constraints.shape[0]
        log.info(
            f"Count of unique pivot, linked items pairs after excluding nonexistent linked items from each cluster: "
            f"{n_valid_cluster_linked_item_pairs}"
        )

        df_pivot_and_linked_sku_pair_constraints_agg_unique = (
            df_valid_pivot_and_linked_sku_pair_constraints.groupby(
                context.groupby_granularity.optimizer + ["pivot_item_no_nbr", "final_cluster_labels"],
            )["linked_item_no_nbr"]
            .unique()
            .reset_index(name="unique_linked_item_no_nbrs")
        )
        # Transforming it into long string to be processed in model_sets_and_params
        df_pivot_and_linked_sku_pair_constraints_agg_unique["unique_linked_item_no_nbrs"] = (
            df_pivot_and_linked_sku_pair_constraints_agg_unique["unique_linked_item_no_nbrs"].apply(
                lambda list_linked_skus: ",".join([str(sku) for sku in list_linked_skus])
            )
        )
        # Merge based on pivot item_no nbr (renaming to item_no nbr to join with the master optimization table)
        # nonexistent final cluster, pivot item pairs will be dropped since it's a left join
        # and the master optimization table has all valid final cluster, item_no nbr pairs
        df_optimization_master_data_dept = (
            df_optimization_master_data_dept
            .merge(
                df_pivot_and_linked_sku_pair_constraints_agg_unique.rename(
                columns={"pivot_item_no_nbr": "item_no_nbr"}
            ),
            on=(context.groupby_granularity.optimizer + ["item_no_nbr", "final_cluster_labels"]),
            how="left",
            )
        )
        log.info("Remaining pivot linked items filtered for each cluster:")
        log.info(
            "\n" + (df_optimization_master_data_dept[["final_cluster_labels", "item_no_nbr", "unique_linked_item_no_nbrs"]]
            .dropna()
            .drop_duplicates()
            .sort_values(by=["final_cluster_labels", "item_no_nbr"])
            .reset_index(drop=True)
            .to_string()
            )
        )

    else:
        df_optimization_master_data_dept["unique_linked_item_no_nbrs"] = ""

    return df_optimization_master_data_dept


def add_global_linear_space_constraints(
    df_optimization_master_data_dept: pd.DataFrame,
    df_global_linear_change_requested_space: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function adds three columns per global linear space dimension (min bound, max bound, change type) to the
    main dataframe
    Args:
        df_optimization_master_data_dept: Optimization master input used by optimizer to create sets and other model
        parameters
        df_global_linear_change_requested_space: Constraint dataframe containing min/max linear space a dimension
        can occupy

    Returns:
    Optimization master data for a department with an extra 3 columns per dimension`)
    """
    # Validate that each dimension/name combo has at most one change type
    max_change_types = (
        df_global_linear_change_requested_space
        .groupby(["dimension", "name"])
        ["constraint_relative_to"]
        .count()
        .reset_index()
        ["constraint_relative_to"]
        .max()
    )
    if max_change_types > 1:
        raise ValueError(
            f"Found duplicate entry per dimension & name in global linear space constraint. Each combination can  "
            f"have at most one entry"
        )

    # Verify that only supplier or brand are being changes are being
    max_dimension_1_entries = (
        df_global_linear_change_requested_space[
            df_global_linear_change_requested_space["dimension"].isin(["supplier", "brand"])
        ]
        .groupby(["constraint_relative_to"])
        ["dimension"]
        .nunique()
        .reset_index()
        ["dimension"]
        .max()
    )
    if max_dimension_1_entries > 1:
        raise ValueError(
            f"Found entries for both brand & supplier. Only permitted to have either one of the two dimensions"
        )

    # Verify that only one of cdt, need state, subcat or segment are being changes are being
    max_dimension_2_entries = (
        df_global_linear_change_requested_space[
            df_global_linear_change_requested_space["dimension"].isin(["need_states", "choice_map", "subcat", "segment"]
            )]
        .groupby(["constraint_relative_to"])
        ["dimension"]
        .nunique()
        .reset_index()
        ["dimension"]
        .max()
    )
    if max_dimension_2_entries > 1:
        raise ValueError(
            f"Found more than one dimension entry across need_states, choice_map, subcat and segment. "
            f"Only permitted to have either one of the four dimensions"
        )

    # Merge min/max global linear space bound based on the dimension
    for dimension in context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys():
        dimension_value = (
            context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions[dimension]
        )

        # Filter the dataframe to only include the concerned dimension
        df_global_linear_space_dimension = (
            df_global_linear_change_requested_space[df_global_linear_change_requested_space["dimension"] == dimension]
        )

        # Rename columns to be specific to dimension
        df_global_linear_space_dimension = df_global_linear_space_dimension.rename(columns={
            "name": f"{dimension_value}",
            "min_bound": f"{dimension}_min_bound",
            "max_bound": f"{dimension}_max_bound",
            "constraint_relative_to": f"{dimension}_change_type"
        }).drop(columns=["dimension"])

        # Merge master dataframe

        
        df_optimization_master_data_dept = (
            df_optimization_master_data_dept.assign(plano_id_temp = lambda dx: dx["plano_id"].astype(str).str[:4])
            .merge(df_global_linear_space_dimension.assign(plano_id_temp = lambda dx: dx["plano_id"].astype(str).str[:4]).drop(columns = ["plano_id"])
                ,on=(context.groupby_granularity.optimizer+ ["plano_id_temp", f"{dimension_value}"]),how="left")
            .drop(columns = ["plano_id_temp"])
                                           )

    return df_optimization_master_data_dept


def add_new_replacement_item_fixed_facing_constraint(
    df_optimization_master_data_dept: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function adds min max forced facings for new items which are replacements
        Context: Model behavior without this function -
        Absolute change in optimal number of facings for any SKU is constrained to one in the model which makes new 
        SKUs with 0 current facings susceptible to having lower optimal facings than the SKUs they are replacing
        which doesn't make operational sense as these new items are often re-packaged versions of the replaced items.
        Thus forcing a minimum facing for these new items equal to the replaced SKU's current facings per cluster.

    Args:
        df_optimization_master_data_dept: Optimization master input used by optimizer to create sets and other model
        parameters

    Returns:
        Optimization master data for a department with modified values for "min_forced_facings_guardrails" and 
        "max_forced_facings_guardrails" for the relevant assortments of new items
    """
    # Filter to new skus which are replacing existing skus
    df = df_optimization_master_data_dept.copy()
    is_new_sku = df["source"]=="new"
    is_replacement_sku = df["item_no_nbr"]!=df["clone_item_item_no_nbr"].fillna(df["item_no_nbr"])
    df_new_replacement_sku = df.loc[is_new_sku & is_replacement_sku]

    # Exit if no new replacement SKUs found
    if df_new_replacement_sku.empty:
        return df_optimization_master_data_dept
        
    df_new_replacement_sku = (
        df_new_replacement_sku[
            ["item_no_nbr", "plano_id", "final_cluster_labels", "plano_ft", "fixture_size", "clone_item_item_no_nbr"]
        ]
        .drop_duplicates()
    )

    # Get current facings for replaced skus per plano_id per cluster
    rename_cols = {
        "item_no_nbr": "clone_item_item_no_nbr",
        "n_current_facings_sku": "clone_item_n_current_facings_sku"
    }
    current_sku_facings_assortment = (
        df[["item_no_nbr", "plano_id", "final_cluster_labels", "plano_ft", "fixture_size", "n_current_facings_sku"]]
        .rename(columns=rename_cols)
    )

    # Merge current facings of replaced skus to corresponding replacement skus
    df_new_replacement_sku = df_new_replacement_sku.merge(
        current_sku_facings_assortment,
        how="left",
        on=["plano_id", "final_cluster_labels", "plano_ft", "fixture_size", "clone_item_item_no_nbr"]
    )

    # Set minimum forced facings of replacement skus to current facings of replaced skus
    max_change_threshold = context.optimization_config.model_formulation.max_change_threshold_for_new_replacement_items
    df_new_replacement_sku["min_forced_facings"] = (
        df_new_replacement_sku["clone_item_n_current_facings_sku"] - max_change_threshold
    ).clip(lower=0)
    df_new_replacement_sku["max_forced_facings"] = (
        df_new_replacement_sku["clone_item_n_current_facings_sku"] + max_change_threshold
    ).clip(upper=context.optimization.model_formulation.max_facings_opti)

    df_new_replacement_sku = df_new_replacement_sku[
        [
            "item_no_nbr", 
            "plano_id", 
            "final_cluster_labels", 
            "plano_ft", 
            "fixture_size", 
            "min_forced_facings", 
            "max_forced_facings",
        ]
    ]

    keep_cols = df_optimization_master_data_dept.columns

    df_optimization_master_data_dept = df_optimization_master_data_dept.merge(
        df_new_replacement_sku,
        how="left",
        on=["item_no_nbr", "plano_id", "final_cluster_labels", "plano_ft", "fixture_size"]
    )

    # Identify item assortments which need to have modified min/max forced facings
    fill_idx = (
        (df_optimization_master_data_dept["facing_type"]!="fixed_facings")
        & (df_optimization_master_data_dept["min_forced_facings"].notnull())
    )
    df_optimization_master_data_dept.loc[fill_idx, "min_forced_facings_guardrails"] = (
        df_optimization_master_data_dept.loc[fill_idx, "min_forced_facings"]
    )
    df_optimization_master_data_dept.loc[fill_idx, "max_forced_facings_guardrails"] = (
        df_optimization_master_data_dept.loc[fill_idx, "max_forced_facings"]
    )
    df_optimization_master_data_dept.loc[fill_idx, "facing_type"] = "new_replacement"

    df_optimization_master_data_dept = df_optimization_master_data_dept[keep_cols]

    return df_optimization_master_data_dept
