from typing import List, Tuple
import pandas as pd
from core.modules.optimization.store_representatives import (
    extract_fixture_size_from_string_col,
)
# from core.tasks.client_input_process.original_cluster_IOH import (
#     load_original_cluster_IOH_input,
# )
# from core.tasks.client_input_process.working_capital_constraint_process import (
#     load_working_capital_constraints,
# )
from core.schemas.optimization import (
    ItemsPODConstraints,
    ItemsPODExempt,
    BrandPODConstraints,
    ForcedFacingsMostGranular,
    DCStoreMapping,
    RemovalPenalty,
)
from core.schemas.client_input.schemas import (
    ItemInScopeWithHierarchySchema,
)
from core.utils.financial_projection_helpers import (
    check_data_integrity,
)
from core.schemas.schemas import SkuTransferenceSchema
from core.schemas.space_elasticity import (
    LatestSkuFacingsPogCategoryDept,
    LatestSkuFacingsPogCategoryDeptWithCategoryLevel,
)

from core.utils.scope_helpers import (
    get_exploded_item_POD_path_and_root,
    get_exempt_item_POD_path_and_root,
    get_exploded_brand_POD_path_and_root,
    get_item_master_path_and_root,
    get_item_forced_facings_path_and_root,
)

from core.utils.optimizer_helpers import *
from oxygen.conf.context import context
import logging

from core.utils.scope_helpers import explode_constraints_for_all_clusters

log = logging.getLogger(__name__)
from core.utils.optimizer_helpers import (
    load_sku_productivity_data_based_on_metric,
    load_need_state_productivity_based_on_metric,
    get_updated_height_depth_orientation,
)

def load_all_relevant_sets_and_contraint_data() -> (
    Tuple[
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
        pd.DataFrame,
    ]
):
    """
    This function loads all the inputs necessary for defining certain sets and constraints; down the road, most of
    these will come from an API call between the app and the Retail Catalyst UI.

    Returns:
    A tuple of 9 dataframes:
    - df_supplier_and_brand_requested_space: comes from an API call, provides a % of linear space in a POG Category
    to be reserved by optimizer for a specific supplier / own brand
    - df_global_linear_change_requested_space: comes from an API call, provides a % of linear space
    occupied globally across all versions
    - df_local_items_requested_space: comes from an API call, provides a % of linear space in a POG Category to be
    reserved by optimizer for local items only
    - df_items_forced_facings_guardrails: comes from an API call, provides a list of items that we want to hold constant (i.e.
    that will keep their current number of facings)
    - df_own_brand_space_constraints: comes from an API call, provides a max % drop of own brand space within a
    (POG Category, Department); e.g. if own brands have 100ft of total linear space, the minimum they can end up with
    post-optimizer is 90ft if that max percent drop is 10%
    - df_max_facings_per_sku: Constraint dataframe containing the max number of facings a SKU can have for a given dept
    (and applies to all SKUs in that department)
    - df_pivot_and_linked_sku_pair_constraints: Constraint dataframe containing pairs of pivot and linked SKUs,
    where if the pivot SKU gets assigned >= 1 facing by optimizer then the linked SKU also needs to be assigned
    >= 1 facing by optimizer
    - df_need_state_min_max_facings_constraints: Contains min and max facings for a need state, which can override
    our initial need state growth constraint based on e.g. need state saturation curves
    - df_item_POD_active: Dataset containing items that are active in the POG Category
    - df_item_POD_exempt: Dataset containing items that are exempt from the POG Category
    - df_brand_POD_active: Dataset containing brands that are active in the POG Category
    - df_plano_ft_forced_facings_final: Dataset containing the final forced facings for each item in the POG Category
    - df_original_cluster_IOH_constraints: Constraint dataframe containing the original cluster IOH constraints
    - df_full_ioh_curves_wide: Dataset containing the full IOH curves data
    - df_latest_space_data: Dataset containing the latest space data
    - df_sales: Dataset containing sales from the previous year
    - df_dc_store_mapping: Dataset containing store to DC mapping
    """
    log.info("Loading all relevant data for sets and constraints definition...")
    # Supplier Brand Space Requests
    supplier_and_brand_requested_schema = (
        select_SuppliersAndBrandsSpaceConstraints_schema(
            context.groupby_granularity.optimizer
        )
    )
    if (
        context.optimization_config.model_formulation.enable_supplier_brand_constraints
    ) & (
        context.optimization_config.model_formulation.supplier_brand_constraints_path
        is not None
    ):
        path_load_supplier_and_brand_requested_space = complete_file_path(
            "",
            context.optimization_config.model_formulation.supplier_brand_constraints_path,
            at_datastores_root=True,
        )
        df_supplier_and_brand_requested_space = (
            supplier_and_brand_requested_schema.load(
                file_path=path_load_supplier_and_brand_requested_space,
                root=True,
            )
        )
    else:
        log.info(
            "Supplier brand constraints are disabled or the input constraints data is not specified. "
            "Using empty DataFrame."
        )
        df_supplier_and_brand_requested_space = pd.DataFrame(
            columns=supplier_and_brand_requested_schema.get_columns()
        )

    # Linear space change Requests
    linear_space_change_requested_schema = (
        select_LinearSpaceChangeGlobalConstraints_schema(
            context.groupby_granularity.optimizer
        )
    )

    "item_with_forced_facings" in context.optimization.data_prep.keys()
    if (
        context.optimization_config.model_formulation.enable_global_linear_space_change_constraints
    ):
        if "global_linear_space_bounds" in context.optimization.data_prep.keys():
            df_global_linear_change_requested_space = (
                pd.DataFrame.from_dict(context.optimization.data_prep.global_linear_space_bounds)
            )
            df_global_linear_change_requested_space.columns = map(str.lower, df_global_linear_change_requested_space.columns)
        
        elif (
            context.optimization_config.model_formulation.global_linear_space_change_path
            is not None
        ):
            path_load_global_linear_change_requested_space = complete_file_path(
                "",
                context.optimization_config.model_formulation.global_linear_space_change_path,
                at_datastores_root=True,
            )
            df_global_linear_change_requested_space = (
                linear_space_change_requested_schema.load(
                    file_path=path_load_global_linear_change_requested_space,
                    root=True,
                )
            )
        else:
            log.info(
                "Global linear space change constraints is enable, but no input source indicated"
                "Using empty DataFrame."
            )
            df_global_linear_change_requested_space = pd.DataFrame(
                columns=linear_space_change_requested_schema.get_columns()
            )


        df_global_linear_change_requested_space["plano_id"] = (
            df_global_linear_change_requested_space["plano_id"].astype(int).astype(str)
        )
    else:
        log.info(
            "Global linear space change constraints is disabled or the input constraints data is not specified. "
            "Using empty DataFrame."
        )
        df_global_linear_change_requested_space = pd.DataFrame(
            columns=linear_space_change_requested_schema.get_columns()
        )

    # Localized Space Requests
    path_load_local_items_requested_space = complete_file_path(
        context.data_stores.etl.root_path,
        context.data_stores.etl.etl_opti_constraint_data_local_items.file_name,
    )
    local_items_requested_space_schema = select_LocalItemsSpaceConstraints_schema(
        context.groupby_granularity.optimizer
    )
    df_local_items_requested_space = local_items_requested_space_schema.load(
        file_path=path_load_local_items_requested_space,
        root=True,
    )

    # item forced facings guardrails
    (
        path_merged_forced_facings,
        root_merged_forced_facings,
    ) = get_item_forced_facings_path_and_root()
    df_items_forced_facings_guardrails = ForcedFacingsMostGranular.load(
        file_path=path_merged_forced_facings,
        root=root_merged_forced_facings,
    )
    if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
        df_items_forced_facings_guardrails.drop(
            columns=["category_level_dept_nbr", "category_level_dept_name"], inplace=True
        )
        df_items_forced_facings_guardrails = (
            df_items_forced_facings_guardrails.drop_duplicates()
        )

    # Max % Drop of Own Brand Space
    own_brand_space_constraints_schema = select_OwnBrandSpaceConstraints_schema(
        context.groupby_granularity.optimizer
    )
    if (context.optimization_config.model_formulation.enable_own_brand_constraints) & (
        context.optimization_config.model_formulation.own_brand_constraints_path
        is not None
    ):
        path_load_own_brand_space_constraints = complete_file_path(
            "",
            context.optimization_config.model_formulation.own_brand_constraints_path,
            at_datastores_root=True,
        )
        df_own_brand_space_constraints = own_brand_space_constraints_schema.load(
            file_path=path_load_own_brand_space_constraints,
            root=True,
        )
    else:
        log.info(
            "Own brand constraints are disabled or the input constraints data is not specified. "
            "Using empty DataFrame."
        )
        df_own_brand_space_constraints = pd.DataFrame(
            columns=own_brand_space_constraints_schema.get_columns()
        )

    # Max no. of facings in dept
    path_load_max_facings_per_sku_constraint = complete_file_path(
        context.data_stores.etl.root_path,
        context.data_stores.etl.etl_opti_constraint_data_max_facings_per_sku.file_name,
    )
    max_facings_per_sku_schema = select_MaxFacingsPerSkuInDeptConstraint_schema(
        context.groupby_granularity.optimizer
    )
    df_max_facings_per_sku = max_facings_per_sku_schema.load(
        file_path=path_load_max_facings_per_sku_constraint,
        root=True,
    )

    # Pivot and Linked SKU pairs
    pivot_and_linked_sku_pair_constraints_schema = (
        select_PivotAndLinkedSkuPairsConstraint_schema(
            context.groupby_granularity.optimizer
        )
    )
    if (
        context.optimization_config.model_formulation.enable_pivot_linked_item_constraints
    ) & (
        context.optimization_config.model_formulation.pivot_linked_item_constraints_path
        is not None
    ):
        path_load_pivot_and_linked_sku_pair_constraints = complete_file_path(
            context.data_stores.client_input_process.root_path,
            context.optimization_config.model_formulation.pivot_linked_item_constraints_path,
            at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
            run_id_folder=context.run_id.client_input_process_run_id,
        )
        df_pivot_and_linked_sku_pair_constraints = (
            pivot_and_linked_sku_pair_constraints_schema.load(
                file_path=path_load_pivot_and_linked_sku_pair_constraints,
                root=root_with_run_id(
                    context.run_id.clustering_run_id,
                    context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
                ),
            )
        )
    else:
        log.info(
            "Pivot linked item constraints are disabled or the input constraints data is not specified. "
            "Using empty DataFrame."
        )
        df_pivot_and_linked_sku_pair_constraints = pd.DataFrame(
            columns=pivot_and_linked_sku_pair_constraints_schema.get_columns()
        )

    # Need state min/max facings constraints
    path_load_need_state_min_max_facings_constraints = complete_file_path(
        context.data_stores.etl.root_path,
        context.data_stores.etl.etl_opti_constraint_data_need_state_min_max_facings_constraints.file_name,
    )
    need_state_min_max_facings_constraints_schema = (
        select_NeedStateMinMaxFacingsConstraint_schema(
            context.groupby_granularity.optimizer
        )
    )
    df_need_state_min_max_facings_constraints = (
        need_state_min_max_facings_constraints_schema.load(
            file_path=path_load_need_state_min_max_facings_constraints,
            root=True,
        )
    )

    (
        path_exploded_item_POD,
        root_exploded_item_POD,
    ) = get_exploded_item_POD_path_and_root()
    df_item_POD_active = ItemsPODConstraints.load(
        file_path=path_exploded_item_POD,
        root=root_exploded_item_POD,
    )
    if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
        df_item_POD_active.drop(columns=["category_level_dept_nbr", "category_level_dept_name"], inplace=True)
        df_item_POD_active = df_item_POD_active.drop_duplicates()

    (path_exempt_item_POD, root_exempt_item_POD) = get_exempt_item_POD_path_and_root()
    df_item_POD_exempt = ItemsPODExempt.load(
        file_path=path_exempt_item_POD,
        root=root_exempt_item_POD,
    )
    if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
        df_item_POD_exempt.drop(columns=["category_level_dept_nbr", "category_level_dept_name"], inplace=True)
        df_item_POD_exempt = df_item_POD_exempt.drop_duplicates()

    (
        path_exploded_brand_POD,
        root_exploded_brand_POD,
    ) = get_exploded_brand_POD_path_and_root()
    df_brand_POD_active = BrandPODConstraints.load(
        file_path=path_exploded_brand_POD,
        root=root_exploded_brand_POD,
    )

    if "category_level_dept_nbr" not in context.groupby_granularity.optimizer:
        df_brand_POD_active.drop(
            columns=["category_level_dept_nbr", "category_level_dept_name"], inplace=True
        )
        df_brand_POD_active = df_brand_POD_active.drop_duplicates()

    # TODO
    # df_original_cluster_IOH_constraints = load_original_cluster_IOH_input()
    df_original_cluster_IOH_constraints = pd.DataFrame()


    # TODO
    # df_full_ioh_curves_wide = load_working_capital_constraints()
    df_full_ioh_curves_wide = pd.DataFrame()

    # Load latest space data
    path_space_data = complete_file_path(
            context.data_stores.store_clustering.root_path,
            context.data_stores.store_clustering.final.latest_space_data_path_df,
            at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            run_id_folder=context.run_id.clustering_run_id,
    )
    df_latest_space_data = reader.read(
        file_path=path_space_data,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
    )
    
    
    # Load latest sale
    path_sales_data = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.historical_sales,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )
    df_sales_data = reader.read(
        file_path=path_sales_data,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
    )


    return (
        df_supplier_and_brand_requested_space,
        df_global_linear_change_requested_space,
        df_local_items_requested_space,
        df_items_forced_facings_guardrails,  # active
        df_own_brand_space_constraints,
        df_max_facings_per_sku,
        df_pivot_and_linked_sku_pair_constraints,
        df_need_state_min_max_facings_constraints,
        df_item_POD_active,
        df_item_POD_exempt,
        df_brand_POD_active,
        df_original_cluster_IOH_constraints,
        df_full_ioh_curves_wide,
        df_latest_space_data,
        df_sales_data,
        # df_dc_store_mapping
    )


def process_constraint_files(
    df_optimization_master_data_dept: pd.DataFrame,
    df_supplier_and_brand_requested_space: pd.DataFrame,
    df_global_linear_change_requested_space: pd.DataFrame,
    df_local_items_requested_space: pd.DataFrame,
    df_items_forced_facings_guardrails: pd.DataFrame,
    df_own_brand_space_constraints: pd.DataFrame,
    df_max_facings_per_sku: pd.DataFrame,
    df_pivot_and_linked_sku_pair_constraints: pd.DataFrame,
    df_need_state_min_max_facings_constraints: pd.DataFrame,
    df_original_cluster_IOH_constraints: pd.DataFrame,
    df_full_ioh_curves_wide: pd.DataFrame,
    df_item_POD_active: pd.DataFrame,
    df_item_POD_exempt: pd.DataFrame,
    df_brand_POD_active: pd.DataFrame,
    category_level_dept_nbr: int,
    plano_cat_desc: str,
    department: int,
) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    # TODO i think this should move to client_input_process entirely
    """
    This function will process the constraint files that are inputs to the main optimizer function for a given dept_id,
    by:
    - Fltering to the plano_cat_desc and dept_id of interest
    - Exploding a dataframe to all clusters available in the data when relevant
    Args:
        df_optimization_master_data_dept: Optimization master dataset for that specific POG Category over which we
        are looping and to which we want to add the manual constraints data
        df_supplier_and_brand_requested_space: comes from an API call, provides a % of linear space in a POG
        Category to be reserved by optimizer for a specific supplier / brand
        df_global_linear_change_requested_space: comes from an API call, provides a % of linear space occupied by a
         dimension on a global level
        df_local_items_requested_space: comes from an API call, provides a % of linear space in a POG Category to be
        reserved by optimizer for local items only
        df_own_brand_space_constraints: comes from an API call, provides a max % drop of own brand space within a
        (POG Category, Department); e.g. if own brands have 100ft of total linear space, the minimum they can end up
        with post-optimizer is 90ft if that max percent drop is 10%
        df_max_facings_per_sku: Constraint dataframe containing the max number of facings a SKU can have for a given
        dept (and applies to all SKUs in that department)
        df_pivot_and_linked_sku_pair_constraints: Constraint dataframe containing pairs of pivot and linked SKUs,
        where if the pivot SKU gets assigned >= 1 facing by optimizer then the linked SKU also needs to be assigned
        >= 1 facing by optimizer
        df_need_state_min_max_facings_constraints: Contains min and max facings for a need state, which can override
        our initial need state growth constraint based on e.g. need state saturation curves
        df_original_cluster_IOH_constraints: Constraint dataframe containing the original cluster IOH constraints
        df_full_ioh_curves_wide: Dataset containing the full IOH curves data
        category_level_dept_nbr: CategoryLevel selected by CM
        plano_cat_desc: POG category for which we want to solve all optimization problems
        department: Department within the given `plano_cat_desc` for which we want to solve all optimization problems

    Returns:
    Processed constraint files for optimizer of a given `plano_cat_desc, dept_id`
    """
    log.info("Processing all constraint dataframes...")
    df_clusters_in_dept = df_optimization_master_data_dept[
        context.groupby_granularity.optimizer + ["final_cluster_labels"]
    ].drop_duplicates()

    # Load plano_cat_id to dept_id mapping to add to some constraint data frames
    df_plano_dept = df_optimization_master_data_dept[
        ["dept_id", "plano_cat_id", "plano_cat_desc"]
    ].drop_duplicates()

    # Load plano_cat_id to dept_id mapping to add to some constraint data frames
    df_plano_id = df_optimization_master_data_dept[
        ["plano_id", "dept_id", "plano_cat_id", "plano_cat_desc"]
    ].drop_duplicates()
    
    # Supplier or Brand Space Requests
    # Add plano cat ID and plano description columns
    df_supplier_and_brand_requested_space = df_supplier_and_brand_requested_space.merge(
        df_plano_dept,
        on=["dept_id"],
        how="inner",
    )
    df_supplier_and_brand_requested_space = filter_based_on_granularity(
        df=df_supplier_and_brand_requested_space,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    # Replace lower/upper bound NA values with default values specified in configuration
    lower_bound_col = "lower_bound_constraint_supplier_or_brand"
    upper_bound_col = "upper_bound_constraint_supplier_or_brand"
    constraint_type_col = "constraint_type_supplier_or_brand"
    constraint_types_bounds = (
        context.optimization.manual_constraints.authorized_supplier_brand_constraint_types
    )
    for constraint_type, (lower_bound, upper_bound) in constraint_types_bounds.items():
        # Specifying na to be False instead of NaN replaces NaN values with False
        constraint_type_filter = df_supplier_and_brand_requested_space[
            constraint_type_col
        ].str.contains(constraint_type, na=False)
        lower_bound_nan_filter = pd.isna(
            df_supplier_and_brand_requested_space[lower_bound_col]
        )
        upper_bound_nan_filter = pd.isna(
            df_supplier_and_brand_requested_space[upper_bound_col]
        )
        df_supplier_and_brand_requested_space.loc[
            lower_bound_nan_filter & constraint_type_filter, lower_bound_col
        ] = lower_bound
        df_supplier_and_brand_requested_space.loc[
            upper_bound_nan_filter & constraint_type_filter, upper_bound_col
        ] = upper_bound

    # Explode constraints to apply to all clusters
    df_supplier_and_brand_requested_space = explode_constraints_for_all_clusters(
        df_constraint=df_supplier_and_brand_requested_space,
        df_clusters_in_dept=df_clusters_in_dept,
    )

    # Global brand space constraint
    df_global_linear_change_requested_space["plano_id"] = (
        df_global_linear_change_requested_space["plano_id"].astype(int).astype(str)
    )

    df_global_linear_change_requested_space = df_global_linear_change_requested_space.merge(
        df_plano_id.assign(plano_id = lambda dx: dx["plano_id"].str[:4]),
        on=["plano_id"],
        how="inner",
    ).drop_duplicates(subset=["dimension", "name"])

    df_global_linear_change_requested_space = filter_based_on_granularity(
        df=df_global_linear_change_requested_space,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    df_global_linear_change_requested_space = explode_constraints_for_all_clusters(
        df_constraint=df_global_linear_change_requested_space,
        df_clusters_in_dept=df_clusters_in_dept,
    )

    # Localized Space Requests
    df_local_items_requested_space = filter_based_on_granularity(
        df=df_local_items_requested_space,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    df_local_items_requested_space = explode_constraints_for_all_clusters(
        df_constraint=df_local_items_requested_space,
        df_clusters_in_dept=df_clusters_in_dept,
    )

    # Items in pipeline with forced facings guardrails
    df_items_forced_facings_guardrails = filter_based_on_granularity(
        df=df_items_forced_facings_guardrails,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    # Max % Drop of Own Brand Space
    # Add plano cat ID and plano description columns
    df_own_brand_space_constraints = df_own_brand_space_constraints.merge(
        df_plano_dept,
        on=["dept_id"],
        how="inner",
    )
    df_own_brand_space_constraints = filter_based_on_granularity(
        df=df_own_brand_space_constraints,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    df_own_brand_space_constraints = explode_constraints_for_all_clusters(
        df_constraint=df_own_brand_space_constraints,
        df_clusters_in_dept=df_clusters_in_dept,
    )

    # Max no. of facings in dept
    df_max_facings_per_sku = filter_based_on_granularity(
        df=df_max_facings_per_sku,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    # Pivot and Linked SKU pairs
    # Add plano cat ID and plano description columns
    df_pivot_and_linked_sku_pair_constraints = (
        df_pivot_and_linked_sku_pair_constraints.merge(
            df_plano_dept,
            on=["dept_id"],
            how="inner",
        )
    )
    df_pivot_and_linked_sku_pair_constraints = filter_based_on_granularity(
        df=df_pivot_and_linked_sku_pair_constraints,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    # Need state min/max facings constraints
    df_need_state_min_max_facings_constraints = filter_based_on_granularity(
        df=df_need_state_min_max_facings_constraints,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    df_need_state_min_max_facings_constraints = explode_constraints_for_all_clusters(
        df_constraint=df_need_state_min_max_facings_constraints,
        df_clusters_in_dept=df_clusters_in_dept,
    )

    df_need_state_min_max_facings_constraints = filter_based_on_granularity(
        df=df_need_state_min_max_facings_constraints,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    df_original_cluster_IOH_constraints = filter_based_on_granularity(
        df=df_original_cluster_IOH_constraints,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    df_full_ioh_curves_wide = filter_based_on_granularity(
        df=df_full_ioh_curves_wide,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    df_item_POD_active = filter_based_on_granularity(
        df=df_item_POD_active,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    df_item_POD_exempt = filter_based_on_granularity(
        df=df_item_POD_exempt,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    df_brand_POD_active = filter_based_on_granularity(
        df=df_brand_POD_active,
        granularity=context.groupby_granularity.optimizer,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )
    return (
        df_supplier_and_brand_requested_space,
        df_global_linear_change_requested_space,
        df_local_items_requested_space,
        df_items_forced_facings_guardrails,
        df_own_brand_space_constraints,
        df_max_facings_per_sku,
        df_pivot_and_linked_sku_pair_constraints,
        df_need_state_min_max_facings_constraints,
        df_original_cluster_IOH_constraints,
        df_full_ioh_curves_wide,
        df_item_POD_active,
        df_item_POD_exempt,
        df_brand_POD_active,
    )


def load_all_relevant_sku_and_pog_category_data(
    category_level_dept_nbr: int,
    plano_cat_desc: str,
    dependent_var: str,
    department: int,
) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
]:
    """
    This function loads all the inputs necessary for defining most parameters for the optimization model (e.g. total
    linear space available for the POG Category, etc.)
    Args:
        category_level_dept_nbr: CategoryLevel selected by CM
        plano_cat_desc: POG Category on which we want to run optimization
        dependent_var: Dependent variable on which we're optimizing (can either be sales or dnp)
        department: Department ID on which we want to run optimization

    Returns:
    A tuple of 6 dataframes:
    - df_latest_sku_level_facings: DataFrame containing the the current facings at the store-POG-SKU level, coming
    from the latest space data available
    - df_space_productivity_per_facing: dataset containing the final space elasticity output (including the item-level
    space productivity), already filtered to a given `plano_cat_desc`
    - df_sku_transference: dataset containing SKU transference for objective function penalty, already filtered to a
    given `plano_cat_desc`
    - df_space_productivity_need_state: dataset containing each need state's saturation facings at the cluster level
    - df_existing_linear_space: dataset with linear space of existing items without a current facing
    """
    log.info("Loading all relevant data for SKU or POG Category level aggregations...")
    latest_space_data_path = complete_file_path(
        context.data_stores.store_clustering.root_path,
        context.data_stores.store_clustering.final.latest_space_data_path_df,
        at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        run_id_folder=context.run_id.clustering_run_id,
    )

    if "category_level_dept_nbr" in context.groupby_granularity.optimizer:
        df_latest_sku_level_facings = LatestSkuFacingsPogCategoryDeptWithCategoryLevel.load(
            file_path=latest_space_data_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            )
        )
        df_latest_sku_level_facings = df_latest_sku_level_facings[
            (df_latest_sku_level_facings["category_level_dept_nbr"] == category_level_dept_nbr)
            & (df_latest_sku_level_facings["plano_cat_desc"] == plano_cat_desc)
            & (df_latest_sku_level_facings["dept_id"] == department)
        ]
    else:
        df_latest_sku_level_facings = LatestSkuFacingsPogCategoryDept.load(
            file_path=latest_space_data_path,
            root=root_with_run_id(
                context.run_id.clustering_run_id,
                context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
            ),
        )
        df_latest_sku_level_facings = df_latest_sku_level_facings[
            (df_latest_sku_level_facings["plano_cat_desc"] == plano_cat_desc)
            & (df_latest_sku_level_facings["dept_id"] == department)
        ]

    # Space elasticity output for space productivity per facing
    df_space_productivity_per_facing = load_sku_productivity_data_based_on_metric(
        metric_name=dependent_var,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    transference_data_path = complete_file_path(
        context.data_stores.store_clustering.root_path,
        context.data_stores.store_clustering.final.transference_df,
        at_datastores_root=context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        run_id_folder=context.run_id.clustering_run_id,
    )

    # SKU transference
    df_sku_transference = SkuTransferenceSchema.load(
        file_path=transference_data_path,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
        # data_format="sql",
        # sql=f"""
        #     SELECT DISTINCT
        #     removed_item_no as item_no_nbr,
        #     (1-exclusivity_percentage/100) as n_transference_sku
        #     FROM {context.data_stores.etl.etl_sku_transference.sql_table_name}
        #     where category_level_dept_nbr in {category_level_filter};
        # """,
    )
    if "category_level_dept_nbr" in context.groupby_granularity.optimizer:
        df_sku_transference = (
            df_sku_transference[(df_sku_transference["category_level_dept_nbr"] == category_level_dept_nbr)]
            .drop(columns=["category_level_dept_nbr"])
            .drop_duplicates(keep="first")
        )
    else:
        df_sku_transference = (
            df_sku_transference.merge(
                df_latest_sku_level_facings[["item_no_nbr"]].drop_duplicates(),
                on=["item_no_nbr"],
                how="inner",
            )
            # .drop(columns=["category_level_dept_nbr"])
            .drop_duplicates(keep="first")
        )

    # Need state saturation
    df_space_productivity_need_state = load_need_state_productivity_based_on_metric(
        metric_name=dependent_var,
        plano_cat_desc=plano_cat_desc,
        department=department,
    )

    # df_new_item_linear_space
    dict_col_space_new_item = {
        "n_current_linear_space_per_facing_sku": "new_item_n_current_linear_space_per_facing_sku",
        "prod_unit_width_ft": "new_item_prod_unit_width_ft",
        "prod_unit_height_ft": "new_item_prod_unit_height_ft",
        "prod_unit_depth_ft": "new_item_prod_unit_depth_ft",
    }
    cols_space = list(dict_col_space_new_item.keys())
    (path_item_master, root_item_master) = get_item_master_path_and_root()
    df_new_item_linear_space = ItemInScopeWithHierarchySchema.load(
        file_path=path_item_master,
        root=root_item_master,
    )

    df_new_item_linear_space = df_new_item_linear_space[
        (df_new_item_linear_space["source"] == "new")
        # & (df_new_item_linear_space[cols_space].notna().any(axis=1))
    ]
    df_new_item_linear_space = (
        df_new_item_linear_space[["item_no_nbr"] + cols_space]
        .drop_duplicates()
        .rename(columns=dict_col_space_new_item)
    )

    # df_new_item_linear_space
    dict_col_space_existing = {
        "n_current_linear_space_per_facing_sku": "existing_n_current_linear_space_per_facing_sku",
        "prod_unit_width_ft": "existing_prod_unit_width_ft",
        "prod_unit_height_ft": "existing_prod_unit_height_ft",
        "prod_unit_depth_ft": "existing_prod_unit_depth_ft",
    }
    df_existing_linear_space = ItemInScopeWithHierarchySchema.load(
        file_path=path_item_master,
        root=root_item_master,
    )
    df_existing_linear_space = (
        df_existing_linear_space[["item_no_nbr"] + cols_space]
        .drop_duplicates()
        .rename(columns=dict_col_space_existing)
    )


    path_dc_mapping_data = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.dc_store_mapping,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )
    df_dc_store_mapping = DCStoreMapping.load(
        file_path = path_dc_mapping_data,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
    )

    path_removal_penalty_data = complete_file_path(
        context.data_stores.client_input_process.root_path,
        context.data_stores.client_input_process.removal_penalty,
        at_datastores_root=context.data_stores.client_input_process.save_to_datastores_root,
        run_id_folder=context.run_id.client_input_process_run_id,
    )
    df_removal_penalty = RemovalPenalty.load(
        file_path = path_removal_penalty_data,
        root=root_with_run_id(
            context.run_id.clustering_run_id,
            context.data_stores.store_clustering.save_to_datastores_root.InternalClusteringAutomatedSelection,
        ),
    )

    return (
        df_latest_sku_level_facings,
        df_space_productivity_per_facing,
        df_sku_transference,
        df_space_productivity_need_state,
        df_new_item_linear_space,
        df_existing_linear_space,
        df_dc_store_mapping,
        df_removal_penalty
    )


def get_latest_facings_per_rep_store_item_no(
    df_cluster_item_no: pd.DataFrame,
    df_latest_sku_level_facings: pd.DataFrame,
    df_prioritized_store_representatives_filt: pd.DataFrame,
):
    """
    This function fetch the latest facings per store-POG-SKU level for the store representative in optimizer's scope
    Args:
        df_cluster_item_no: DataFrame containing the cluster-item in optimizer's scope
        df_latest_sku_level_facings: DataFrame containing the current facings at the store-POG-SKU level, coming
        from the latest space data available
        df_prioritized_store_representatives_filt: DataFrame containing information about the store representative for
        each grouping of (plano_cat_id, plano_cat_desc, plano_ft, final_cluster_labels)
    Returns:
    A DataFrame with the latest facings per store-POG-SKU level for the store representative in optimizer's scope
    """
    # Introduce the dimensions of plano_ft, fixture_size, and filters the latest sku facings data to only have the
    # store representative for a given representative store
    df_prioritized_store_representatives_item_no = (
        df_prioritized_store_representatives_filt.merge(
            df_cluster_item_no,
            on=(context.groupby_granularity.optimizer + ["final_cluster_labels", "plano_id"]),
            how="left",
        )
    )

    df_latest_sku_store_facings = df_latest_sku_level_facings[
        context.groupby_granularity.optimizer
        + [
            "store_nbr",
            "item_no_nbr",
            "n_current_facings_sku",
            "fixture_desc",
            "n_current_linear_space_used_sku",
            "orientation",
        ]
    ].drop_duplicates()

    df_rep_store_item_no_w_latest_facings = df_prioritized_store_representatives_item_no.merge(
        df_latest_sku_store_facings,
        on=(context.groupby_granularity.optimizer + ["store_nbr", "item_no_nbr", "fixture_desc"]),
        how="left",
    )

    df_rep_store_item_no_w_latest_facings[
        ["n_current_linear_space_used_sku", "n_current_facings_sku"]
    ] = df_rep_store_item_no_w_latest_facings[
        ["n_current_linear_space_used_sku", "n_current_facings_sku"]
    ].fillna(
        0
    )
    return df_rep_store_item_no_w_latest_facings


def get_linear_space_for_existing_item(
    df_rep_store_item_no_w_latest_facings: pd.DataFrame,
    agg_level_clustering: List[str],
    df_final_clusters: pd.DataFrame,
    df_latest_sku_level_facings: pd.DataFrame,
    df_existing_linear_space: pd.DataFrame
):
    """
    Calculates the mode of linear space used by a SKU across all stores within a cluster (based on the current
    median number of facings) and defines the median linear space per facing for that SKU, which is used later
    in optimization to define space constraints at the Cluster-SKU level.

    This function computes three levels of modes: cluster-planogram mode, cluster mode, and chain-wide mode,
    and applies a sequential fallback logic to select the appropriate value for `n_current_linear_space_per_facing_sku`.
    If `n_current_linear_space_per_facing_sku` is NaN, an assertion ensures that `source` is "new".

    Args:
        df_rep_store_item_no_w_latest_facings (pd.DataFrame): DataFrame with the latest facings per store-POG-SKU
            level for the store representative within the optimizer's scope.
        agg_level_clustering (List[str]): List defining the aggregation level at which clustering is performed.
        df_final_clusters (pd.DataFrame): DataFrame containing the cluster labels used for space elasticity
            fitting and optimization.
        df_latest_sku_level_facings (pd.DataFrame): DataFrame containing the current facings at the store-POG-SKU
            level, sourced from the latest available space data.

    Returns:
        pd.DataFrame: DataFrame with the calculated `n_current_linear_space_per_facing_sku`, which represents
        the linear space per facing of a SKU at different levels of aggregation. This is used later in the
        optimization process to set space constraints at the Cluster-SKU level.

    Steps:
        1. Calculates `n_current_linear_space_per_facing_sku` at the most granular level by dividing
           `n_current_linear_space_used_sku` by `n_current_facings_sku`.
        2. Computes three levels of modes:
            - Cluster-planogram level mode (`n_linear_space_per_facing_sku_cluster_plano_mode`)
            - Cluster level mode (`n_linear_space_per_facing_sku_cluster_mode`)
            - Chain-wide mode (`n_linear_space_per_facing_sku_mode`)
        3. Merges these modes with `df_rep_store_item_no_w_latest_facings` and applies a sequential fallback
           logic to create `n_current_linear_space_per_facing_sku` using the available mode columns.
        4. Ensures via assertion that if `n_current_linear_space_per_facing_sku` is NaN, `source` is "new".
    """
    # STEP 1: get the n_current_linear_space_per_facing_sku at the most granular level
    df_final_clusters = df_final_clusters[
        agg_level_clustering + ["final_cluster_labels"]
    ]

    df_latest_sku_level_facings = extract_fixture_size_from_string_col(
        df=df_latest_sku_level_facings,
    )
    df_latest_sku_level_facings_x_clusters = df_latest_sku_level_facings.merge(
        df_final_clusters,
        on=agg_level_clustering,
        how="inner",
    )

    df_latest_sku_level_facings_x_clusters["n_current_linear_space_per_facing_sku"] = (
        df_latest_sku_level_facings_x_clusters["n_current_linear_space_used_sku"]
        / df_latest_sku_level_facings_x_clusters["n_current_facings_sku"]
    )

    # Step 2: Group by the desired granularity and get the mode for `n_current_linear_space_per_facing_sku`
    # we have 3 modes to consider: cluster_plano_mode, cluster_mode, chainwide_mode
    df_latest_sku_linear_space_per_cluster_plano_mode = (
        df_latest_sku_level_facings_x_clusters.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_sku_level
        )
        .agg(
            n_linear_space_per_facing_sku_cluster_plano_mode=(
                "n_current_linear_space_per_facing_sku",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_width_ft_cluster_plano_mode=(
                "prod_unit_width_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_height_ft_cluster_plano_mode=(
                "prod_unit_height_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_depth_ft_cluster_plano_mode=(
                "prod_unit_depth_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            orientation_cluster_plano_mode=(
                "orientation",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
        )
        .reset_index()
    )

    df_latest_sku_linear_space_per_cluster_mode = (
        df_latest_sku_level_facings_x_clusters.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_sku_cluster_level
        )
        .agg(
            n_linear_space_per_facing_sku_cluster_mode=(
                "n_current_linear_space_per_facing_sku",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_width_ft_cluster_mode=(
                "prod_unit_width_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_height_ft_cluster_mode=(
                "prod_unit_height_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_depth_ft_cluster_mode=(
                "prod_unit_depth_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            orientation_cluster_mode=(
                "orientation",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
        )
        .reset_index()
    )

    df_latest_sku_linear_space_chainwide_mode = (
        df_latest_sku_level_facings_x_clusters.groupby(
            context.groupby_granularity.optimizer + ["item_no_nbr"]
        )
        .agg(
            n_linear_space_per_facing_sku_mode=(
                "n_current_linear_space_per_facing_sku",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_width_ft_mode=(
                "prod_unit_width_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_height_ft_mode=(
                "prod_unit_height_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            prod_unit_depth_ft_mode=(
                "prod_unit_depth_ft",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
            orientation_mode=(
                "orientation",
                lambda x: x.mode().iloc[0] if not x.mode().empty else None,
            ),
        )
        .reset_index()
    )

    df_latest_facings_linear_space_by_sku_all_plano_ft = (
        df_rep_store_item_no_w_latest_facings.merge(
            df_latest_sku_linear_space_per_cluster_plano_mode,
            on=context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_sku_level,
            how="left",
        )
        .merge(
            df_latest_sku_linear_space_per_cluster_mode,
            on=context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_sku_cluster_level,
            how="left",
        )
        .merge(
            df_latest_sku_linear_space_chainwide_mode,
            on=context.groupby_granularity.optimizer + ["item_no_nbr"],
            how="left",
        )
    )

    # Step 3: Apply sequential fallback logic to create `n_current_linear_space_per_facing_sku`
    for space_dim in [
        "n_linear_space_per_facing_sku",
        "prod_unit_width_ft",
        "prod_unit_height_ft",
        "prod_unit_depth_ft",
        "orientation",
    ]:
        df_latest_facings_linear_space_by_sku_all_plano_ft[space_dim] = (
            df_latest_facings_linear_space_by_sku_all_plano_ft[
                space_dim + "_cluster_plano_mode"
            ]
            .combine_first(
                df_latest_facings_linear_space_by_sku_all_plano_ft[
                    space_dim + "_cluster_mode"
                ]
            )
            .combine_first(
                df_latest_facings_linear_space_by_sku_all_plano_ft[space_dim + "_mode"]
            )
        )

        df_latest_facings_linear_space_by_sku_all_plano_ft.drop(
            [
                space_dim + "_cluster_plano_mode",
                space_dim + "_cluster_mode",
                space_dim + "_mode",
            ],
            axis=1,
            inplace=True,
        )

        df_latest_facings_linear_space_by_sku_all_plano_ft.rename(
            columns={
                "n_linear_space_per_facing_sku": "n_current_linear_space_per_facing_sku"
            },
            inplace=True,
        )

    # Step 4: For existing items without facings, take the dimension from new items table
    space_dim_cols = ["n_current_linear_space_per_facing_sku",
        "prod_unit_width_ft",
        "prod_unit_height_ft",
        "prod_unit_depth_ft"
    ]
    space_dim_cols_existing = (
       ["existing_" + col for col in space_dim_cols] 
    )
    df_item_linear_space = df_existing_linear_space[["item_no_nbr"] + space_dim_cols_existing].drop_duplicates()


    # Merge to master dataframe
    df_latest_facings_linear_space_by_sku_all_plano_ft = df_latest_facings_linear_space_by_sku_all_plano_ft.merge(
        df_item_linear_space,
        on="item_no_nbr",
        how="left"
    )

    for space_dim_col in space_dim_cols:
        # Fill in the missing rows
        df_latest_facings_linear_space_by_sku_all_plano_ft[space_dim_col] = (
            df_latest_facings_linear_space_by_sku_all_plano_ft[space_dim_col].fillna(
                df_latest_facings_linear_space_by_sku_all_plano_ft[f"existing_{space_dim_col}"]
            )
        )
    
        # Drop temporary columns
        df_latest_facings_linear_space_by_sku_all_plano_ft = df_latest_facings_linear_space_by_sku_all_plano_ft.drop(
            columns=[f"existing_{space_dim_col}"]
        )

    # TODO: uncomment after using actual data
    # Assertion to check if any of the dimensions is NaN only when `source` is "new"
    # assert (
    #     df_latest_facings_linear_space_by_sku_all_plano_ft[
    #         df_latest_facings_linear_space_by_sku_all_plano_ft[
    #             [
    #                 "n_current_linear_space_per_facing_sku",
    #                 "prod_unit_width_ft",
    #                 "prod_unit_height_ft",
    #                 "prod_unit_depth_ft",
    #             ]
    #         ]
    #         .isna()
    #         .any(axis=1)
    #     ]["source"]
    #     == "new"
    # ).all(), "Assertion failed: dimension is NaN where item_no `source` is not 'new'."

    return df_latest_facings_linear_space_by_sku_all_plano_ft


def add_missing_n_current_all_dimensions_per_facing_sku(
    df_optimization_master_input: pd.DataFrame, cols_space: list[str]
):

    """
    For the SKUs that are not in the representative store, we will fill the null linear space used and current facings
    with 0, and we will get the linear space per facing (used for optimization sets and params) as an average across
    the stores in the cluster (most of them will only have 1 possible value, but some clusters and plano_ft sizes
    may have different values for linear space because different UPCs may have the same item_no_nbr, so we average them
    which is safer than risking introducing duplicates
    Args:
        df_optimization_master_input: Optimization master input used by optimizer to create sets and other model
        parameters
        cols_space: Columns containing the dimensions values to fill

    Returns:
    Optimization master input used by optimizer to create sets and other model parameters, having filled any nulls
    from not finding a SKU in the representative store. This way, all SKUs available in the cluster that have been
    modeled will be in the optimization input and a possibility for the optimizer to choose from, instead of just the
    ones available in the representative store
    """
    # Split data into rows with and without missing values in the specified columns
    cond_in_plano_fixture = df_optimization_master_input[cols_space].notna().all(axis=1)
    df_existing = df_optimization_master_input[cond_in_plano_fixture]
    df_missing = df_optimization_master_input[~cond_in_plano_fixture]

    # Create the mappings once for each column in cols_space
    mappings = {}
    fallback_averages = {}

    for col_space in cols_space:
        df_existing_col_space = df_optimization_master_input[
            df_optimization_master_input[col_space].notna()
        ]
        cluster_item_no_plano_dim_map = (
            df_existing_col_space.groupby(
                ["final_cluster_labels", "item_no_nbr", "plano_ft", "fixture_size", "plano_id"]
            )[col_space]
            .agg(lambda x: x.mode().iloc[0])  # Directly get the first mode
            .to_dict()
        )
        cluster_item_no_dim_map = (
            df_existing_col_space.groupby(["final_cluster_labels", "item_no_nbr"])[
                col_space
            ]
            .agg(lambda x: x.mode().iloc[0])  # Directly get the first mode
            .to_dict()
        )
        item_no_dim_map = (
            df_existing_col_space.groupby("item_no_nbr")[col_space]
            .agg(lambda x: x.mode().iloc[0])  # Directly get the first mode
            .to_dict()
        )
        mappings[col_space] = (
            cluster_item_no_plano_dim_map,
            cluster_item_no_dim_map,
            item_no_dim_map,
        )

        # fallback averages for new items
        # Cluster-planogram level averages
        cluster_plano_avg_map = {}
        for (cluster, item, plano_ft, fixture_size, plano_id), value in cluster_item_no_plano_dim_map.items():
            key = (cluster, plano_ft, fixture_size, plano_id)
            if key not in cluster_plano_avg_map:
                cluster_plano_avg_map[key] = []
            cluster_plano_avg_map[key].append(value)

        # Convert to averages
        for key in cluster_plano_avg_map:
            cluster_plano_avg_map[key] = sum(cluster_plano_avg_map[key]) / len(cluster_plano_avg_map[key])

        # Cluster-level averages
        cluster_avg_map = {}
        for (cluster, item), value in cluster_item_no_dim_map.items():
            if cluster not in cluster_avg_map:
                cluster_avg_map[cluster] = []
            cluster_avg_map[cluster].append(value)

        # Convert to averages
        for cluster in cluster_avg_map:
            cluster_avg_map[cluster] = sum(cluster_avg_map[cluster]) / len(cluster_avg_map[cluster])

        # Overall average
        valid_values = [v for v in item_no_dim_map.values() if not pd.isna(v)]
        overall_avg = sum(valid_values) / len(valid_values) if valid_values else None

        fallback_averages[col_space] = {
            'cluster_plano_avg_map': cluster_plano_avg_map,
            'cluster_avg_map': cluster_avg_map,
            'overall_avg': overall_avg
        }

    # Function to select the dimension based on the precomputed mappings
    def select_dimension(row, col_space):
        cluster_item_no_plano_dim_map, cluster_item_no_dim_map, item_no_dim_map = mappings[col_space]
        fallback_data = fallback_averages[col_space]

        if pd.isna(row[col_space]):
            item_no_nbr_key = (
                row["clone_item_item_no_nbr"]
                if row["is_net_new_sku"] == 1 and row["is_fake_new_sku"] == 0 and row["clone_item_item_no_nbr"] != row["item_no_nbr"]
                else row["item_no_nbr"]
            )

            # First attempt: Cluster-planogram level mapping
            cluster_plano_value = cluster_item_no_plano_dim_map.get(
                (
                    row["final_cluster_labels"],
                    item_no_nbr_key,
                    row["plano_ft"],
                    row["fixture_size"],
                    row["plano_id"],
                )
            )
            if cluster_plano_value is not None and not pd.isna(cluster_plano_value):
                return cluster_plano_value

            # Second attempt: Cluster-level mapping
            cluster_value = cluster_item_no_dim_map.get(
                (row["final_cluster_labels"], item_no_nbr_key)
            )
            if cluster_value is not None and not pd.isna(cluster_value):
                return cluster_value

            # Third attempt: Item-level mapping
            item_value = item_no_dim_map.get(item_no_nbr_key)
            if item_value is not None and not pd.isna(item_value):
                return item_value

            # Fourth attempt - For new items, use precomputed averages
            if row["is_net_new_sku"] == 1:
                # Try cluster-planogram average
                cluster_plano_key = (row["final_cluster_labels"], row["plano_ft"], row["fixture_size"], row["plano_id"])
                cluster_plano_avg = fallback_data['cluster_plano_avg_map'].get(cluster_plano_key)
                if cluster_plano_avg is not None:
                    return cluster_plano_avg

                # Try cluster average
                cluster_avg = fallback_data['cluster_avg_map'].get(row["final_cluster_labels"])
                if cluster_avg is not None:
                    return cluster_avg

                # Final fallback: overall average
                if fallback_data['overall_avg'] is not None:
                    return fallback_data['overall_avg']

            log.warning(f"ALL LOOKUPS FAILED for item_no_nbr: {item_no_nbr_key}, col_space: {col_space}")

        return row[col_space]

    # Apply the select_dimension function to fill missing values in each column
    for col_space in cols_space:
        df_missing[col_space] = df_missing.apply(
            lambda row: select_dimension(row, col_space), axis=1
        )

    # Filter out rows with any remaining NaNs in the specified columns
    df_missing_cleaned = df_missing.dropna(subset=cols_space)

    # Identify dropped SKUs due to lack of linear space info
    dropped_skus = (
        df_missing.loc[df_missing[cols_space].isna().any(axis=1), "item_no_nbr"]
        .unique()
        .tolist()
    )
    log.info(
        f"{len(dropped_skus)} SKUs were dropped due to missing space dimensions information."
    )
    log.info(f"List of dropped SKUs: {dropped_skus}")

    # Concatenate the cleaned missing data with existing data
    df = pd.concat([df_existing, df_missing_cleaned])

    return df


def get_config_percentile_facings_in_dept(
    agg_level_clustering: List[str],
    df_final_clusters: pd.DataFrame,
    df_latest_sku_level_facings: pd.DataFrame,
    config_percentile: float,
) -> pd.DataFrame:
    """
    Calculates the `max_percentile` facings assigned to any SKU within the [plano_cat_id, dept_id, cluster] which will
    be used later for one of the model constraints
    Args:
        agg_level_clustering: Aggregation level at which clustering is defined
        df_final_clusters: DataFrame containing the cluster labels used for space elasticity fitting & optimization
        df_latest_sku_level_facings: DataFrame containing the the current facings at the store-POG-SKU level, coming
        from the latest space data available
        config_percentile: Looks for the 95th percentile of facings assigned to any given SKU across the
        [plano_cat_id, final_cluster_labels]

    Returns:
    A DataFrame with `n_facings_config_percentile_dept` used later in optimization to prevent optimizer to
    assign more than that number of facings
    """
    df_final_clusters = df_final_clusters[
        agg_level_clustering + ["final_cluster_labels"]
    ]
    agg_level_clustering = [
        item for item in agg_level_clustering if item != "category_level_dept_name"
    ]
    df_latest_sku_level_facings_x_clusters = df_latest_sku_level_facings.merge(
        df_final_clusters,
        on=agg_level_clustering,
        how="inner",
    )
    df_config_percentile_facings_in_dept = (
        df_latest_sku_level_facings_x_clusters.groupby(
            (context.groupby_granularity.optimizer + ["final_cluster_labels"])
        )["n_current_facings_sku"]
        .quantile(config_percentile)
        .reset_index()
        .rename(columns={"n_current_facings_sku": "n_facings_config_percentile_dept"})
    )
    return df_config_percentile_facings_in_dept


def prepare_elasticity_information(
    df_optimization_master_input: pd.DataFrame,
    df_space_productivity_per_facing: pd.DataFrame,
    df_space_productivity_need_state: pd.DataFrame,
):
    df_optimization_master_input = df_optimization_master_input.copy()
    df_space_productivity_per_facing = df_space_productivity_per_facing.copy()
    df_space_productivity_need_state = df_space_productivity_need_state.copy()

    # Get the elasticity curve information (can prob remove some cols)
    df_space_productivity_per_facing.rename(
        columns={"item_no_nbr": "clone_item_item_no_nbr"}, inplace=True
    )

    elasticity_groupby_key = (
            context.groupby_granularity.elasticity
            + context.optimization.data_prep.addtl_agg_clone_sku_cluster_level
            + ["fixture_desc"]
        )

    # Remove NS constraints
    if "need_state_unique_id" in elasticity_groupby_key:
        elasticity_groupby_key.remove("need_state_unique_id")
        df_space_productivity_per_facing = df_space_productivity_per_facing.drop(columns = ["need_state_unique_id"])

    df_optimization_master_input = df_optimization_master_input.merge(
        df_space_productivity_per_facing,
        on=elasticity_groupby_key,
        how="left",
    )  # elasticity_override_granularity null

    # Get the need state elasticity curve information
    df_optimization_master_input = df_optimization_master_input.merge(
        df_space_productivity_need_state,
        on=(
            context.groupby_granularity.elasticity
            + context.optimization.data_prep.addtl_agg_need_state_level_constraints
        ),
        how="left",
    )
    return df_optimization_master_input


def get_linear_space_for_new_item(
    df_optimization_master_input: pd.DataFrame,
    df_new_item_linear_space: pd.DataFrame,
):
    # get 'n_current_facings_sku', 'n_current_linear_space_used_sku', 'n_current_linear_space_per_facing_sku'
    # n_current_linear_space_used_sku and n_current_facings_sku should be 0
    df_optimization_master_input = df_optimization_master_input.merge(
        df_new_item_linear_space,
        on="item_no_nbr",
        how="left",
    )

    # new item will use the provided dimensions
    dict_col_space_new_item = {
        "n_current_linear_space_per_facing_sku": "new_item_n_current_linear_space_per_facing_sku",
        "prod_unit_width_ft": "new_item_prod_unit_width_ft",
        "prod_unit_height_ft": "new_item_prod_unit_height_ft",
        "prod_unit_depth_ft": "new_item_prod_unit_depth_ft",
    }
    cols_space = list(dict_col_space_new_item.keys())

    df_optimization_master_input.fillna(
        {
            col: df_optimization_master_input[fill_col]
            for col, fill_col in dict_col_space_new_item.items()
        },
        inplace=True,
    )

    df_optimization_master_input.drop(
        columns=list(dict_col_space_new_item.values()), inplace=True
    )

    df_optimization_master_input = add_missing_n_current_all_dimensions_per_facing_sku(
        df_optimization_master_input, cols_space
    )
    return df_optimization_master_input


def create_master_optimization_input(
    df_optimization_master_input_exploded_item_no: pd.DataFrame,
    df_space_productivity_per_facing: pd.DataFrame,
    df_new_item_linear_space: pd.DataFrame,
    df_config_percentile_facings_in_dept: pd.DataFrame,
    df_sku_transference: pd.DataFrame,
    df_space_productivity_need_state: pd.DataFrame
) -> pd.DataFrame:
    """
    Merges all datasets of interest to create the master optimization dataset which will be used to create sets,
    parameters, decision variables, constraints and objective function for the optimization model.
    Args:
        df_optimization_master_input_exploded_item_no: DataFrame containing information about the store representative for
        each grouping of (plano_cat_id, plano_cat_desc, plano_ft, final_cluster_labels)
        df_space_productivity_per_facing: DataFrame with space productivity per facing columns from the space
        elasticity module's output
        df_new_item_linear_space: DataFrame containing the linear space per facing for new items
        df_config_percentile_facings_in_dept: A DataFrame with `n_facings_config_percentile_dept` used later
        in optimization to prevent optimizer to assign more than that number of facings
        df_sku_transference: dataset containing SKU transference for objective function penalty, already filtered to a
        given `plano_cat_desc`
        df_space_productivity_need_state: dataset containing each need state's saturation facings at the cluster level
    Returns:
    One master optimization dataset which will be used to create sets, parameters, decision variables, constraints
    and objective function for the optimization model
    """

    # Creating the skeleton of data to which we'll join the different fields
    df_optimization_master_input = df_optimization_master_input_exploded_item_no.rename(
        columns={"store_nbr": "representative_store_nbr"}
    )

    # tag is_fake_new_sku and is_net_new_sku
    df_optimization_master_input["is_fake_new_sku"] = (
        df_optimization_master_input["source"] == "fake_new"
    ).astype(int)
    df_optimization_master_input["is_net_new_sku"] = (
        (df_optimization_master_input["source"] == "new")
        | (df_optimization_master_input["source"] == "fake_new")
        # for financial projection to work properly, both new and fake_new should be considered as is_net_new_sku == 1
    ).astype(int)

    df_optimization_master_input = get_updated_height_depth_orientation(
        df_optimization_master_input
    )

    df_optimization_master_input = prepare_elasticity_information(
        df_optimization_master_input,
        df_space_productivity_per_facing,
        df_space_productivity_need_state,
    )

    # apply the clone_pct on the productivity_per_facing if using clone item
    df_optimization_master_input["clone_pct"].fillna(1.0, inplace=True)
    # 1. Filter productivity columns that match the pattern
    productivity_cols = df_optimization_master_input.filter(
        like="n_space_prod_fit_facings_"
    ).columns
    # 2. Vectorized operation to multiply all productivity columns by 'clone_pct'
    df_optimization_master_input[productivity_cols] = df_optimization_master_input[
        productivity_cols
    ].multiply(df_optimization_master_input["clone_pct"], axis=0)
    df_optimization_master_input = get_linear_space_for_new_item(
        df_optimization_master_input,
        df_new_item_linear_space,
    )
    # Fill default orientation for new items
    df_optimization_master_input.orientation.fillna("Front", inplace=True)

    df_optimization_master_input = df_optimization_master_input.merge(
        df_config_percentile_facings_in_dept,
        on=(context.groupby_granularity.optimizer + ["final_cluster_labels"]),
        how="left",
    )

    # Add the transference information, log if any missing
    df_sku_transference.rename(columns={"item_no_nbr": "clone_item_item_no_nbr"}, inplace=True)
    df_optimization_master_input = df_optimization_master_input.merge(
        df_sku_transference, on=["clone_item_item_no_nbr"], how="left"
    )
    # is_net_new_sku automatically gets a transference of 1
    df_optimization_master_input[
        "n_transference_sku"
    ] = df_optimization_master_input.apply(
        lambda x: 1.0 if x["is_net_new_sku"] == 1 else x["n_transference_sku"], axis=1
    )
    df_optimization_master_input_no_transference = df_optimization_master_input[
        df_optimization_master_input["n_transference_sku"].isna()
    ][["dept_id", "source", "item_no_nbr", "clone_item_item_no_nbr"]].drop_duplicates()
    if len(df_optimization_master_input_no_transference) > 0:
        log.info(
            f"{len(df_optimization_master_input_no_transference)} rows in df_optimization_master_input have no transference information, filling with 0.5"
        )
        log.info(df_optimization_master_input_no_transference)
        df_optimization_master_input["n_transference_sku"].fillna(0.5, inplace=True)

    check_data_integrity(
        df_optimization_master_input,
        ["elasticity_override_granularity"],
    )

    check_data_integrity(
        df_optimization_master_input,
        ["elasticity_override_granularity", "threshold_for_store_cluster"],
    )
    df_optimization_master_input["include_in_optimizer_choices"] = 1

    return df_optimization_master_input


def add_dc_store_count_information(
    df_optimization_master_input_exploded_item_no: pd.DataFrame,
    df_dc_store_mapping: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adds DC information and calculates total store counts per DC across ALL clusters.
    """    
    log.info("Adding DC store count information...")
    
    # Add DC information to the optimization master data
    df_optimization_master_input_exploded_item_no = df_optimization_master_input_exploded_item_no.merge(
            df_dc_store_mapping,
            on='store_nbr',
            how='left'
        )
    
    # Calculate total stores per DC across ALL data
    dc_total_stores = (
        df_optimization_master_input_exploded_item_no[['dc_id', 'store_nbr']]
        .drop_duplicates()
        .groupby('dc_id')['store_nbr']
        .nunique()
        .reset_index()
        .rename(columns={'store_nbr': 'total_stores_in_dc'})
    )
    
    # Calculate stores per DC within each cluster-planogram combination
    dc_cluster_plano_stores = (
        df_optimization_master_input_exploded_item_no.groupby([
            'final_cluster_labels', 'plano_ft', 'fixture_size', 'plano_id', 'dc_id'
        ])['store_nbr']
        .nunique()
        .reset_index()
        .rename(columns={'store_nbr': 'stores_in_dc_per_cluster_plano'})
    )
    
    # Merge total DC counts
    df_optimization_master_input_exploded_item_no = df_optimization_master_input_exploded_item_no.merge(
        dc_total_stores,
        on='dc_id',
        how='left'
    )
    
    # Merge cluster-plano specific DC counts  
    df_optimization_master_input_exploded_item_no = df_optimization_master_input_exploded_item_no.merge(
        dc_cluster_plano_stores,
        on=['final_cluster_labels', 'plano_ft', 'fixture_size', 'plano_id', 'dc_id'],
        how='left'
    )
    
    dc_info_rows = df_optimization_master_input_exploded_item_no['dc_id'].notna().sum()
    total_rows = len(df_optimization_master_input_exploded_item_no)
    unique_dcs = df_optimization_master_input_exploded_item_no['dc_id'].nunique()
    
    log.info(f"Added DC information to {dc_info_rows}/{total_rows} rows ({dc_info_rows/total_rows:.1%})")
    log.info(f"Total unique DCs: {unique_dcs}")

    # Log any stores without DC mapping
    stores_without_dc = df_optimization_master_input_exploded_item_no[df_optimization_master_input_exploded_item_no['dc_id'].isna()]['store_nbr'].nunique()
    if stores_without_dc > 0:
        log.warning(f"{stores_without_dc} stores do not have DC mapping")
            
    return df_optimization_master_input_exploded_item_no


def add_removal_penalty_information(
    df_optimization_master_input_exploded_item_no: pd.DataFrame,
    df_removal_penalty: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adds removal penalty information to the optimization master data.
    
    Args:
        df_optimization_master_input_exploded_item_no: Main optimization dataframe
        df_removal_penalty: DataFrame with columns ['item_no_nbr', 'removal_penalty']
    
    Returns:
        DataFrame with removal penalty information added
    """
    log.info("Adding removal penalty information...")
    
    # Merge removal penalty data
    df_result = df_optimization_master_input_exploded_item_no.merge(
        df_removal_penalty,
        on='item_no_nbr',
        how='left'
    )
    
    # Calculate average removal penalty from non-null values
    avg_removal_penalty = df_result['removal_penalty'].mean()
    
    # Fill missing values with average, or 0 if all values are missing
    if pd.isna(avg_removal_penalty):
        log.warning("All removal penalty values are missing. Filling with 0.")
        df_result['removal_penalty'].fillna(0, inplace=True)
    else:
        log.info(f"Filling missing removal penalty values with average: {avg_removal_penalty:.4f}")
        df_result['removal_penalty'].fillna(avg_removal_penalty, inplace=True)
    
    # Log statistics
    penalty_info_rows = df_removal_penalty.shape[0]
    total_items = df_result['item_no_nbr'].nunique()
    missing_items = df_result[df_result['removal_penalty'] == (0 if pd.isna(avg_removal_penalty) else avg_removal_penalty)]['item_no_nbr'].nunique()
    
    log.info(f"Removal penalty provided for {penalty_info_rows} items")
    log.info(f"Total unique items in optimization data: {total_items}")
    log.info(f"Items filled with default value: {missing_items}")
    
    return df_result
