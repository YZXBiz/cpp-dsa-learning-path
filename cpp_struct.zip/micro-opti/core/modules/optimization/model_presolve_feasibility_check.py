import numpy as np
from core.modules.optimization.model_data_wrapper_v2 import OptimizationModelData
import logging

log = logging.getLogger(__name__)


def check_need_state_space_required_for_one_facing(
    opti_data: OptimizationModelData,
) -> OptimizationModelData:
    """
    Evaluates the space required for each need state (NS) with at least one facing
    in the given category-group pairs (c, g). Removes the (n, c, g) tuples that
    cannot satisfy the space constraints and logs the insufficient space situations.

    This function checks if the available space in each (c, g) pair can accommodate
    the minimum required space for all need states. If not, the (n, c, g) tuples
    are removed from `opti_data.eligible_ncg`, and the removed tuples are recorded
    in `opti_data.select_min_NS`.

    Args:
        opti_data (OptimizationModelData): The optimization model data object containing
            various attributes including space allocations, item dimensions, and eligible
            category-group pairs.

    Attributes Modified:
        opti_data.select_min_NS (list of tuples): Stores the (n, c, g) tuples that were
            removed due to insufficient space.

    Logs:
        Logs information about the (c, g) pairs that cannot satisfy the space constraints,
        including the available space, required space, and reserved space.

    Returns:
        OptimizationModelData: The updated optimization data with the recorded need state
        representation counts for each `(c, g)` pair.
    """
    # Collect (n, c, g) tuples to remove
    select_min_NS = {}

    # Report the (c, g) pairs where it's impossible to select all NS
    for c, g in opti_data.eligible_cg:
        min_c_g = 0.0
        available_space = (
            opti_data.total_linear_space_in_dept[c, g]
            - opti_data.local_items_reserved_linear_space[c, g]
        )

        # Determine the number of need states and calculate the minimum required
        total_ns = len(opti_data.ns_per_c_g[(c, g)])
        min_required_ns = (
            total_ns  # int(total_ns * opti_data.min_ns_represent_percentage)
        )

        # Calculate the space required for each n and sort n by the selected method
        space_calculation_method = (
            opti_data.need_state_space_presolve_calculation_method
        )
        if space_calculation_method == "min":
            sorted_ns_with_space = sorted(
                [
                    (
                        n,
                        min(
                            opti_data.item_width_x_facings[(i, 1, c, g)]
                            for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                        ),
                    )
                    for n in opti_data.ns_per_c_g[(c, g)]
                ],
                key=lambda x: x[1],  # Sort by the min_n_c_g value
            )
        elif space_calculation_method == "median":
            sorted_ns_with_space = sorted(
                [
                    (
                        n,
                        np.median(
                            [
                                opti_data.item_width_x_facings[(i, 1, c, g)]
                                for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                            ]
                        ),
                    )
                    for n in opti_data.ns_per_c_g[(c, g)]
                ],
                key=lambda x: x[1],  # Sort by the median_n_c_g value
            )
        else:
            raise ValueError(
                "Invalid need_state_space_calculation_method. Use 'min' or 'median'."
            )

        ns_count = 0

        for _, min_n_c_g in sorted_ns_with_space:
            min_c_g += min_n_c_g
            ns_count += 1

            # Early exit if we know the constraint cannot be satisfied
            if min_c_g > available_space:
                break

        # Only proceed if available space is less than the required space
        if available_space < min_c_g:
            # If ns_count is less than required, store ns_count - 1, otherwise store min_required_ns
            select_min_NS[(c, g)] = (
                ns_count - 1 if ns_count <= min_required_ns else min_required_ns
            )
            percentage_accommodated = (select_min_NS[(c, g)] / total_ns) * 100
            log.info(
                f"Cluster: {c}, G: {g}, Total Need States: {total_ns}, "
                f"Available Space: {available_space}, Required Space: {min_c_g}, "
                f"Total Space: {opti_data.total_linear_space_in_dept[c, g]}, "
                f"Reserved Space: {opti_data.local_items_reserved_linear_space[c, g]}, "
                f"Min Required NS: {min_required_ns}, NS Accommodated: {select_min_NS[(c, g)]}, "
                f"Percentage Accommodated: {percentage_accommodated:.2f}%"
            )

        else:
            select_min_NS[(c, g)] = total_ns

    # Assign the select_min_NS dictionary to opti_data
    opti_data.select_min_NS = select_min_NS

    return opti_data
