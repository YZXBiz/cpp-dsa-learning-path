from typing import Dict, List, Tuple
import gc

import numpy as np
import pandas as pd
from core.modules.optimization.model_data_wrapper_v2 import OptimizationModelData
from oxygen.conf.context import context
from pulp import LpProblem, LpVariable
import logging

import ipdb

log = logging.getLogger(__name__)


def post_process_solved_model(
    df_optimization_master_data_filt: pd.DataFrame,
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    is_problem_infeasible: bool,
) -> Tuple[OptimizationModelData, pd.DataFrame]:
    """
    Post-processes the solved model to extract variable values, overall objective and space productivity metrics
    Args:
        df_optimization_master_data_filt: Optimization master data for filtered for the scope of the optimization
        problem (plano_cat_desc, dept_id, plano_ft, fixture_size, cluster_id)
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function
        is_problem_infeasible: Boolean that specified whether this problem was infeasible or not. If it was, then we will
        assign the current assortment as optimal solution, but we'll be able to keep track of infeasible ones

    Returns:
    Tuple with:
    - Updated `data_object` with the 2 attributes `current_total_space_prod` and `optimal_total_space_prod`
    - Updated `df_optimization_master_data_filt` with a few columns on optimal linear space used, optimal space prod
    and current space prod, all at SKU level
    """
    df_optimization_master_data_filt["n_optimal_facings_sku"] = [
        [f for f in range(0, context.optimization.model_formulation.max_facings_opti)]
    ] * len(df_optimization_master_data_filt)
    df_optimization_master_data_filt = df_optimization_master_data_filt.explode(
        "n_optimal_facings_sku"
    )
    df_optimization_master_data_filt[
        "n_optimal_facings_sku"
    ] = df_optimization_master_data_filt["n_optimal_facings_sku"].astype(int)
    df_optimization_master_data_filt["is_problem_infeasible"] = is_problem_infeasible
    # Getting slack variables values when they are used
    if (
        context.optimization_config.model_formulation.enable_enforce_as_many_need_states_as_possible_constraint
        == True
    ):
        df_optimization_master_data_filt = add_optimal_variables_info(
            df_optimization_master_data_filt=df_optimization_master_data_filt,
            vars_obj=opti_data.slack_min_ns_vars,
            vars_indices=context.optimization.post_processing.slack_vars_indices,
            var_name="slack_min_ns_vars",
            is_problem_infeasible=is_problem_infeasible,
        )
    # Getting optimal values of all x, and then the other "dummy" optimization variables
    df_optimization_master_data_filt = add_optimal_variables_info(
        df_optimization_master_data_filt=df_optimization_master_data_filt,
        vars_obj=opti_data.x_vars,
        vars_indices=context.optimization.post_processing.x_vars_indices,
        var_name="x_ifcg",
        is_problem_infeasible=is_problem_infeasible,
    )
    
    # Adding optimal objective value
    if is_problem_infeasible:
        df_optimization_master_data_filt["optimal_objective_value"] = np.nan
        df_optimization_master_data_filt["optimal_objective_value_contribution"] = np.nan
        setattr(opti_data, "optimal_objective_value", np.nan)
    else:
        df_optimization_master_data_filt[
            "optimal_objective_value"
        ] = opti_model.objective.value()
        setattr(opti_data, "optimal_objective_value", opti_model.objective.value())

        # Add individual contribution to objective function
        ls_obj_contribution = []
        for v in opti_model.variables():
            # Contribution to objective
            coeff = opti_model.objective.get(v)
            contribution = coeff * v.varValue if coeff else 0
            ls_obj_contribution.append([v.name, contribution])

        # Create dataframe with contribution per x_ifcg index
        df_obj_contribution = pd.DataFrame(
            data=ls_obj_contribution,
            columns=["x_ifcg", "optimal_objective_value_contribution"]
        )

        # Merge to master dataframe
        df_optimization_master_data_filt = df_optimization_master_data_filt.merge(
            df_obj_contribution, on="x_ifcg", how="left"
        )

        # Fill missing values with 0
        df_optimization_master_data_filt["optimal_objective_value_contribution"] = df_optimization_master_data_filt[
            "optimal_objective_value_contribution"].fillna(0)

    # Adding optimal & current linear space used by SKU and total space productivity used
    (
        opti_data,
        df_optimization_master_data_filt,
    ) = calculate_sku_total_space_productivity(
        df_optimization_master_data_filt=df_optimization_master_data_filt,
        opti_data=opti_data,
    )

    # Filling null values for "object" type columns, which are supposedly strings, so that we don't get a Spark error
    # when trying to save a dataframe with columns that are completely null (and Spark can't infer type)
    for col in df_optimization_master_data_filt.columns:
        if df_optimization_master_data_filt[col].dtype == "object":
            df_optimization_master_data_filt[col].fillna("", inplace=True)

    return opti_data, df_optimization_master_data_filt


def calculate_sku_total_space_productivity(
    df_optimization_master_data_filt: pd.DataFrame,
    opti_data: OptimizationModelData,
) -> Tuple[OptimizationModelData, pd.DataFrame]:
    """
    This function calculates the total SKU Space productivity for both optimal facings and current facings, in order
    to calculate the dependent variable's optimal_total_space_prod and current_total_space_prod (and the lift between
    the two). Note that the optimal space productivity can be negative for a SKU, only in the case where it used to
    have a non-zero space productivity and was removed from the assortment, in which case it penalizes the total space
    productivity of the assortment by - space_prod_at_f_facings * (1 - transference), similarly to the way it is done
    in the objective function
    Args:
        df_optimization_master_data_filt: Optimization master data for filtered for the scope of the optimization
        problem (plano_cat_desc, dept_id, plano_ft, fixture_size, cluster_id)
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple with:
    - Updated `data_object` with the 2 attributes `current_total_space_prod` and `optimal_total_space_prod`
    - Updated `df_optimization_master_data_filt` with a few columns on optimal linear space used, optimal space prod
    and current space prod, all at SKU level
    """

    df_optimization_master_data_filt["n_optimal_linear_space_used_sku"] = (
        df_optimization_master_data_filt["n_optimal_facings_sku"]
        * df_optimization_master_data_filt["n_current_linear_space_per_facing_sku"]
    )
    df_optimization_master_data_filt["n_optimal_space_productivity"] = np.nan
    df_optimization_master_data_filt["n_current_space_productivity"] = np.nan

    for f in range(0, context.optimization.model_formulation.max_facings_opti):
        # Optimal space productivity
        df_optimization_master_data_filt.loc[
            df_optimization_master_data_filt["n_optimal_facings_sku"] == f,
            "n_optimal_space_productivity",
        ] = df_optimization_master_data_filt[f"n_space_prod_fit_facings_{f}"]

        # Current space productivity
        df_optimization_master_data_filt.loc[
            df_optimization_master_data_filt["n_current_facings_sku"] == f,
            "n_current_space_productivity",
        ] = df_optimization_master_data_filt[f"n_space_prod_fit_facings_{f}"]

    current_total_space_prod = df_optimization_master_data_filt[
        "n_current_space_productivity"
    ].sum()
    optimal_total_space_prod = df_optimization_master_data_filt[
        "n_optimal_space_productivity"
    ].sum()
    setattr(opti_data, "current_total_space_prod", current_total_space_prod)
    setattr(opti_data, "optimal_total_space_prod", optimal_total_space_prod)
    return opti_data, df_optimization_master_data_filt


def add_optimal_variables_info(
    df_optimization_master_data_filt: pd.DataFrame,
    vars_obj: Dict[Tuple[int, int, int, int], LpVariable],
    vars_indices: List[str],
    var_name: str,
    is_problem_infeasible: bool,
) -> pd.DataFrame:
    """
    Extracts optimal variables information and merges it back to df_optimization_master_data_filt.
    Notice that it will also have to artificially keep the SKUs that were originally excluded because they are assigned
    facings in the store representative's planogram, but have no sales in the past 12months
    Args:
        df_optimization_master_data_filt: Optimization master data for filtered for the scope of the optimization
        problem (plano_cat_desc, dept_id, plano_ft, fixture_size, cluster_id)
        vars_obj: LpVariable object to be used to extract information
        vars_indices: Indices names that index the variable we're processing, which will be useful when we want to
        merge back into the main dataframe
        var_name: Name of the variable in the optimization model e.g. `x_i_f`
        is_problem_infeasible: Boolean that specified whether this problem was infeasible or not. If it was, then we will
        assign the current assortment as optimal solution, but we'll be able to keep track of infeasible ones

    Returns:
    Original dataframe `df_optimization_master_data_filt` with 2 new columns: `var_name` and `{var_name}_optimal_value`
    """
    df_vars = pd.DataFrame.from_dict(vars_obj, orient="index", columns=[var_name])
    df_vars.index = pd.MultiIndex.from_tuples(df_vars.index, names=vars_indices)
    df_vars.reset_index(inplace=True)
    df_vars[f"{var_name}_optimal_value"] = (
        df_vars[var_name].apply(lambda item: item.varValue).astype(float)
    )
    df_vars[var_name] = df_vars[var_name].apply(lambda x: str(x))
    df_optimization_master_data_filt = df_optimization_master_data_filt.merge(
        df_vars.drop_duplicates(subset=vars_indices),
        on=vars_indices,
        how="left",
    )
    # Clean up optimal facings only when we add x_ifcg output to the data frame
    if var_name == "x_ifcg":
        # When infeasible, assign optimal facings to be exactly the same as current facings (so keep current assortment)
        if is_problem_infeasible:
            log.warning(
                "Optimization problem was infeasible; we will override optimal facings with current ones"
            )
            df_optimization_master_data_filt[f"{var_name}_optimal_value"] = 0
            df_optimization_master_data_filt.loc[
                (
                    df_optimization_master_data_filt["n_current_facings_sku"]
                    == df_optimization_master_data_filt["n_optimal_facings_sku"]
                )
                & (
                    df_optimization_master_data_filt["include_in_optimizer_choices"]
                    == 1
                ),
                f"{var_name}_optimal_value",
            ] = 1

        # We have to fill the nulls with 1 because those correspond to the SKUs that were originally willfully excluded
        # from the optimizer (because they don't have any sales, but still have space assigned in the store representative)
        df_optimization_master_data_filt.loc[
            (df_optimization_master_data_filt["include_in_optimizer_choices"] == 0)
            & (df_optimization_master_data_filt["n_optimal_facings_sku"] == 0),
            f"{var_name}_optimal_value",
        ] = 1

    return df_optimization_master_data_filt


def calculate_need_state_saturation_multipliers(
    df_all_need_state_curves: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function takes the original need state elasticity curves, and uses them to create a need state saturation
    multiplier. This multiplier is meant to capture diminishing returns / saturation as the number of total facings
    within a need state increases. Currently, we define the need state multiplier as:
    (1 - (prediction @ facing i - prediction at facing=1 / prediction @ saturation point - prediction at facing=1))

    After calculating the multiplier for each possible need state facing, we convert the multiplier dataframe from
    wide to long form — this will greatly simplify the math of combining with the item-level rankings in downstream
    functions.

    Args:
        df_all_need_state_curves: dataframe containing need state elasticity curves across all plano_cat_desc
        and departments, loaded in by `load_need_state_saturation_curves`

    Returns:
        df_saturation_multipliers_long: dataframe containing need state elasticity curves and their multipliers
        in long form (i.e. one row per simulated facing, per item/ns/cluster)
    """

    saturation_floor = context.financial_projections.saturation_floor

    # Create a new column which extracts the space productivity at the "saturation_facings".
    df_all_need_state_curves["saturation_value"] = df_all_need_state_curves.apply(
        lambda row: row[f"n_space_prod_fit_facings_{row['saturation_facings']}"], axis=1
    )

    # For each need state facing, calculate our saturation multiplier, defined as: multiplier =
    # (1 - (prediction @ facing i - prediction at facing=1 / prediction @ saturation point - prediction at facing=1))
    for f in range(
        0, context.financial_projections.max_facings_elasticity
    ):
        col_name = f"need_state_multiplier_{f}"
        df_all_need_state_curves[f"need_state_multiplier_{f}"] = np.maximum(
            1
            - (
                (
                    df_all_need_state_curves[f"n_space_prod_fit_facings_{f}"]
                    - df_all_need_state_curves["n_space_prod_fit_facings_1"]
                )
                / (
                    df_all_need_state_curves["saturation_value"]
                    - df_all_need_state_curves["n_space_prod_fit_facings_1"]
                )
            ),
            saturation_floor,
        )

        df_all_need_state_curves.loc[
            df_all_need_state_curves["saturation_facings"] < f, col_name
        ] = saturation_floor

    # Add edge case handling to ensure that the first facing always has a multiplier of 100%, even if the saturation
    # facing is equal to 1.
    df_all_need_state_curves["need_state_multiplier_1"] = 1.0

    # Convert the multiplier from wide form to long form using melt function. Having the data in long form
    # will be important for us downstream when we join the multiplier data with the item ranking data
    df_saturation_multipliers_long = pd.melt(
        df_all_need_state_curves,
        id_vars=(
            context.groupby_granularity.optimizer
            + context.financial_projections.addtl_need_state_multiplier_grouping_cols
        ),
        value_vars=[
            x for x in df_all_need_state_curves.columns if "need_state_multiplier_" in x
        ],
        var_name="ranking_column",
        value_name="need_state_multiplier",
    )
    # Do some quick string processing to replace the column containing the number of facing column names to integer
    # number of facings
    df_saturation_multipliers_long["ranking"] = (
        df_saturation_multipliers_long["ranking_column"]
        .str.split("_")
        .str[3]
        .astype(int)
    )
    df_saturation_multipliers_long = df_saturation_multipliers_long.drop(
        columns=["ranking_column"]
    )
    return df_saturation_multipliers_long


def calculate_item_space_productivity_rankings(
    df_opti_modeling_output: pd.DataFrame,
    ranking_variable: str,
    item_ranking_grouping_cols: List[str],
) -> pd.DataFrame:
    """
    This function takes in the item-level optimization data, and ranks the assortment (either current or optimal,
    depending on the `ranking_variable` provided) based on incremental value per facing, per linear space within a
    need state. This item facing level ranking will be used to determine the appropriate need state saturation
    multiplier should be applied to which incremental space productivity values.

    Args:
        df_opti_modeling_output: Main optimization output containing all POG Categories and assigned facings,
        space productivity, linear space used, etc.
        ranking_variable: Column name corresponding to the number of facings per item in the assortment, should be
        `n_optimal_facings_sku` to rank the optimal assortment, and `n_current_facings_sku` to rank the current
        assortment
        item_ranking_grouping_cols: Config-driven level of aggregation we will use to rank the item-facing incremental
        value per linear space

    Returns:
        df_item_level_outputs_long: Item facing rankings of incremental value per linear space in long format
    """
    # Convert from wide to long format using melt function, and ensure our `n_facings` variable is
    # stored properly as an integer
    df_item_level_outputs_long = pd.melt(
        df_opti_modeling_output,
        id_vars=item_ranking_grouping_cols
        + ["n_current_linear_space_per_facing_sku", "cdt", ranking_variable],
        value_vars=[
            x
            for x in df_opti_modeling_output.columns
            if "n_space_prod_fit_facings_" in x
        ],
        var_name="n_facings_columns",
        value_name="n_space_prod_fit_facings",
    )
    df_item_level_outputs_long["n_facings"] = (
        df_item_level_outputs_long["n_facings_columns"]
        .str.split("_")
        .str[5]
        .astype(int)
    )
    df_item_level_outputs_long = df_item_level_outputs_long.drop(
        columns=["n_facings_columns"]
    )

    del df_opti_modeling_output
    gc.collect()

    # Filter and calculate incremental values

    # Filter to keep only the number of facings per item/cluster/NS/dept/plano_ft/fixture where the simulated
    # facing is <= the ranking_variable of interest (either `n_optimal_facings_sku` or `n_current_facings_sku`).
    # This limits the scope of our item ranking to only the SKUs in the assortment of interest (either current or
    # optimal).
    df_item_level_outputs_long = df_item_level_outputs_long[
        df_item_level_outputs_long[ranking_variable]
        >= df_item_level_outputs_long["n_facings"]
    ]

    # Add a column that calculates the incremental value per facing, where incremental value is defined as the
    # (total space productivity at facing i - total space productivity at facing i-1)
    df_item_level_outputs_long = df_item_level_outputs_long.sort_values(
        by=item_ranking_grouping_cols + ["n_facings"]
    )
    df_item_level_outputs_long["previous_facing_value"] = (
        df_item_level_outputs_long.groupby(item_ranking_grouping_cols)[
            "n_space_prod_fit_facings"
        ]
        .shift(1)
        .fillna(0)
    )
    df_item_level_outputs_long["incremental_value"] = (
        df_item_level_outputs_long["n_space_prod_fit_facings"]
        - df_item_level_outputs_long["previous_facing_value"]
    )
    df_item_level_outputs_long["incremental_value_per_linear_space"] = (
        df_item_level_outputs_long["incremental_value"]
        / df_item_level_outputs_long["n_current_linear_space_per_facing_sku"]
    )



    # Rank incremental values
    df_item_level_outputs_long["ranking"] = df_item_level_outputs_long.groupby(
        [x for x in item_ranking_grouping_cols if x != "item_no_nbr"]
    )["incremental_value_per_linear_space"].rank(ascending=False, method="first")
    
    # Rank each candidate facing by its `incremental_value_per_linear_space`. Note, we sort by both
    # `incremental_value_per_linear_space` and `n_facings` and use `method="first"` within the rank so that in
    # the event of a tie, we will choose the item with the lower number of facings.
    df_item_level_outputs_long["ranking"] = (
        df_item_level_outputs_long.sort_values(
            by=["incremental_value_per_linear_space", "n_facings"],
            ascending=[False, True],
        )
        .groupby([x for x in item_ranking_grouping_cols if x != "item_no_nbr"])
        .cumcount()
        + 1
    )
    return df_item_level_outputs_long


def calculate_discounted_space_productivity(
    df_saturation_multipliers_long: pd.DataFrame,
    df_item_ranking_long: pd.DataFrame,
    item_ranking_grouping_cols: List[str],
) -> pd.DataFrame:
    """
    This function combines the need state saturation multiplier and item-facing rankings to create an adjusted
    incremental value per item/cluster/NS/dept/plano_ft/fixture_size. It discounts original incremental value per
    item-facing by the appropriate need state saturation multiplier, and then aggregates to back to the item level.

    Args:
        df_saturation_multipliers_long: Dataframe containing need state elasticity curves and their multipliers
        in long format
        df_item_ranking_long: Dataframe containing item facing rankings of incremental value per linear space in
        long format
        item_ranking_grouping_cols: Config-driven level of aggregation we will use to rank the item-facing incremental
        value per linear space

    Returns:
        df_item_level_outputs_with_adjustments: DataFrame containing adjusted space productivity value after applying
        multiplier for need state saturation
    """
    # Join together the long form item rankings and NS saturation multipliers. In the places where
    # `need_state_multiplier` is null after the join, we fill NA's with 0, since the nulls will only be produced where
    # the item ranking is > max multiplier we estimate
    df_saturation_multipliers_long = df_saturation_multipliers_long.drop_duplicates()

    df_merged_long = df_item_ranking_long.merge(
        df_saturation_multipliers_long,
        on=(
            context.groupby_granularity.optimizer
            + context.financial_projections.addtl_need_state_multiplier_grouping_cols
            + ["ranking"]
        ),
        how="left",
    )

    # Fill missing values with median
    df_merged_long["need_state_multiplier"] = (
        df_merged_long["need_state_multiplier"]
        .fillna(
            df_merged_long.groupby(["cdt", "ranking"])["need_state_multiplier"].transform("median")
        )
        .fillna(
            df_merged_long.groupby(["cdt"])["need_state_multiplier"].transform("median")
        )
    )

    df_merged_long["adjusted_incremental_value"] = (
        df_merged_long["incremental_value"] * df_merged_long["need_state_multiplier"]
    ).fillna(0)

    df_item_level_outputs_with_adjustments = (
        df_merged_long.groupby(item_ranking_grouping_cols)
        .agg(
            adjusted_incremental_value=pd.NamedAgg(
                column="adjusted_incremental_value", aggfunc="sum"
            )
        )
        .reset_index()
    )
    return df_item_level_outputs_with_adjustments


def singleprocess_rankings(
    df_opti_modeling_output,
    ranking_variable,
    df_saturation_multipliers_long,
    item_ranking_grouping_cols,
):
    """
    This function is single processing the calculate_item_space_productivity_rankings and calculate_discounted_space_productivity in plano-dept-item_no groups
    Args:
        df_opti_modeling_output: Main optimization output
        ranking_variable: Column name corresponding to the number of facings per item in the assortment, should be
        `n_optimal_facings_sku` to rank the optimal assortment, and `n_current_facings_sku` to rank the current assortment
        df_saturation_multipliers_long: Dataframe containing need state elasticity curves and their multipliers
        in long format
        item_ranking_grouping_cols: Config-driven level of aggregation we will use to rank the item-facing incremental
        value per linear space
    Returns:
        DataFrame containing adjusted space productivity value after applying multiplier for need state saturation
    """

    # Step 1: Calculate item space productivity rankings
    df_item_ranking_long = calculate_item_space_productivity_rankings(
        df_opti_modeling_output, ranking_variable, item_ranking_grouping_cols
    )

    # Step 2: Calculate discounted space productivity
    df_adjusted_value = calculate_discounted_space_productivity(
        df_saturation_multipliers_long, df_item_ranking_long, item_ranking_grouping_cols
    )

    return df_adjusted_value


def calculate_need_state_adjusted_space_productivity(
    df_opti_modeling_output: pd.DataFrame,
    df_all_need_state_curves: pd.DataFrame,
    item_ranking_grouping_cols: List[str],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    This main function adds "adjusted" current space productivity and optimal productivity columns to the original
    item-level optimization outputs. The "adjusted" productivity values account for need state saturation — the concept
    that as you grow a need state, you should expect diminishing returns on value. It:
    1. Calculates saturation multipliers based on need state elasticity curves
    2. Ranks the current and optimal assortment based on item-facing productivity per linear space
    3. Discounts the incremental value in (2) by the multiplier in (1)
    4. Adds this information to the optimization item-level outputs

    Args:
        df_opti_modeling_output: Main optimization output containing all POG Categories and assigned facings, space
        productivity, linear space used, etc. for the `dependent_var` we're running on
        dependent_var: Dependent variable against which we originally optimized
        item_ranking_grouping_cols: Config-driven level of aggregation we will use to rank the item-facing incremental
        value per linear space

    Returns:
        df_opti_modeling_output_with_saturation: DataFrame of original item level optimization outputs, with
        adjusted current and optimal space productivity columns added
    """    
    # Calculate need state saturation multipliers, converting dataframe into long format
    df_saturation_multipliers_long = calculate_need_state_saturation_multipliers(
        df_all_need_state_curves=df_all_need_state_curves
    )

    del df_all_need_state_curves
    gc.collect()

    # Calculate item-level productivity rankings and adjusted value for optimal assortment
    df_optimal_adjusted_value = singleprocess_rankings(
        df_opti_modeling_output=df_opti_modeling_output,
        ranking_variable="n_optimal_facings_sku",
        df_saturation_multipliers_long=df_saturation_multipliers_long,
        item_ranking_grouping_cols=item_ranking_grouping_cols,
    )

    # Calculate item-level productivity rankings and adjusted value for current assortment
    df_current_adjusted_value = singleprocess_rankings(
        df_opti_modeling_output=df_opti_modeling_output,
        ranking_variable="n_current_facings_sku",
        df_saturation_multipliers_long=df_saturation_multipliers_long,
        item_ranking_grouping_cols=item_ranking_grouping_cols,
    )

    del df_saturation_multipliers_long
    gc.collect()
    
    return (df_optimal_adjusted_value, df_current_adjusted_value)
