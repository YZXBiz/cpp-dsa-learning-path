import pandas as pd
import numpy as np

import logging

log = logging.getLogger(__name__)


def add_optimal_variables_info(vars_obj, vars_indices, var_name) -> pd.DataFrame:
    """
    Convert a dictionary of PuLP variables into a DataFrame with optimal values.

    Args:
        vars_obj (dict): A dictionary with keys as tuples representing variable indices
                         and values as PuLP LpVariable objects.
        vars_indices (list): A list of names for the indices (corresponding to the levels of the tuples).
        var_name (str): The name to assign to the variable column in the DataFrame.

    Returns:
        pd.DataFrame: A DataFrame containing the variables, their indices, and their optimal values.
    """

    # Create DataFrame from the dictionary of variables
    df_vars = pd.DataFrame.from_dict(vars_obj, orient="index", columns=[var_name])
    df_vars.index = pd.MultiIndex.from_tuples(df_vars.index, names=vars_indices)
    df_vars.reset_index(inplace=True)

    # Safely extract the optimal values, handling None values
    df_vars[f"{var_name}_optimal_value"] = (
        df_vars[var_name]
        .apply(lambda item: item.varValue if item.varValue is not None else np.nan)
        .astype(float)
    )

    # Convert the LpVariable objects to their string representation
    df_vars[var_name] = df_vars[var_name].apply(lambda x: str(x))

    return df_vars
