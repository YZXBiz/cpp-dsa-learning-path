import pandas as pd
import numpy as np
from core.modules.optimization.model_data_wrapper_v2 import OptimizationModelData
from pulp import (
    LpVariable,
    LpConstraint,
    LpConstraintEQ,
    LpConstraintGE,
    LpConstraintLE,
    LpProblem,
    lpSum,
    LpAffineExpression
)
from oxygen.conf.context import context
import logging
from typing import List, Dict, Tuple, Union
import ipdb

log = logging.getLogger(__name__)


def add_objective_function_to_model(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds objective function to the model, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf for more
    details. The objective function tries to maximize the space productivity (based on sales or dnp)
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with objective function
    """
    log.info("Setting objective function without penalty terms first")
    objective_function = lpSum(
        opti_data.x_vars[(i, f, c, g)]
        * opti_data.item_productivity_per_facing[(i, f, c, g)]
        for (i, f, c, g) in opti_data.x_vars
    ) - lpSum(
        opti_data.item_productivity_current_facings[(i, c, g)]
        * (1 - opti_data.item_transference[i])
        * (
            1
            - lpSum(
                opti_data.x_vars[(i, f, c, g)]
                for f in opti_data.facings_per_item[i][1:]
            )
        )
        # We don't sum the 0 facings variables because the penalty is only for the SKUs that were assigned 0 facings
        for (i, c, g) in opti_data.eligible_icg
    )

    if context.optimization_config.model_formulation.enable_removal_penalty:
        log.info("Adding removal penalty term to objective function")
        
        # Only apply penalty to items that currently have positive facings
        items_with_current_facings = [
            i for i in opti_data.items_all
            if i in opti_data.removal_penalty_per_item and
            any(
                opti_data.current_facings_per_item.get((i, c, g), 0) > 0
                for c, g in opti_data.eligible_cg
                if (i, c, g) in opti_data.eligible_icg
            )
        ]
        
        objective_function -= lpSum(  # Changed from gp.quicksum to lpSum
            opti_data.removal_penalty_per_item[i]
            * (
                1 - lpSum(  # Changed from gp.quicksum to lpSum
                    opti_data.x_vars[(i, f, c, g)]
                    for c, g in opti_data.eligible_cg
                    for f in opti_data.facings_per_item[i][1:]
                    if (i, f, c, g) in opti_data.x_vars
                )
            )
            for i in items_with_current_facings
        )
    
        log.info(f"Applied removal penalty to {len(items_with_current_facings)} items with current facings")

    # Log problem size
    cnt_items = len(opti_data.items_all)
    cnt_c_g = len(opti_data.ns_per_c_g.keys())
    avg_ns_per_cg = pd.Series([len(v) for v in opti_data.ns_per_c_g.values()]).mean()
    log.info(f"Logging summary stats for the overall optimization problem size ...")
    log.info(f"num_items = {cnt_items:,}")
    log.info(f"num_cluster_plano_fixture_pairs = {cnt_c_g:,}")
    log.info(f"avg_num_need_states_per_c_g = {avg_ns_per_cg:.2f}")

    # Add slack variables to objective function if enable_enforce_as_many_need_states_as_possible_constraint is True
    if (
        context.optimization_config.model_formulation.enable_enforce_as_many_need_states_as_possible_constraint
        == True
    ):
        log.info(
            "Add penalty terms to original objective function because enable_enforce_as_many_need_states_as_possible_constraint is set to True"
        )
        # Set penalty coefficient
        penalty_coefficient_label = (
            context.optimization_config.model_formulation.penalty_coefficient
        )
        try:
            penalty_coefficient_value = round(
                sum(getattr(opti_data, penalty_coefficient_label).values()), 2
            )
        except ValueError as e:
            log.error(f"{e}")
        cnt_need_states = len(
            opti_data.need_states_top1_item_productivity_current_facing.keys()
        )
        log.info("Logging extra need states and slack penalty info...")
        log.info(f"num_need_states = {cnt_need_states:,}")
        log.info(
            f"penalty_coefficient_for_slack_vars = {penalty_coefficient_value:.2f}, label = {penalty_coefficient_label}"
        )
        setattr(
            opti_data, "penalty_coefficient_for_slack_vars", penalty_coefficient_value
        )
        # Define objective function
        objective_function = objective_function - (
            lpSum(
                opti_data.slack_min_ns_vars[(c, g)] for c, g in opti_data.select_min_NS
            )
            * penalty_coefficient_value
        )

    # Add slack variables to objective function if enable_supplier_brand_global_constraints is True
    if (
            context.optimization_config.model_formulation.enable_global_linear_space_change_constraints
            == True
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "supplier_brand_global_constraints is set to True"
        )
        global_brand_supplier_penalty_coefficient = (
            context.optimization_config.model_formulation.global_linear_space_change_penalty_coefficient
        )

        # Add slack variables associated with brand & supplier
        for dimension in context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys():
            # If slack variable associated with the dimension is defined, loop through its keys & add the value
            # to the objective function with a penalty multiplier
            # Condition only checks for min slack variable since both variables (min/max) are created in conjunction
            if f"slack_{dimension}_space_min" in dir(opti_data):
                slack_min_var = getattr(opti_data, f"slack_{dimension}_space_min")
                slack_max_var = getattr(opti_data, f"slack_{dimension}_space_max")

                objective_function = (
                    objective_function
                    - (
                        lpSum(slack_min_var[k] for k in slack_min_var.keys())
                        * global_brand_supplier_penalty_coefficient
                    )
                    - (
                        lpSum(slack_max_var[k] for k in slack_max_var.keys())
                        * global_brand_supplier_penalty_coefficient
                    )
                )

    # Add slack variables to objective function if there are soft max need states
    if (
            hasattr(opti_data, "slack_max_need_state_facings")
            and context.optimization_config.model_formulation.enable_min_max_need_state_facings_constraint
            == True
    ):
        log.info(
            "Add penalty terms to original objective function for soft max need state facings constraints"
        )
        
        penalty_max_need_state_facings = context.optimization_config.model_formulation.penalty_max_need_state_facings
        slack_max_need_state_facings = getattr(opti_data, "slack_max_need_state_facings", {})
        
        if slack_max_need_state_facings:
            objective_function -= penalty_max_need_state_facings * lpSum(
                slack_max_need_state_facings[key] for key in slack_max_need_state_facings
            )
            log.info(f"Added penalty for {len(slack_max_need_state_facings)} soft max need state facings constraints")
        else:
            log.warning("slack_max_need_state_facings exists but is empty")

    # Add slack variable to objective functions if enable_minimum_store_per_sku is True
    if (
            context.optimization_config.model_formulation.enable_minimum_store_per_sku
            == True
        and len(context.optimization.model_formulation.dict_item_POD_min_store) > 0
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "minimum_store_per_sku is set to True"
        )

        penalty_min_store_per_sku = context.optimization_config.model_formulation.penalty_min_store_per_sku
        slack_pod_lb = getattr(opti_data, "slack_pod_lb", {})
    
        if slack_pod_lb:
            objective_function -= penalty_min_store_per_sku * lpSum(
                slack_pod_lb[key] for key in slack_pod_lb
            )
        else:
            log.warning("enable_minimum_store_per_sku is True but no slack_pod_lb variables found")

    # Add slack variable to objective functions if enable_maximum_store_per_sku is True
    if (
            context.optimization_config.model_formulation.enable_maximum_store_per_sku
            == True
        and len(context.optimization.model_formulation.dict_item_POD_max_store) > 0
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "maximum_store_per_sku is set to True"
        )

        penalty_max_store_per_sku = context.optimization_config.model_formulation.penalty_max_store_per_sku
        slack_pod_ub = getattr(opti_data, "slack_pod_ub", {})
    
        if slack_pod_ub:
            objective_function -= penalty_max_store_per_sku * lpSum(
                slack_pod_ub[key] for key in slack_pod_ub
            )
        else:
            log.warning("enable_maximum_store_per_sku is True but no slack_pod_ub variables found")


    # DC minimum stores constraint penalty
    if (
            context.optimization_config.model_formulation.enable_dc_minimum_stores_constraint
            == True
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "dc_minimum_stores_constraint is set to True"
        )
        penalty_dc_min_stores = context.optimization_config.model_formulation.penalty_dc_min_stores
        slack_dc_min_stores = getattr(opti_data, "slack_dc_min_stores", {})

        if slack_dc_min_stores:
            objective_function -= penalty_dc_min_stores * lpSum(
                slack_dc_min_stores[key] for key in slack_dc_min_stores
            )
        else:
            log.warning("enable_dc_minimum_stores_constraint is True but no slack_dc_min_stores variables found")
 
    if (
            context.optimization_config.model_formulation.enable_item_store_count_change_min
            == True
            and len(context.optimization.model_formulation.dict_item_pod_min_change) > 0
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "item_store_count_change_min is set to True"
        )
        
        penalty_store_count_min_change = context.optimization_config.model_formulation.penalty_store_count_min_change
        slack_store_count_min_change = getattr(opti_data, "slack_store_count_min_change", {})
        if slack_store_count_min_change:
            objective_function -= penalty_store_count_min_change * lpSum(
                slack_store_count_min_change[key] for key in slack_store_count_min_change
            )
        else:
            log.warning("enable_item_store_count_change_min is True but no slack_store_count_min_change variables found")

    if (
            context.optimization_config.model_formulation.enable_item_store_count_change_max
            == True
            and len(context.optimization.model_formulation.dict_item_pod_max_change) > 0
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "item_store_count_change_max is set to True"
        )
        
        penalty_store_count_max_change = context.optimization_config.model_formulation.penalty_store_count_max_change
        slack_store_count_max_change = getattr(opti_data, "slack_store_count_max_change", {})
        if slack_store_count_max_change:
            objective_function -= penalty_store_count_max_change * lpSum(
                slack_store_count_max_change[key] for key in slack_store_count_max_change
            )
        else:
            log.warning("enable_item_store_count_change_max is True but no slack_store_count_max_change variables found")
        
    # Add slack variables to objective function if enable_assortment_expansion_reduction is True
    if (
            context.optimization_config.model_formulation.enable_assortment_expansion_reduction
            == True
    ):
        log.info(
            "Add penalty terms to original objective function because enable_"
            "sku_reduction_increase_constraints is set to True"
        )

        log.info("Adding penalties for slack variables to objective function")
        if hasattr(opti_data, "slack_expand"):
            penalty_expand = context.optimization_config.model_formulation.penalty_assortment_expand
            
            objective_function -= penalty_expand * lpSum(
                opti_data.slack_expand[group_key]
                for group_key in opti_data.slack_expand.keys()
            )
            
        elif hasattr(opti_data, "slack_reduce"):
            penalty_reduce = context.optimization_config.model_formulation.penalty_assortment_reduce
    
            objective_function -= penalty_reduce * lpSum(
                opti_data.slack_reduce[group_key]
                for group_key in opti_data.slack_reduce.keys()
            )

    setattr(opti_data, "objective_function", objective_function)
    opti_model.setObjective(objective_function)
    return opti_model, opti_data


def add_all_constraints_to_model(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds all constraints to the model, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf for more
    details.
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with all constraints
    """
    opti_model, opti_data = add_total_used_space_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )
    opti_model, opti_data = add_total_used_facing_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )
        
    if len(opti_data.facings_per_item_forced_guardrail) > 0:
        log.info(
            "Adding forced facings guardrails to items specified in manual constraints"
        )
        opti_model, opti_data = add_items_forced_facings_guardrails_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info(
            "No forced facings guardrails to items specified in manual constraints for this specific problem"
        )

    if context.optimization_config.model_formulation.enable_working_capital_constraints:
        log.info(
            f"Adding working capital constraints to original cluster labels specified"
        )
        opti_model, opti_data = add_min_max_working_capital_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
        )

    opti_model, opti_data = initial_solution_warm_start(
        opti_model=opti_model,
        opti_data=opti_data,
    )

    if (
        len(opti_data.item_POD_threshold_LB) > 0
        or len(opti_data.item_POD_threshold_UB) > 0
    ):
        log.info("Setting item POD threshold constraints")
        opti_model, opti_data = add_item_POD_threshold_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No item POD threshold constraints to apply")

    if (
        len(opti_data.brand_POD_threshold_LB) > 0
        or len(opti_data.brand_POD_threshold_UB) > 0
    ):
        log.info("Setting brand POD threshold constraints")
        opti_model, opti_data = add_brand_POD_threshold_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No brand POD threshold constraints to apply")

    if len(opti_data.dict_item_POD_min_store_idx) > 0:
        log.info("Setting item minimum POD threshold constraints")
        (
            opti_model,
            opti_data,
        ) = add_min_POD_per_item_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No item minimum POD threshold constraints to apply.")

    if len(opti_data.dict_item_POD_max_store_idx) > 0:
        log.info("Setting item maximum POD threshold constraints")
        (
            opti_model,
            opti_data,
        ) = add_max_POD_per_item_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No item maximum POD threshold constraints to apply.")

    if context.optimization_config.model_formulation.enable_dc_minimum_stores_constraint:
        log.info("Setting minimum store per DC constraints")
        (
            opti_model,
            opti_data,
        ) = add_dc_minimum_stores_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No minimum DC per store constraints to apply.")

    if len(opti_data.dict_item_pod_min_change_idx) > 0:
        log.info("Setting item store count change constraints")
        (
            opti_model,
            opti_data,
        ) = add_item_store_count_min_change_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No item store count min change constraints to apply.")

    if len(opti_data.dict_item_pod_max_change_idx) > 0:
        log.info("Setting item store count change constraints")
        (
            opti_model,
            opti_data,
        ) = add_item_store_count_max_change_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No item store count max change constraints to apply.")

    if (
        context.optimization_config.model_formulation.enable_enforce_as_many_need_states_as_possible_constraint
        == True
    ):
        log.info(
            "Setting enforce as many need states represented as possible constraint"
        )
        opti_model, opti_data = add_min_number_need_states_represented_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )

    opti_model, opti_data = add_at_most_one_facing_value_assigned_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )
    opti_model, opti_data = add_max_incremental_facings_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )

    opti_model, opti_data = add_max_decremental_facings_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )

    opti_model, opti_data = add_max_facings_in_plano_cat_constraint(
        opti_model=opti_model,
        opti_data=opti_data,
    )

    if (
        context.optimization_config.model_formulation.enable_min_max_need_state_facings_constraint
        == True
    ):
        opti_model, opti_data = add_min_max_need_state_facings_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )

    if len(opti_data.max_pct_drop_own_brand_space) > 0:
        log.info("Setting max % drop of allocated space to Own Brands Constraint")
        opti_model, opti_data = add_max_pct_drop_own_brand_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    elif (len(opti_data.min_pct_allocated_from_total_space_to_own_brands) > 0) and (
        len(opti_data.max_pct_allocated_from_total_space_to_own_brands) > 0
    ):  # They need to both be non-null
        log.info("Setting % range of allocated space to Own Brands Constraint")
        (
            opti_model,
            opti_data,
        ) = add_pct_range_allocated_own_brand_from_total_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info(
            "No % range of allocated space to Own Brand constraint was specified for this specific problem"
        )

    # Supplier / Brand related space constraints: % change in facings
    if len(opti_data.dict_bounds_constraint_supplier_space_pct_change_facings) > 0:
        log.info("Setting supplier total % change in facings constraint")
        (
            opti_model,
            opti_data,
        ) = add_facings_pct_change_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="supplier",
        )
    elif len(opti_data.dict_bounds_constraint_brand_space_pct_change_facings) > 0:
        log.info("Setting brand total % change in facings constraint")
        (
            opti_model,
            opti_data,
        ) = add_facings_pct_change_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="brand",
        )
    else:
        log.info("No supplier/brand constraint based on % change in facings")

    # Supplier / Brand related space constraints: % allocated linear space
    if (
        len(opti_data.dict_bounds_constraint_supplier_space_pct_allocated_linear_space)
        > 0
    ):
        log.info("Setting supplier % allocated linear space constraint")
        (
            opti_model,
            opti_data,
        ) = add_pct_allocated_linear_space_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="supplier",
        )
    elif (
        len(opti_data.dict_bounds_constraint_brand_space_pct_allocated_linear_space) > 0
    ):
        log.info("Setting brand % allocated linear space constraint")
        (
            opti_model,
            opti_data,
        ) = add_pct_allocated_linear_space_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="brand",
        )
    else:
        log.info("No supplier/brand constraint based on % allocated linear space")

    # Supplier / Brand related space constraints: total number of facings
    if len(opti_data.dict_bounds_constraint_supplier_space_total_number_facings) > 0:
        log.info("Setting supplier total # of facings constraint")
        (
            opti_model,
            opti_data,
        ) = add_facings_allowed_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="supplier",
        )
    elif len(opti_data.dict_bounds_constraint_brand_space_total_number_facings) > 0:
        log.info("Setting brand total # of facings constraint")
        (
            opti_model,
            opti_data,
        ) = add_facings_allowed_supplier_or_brand_guardrail_constraints(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="brand",
        )
    else:
        log.info(
            "No supplier/brand constraint based on total number of facings allowed"
        )

    if len(opti_data.dict_brand_global_linear_space_change_constraints) > 0:
        log.info("Setting brand global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="brand"
        )
    elif len(opti_data.dict_supplier_global_linear_space_change_constraints) > 0:
        log.info("Setting supplier global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="supplier"
        )
    elif len(opti_data.dict_need_states_global_linear_space_change_constraints) > 0:
        log.info("Setting need states global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="need_states"
        )
    elif len(opti_data.dict_cdt_global_linear_space_change_constraints) > 0:
        log.info("Setting choice map global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="choice_map"
        )
    elif len(opti_data.dict_subcat_global_linear_space_change_constraints) > 0:
        log.info("Setting sub-category global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="subcat"
        )
    elif len(opti_data.dict_segment_global_linear_space_change_constraints) > 0:
        log.info("Setting segment global linear space allowed")
        (
            opti_model,
            opti_data,
        ) = add_global_total_linear_space_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
            dimension="segment"
        )
    else:
        log.info(
            "No constraint based on global total linear space allowed"
        )

    # Pivot/Linked SKU pairs constraint
    if len(opti_data.dict_cluster_plano_pivot_to_linked_skus) > 0:
        log.info("Setting pivot/linked SKU pairs constraints")
        (
            opti_model,
            opti_data,
        ) = add_pivot_linked_sku_pairs_constraint(
            opti_model=opti_model,
            opti_data=opti_data,
        )
    else:
        log.info("No pivot/linked SKU pairs constraint to apply")

    # Add constraints for SKU increase and reduction:
    if (
            context.optimization_config.model_formulation.enable_assortment_expansion_reduction
            == True
            and len(opti_data.dict_assortment_expansion_reduction_idx) > 0
    ):
        log.info("Setting SKU increase and reduction constraints")
        (
            opti_model,
            opti_data,
        ) = add_assortment_percent_change_constraints(
            opti_model=opti_model,
            opti_data=opti_data
        )
    else:
        log.info("No SKU increase or reduction constraint to apply")

    return opti_model, opti_data


def add_min_max_working_capital_constraints(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds minimum and maximum working capital constraints to an optimization model.

    This function introduces two sets of constraints (minimum and maximum working capital)
    based on the specified inventory-on-hand (IOH) budgets and percentage constraints for
    each original cluster label. The constraints are added to the `opti_model` and updated
    in `opti_data`, ensuring that the working capital allocated to each cluster remains
    within the defined limits.

    Parameters:
        opti_model (LpProblem): The optimization model where constraints are applied.
        opti_data (OptimizationModelData): The data required for optimization, containing
            IOH budgets, items, clusters, and constraint parameters.

    Returns:
        Tuple[LpProblem, OptimizationModelData]: The updated optimization model and data
            object with the newly added constraints.

    Constraints:
        - Minimum Working Capital: Ensures that the allocated inventory budget for each
          cluster does not fall below a minimum threshold.
        - Maximum Working Capital: Ensures that the allocated inventory budget for each
          cluster does not exceed a maximum threshold.

    Attributes in `opti_data`:
        - `min_inventory_constraint`: A dictionary storing the minimum working capital
          constraints by cluster.
        - `max_inventory_constraint`: A dictionary storing the maximum working capital
          constraints by cluster.

    Examples:
        >>> model, data = add_min_max_working_capital_constraints(opti_model, opti_data)
        >>> # The model now has additional constraints on working capital for each cluster.
    """
    min_inventory_constraint = {
        c_: LpConstraint(
            e=lpSum(
                opti_data.x_vars[(i, f, c, g)]
                * opti_data.ioh_cost_per_facing[(i, f, c_)]
                for c in opti_data.final_cluster_by_original_cluster[c_]
                for g in opti_data.plano_fixture_by_cluster[c]
                for i in opti_data.items_per_c_g[(c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintGE,
            rhs=(
                (
                    opti_data.cluster_ioh_full_budget[c_]
                )
                * (1 + opti_data.min_pct_ioh_constraint[c_])
            ),
            name=f"{opti_data.problem_id}_working_capital_constraint_min_{c_}",
        )
        for c_ in opti_data.original_cluster_labels_ioh_constrained
    }

    max_inventory_constraint = {
        c_: LpConstraint(
            e=lpSum(
                opti_data.x_vars[(i, f, c, g)]
                * opti_data.ioh_cost_per_facing[(i, f, c_)]
                for c in opti_data.final_cluster_by_original_cluster[c_]
                for g in opti_data.plano_fixture_by_cluster[c]
                for i in opti_data.items_per_c_g[(c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintLE,
            rhs=(
                (
                    opti_data.cluster_ioh_full_budget[c_]
                )
                * (1 + opti_data.max_pct_ioh_constraint[c_])
            ),
            name=f"{opti_data.problem_id}_working_capital_constraint_max_{c_}",
        )
        for c_ in opti_data.original_cluster_labels_ioh_constrained
    }

    # Store the constraints in opti_data
    setattr(opti_data, "min_inventory_constraint", min_inventory_constraint)
    setattr(opti_data, "max_inventory_constraint", max_inventory_constraint)

    # Add constraints to the optimization model
    for c_ in opti_data.original_cluster_labels_ioh_constrained:
        log.info(
            f"Setting min={opti_data.min_pct_ioh_constraint[c_]} and max={opti_data.max_pct_ioh_constraint[c_]} "
            f"working capital constraints for original cluster {opti_data.original_idx_to_original_cluster[c_]}",
        )
        opti_model.addConstraint(constraint=min_inventory_constraint[c_])
        opti_model.addConstraint(constraint=max_inventory_constraint[c_])

    return opti_model, opti_data


def add_total_used_space_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds total used space constraint, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf for more
    details. Makes sure the space allocation doesn’t go above the total linear space available, but also leaves some
    pre-determined space within that POG category for local items (LR)
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """

    total_used_space_constraint = {
        (c, g): LpConstraint(
            e=(
                opti_data.total_linear_space_in_dept[c, g]
                - lpSum(
                    opti_data.x_vars[(i, f, c, g)]
                    * opti_data.item_width_x_facings[(i, f, c, g)]
                    for (i, f) in opti_data.eligible_if_for_cg[(c, g)]
                )
            ),
            sense=LpConstraintGE,
            rhs=opti_data.local_items_reserved_linear_space[c, g],
            name=f"{opti_data.problem_id}_total_used_space_constraint_{c}_{g}",
        )
        for (c, g) in opti_data.eligible_cg 
        if g not in opti_data.facing_only_constrained_planos
    }

    setattr(
        opti_data,
        "total_used_space_constraint",
        total_used_space_constraint,
    )
    for c, g in opti_data.eligible_cg:
        if g not in opti_data.facing_only_constrained_planos:
            opti_model.addConstraint(constraint=total_used_space_constraint[(c, g)])

    return opti_model, opti_data


def add_total_used_facing_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds total used space constraint. Makes sure the space allocation doesn’t go above the facing count space available. 
    This is used for POGs which have bins/pull cards with pre-set space. 
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """

    total_used_facing_constraint = {
        (c, g): LpConstraint(
            e=(
                opti_data.total_facings_space_in_dept[c, g]
                - lpSum(
                    opti_data.x_vars[(i, f, c, g)]
                    * f
                    for (i, f) in opti_data.eligible_if_for_cg[(c, g)]
                )
            ),
            sense=LpConstraintGE,
            rhs=0,
            name=f"{opti_data.problem_id}_total_used_facings_constraint_{c}_{g}",
        )
        for (c, g) in opti_data.eligible_cg
        if g not in opti_data.linear_space_only_constrained_planos
    }

    setattr(
        opti_data,
        "total_used_facings_constraint",
        total_used_facing_constraint,
    )
    for c, g in opti_data.eligible_cg:
        if g not in opti_data.linear_space_only_constrained_planos:
            opti_model.addConstraint(constraint=total_used_facing_constraint[(c, g)])

    return opti_model, opti_data


def add_items_forced_facings_guardrails_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds items held with constant facings, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf for more
    details. Makes sure that for all with forced guardrails in number of facings, the number of facings that are
    inside the specified range are forced to sum to 1 in the optimizer so that at least one of them is actually 1
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    dict_items_forced_facings_guardrails_constraint = {
        (i, c, g): LpConstraint(
            e=lpSum(
                opti_data.x_vars[(i, f, c, g)]
                for f in opti_data.facings_per_item_forced_guardrail[(i, c, g)]
            ),
            sense=LpConstraintEQ,
            rhs=1,
            name=f"{opti_data.problem_id}_items_forced_facings_guardrails_constraint_{i}_{c}_{g}",
        )
        for (i, c, g) in opti_data.facings_per_item_forced_guardrail
    }
    setattr(
        opti_data,
        "dict_items_forced_facings_guardrails_constraint",
        dict_items_forced_facings_guardrails_constraint,
    )
    for i, c, g in dict_items_forced_facings_guardrails_constraint:
        opti_model.addConstraint(
            constraint=dict_items_forced_facings_guardrails_constraint[(i, c, g)]
        )

    return opti_model, opti_data


def initial_solution_warm_start(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Initializes the optimization model with a warm start by setting initial values
    for variables associated with the smallest non-regional items per need state.

    This function iterates through the dictionary of smallest non-regional items for
    each need state and assigns an initial value of 1 to the decision variables
    (`x_vars`) that correspond to eligible combinations of customer groups (`cg`)
    for these items. This warm start helps the solver by providing a feasible
    starting point, potentially reducing the time to find the optimal solution.

    Args:
        opti_model (LpProblem): The linear programming model to be solved.
        opti_data (OptimizationModelData): Data object containing optimization-related
            information such as decision variables, eligibility mappings, and the
            smallest non-regional item dictionary for each need state.

    Returns:
        Tuple[LpProblem, OptimizationModelData]: The modified optimization model
        and data object with updated variable values for warm starting.
    """
    # Set initial values for the smallest non-regional items
    for ns in opti_data.smallest_non_regional_item_per_need_state_dict.keys():
        i = opti_data.smallest_non_regional_item_per_need_state_dict[ns]
        eligible_cg = [
            (c, g)
            for (c, g) in opti_data.eligible_cg
            if (i, c, g) in opti_data.eligible_icg
        ]
        for c, g in eligible_cg:
            opti_data.x_vars[(i, 1, c, g)].varValue = 1

    return opti_model, opti_data


def add_item_POD_threshold_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    for i in opti_data.items_all:
        eligible_cg = [
            (c, g)
            for (c, g) in opti_data.eligible_cg
            if (i, c, g) in opti_data.eligible_icg
        ]
        opti_model.addConstraint(
            lpSum(
                opti_data.x_vars[(i, f, c, g)]
                for f in opti_data.facings_per_item[i][1:]
                # The [1:] excludes the 0th facing because we want at least one non-zero facing
                for (c, g) in eligible_cg
            )
            >= opti_data.y_vars[i],
            f"{opti_data.problem_id}_link_x_y_binary_{i}",
        )

    for i in opti_data.items_all:
        eligible_cg = [
            (c, g)
            for (c, g) in opti_data.eligible_cg
            if (i, c, g) in opti_data.eligible_icg
        ]
        bigM = (
            len(opti_data.facings_per_item[i])
            * len(opti_data.clusters)
            * len(opti_data.all_plano_fixture)
        )

        opti_model.addConstraint(
            lpSum(
                opti_data.x_vars[(i, f, c, g)]
                for f in opti_data.facings_per_item[i][1:]
                # The [1:] excludes the 0th facing because we want at least one non-zero facing
                for (c, g) in eligible_cg
            )
            / bigM
            <= opti_data.y_vars[i],
            f"{opti_data.problem_id}_link_x_y_binary2_{i}",
        )

    # add hard enforcement of item
    for i in opti_data.item_POD_enforce_type.keys():
        POD_enforce_type = opti_data.item_POD_enforce_type[i].lower()
        if "hard" in POD_enforce_type:
            opti_model.addConstraint(
                opti_data.y_vars[i] == 1,
                f"{opti_data.problem_id}_force_POD_{i}",
            )
            if i in opti_data.item_POD_threshold_LB.keys():
                log.info(
                    f"Forcing POD for item {opti_data.item_idx_to_item_no[i]} with at least {opti_data.item_POD_threshold_LB[i]} POD enforced"
                )
            if i in opti_data.item_POD_threshold_UB.keys():
                log.info(
                    f"Forcing POD for item {opti_data.item_idx_to_item_no[i]} with at most {opti_data.item_POD_threshold_UB[i]} POD enforced"
                )

    # item POD LB threshold constraint
    for i in opti_data.item_POD_threshold_LB.keys():
        eligible_cg = [
            (c, g)
            for (c, g) in opti_data.eligible_cg
            if (i, c, g) in opti_data.eligible_icg
        ]

        opti_model.addConstraint(
            lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)])
                * opti_data.store_count_by_cluster_plano[(c, g)]
                for (c, g) in eligible_cg
            )
            >= opti_data.item_POD_threshold_LB[i] * opti_data.y_vars[i],
            f"{opti_data.problem_id}_item_POD_threshold_LB_{i}",
        )

    # item POD UB threshold constraint
    for ii in opti_data.item_POD_threshold_UB.keys():
        eligible_cg = [
            (c, g)
            for (c, g) in opti_data.eligible_cg
            if (ii, c, g) in opti_data.eligible_icg
        ]

        opti_model.addConstraint(
            lpSum(
                (1 - opti_data.x_vars[(ii, 0, c, g)])
                * opti_data.store_count_by_cluster_plano[(c, g)]
                for (c, g) in eligible_cg
            )
            <= opti_data.item_POD_threshold_UB[ii] * opti_data.y_vars[ii],
            f"{opti_data.problem_id}_item_POD_threshold_UB_{ii}",
        )

    return opti_model, opti_data


def add_brand_POD_threshold_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    # brand POD LB threshold constraint
    for b in opti_data.brand_POD_threshold_LB.keys():
        opti_model.addConstraint(
            lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)])
                * opti_data.store_count_by_cluster_plano[(c, g)]
                for (i, c, g) in opti_data.eligible_icg
                if i in opti_data.items_per_brand[b]
            )
            >= opti_data.brand_POD_threshold_LB[b],
            f"{opti_data.problem_id}_brand_POD_threshold_LB_{b}",
        )
        log.info(
            f"Forcing POD for brand {opti_data.brand_idx_to_brand[b]} with at least {opti_data.brand_POD_threshold_LB[b]} POD enforced"
        )

    # brand POD UB threshold constraint
    for b in opti_data.brand_POD_threshold_UB.keys():
        opti_model.addConstraint(
            lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)])
                * opti_data.store_count_by_cluster_plano[(c, g)]
                for (i, c, g) in opti_data.eligible_icg
                if i in opti_data.items_per_brand[b]
            )
            <= opti_data.brand_POD_threshold_UB[b],
            f"{opti_data.problem_id}_brand_POD_threshold_UB_{b}",
        )
        log.info(
            f"Forcing POD for brand {opti_data.brand_idx_to_brand[b]} with at most {opti_data.brand_POD_threshold_UB[b]} POD enforced"
        )

    return opti_model, opti_data



def add_min_number_need_states_represented_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds constraints to the optimization model to ensure that at least a specified
    number of need states (NS) are represented in each (c, g) pair from
    `opti_data.select_min_NS`.

    This function creates binary variables for each need state and links them to the
    decision variables (x_vars). It then adds constraints to ensure that at least the
    specified number of need states are selected for each category-group pair.

    Args:
        opti_model (LpProblem): The optimization model to which the constraints will be added.
        opti_data (OptimizationModelData): The optimization data containing relevant variables
                                           and eligible category-group pairs.

    Returns:
        Tuple[LpProblem, OptimizationModelData]: A tuple containing the updated optimization
        model and optimization data, with added constraints and binary variables.

    Attributes:
        ns_selection_vars (dict): A dictionary mapping (n, c, g) tuples to their corresponding
                                  binary variables. Stored in `opti_data`.
        constraints_min_number_ns (dict): A dictionary mapping (c, g) pairs to their corresponding
                                           constraints that enforce the minimum number of need states.
                                           Stored in `opti_data`.
    """
    # Create ns_selection_vars variable for (n, c, g)
    ns_selection_vars = {}
    for c, g in opti_data.select_min_NS:
        for n in opti_data.ns_per_c_g[(c, g)]:
            ns_selection_vars[(n, c, g)] = LpVariable(
                f"selected_ns_{n}_{c}_{g}", cat="Binary"
            )

    # Define ns_selection_vars (that links x_vars[(i, f, c, g)]);
    # this variable should be 0 if need state n isn't represented at all, 1 otherwise
    for c, g in opti_data.select_min_NS:
        for n in opti_data.ns_per_c_g[(c, g)]:
            opti_model.addConstraint(
                lpSum(
                    opti_data.x_vars[(i, f, c, g)]
                    for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                    for f in opti_data.facings_per_item[i][1:]
                    # The [1:] excludes the 0th facing because we want at least one non-zero facing in the need state
                )
                >= ns_selection_vars[(n, c, g)],
                f"{opti_data.problem_id}_link_ns_selection1_{n}_{c}_{g}",
            )

    for c, g in opti_data.select_min_NS:
        for n in opti_data.ns_per_c_g[(c, g)]:
            available_items = opti_data.items_per_need_state_c_g[(n, c, g)]
            bigM = len(available_items) * max(
                len(opti_data.facings_per_item[i]) for i in available_items
            )
            opti_model.addConstraint(
                lpSum(
                    opti_data.x_vars[(i, f, c, g)]
                    for i in available_items
                    for f in opti_data.facings_per_item[i][1:]
                    # The [1:] excludes the 0th facing because we want at least one non-zero facing in the need state
                )
                / bigM
                <= ns_selection_vars[(n, c, g)],
                f"{opti_data.problem_id}_link_ns_selection2_{n}_{c}_{g}",
            )

    # Initialize the dictionary to hold the 75% constraints
    constraints_min_number_ns = {}
    # Create slack variables
    slack_min_ns_vars = {}
    for c, g in opti_data.select_min_NS:
        slack_min_ns_vars[(c, g)] = LpVariable(
            f"{opti_data.problem_id.replace('-', '_')}_slack_min_ns_{c}_{g}",
            lowBound=0,
            cat="Continuous",
        )
    # Loop over each (c, g) in opti_data.select_min_NS
    for c, g in opti_data.select_min_NS:
        # Calculate 75% of total need states (round up if needed)
        min_number_ns = opti_data.select_min_NS[(c, g)]

        # Create a constraint ensuring at least 75% of the need states are selected
        constraints_min_number_ns[(c, g)] = LpConstraint(
            e=(
                lpSum(
                    ns_selection_vars[(n, c, g)] for n in opti_data.ns_per_c_g[(c, g)]
                )
                + slack_min_ns_vars[(c, g)]
            ),
            sense=LpConstraintEQ,
            rhs=min_number_ns,
            name=f"{opti_data.problem_id}_constraints_min_number_ns_{c}_{g}",
        )

    setattr(opti_data, "ns_selection_vars", ns_selection_vars)
    setattr(opti_data, "constraints_min_number_ns", constraints_min_number_ns)
    setattr(opti_data, "slack_min_ns_vars", slack_min_ns_vars)

    # Add the constraints to the optimization model
    for c, g in constraints_min_number_ns:
        opti_model.addConstraint(constraint=constraints_min_number_ns[(c, g)])

    return opti_model, opti_data


def add_at_most_one_facing_value_assigned_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds at most one facing value assigned constraint, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf
    for more details. Exactly one facing possibility is selected for a given item.
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    dict_at_most_one_facing_value_assigned_constraint = {
        (i, c, g): LpConstraint(
            e=lpSum(
                opti_data.x_vars[(i, f, c, g)] for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintEQ,
            rhs=1,
            name=f"{opti_data.problem_id}_at_most_one_facing_value_assigned_constraint_{i}_{c}_{g}",
        )
        for (i, c, g) in opti_data.eligible_icg
    }
    setattr(
        opti_data,
        "dict_at_most_one_facing_value_assigned_constraint",
        dict_at_most_one_facing_value_assigned_constraint,
    )
    for i, c, g in opti_data.eligible_icg:
        opti_model.addConstraint(
            constraint=dict_at_most_one_facing_value_assigned_constraint[(i, c, g)]
        )

    return opti_model, opti_data


def add_max_incremental_facings_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    This constraint enforces that a SKU can't get more than 3 (config-driven) incremental facings from its current
    number of facings:
    - If SKU A currently has 2 facings in the representative store, then the optimizer cannot assign more than 5
    facings to it
    - Notice that this constraint only applies to increase in the number of facings, see add_max_decremental_facings_constraint for handling increase.
    - Items with facing guardrails are excluded from this constraint as they have their own facing restrictions.
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with the constraints described above
    """
    
    # Get set of items with facing guardrails to exclude
    items_with_guardrails = set()
    if len(opti_data.facings_per_item_forced_guardrail) > 0:
        for (i, c, g) in opti_data.facings_per_item_forced_guardrail.keys():
            items_with_guardrails.add((i, c, g))
    
    # Filter out items with facing guardrails from the constraint
    filtered_constraints = {}
    excluded_count = 0
    total_original_count = 0
    
    for (i, c, g) in opti_data.facings_per_item_ineligible_max_incremental:
        total_original_count += len(opti_data.facings_per_item_ineligible_max_incremental[(i, c, g)])
        
        if (i, c, g) not in items_with_guardrails:
            # Only add constraint if item doesn't have facing guardrails
            filtered_constraints[(i, c, g)] = opti_data.facings_per_item_ineligible_max_incremental[(i, c, g)]
        else:
            excluded_count += len(opti_data.facings_per_item_ineligible_max_incremental[(i, c, g)])
    
    dict_max_incremental_facings_constraint = {
        (i, f, c, g): LpConstraint(
            e=opti_data.x_vars[(i, f, c, g)],
            sense=LpConstraintEQ,
            rhs=0,
            name=f"{opti_data.problem_id}_max_incremental_facings_constraint_{i}_{f}_{c}_{g}",
        )
        for (i, c, g) in filtered_constraints
        for f in filtered_constraints[(i, c, g)]
    }
    
    setattr(
        opti_data,
        "dict_max_incremental_facings_constraint",
        dict_max_incremental_facings_constraint,
    )
    
    for i, c, g in filtered_constraints:
        for f in filtered_constraints[(i, c, g)]:
            opti_model.addConstraint(
                constraint=dict_max_incremental_facings_constraint[(i, f, c, g)]
            )

    if excluded_count > 0:
        log.info(f"Excluded {excluded_count} max incremental facing constraints out of {total_original_count} total constraints due to items having facing guardrails")
    else:
        log.info("No items excluded from max incremental facings constraint")

    return opti_model, opti_data


def add_max_decremental_facings_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    This constraint enforces that a SKU can't lose more than 3 (config-driven) facings from its current
    number of facings:
    - If SKU A currently has 5 facings in the representative store, then the optimizer cannot assign fewer than 2
    facings to it
    - Notice that this constraint only applies to decrease in the number of facings, see add_max_incremental_facings_constraint for handling increase.
    - Items with facing guardrails are excluded from this constraint as they have their own facing restrictions.

    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with the constraints described above
    """
    
    # Get set of items with facing guardrails to exclude
    items_with_guardrails = set()
    if len(opti_data.facings_per_item_forced_guardrail) > 0:
        for (i, c, g) in opti_data.facings_per_item_forced_guardrail.keys():
            items_with_guardrails.add((i, c, g))
    
    # Filter out items with facing guardrails from the constraint
    filtered_constraints = {}
    excluded_count = 0
    total_original_count = 0
    
    for (i, c, g) in opti_data.facings_per_item_ineligible_max_decremental:
        total_original_count += len(opti_data.facings_per_item_ineligible_max_decremental[(i, c, g)])
        
        if (i, c, g) not in items_with_guardrails:
            # Only add constraint if item doesn't have facing guardrails
            filtered_constraints[(i, c, g)] = opti_data.facings_per_item_ineligible_max_decremental[(i, c, g)]
        else:
            excluded_count += len(opti_data.facings_per_item_ineligible_max_decremental[(i, c, g)])
    
    dict_max_decremental_facings_constraint = {
        (i, f, c, g): LpConstraint(
            e=opti_data.x_vars[(i, f, c, g)],
            sense=LpConstraintEQ,
            rhs=0,
            name=f"{opti_data.problem_id}_max_decremental_facings_constraint_{i}_{f}_{c}_{g}",
        )
        for (i, c, g) in filtered_constraints
        for f in filtered_constraints[(i, c, g)]
    }

    setattr(
        opti_data,
        "dict_max_decremental_facings_constraint",
        dict_max_decremental_facings_constraint,
    )

    for i, c, g in filtered_constraints:
        for f in filtered_constraints[(i, c, g)]:
            opti_model.addConstraint(
                constraint=dict_max_decremental_facings_constraint[(i, f, c, g)]
            )

    if excluded_count > 0:
        log.info(f"Excluded {excluded_count} max decremental facing constraints out of {total_original_count} total constraints due to items having facing guardrails")
    else:
        log.info("No items excluded from max decremental facings constraint")

    return opti_model, opti_data


def add_max_facings_in_plano_cat_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    This constraint enforces that the maximum number of facings that any SKU can get is at most the 95th percentile of
    facings assigned within the POG category, to which we add a config-driven parameter (e.g. 2). For example:
    If for Vitamins in Cluster 0C for 21ft POGs, the 95th percentile of facings we observe for any given SKU is 6, then
    the maximum amount of facings a SKU can ever get assigned by the optimizer will be 6+2 = 8
    Notice that opti_data.facings_per_item_above_max_authorized_in_dept wil already start at 9 (so it will already
    take into account the extra config-driven facings, in our example 2)
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with the constraints described above
    """
    dict_max_facings_in_plano_cat_constraint = {
        (i, f, c, g): LpConstraint(
            e=opti_data.x_vars[(i, f, c, g)],
            sense=LpConstraintEQ,
            rhs=0,
            name=f"{opti_data.problem_id}_max_facings_in_plano_cat_constraint_{i}_{f}_{c}_{g}",
        )
        for (i, c, g) in opti_data.facings_per_item_above_max_authorized_in_dept
        for f in opti_data.facings_per_item_above_max_authorized_in_dept[(i, c, g)]
    }
    setattr(
        opti_data,
        "dict_max_facings_in_plano_cat_constraint",
        dict_max_facings_in_plano_cat_constraint,
    )
    for i, c, g in opti_data.facings_per_item_above_max_authorized_in_dept:
        for f in opti_data.facings_per_item_above_max_authorized_in_dept[(i, c, g)]:
            opti_model.addConstraint(
                constraint=dict_max_facings_in_plano_cat_constraint[(i, f, c, g)]
            )

    return opti_model, opti_data


def add_min_max_need_state_facings_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds min/max need state facings constraints. Min constraints remain hard.
    Max constraints are soft for need states containing pivot/linked SKU pairs OR items with facing guardrails,
    hard for all others.
    """
    # Add min constraint (always hard)
    n_c_g_w_min_facings_per_need_state_requirement = set(
        opti_data.min_facings_per_need_state.keys()
    ) & set(opti_data.items_per_need_state_c_g.keys())
    dict_min_need_state_facings_constraint = {
        (n, c, g): LpConstraint(
            e=lpSum(
                f * opti_data.x_vars[(i, f, c, g)]
                for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintGE,
            rhs=opti_data.min_facings_per_need_state[(n, c, g)],
            name=f"{opti_data.problem_id}_min_need_state_facings_constraint_{n}_{c}_{g}",
        )
        for (n, c, g) in n_c_g_w_min_facings_per_need_state_requirement
    }
    setattr(
        opti_data,
        "dict_min_need_state_facings_constraint",
        dict_min_need_state_facings_constraint,
    )
    for n, c, g in dict_min_need_state_facings_constraint:
        opti_model.addConstraint(
            constraint=dict_min_need_state_facings_constraint[(n, c, g)]
        )

    # Add max constraint (soft for need states with pivot/linked SKUs OR facing guardrails, hard for others)
    n_c_g_w_max_facings_per_need_state_requirement = set(
        opti_data.max_facings_per_need_state.keys()
    ) & set(opti_data.items_per_need_state_c_g.keys())
    
    # Identify need states that contain pivot/linked SKUs OR items with facing guardrails
    need_states_with_special_items = set()
    
    # First, identify need states with pivot/linked SKUs (existing logic)
    if len(opti_data.dict_cluster_plano_pivot_to_linked_skus) > 0:
        for (c, g) in opti_data.dict_cluster_plano_pivot_to_linked_skus.keys():
            pivot_items = set(opti_data.dict_cluster_plano_pivot_to_linked_skus[(c, g)].keys())
            linked_items = set()
            for pivot_item, linked_list in opti_data.dict_cluster_plano_pivot_to_linked_skus[(c, g)].items():
                linked_items.update(linked_list)
            
            pivot_linked_items = pivot_items | linked_items
            
            # Find need states containing these items
            for (n, c_check, g_check) in n_c_g_w_max_facings_per_need_state_requirement:
                if c_check == c and g_check == g:
                    items_in_need_state = set(opti_data.items_per_need_state_c_g[(n, c, g)])
                    if pivot_linked_items & items_in_need_state:  # If there's intersection
                        need_states_with_special_items.add((n, c, g))
    
    # Second, identify need states with items that have facing guardrails (new logic)
    if len(opti_data.facings_per_item_forced_guardrail) > 0:
        # Get items with guardrails by cluster/plano
        items_with_guardrails_by_cg = {}
        for (i, c, g) in opti_data.facings_per_item_forced_guardrail.keys():
            if (c, g) not in items_with_guardrails_by_cg:
                items_with_guardrails_by_cg[(c, g)] = set()
            items_with_guardrails_by_cg[(c, g)].add(i)
        
        # Find need states containing items with guardrails
        for (n, c, g) in n_c_g_w_max_facings_per_need_state_requirement:
            if (c, g) in items_with_guardrails_by_cg:
                items_in_need_state = set(opti_data.items_per_need_state_c_g[(n, c, g)])
                guardrail_items = items_with_guardrails_by_cg[(c, g)]
                if guardrail_items & items_in_need_state:  # If there's intersection
                    need_states_with_special_items.add((n, c, g))
    
    # Separate need states into soft and hard constraint groups
    soft_constraint_need_states = need_states_with_special_items
    hard_constraint_need_states = n_c_g_w_max_facings_per_need_state_requirement - soft_constraint_need_states
    
    slack_max_need_state_facings = {}
    dict_max_need_state_facings_constraint = {}
    
    # Add soft max constraints for need states with pivot/linked SKUs OR facing guardrails
    if soft_constraint_need_states:
        for (n, c, g) in soft_constraint_need_states:
            # Create slack variable
            slack_var = LpVariable(
                f"slack_max_ns_facings_{n}_{c}_{g}",
                lowBound=0,
                cat="Continuous"
            )
            slack_max_need_state_facings[(n, c, g)] = slack_var
            
            # Create soft constraint
            dict_max_need_state_facings_constraint[(n, c, g)] = LpConstraint(
                e=lpSum(
                    f * opti_data.x_vars[(i, f, c, g)]
                    for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                    for f in opti_data.facings_per_item[i]
                ) - slack_var,
                sense=LpConstraintLE,
                rhs=opti_data.max_facings_per_need_state[(n, c, g)],
                name=f"{opti_data.problem_id}_soft_max_need_state_facings_constraint_{n}_{c}_{g}",
            )
        
        log.info(f"Added {len(soft_constraint_need_states)} soft max need state facings constraints for need states with pivot/linked SKUs or facing guardrails")
    
    # Add hard max constraints for all other need states
    if hard_constraint_need_states:
        for (n, c, g) in hard_constraint_need_states:
            dict_max_need_state_facings_constraint[(n, c, g)] = LpConstraint(
                e=lpSum(
                    f * opti_data.x_vars[(i, f, c, g)]
                    for i in opti_data.items_per_need_state_c_g[(n, c, g)]
                    for f in opti_data.facings_per_item[i]
                ),
                sense=LpConstraintLE,
                rhs=opti_data.max_facings_per_need_state[(n, c, g)],
                name=f"{opti_data.problem_id}_hard_max_need_state_facings_constraint_{n}_{c}_{g}",
            )
        
        log.info(f"Added {len(hard_constraint_need_states)} hard max need state facings constraints for need states without pivot/linked SKUs or facing guardrails")
    
    # Store slack variables (only exists if soft constraints were created)
    if slack_max_need_state_facings:
        setattr(opti_data, "slack_max_need_state_facings", slack_max_need_state_facings)
    
    setattr(
        opti_data,
        "dict_max_need_state_facings_constraint",
        dict_max_need_state_facings_constraint,
    )
    for n, c, g in dict_max_need_state_facings_constraint:
        opti_model.addConstraint(
            constraint=dict_max_need_state_facings_constraint[(n, c, g)]
        )

    return opti_model, opti_data


def add_max_pct_drop_own_brand_space_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds max % drop in own brand space constraint, see latest docs/Space_Assortment_Optimization_Formulation_vX.pdf for
    more details; e.g. if own brands have 100ft of total linear space, the minimum they can end up with post-optimizer
    is 90ft if that max percent drop is 10%
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """

    max_pct_drop_own_brand_space_constraint = {
        (c, g): LpConstraint(
            e=lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for i in opti_data.items_own_brand_only_per_c_g[(c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintGE,
            rhs=(1 - opti_data.max_pct_drop_own_brand_space[(c, g)])
            * opti_data.total_linear_space_in_dept_for_own_brand[(c, g)],
            name=f"{opti_data.problem_id}_max_pct_drop_own_brand_space_constraint_{c}_{g}",
        )
        for (c, g) in opti_data.max_pct_drop_own_brand_space.keys()
    }

    setattr(
        opti_data,
        "max_pct_drop_own_brand_space_constraint",
        max_pct_drop_own_brand_space_constraint,
    )
    for c, g in opti_data.max_pct_drop_own_brand_space.keys():
        opti_model.addConstraint(
            constraint=max_pct_drop_own_brand_space_constraint[(c, g)]
        )

    return opti_model, opti_data


def add_pct_allocated_linear_space_supplier_or_brand_guardrail_constraints(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    dimension: str,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    This function adds the constraints of % of allocated linear space to a supplier or a brand
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function
        dimension: dimension for which we want to create the constraint, can only be supplier or brand

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    assert dimension in [
        "supplier",
        "brand",
    ], f"Expected 'supplier' or 'brand' got '{dimension}'"
    if dimension == "supplier":
        dict_bounds = (
            opti_data.dict_bounds_constraint_supplier_space_pct_allocated_linear_space
        )
        dimension_indices = opti_data.suppliers
        items_subset = opti_data.items_per_supplier
    else:
        dict_bounds = (
            opti_data.dict_bounds_constraint_brand_space_pct_allocated_linear_space
        )
        dimension_indices = opti_data.brands
        items_subset = opti_data.items_per_brand

    # Add min side of constraint
    dict_pct_allocated_linear_space_supplier_or_brand_guardrail_lower_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[t_or_b]
                for f in opti_data.facings_per_item[i]
                if (i, c, g) in opti_data.eligible_icg
            )
            - (
                dict_bounds[(t_or_b, c, g)][0]
                * lpSum(
                    opti_data.item_width_x_facings[(i, f, c, g)]
                    * opti_data.x_vars[(i, f, c, g)]
                    for i in opti_data.items_per_c_g[(c, g)]
                    for f in opti_data.facings_per_item[i]
                )
            ),
            sense=LpConstraintGE,
            rhs=0.0,  # lower bound {t_or_b, max}
            name=f"{opti_data.problem_id}_pct_allocated_linear_space_allowed_{dimension}_guardrail_lower_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_pct_allocated_linear_space_{dimension}_guardrail_lower_constraint",
        dict_pct_allocated_linear_space_supplier_or_brand_guardrail_lower_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_pct_allocated_linear_space_supplier_or_brand_guardrail_lower_constraint[
                        (t_or_b, c, g)
                    ]
                )

    # Add max side of constraint
    dict_pct_allocated_linear_space_supplier_or_brand_guardrail_upper_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[t_or_b]
                for f in opti_data.facings_per_item[i]
                if (i, c, g) in opti_data.eligible_icg
            )
            - (
                dict_bounds[(t_or_b, c, g)][1]
                * lpSum(
                    opti_data.item_width_x_facings[(i, f, c, g)]
                    * opti_data.x_vars[(i, f, c, g)]
                    for i in opti_data.items_per_c_g[(c, g)]
                    for f in opti_data.facings_per_item[i]
                )
            ),
            sense=LpConstraintLE,
            rhs=0.0,  # upper bound {t_or_b, max}
            name=f"{opti_data.problem_id}_pct_allocated_linear_space_allowed_{dimension}_guardrail_upper_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_pct_allocated_linear_space_{dimension}_guardrail_upper_constraint",
        dict_pct_allocated_linear_space_supplier_or_brand_guardrail_upper_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_pct_allocated_linear_space_supplier_or_brand_guardrail_upper_constraint[
                        (t_or_b, c, g)
                    ]
                )

    return opti_model, opti_data


def add_facings_pct_change_supplier_or_brand_guardrail_constraints(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    dimension: str,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Ensures that the % change in total facings for a given supplier (indexed by t) or brand (indexed by b) is within
    certain bounds (defined by \lambda_{t, min}, \lambda_{t, max} or \lambda_{b, min}, \lambda_{b, max}), here
    present in `dict_bounds_constraint_supplier_space_pct_change_facings` or
    `dict_bounds_constraint_brand_space_pct_change_facings` specified by the user
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function
        dimension: dimension for which we want to create the constraint, can only be supplier or brand

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    assert dimension in [
        "supplier",
        "brand",
    ], f"Expected 'supplier' or 'brand' got '{dimension}'"
    if dimension == "supplier":
        dict_bounds = opti_data.dict_bounds_constraint_supplier_space_pct_change_facings
        dimension_indices = opti_data.suppliers
        items_subset = opti_data.items_per_supplier
    else:
        dict_bounds = opti_data.dict_bounds_constraint_brand_space_pct_change_facings
        dimension_indices = opti_data.brands
        items_subset = opti_data.items_per_brand

    # Add min side of constraint
    dict_facings_pct_chg_supplier_or_brand_guardrail_lower_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                f * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[(t_or_b, c, g)]
                if (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
            )
            - (
                dict_bounds[t_or_b][0]  # lower bound {t_or_b, min}
                * lpSum(
                    opti_data.current_facings_per_item[(i, c, g)] for i in items_subset
                )
            ),
            sense=LpConstraintGE,
            rhs=0.0,
            name=f"{opti_data.problem_id}_facings_pct_chg_allowed_{dimension}_guardrail_lower_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_facings_allowed_{dimension}_guardrail_lower_constraint",
        dict_facings_pct_chg_supplier_or_brand_guardrail_lower_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_facings_pct_chg_supplier_or_brand_guardrail_lower_constraint[
                        (t_or_b, c, g)
                    ]
                )

    # Add max side of constraint
    dict_facings_pct_chg_supplier_or_brand_guardrail_upper_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                f * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[(t_or_b, c, g)]
                if (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
            )
            - (
                dict_bounds[t_or_b][1]  # upper bound {t_or_b, max}
                * lpSum(
                    opti_data.current_facings_per_item[(i, c, g)] for i in items_subset
                )
            ),
            sense=LpConstraintLE,
            rhs=0.0,
            name=f"facings_pct_chg_allowed_{dimension}_guardrail_upper_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_facings_allowed_{dimension}_guardrail_upper_constraint",
        dict_facings_pct_chg_supplier_or_brand_guardrail_upper_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_facings_pct_chg_supplier_or_brand_guardrail_upper_constraint[
                        (t_or_b, c, g)
                    ]
                )

    return opti_model, opti_data


def add_facings_allowed_supplier_or_brand_guardrail_constraints(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    dimension: str,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Ensures that the total number of facings for a given supplier (indexed by t) or brand (indexed by b) is within
    certain bounds (defined by F_{t, min}, F_{t, max} or F_{b, min}, F_{b, max}), here
    present in `dict_bounds_constraint_supplier_space_total_number_facings` or
    `dict_bounds_constraint_brand_space_total_number_facings` specified by the user
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function
        dimension: dimension for which we want to create the constraint, can only be supplier or brand

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    assert dimension in [
        "supplier",
        "brand",
    ], f"Expected 'supplier' or 'brand' got '{dimension}'"
    if dimension == "supplier":
        dict_bounds = (
            opti_data.dict_bounds_constraint_supplier_space_total_number_facings
        )
        dimension_indices = opti_data.suppliers
        items_subset = opti_data.items_per_supplier
    else:
        dict_bounds = opti_data.dict_bounds_constraint_brand_space_total_number_facings
        dimension_indices = opti_data.brands
        items_subset = opti_data.items_per_brand

    # Add min side of constraint
    dict_facings_allowed_supplier_or_brand_guardrail_lower_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                f * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[t_or_b]
                if (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
            )
            - dict_bounds[(t_or_b, c, g)][0],  # lower bound {t_or_b, min}
            sense=LpConstraintGE,
            rhs=0.0,
            name=f"{opti_data.problem_id}_facings_allowed_{dimension}_guardrail_lower_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_facings_allowed_{dimension}_guardrail_lower_constraint",
        dict_facings_allowed_supplier_or_brand_guardrail_lower_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_facings_allowed_supplier_or_brand_guardrail_lower_constraint[
                        (t_or_b, c, g)
                    ]
                )

    # Add max side of constraint
    dict_facings_allowed_supplier_or_brand_guardrail_upper_constraint = {
        (t_or_b, c, g): LpConstraint(
            e=lpSum(
                f * opti_data.x_vars[(i, f, c, g)]
                for i in items_subset[t_or_b]
                if (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
            )
            - dict_bounds[(t_or_b, c, g)][1],  # upper bound {t_or_b, max}
            sense=LpConstraintLE,
            rhs=0.0,
            name=f"{opti_data.problem_id}_facings_allowed_{dimension}_guardrail_upper_constraint_dimension_{t_or_b}_{c}_{g}",
        )
        for t_or_b in dimension_indices
        if t_or_b in dict_bounds.keys()
        for (c, g) in opti_data.eligible_cg
    }
    setattr(
        opti_data,
        f"dict_facings_allowed_{dimension}_guardrail_upper_constraint",
        dict_facings_allowed_supplier_or_brand_guardrail_upper_constraint,
    )
    for t_or_b in dimension_indices:
        if t_or_b in dict_bounds.keys():
            for c, g in opti_data.eligible_cg:
                opti_model.addConstraint(
                    constraint=dict_facings_allowed_supplier_or_brand_guardrail_upper_constraint[
                        (t_or_b, c, g)
                    ]
                )

    return opti_model, opti_data


def add_pct_range_allocated_own_brand_from_total_space_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds range of allocated % space from total available linear space to own brands, this is a constraint
    used in the catalyst UI. If [min, max]=[0.9, 1.1] then the total space allocated to own brands
    Note: You cannot use both this constraint and another one related to space allocation to Own Brands, as you would
    have a very high likelihood of creating an infeasible optimization problem.
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    # Add min side of constraint

    min_pct_allocated_own_brands_from_total_space_constraint = {
        (c, g): LpConstraint(
            e=lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for i in opti_data.items_own_brand_only_per_c_g[(c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintGE,
            rhs=opti_data.min_pct_allocated_from_total_space_to_own_brands[(c, g)]
            * lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for (i, f) in opti_data.eligible_if_for_cg[(c, g)]
            ),
            name=f"{opti_data.problem_id}_min_pct_allocated_own_brands_from_total_space_constraint{c}_{g}",
        )
        for (c, g) in opti_data.min_pct_allocated_from_total_space_to_own_brands.keys()
    }
    setattr(
        opti_data,
        "min_pct_allocated_own_brands_from_total_space_constraint",
        min_pct_allocated_own_brands_from_total_space_constraint,
    )
    for c, g in opti_data.min_pct_allocated_from_total_space_to_own_brands.keys():
        opti_model.addConstraint(
            constraint=min_pct_allocated_own_brands_from_total_space_constraint[(c, g)]
        )

    # Add max side of constraint
    max_pct_allocated_own_brands_from_total_space_constraint = {
        (c, g): LpConstraint(
            e=lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for i in opti_data.items_own_brand_only_per_c_g[(c, g)]
                for f in opti_data.facings_per_item[i]
            ),
            sense=LpConstraintLE,
            rhs=opti_data.max_pct_allocated_from_total_space_to_own_brands[(c, g)]
            * lpSum(
                opti_data.item_width_x_facings[(i, f, c, g)]
                * opti_data.x_vars[(i, f, c, g)]
                for (i, f) in opti_data.eligible_if_for_cg[(c, g)]
            ),
            name=f"{opti_data.problem_id}_max_pct_allocated_own_brands_from_total_space_constraint{c}_{g}",
        )
        for (c, g) in opti_data.max_pct_allocated_from_total_space_to_own_brands.keys()
    }
    setattr(
        opti_data,
        "max_pct_allocated_own_brands_from_total_space_constraint",
        max_pct_allocated_own_brands_from_total_space_constraint,
    )
    for c, g in opti_data.max_pct_allocated_from_total_space_to_own_brands.keys():
        opti_model.addConstraint(
            constraint=max_pct_allocated_own_brands_from_total_space_constraint[(c, g)]
        )

    return opti_model, opti_data


def add_global_total_linear_space_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    dimension: str,
) -> Tuple[LpProblem, OptimizationModelData]:
    assert dimension in (
        context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys()
    ), (f"Expected {context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys()} "
        f"got '{dimension}'")

    if dimension == "supplier":
        dict_bounds = opti_data.dict_supplier_global_linear_space_change_constraints
        items_subset = opti_data.items_per_supplier
    elif dimension == "brand":
        dict_bounds = opti_data.dict_brand_global_linear_space_change_constraints
        items_subset = opti_data.items_per_brand
    elif dimension == "need_states":
        dict_bounds = opti_data.dict_need_states_global_linear_space_change_constraints
        items_subset = opti_data.items_per_need_states
    elif dimension == "choice_map":
        dict_bounds = opti_data.dict_cdt_global_linear_space_change_constraints
        items_subset = opti_data.items_per_cdt
    elif dimension == "subcat":
        dict_bounds = opti_data.dict_subcat_global_linear_space_change_constraints
        items_subset = opti_data.items_per_subcat
    elif dimension == "segment":
        dict_bounds = opti_data.dict_segment_global_linear_space_change_constraints
        items_subset = opti_data.items_per_segment

    # Slack variable dictionaries
    slack_global_linear_space_min = {}
    slack_global_linear_space_max = {}

    for b in dict_bounds.keys():
        # Create slack variables
        slack_global_linear_space_min[b] = LpVariable(f"{dimension}_slack_min_{b}", lowBound=0, cat="Continuous")
        slack_global_linear_space_max[b] = LpVariable(f"{dimension}_slack_max_{b}", lowBound=0, cat="Continuous")

        opti_model.addConstraint(
            lpSum(
                opti_data.x_vars[(i, f, c, g)]
                * opti_data.item_width_x_facings[(i, f, c, g)]
                for (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
                if i in items_subset[b]
            ) + slack_global_linear_space_min[b]
            >= dict_bounds[b][0],
            f"{opti_data.problem_id}_{dimension}_global_space_min_{b}",
        )

        opti_model.addConstraint(
            lpSum(
                opti_data.x_vars[(i, f, c, g)]
                * opti_data.item_width_x_facings[(i, f, c, g)]
                for (i, c, g) in opti_data.eligible_icg
                for f in opti_data.facings_per_item[i]
                if i in items_subset[b]
            ) - slack_global_linear_space_max[b]
            <= dict_bounds[b][1],
            f"{opti_data.problem_id}_{dimension}_global_space_max_{b}",
        )

    # Add variables to opti data
    setattr(opti_data, f"slack_{dimension}_space_min", slack_global_linear_space_min)
    setattr(opti_data, f"slack_{dimension}_space_max", slack_global_linear_space_max)

    return opti_model, opti_data


def add_pivot_linked_sku_pairs_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds constraint where pairs of pivot and linked SKUs get linked, i.e. if the pivot SKU gets assigned >= 1 facing
    by optimizer then the linked SKU also needs to be assigned >= 1 facing by optimizer. This can be modeled by saying
    that the sum of x_i_f for f >= 1 and for the linked item must be >= than the sum of x_i_f for f >= 1 for the pivot
    item; this way, if one of the x_i_f for the pivot SKU is = 1 (i.e. it has at least one facing) then at least one
    of the same variables for the linked SKU need to be one (so needs to have at least one facing)
    Args:
        opti_model: `LpProblem` object to which we will add objective function and constraints
        opti_data: `OptimizationModelData` object which will be updated with constraints and objective function

    Returns:
    Tuple of [LpProblem, OptimizationModelData] updated with these constraints
    """
    # If pivot SKU gets at least 1 facing, then so does the linked SKU
    dict_pivot_linked_sku_pairs_constraint = {
        (i_pivot_item, i_linked_item, c, g): LpConstraint(
            e=lpSum(
                opti_data.x_vars[(i_linked_item, f, c, g)]
                for f in opti_data.facings_per_item[i_linked_item]
                if f >= 1
            )
            - lpSum(
                opti_data.x_vars[(i_pivot_item, f, c, g)]
                for f in opti_data.facings_per_item[i_pivot_item]
                if f >= 1
            ),
            sense=LpConstraintEQ,
            rhs=0,
            name=f"{opti_data.problem_id}_pivot_linked_sku_pairs_constraint_{i_pivot_item}_{i_linked_item}_{c}_{g}",
        )
        for (c, g) in opti_data.eligible_cg
        if (c, g) in opti_data.dict_cluster_plano_pivot_to_linked_skus.keys()
        for i_pivot_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[
            (c, g)
        ].keys()
        for i_linked_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[(c, g)][
            i_pivot_item
        ]
    }

    setattr(
        opti_data,
        "dict_pivot_linked_sku_pairs_constraint",
        dict_pivot_linked_sku_pairs_constraint,
    )
    # If the pivot SKU gets 0 facings, then so does the linked SKU
    dict_pivot_linked_sku_pairs_pivot_has_0_facings_constraint = {
        (i_pivot_item, i_linked_item, c, g): LpConstraint(
            e=opti_data.x_vars[(i_linked_item, 0, c, g)]
            - opti_data.x_vars[(i_pivot_item, 0, c, g)],
            sense=LpConstraintEQ,
            rhs=0,
            name=f"{opti_data.problem_id}_pivot_linked_sku_pairs_pivot_has_0_facings_constraint_{i_pivot_item}_{i_linked_item}_{c}_{g}",
        )
        for (c, g) in opti_data.eligible_cg
        if (c, g) in opti_data.dict_cluster_plano_pivot_to_linked_skus.keys()
        for i_pivot_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[
            (c, g)
        ].keys()
        for i_linked_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[(c, g)][
            i_pivot_item
        ]
        # if (i_pivot_item in opti_data.items_per_c_g[(c, g)]) and (i_linked_item in opti_data.items_per_c_g[(c, g)])
    }
    setattr(
        opti_data,
        "dict_pivot_linked_sku_pairs_pivot_has_0_facings_constraint",
        dict_pivot_linked_sku_pairs_pivot_has_0_facings_constraint,
    )

    # Creating the constraints, making sure we don't add any duplicate constraints
    for c, g in opti_data.eligible_cg:
        if (c, g) in opti_data.dict_cluster_plano_pivot_to_linked_skus.keys():
            for i_pivot_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[
                (c, g)
            ].keys():
                for i_linked_item in opti_data.dict_cluster_plano_pivot_to_linked_skus[
                    (c, g)
                ][i_pivot_item]:
                    opti_model.addConstraint(
                        constraint=dict_pivot_linked_sku_pairs_constraint[
                            (i_pivot_item, i_linked_item, c, g)
                        ]
                    )
                    opti_model.addConstraint(
                        constraint=dict_pivot_linked_sku_pairs_pivot_has_0_facings_constraint[
                            (i_pivot_item, i_linked_item, c, g)
                        ]
                    )

    return opti_model, opti_data


def add_assortment_percent_change_constraints(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds SKU percent change constraints (min reduction, max expansion) based on `dict_assortment_expansion_reduction_idx`.
    The constraints are now based on the simplified cluster_idx that's derived from the final_cluster_label.
    Only creates constraints when there are actual non-null values for the percentages.
    
    Both expansion and reduction percentages are calculated based on currently active SKUs (those with positive facings).

    Args:
        opti_model: `LpProblem` object to which we will add constraints.
        opti_data: `OptimizationModelData` object containing optimization-related data.

    Returns:
        Tuple[LpProblem, OptimizationModelData]: Updated optimization model and data.
    """
    z_expand = {}
    z_reduce = {}
    slack_expand = {}
    slack_reduce = {}
    dict_min_reduce_constraint = {}
    dict_max_expand_constraint = {}

    # Iterate over the constraints in dict_assortment_expansion_reduction_idx
    for constraint in opti_data.dict_assortment_expansion_reduction_idx:
        plano_fixture_idx = constraint["plano_fixture_idx"]
        cluster_idx = constraint["cluster_idx"]
        
        # Use simplified group key (cluster_idx, plano_fixture_idx)
        group_key = (cluster_idx, plano_fixture_idx)
        
        # Get items for this cluster and planogram
        items = opti_data.items_per_c_g.get(group_key, [])
        
        if len(items) == 0:
            log.warning(f"No items found for group {group_key}, skipping constraint")
            continue

        # Check for valid values and convert to float
        min_reduce_pct = constraint.get("target_sku_reduction_perc")
        min_reduce_pct = min_reduce_pct if isinstance(min_reduce_pct, (float, int)) else np.nan
        
        max_expand_pct = constraint.get("target_sku_expansion_perc")
        max_expand_pct = max_expand_pct if isinstance(max_expand_pct, (float, int)) else np.nan
        
        # Only process if we have valid (non-null, non-NaN) values >= 0
        has_reduction_constraint = (min_reduce_pct is not None and 
                                  not pd.isna(min_reduce_pct) and 
                                  float(min_reduce_pct) >= 0)  # Changed from > 0 to >= 0
        
        has_expansion_constraint = (max_expand_pct is not None and 
                                  not pd.isna(max_expand_pct) and 
                                  float(max_expand_pct) >= 0)  # Changed from > 0 to >= 0
        
        # Skip if neither constraint has a valid value
        if not has_reduction_constraint and not has_expansion_constraint:
            log.info(f"No valid reduction or expansion percentages for group {group_key}, skipping constraint")
            continue

        current_skus = len(items)
        
        # Count SKUs that can be expanded (currently have 0 facings) and reduced (currently have >0 facings)
        skus_with_zero_facings = sum(1 for i in items 
                                    if opti_data.current_facings_per_item.get((i, *group_key), 0) == 0)
        skus_with_positive_facings = current_skus - skus_with_zero_facings
        
        # log.info(f"Group {group_key}: {current_skus} total SKUs, {skus_with_positive_facings} active, {skus_with_zero_facings} inactive")
        
        # Initialize expressions
        expand_expr = LpAffineExpression()
        reduce_expr = LpAffineExpression()

        # Create binary variables and linking constraints for all items in this group
        for i in items:
            current_facing = opti_data.current_facings_per_item.get((i, *group_key), 0)

            # Only create variables if we actually need them for constraints
            if has_expansion_constraint:
                z_expand_var = LpVariable(f"z_expand_{i}_{'_'.join(map(str, group_key))}", cat="Binary")
                z_expand[i, group_key] = z_expand_var

                # Link z_expand: if currently 0 facing → now gets any positive facing
                opti_model.addConstraint(
                    lpSum(
                        opti_data.x_vars[(i, f, *group_key)]
                        for f in opti_data.facings_per_item[i] if f > 0
                    ) == z_expand_var,
                    f"link_expand_presence_{i}_{'_'.join(map(str, group_key))}",
                )
                
                # Only add to expansion expression if item currently has 0 facings
                if current_facing == 0:
                    expand_expr += z_expand_var

            if has_reduction_constraint:
                z_reduce_var = LpVariable(f"z_reduce_{i}_{'_'.join(map(str, group_key))}", cat="Binary")
                z_reduce[i, group_key] = z_reduce_var

                # Link z_reduce: if currently >0 → now gets 0 facings
                if current_facing > 0:
                    opti_model.addConstraint(
                        opti_data.x_vars[(i, 0, *group_key)] == z_reduce_var,
                        f"link_reduce_presence_{i}_{'_'.join(map(str, group_key))}",
                    )
                    reduce_expr += z_reduce_var

        # Create reduction constraint only if we have a valid reduction percentage
        # Base reduction count on currently active SKUs
        if has_reduction_constraint:
            min_reduce_pct_val = float(min_reduce_pct)
            min_reduce_count = int(round(min_reduce_pct_val * skus_with_positive_facings))  # Based on active SKUs
            
            # Validate the constraint makes sense - this is now always valid since we base on active SKUs
            if min_reduce_count >= 0:
                slack_reduce_var = LpVariable(f"slack_reduce_{'_'.join(map(str, group_key))}", lowBound=0)
                slack_reduce[group_key] = slack_reduce_var
                dict_min_reduce_constraint[group_key] = LpConstraint(
                    e=reduce_expr + slack_reduce_var,
                    sense=LpConstraintGE,
                    rhs=min_reduce_count,
                    name=f"{opti_data.problem_id}_soft_min_reduce_{'_'.join(map(str, group_key))}",
                )
                # log.info(f"Added reduction constraint for group {group_key}: target {min_reduce_pct_val:.1%} of {skus_with_positive_facings} active SKUs = {min_reduce_count} SKUs to reduce")
            else:
                log.warning(f"Invalid reduction constraint for group {group_key}: negative reduction count")

        # Create expansion constraint only if we have a valid expansion percentage
        # Base expansion count on currently active SKUs (but still limited by inactive SKUs)
        if has_expansion_constraint:
            max_expand_pct_val = float(max_expand_pct)
            max_expand_count = int(round(max_expand_pct_val * skus_with_positive_facings))  # Based on active SKUs
            
            # Validate the constraint makes sense - can't expand more SKUs than those with zero facings
            if max_expand_count >= 0:
                if max_expand_count > skus_with_zero_facings:
                    log.warning(f"Expansion target ({max_expand_count}) exceeds inactive SKUs ({skus_with_zero_facings}) for group {group_key} - will rely on slack variables")
                
                slack_expand_var = LpVariable(f"slack_expand_{'_'.join(map(str, group_key))}", lowBound=0)
                slack_expand[group_key] = slack_expand_var
                dict_max_expand_constraint[group_key] = LpConstraint(
                    e=expand_expr - slack_expand_var,  # Note: subtract slack for LE constraint
                    sense=LpConstraintLE,
                    rhs=max_expand_count,
                    name=f"{opti_data.problem_id}_soft_max_expand_{'_'.join(map(str, group_key))}",
                )
                # log.info(f"Added expansion constraint for group {group_key}: target {max_expand_pct_val:.1%} of {skus_with_positive_facings} active SKUs = {max_expand_count} SKUs to expand (max possible: {skus_with_zero_facings})")
            else:
                log.warning(f"Invalid expansion constraint for group {group_key}: negative expansion count")

    # Add constraints to the model
    for group_key, constraint in dict_min_reduce_constraint.items():
        opti_model.addConstraint(constraint=constraint)
    for group_key, constraint in dict_max_expand_constraint.items():
        opti_model.addConstraint(constraint=constraint)

    # Store variables and constraints in opti_data for diagnostics and objective
    setattr(opti_data, "slack_expand", slack_expand)
    setattr(opti_data, "slack_reduce", slack_reduce)
    setattr(opti_data, "z_expand", z_expand)
    setattr(opti_data, "z_reduce", z_reduce)
    setattr(opti_data, "dict_min_reduce_constraint", dict_min_reduce_constraint)
    setattr(opti_data, "dict_max_expand_constraint", dict_max_expand_constraint)

    log.info(f"Added {len(dict_min_reduce_constraint)} reduction constraints and {len(dict_max_expand_constraint)} expansion constraints")
    
    return opti_model, opti_data


def add_min_POD_per_item_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds a soft lower bound (LB) item POD threshold constraint with slack variables.
    The penalty for violating the LB is subtracted from the objective function.
    
    Constraints are now plano-specific: a minimum store count is applied to an item 
    only in the context of a specific planogram.
    """
    dict_item_POD_min_store_idx = opti_data.dict_item_POD_min_store_idx
    slack_pod_lb = {}
    dict_item_POD_min_store_constraint = {}

    # Iterate through plano_ids in the constraints dictionary
    for plano_id in dict_item_POD_min_store_idx:
        plano_idx = None
        for idx, pid in opti_data.plano_idx_to_plano.items():
            if str(pid) == str(plano_id):
                plano_idx = idx
                break

        if plano_idx is None:
            log.warning(f"Planogram ID {plano_id} not found in plano_idx_to_plano mapping, skipping constraints")
            continue
            
        # Process each item in this planogram
        for i, min_store_count in dict_item_POD_min_store_idx[plano_id].items():
            # Filter eligible cluster-planogram pairs for this item and this planogram
            eligible_cg = [
                (c, g)
                for (c, g) in opti_data.eligible_cg
                if (i, c, g) in opti_data.eligible_icg
            ]
            
            if not eligible_cg:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} not found in planogram {plano_id}, skipping constraint")
                continue
                
            # Create constraint key that includes the plano_id for uniqueness
            constraint_key = (i, plano_id)
            
            # Create slack variable
            slack_var = LpVariable(f"slack_pod_lb_{i}_{plano_id}", lowBound=0, cat="Continuous")
            slack_pod_lb[constraint_key] = slack_var

            # Create constraint specific to this item in this planogram
            constraint = LpConstraint(
                e=lpSum(
                    (1 - opti_data.x_vars[(i, 0, c, g)])
                    * opti_data.store_count_by_cluster_plano[(c, g)]
                    for (c, g) in eligible_cg
                ) + slack_var,
                sense=LpConstraintGE,
                rhs=min_store_count,
                name=f"{opti_data.problem_id}_dict_item_POD_min_store_soft_{i}_plano_{plano_id}",
            )
            dict_item_POD_min_store_constraint[constraint_key] = constraint
            
            log.info(f"Added minimum POD constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: minimum {min_store_count} stores")

    # Store slack variables and constraints for diagnostics/objective
    setattr(opti_data, "slack_pod_lb", slack_pod_lb)
    setattr(opti_data, "dict_item_POD_min_store_constraint", dict_item_POD_min_store_constraint)

    # Add constraints to the model
    for constraint_key, constraint in dict_item_POD_min_store_constraint.items():
        opti_model.addConstraint(constraint=constraint)

    log.info(f"Added {len(dict_item_POD_min_store_constraint)} minimum POD constraints for specific plano-item combinations")
    return opti_model, opti_data


def add_max_POD_per_item_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds a soft upper bound (UB) item POD threshold constraint with slack variables.
    The penalty for violating the UB is subtracted from the objective function.
    
    Constraints are now plano-specific: a minimum store count is applied to an item 
    only in the context of a specific planogram.
    """
    dict_item_POD_max_store_idx = opti_data.dict_item_POD_max_store_idx
    slack_pod_ub = {}
    dict_item_POD_max_store_constraint = {}

    # Iterate through plano_ids in the constraints dictionary
    for plano_id in dict_item_POD_max_store_idx:
        plano_idx = None
        for idx, pid in opti_data.plano_idx_to_plano.items():
            if str(pid) == str(plano_id):
                plano_idx = idx
                break

        if plano_idx is None:
            log.warning(f"Planogram ID {plano_id} not found in plano_idx_to_plano mapping, skipping constraints")
            continue
            
        # Process each item in this planogram
        for i, max_store_count in dict_item_POD_max_store_idx[plano_id].items():
            # Filter eligible cluster-planogram pairs for this item and this planogram
            eligible_cg = [
                (c, g)
                for (c, g) in opti_data.eligible_cg
                if (i, c, g) in opti_data.eligible_icg
            ]
            
            if not eligible_cg:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} not found in planogram {plano_id}, skipping constraint")
                continue
                
            # Create constraint key that includes the plano_id for uniqueness
            constraint_key = (i, plano_id)
            
            # Create slack variable
            slack_var = LpVariable(f"slack_pod_ub_{i}_{plano_id}", lowBound=0, cat="Continuous")
            slack_pod_ub[constraint_key] = slack_var

            # Create constraint specific to this item in this planogram
            constraint = LpConstraint(
                e=lpSum(
                    (1 - opti_data.x_vars[(i, 0, c, g)])
                    * opti_data.store_count_by_cluster_plano[(c, g)]
                    for (c, g) in eligible_cg
                ) - slack_var,
                sense=LpConstraintLE,
                rhs=max_store_count,
                name=f"{opti_data.problem_id}_dict_item_POD_max_store_soft_{i}_plano_{plano_id}",
            )
            dict_item_POD_max_store_constraint[constraint_key] = constraint
            
            log.info(f"Added maximum POD constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: maximum {max_store_count} stores")

    # Store slack variables and constraints for diagnostics/objective
    setattr(opti_data, "slack_pod_ub", slack_pod_ub)
    setattr(opti_data, "dict_item_POD_max_store_constraint", dict_item_POD_max_store_constraint)

    # Add constraints to the model
    for constraint_key, constraint in dict_item_POD_max_store_constraint.items():
        opti_model.addConstraint(constraint=constraint)

    log.info(f"Added {len(dict_item_POD_max_store_constraint)} maximum POD constraints for specific plano-item combinations")
    return opti_model, opti_data


def add_item_store_count_min_change_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds a soft constraint on the directional minimum change in the number of stores carrying each SKU.
    These constraints are plano-specific: a minimum store count change applies to an item 
    only in the context of a specific planogram.
    
    The constraint interpretation:
    - If min_change > 0: enforces minimum INCREASE in store count
    - If min_change < 0: enforces minimum DECREASE in store count
    - If min_change = 0: no constraint is added
    """
    item_min_change_dict = opti_data.dict_item_pod_min_change_idx
    current_store_count_per_item = opti_data.current_store_count_per_items_all_idx

    slack_store_count_min_change = {}
    dict_item_store_count_min_change_constraint = {}
    
    # Iterate through plano_ids in the constraints dictionary
    for plano_id in item_min_change_dict:
        plano_idx = None
        for idx, pid in opti_data.plano_idx_to_plano.items():
            if str(pid) == str(plano_id):
                plano_idx = idx
                break

        if plano_idx is None:
            log.warning(f"Planogram ID {plano_id} not found in plano_idx_to_plano mapping, skipping constraints")
            continue
            
        # Process each item in this planogram
        for i, min_change in item_min_change_dict[plano_id].items():
            # Skip if min_change is zero or None
            if min_change == 0 or min_change is None:
                log.info(f"Skipping item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: min_change is {min_change}")
                continue
                
            # Get current store count for this item - using correct data structure
            current_count = current_store_count_per_item.get(plano_id, {}).get(i, 0)
            
            if current_count == 0:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} has no current store count in planogram {plano_id}, using 0")
            
            # Filter eligible cluster-planogram pairs for this item and this planogram
            eligible_cg = [
                (c, g)
                for (c, g) in opti_data.eligible_cg
                if (i, c, g) in opti_data.eligible_icg
            ]
            
            if not eligible_cg:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} not eligible in planogram {plano_id}, skipping constraint")
                continue
                
            # Create constraint key that includes the plano_id for uniqueness
            constraint_key = (i, plano_id)
            
            # Create slack variable
            slack_var = LpVariable(f"slack_store_count_min_change_{i}_{plano_id}", lowBound=0, cat="Continuous")
            slack_store_count_min_change[constraint_key] = slack_var

            # Calculate new store count for this item in this planogram
            new_store_count_expr = lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)]) * opti_data.store_count_by_cluster_plano[(c, g)]
                for (c, g) in eligible_cg
            )

            # Create constraint based on sign of min_change
            if min_change > 0:
                # Minimum INCREASE constraint: new_count + slack >= current_count + min_change
                constraint = LpConstraint(
                    e=new_store_count_expr + slack_var,
                    sense=LpConstraintGE,
                    rhs=current_count + min_change,
                    name=f"{opti_data.problem_id}_soft_item_store_count_min_increase_{i}_plano_{plano_id}",
                )
                log.info(f"Added minimum store count INCREASE constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: minimum increase {min_change} stores (current: {current_count})")
                
            elif min_change < 0:
                # Minimum DECREASE constraint: new_count - slack <= current_count + min_change
                # Since min_change is negative, current_count + min_change is the target reduced count
                constraint = LpConstraint(
                    e=new_store_count_expr - slack_var,
                    sense=LpConstraintLE,
                    rhs=current_count + min_change,  # min_change is negative
                    name=f"{opti_data.problem_id}_soft_item_store_count_min_decrease_{i}_plano_{plano_id}",
                )
                min_decrease = abs(min_change)  # For logging purposes
                log.info(f"Added minimum store count DECREASE constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: minimum decrease {min_decrease} stores (current: {current_count})")

            dict_item_store_count_min_change_constraint[constraint_key] = constraint

    # Store variables and constraints
    setattr(opti_data, "slack_store_count_min_change", slack_store_count_min_change)
    setattr(opti_data, "dict_item_store_count_min_change_constraint", dict_item_store_count_min_change_constraint)

    # Add constraints to the model
    for constraint_key, constraint in dict_item_store_count_min_change_constraint.items():
        opti_model.addConstraint(constraint=constraint)

    log.info(f"Added {len(dict_item_store_count_min_change_constraint)} directional minimum store count change constraints for specific plano-item combinations")
    return opti_model, opti_data


def add_item_store_count_max_change_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds a soft constraint on the directional maximum change in the number of stores carrying each SKU.
    These constraints are plano-specific: a maximum store count change applies to an item 
    only in the context of a specific planogram.
    
    The constraint interpretation:
    - If max_change > 0: enforces maximum INCREASE in store count (new_count <= current + max_change)
    - If max_change < 0: enforces maximum DECREASE in store count (new_count >= current + max_change)
    - If max_change = 0: no constraint is added
    """
    item_max_change_dict = opti_data.dict_item_pod_max_change_idx
    current_store_count_per_item = opti_data.current_store_count_per_items_all_idx

    slack_store_count_max_change = {}
    dict_item_store_count_max_change_constraint = {}
    
    # Iterate through plano_ids in the constraints dictionary
    for plano_id in item_max_change_dict:
        plano_idx = None
        for idx, pid in opti_data.plano_idx_to_plano.items():
            if str(pid) == str(plano_id):
                plano_idx = idx
                break

        if plano_idx is None:
            log.warning(f"Planogram ID {plano_id} not found in plano_idx_to_plano mapping, skipping constraints")
            continue
            
        # Process each item in this planogram
        for i, max_change in item_max_change_dict[plano_id].items():
            # Skip if max_change is zero or None
            if max_change == 0 or max_change is None:
                log.info(f"Skipping item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: max_change is {max_change}")
                continue
                
            # Get current store count for this item - using correct data structure
            current_count = current_store_count_per_item.get(plano_id, {}).get(i, 0)
            
            if current_count == 0:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} has no current store count in planogram {plano_id}, using 0")
            
            # Filter eligible cluster-planogram pairs for this item and this planogram
            eligible_cg = [
                (c, g)
                for (c, g) in opti_data.eligible_cg
                if (i, c, g) in opti_data.eligible_icg
            ]
            
            if not eligible_cg:
                log.warning(f"Item {opti_data.item_idx_to_item_no.get(i, i)} not eligible in planogram {plano_id}, skipping constraint")
                continue
                
            # Create constraint key that includes the plano_id for uniqueness
            constraint_key = (i, plano_id)
            
            # Create slack variable
            slack_var = LpVariable(f"slack_store_count_max_change_{i}_{plano_id}", lowBound=0, cat="Continuous")
            slack_store_count_max_change[constraint_key] = slack_var

            # Calculate new store count for this item in this planogram
            new_store_count_expr = lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)]) * opti_data.store_count_by_cluster_plano[(c, g)]
                for (c, g) in eligible_cg
            )

            # Create constraint based on sign of max_change
            if max_change > 0:
                # Maximum INCREASE constraint: new_count - slack <= current_count + max_change
                constraint = LpConstraint(
                    e=new_store_count_expr - slack_var,
                    sense=LpConstraintLE,
                    rhs=current_count + max_change,
                    name=f"{opti_data.problem_id}_soft_item_store_count_max_increase_{i}_plano_{plano_id}",
                )
                log.info(f"Added maximum store count INCREASE constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: maximum increase {max_change} stores (current: {current_count})")
                
            elif max_change < 0:
                # Maximum DECREASE constraint: new_count + slack >= current_count + max_change
                # Since max_change is negative, current_count + max_change is the minimum allowed count
                constraint = LpConstraint(
                    e=new_store_count_expr + slack_var,
                    sense=LpConstraintGE,
                    rhs=current_count + max_change,  # max_change is negative
                    name=f"{opti_data.problem_id}_soft_item_store_count_max_decrease_{i}_plano_{plano_id}",
                )
                max_decrease = abs(max_change)  # For logging purposes
                log.info(f"Added maximum store count DECREASE constraint for item {opti_data.item_idx_to_item_no.get(i, i)} in planogram {plano_id}: maximum decrease {max_decrease} stores (current: {current_count})")

            dict_item_store_count_max_change_constraint[constraint_key] = constraint

    # Store variables and constraints
    setattr(opti_data, "slack_store_count_max_change", slack_store_count_max_change)
    setattr(opti_data, "dict_item_store_count_max_change_constraint", dict_item_store_count_max_change_constraint)

    # Add constraints to the model
    for constraint_key, constraint in dict_item_store_count_max_change_constraint.items():
        opti_model.addConstraint(constraint=constraint)

    log.info(f"Added {len(dict_item_store_count_max_change_constraint)} directional maximum store count change constraints for specific plano-item combinations")
    return opti_model, opti_data


def add_dc_minimum_stores_constraint(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Adds soft constraint ensuring items are assigned to at least min_stores_per_dc
    stores within each DC if assigned at all.
    """
    if not hasattr(opti_data, 'dc_cluster_store_mapping') or not opti_data.dc_cluster_store_mapping:
        log.info("DC constraints not enabled or no DC mapping available")
        return opti_model, opti_data
    
    slack_dc_min_stores = {}
    dict_dc_min_stores_constraint = {}
    dc_assignment_vars = {}
    constraint_count = 0
    
    # Group cluster-planogram pairs by DC for efficient processing
    dc_to_cluster_planos = {}
    for (c, g), dc_store_counts in opti_data.dc_cluster_store_mapping.items():
        for dc_id, store_count in dc_store_counts.items():
            if dc_id not in dc_to_cluster_planos:
                dc_to_cluster_planos[dc_id] = []
            dc_to_cluster_planos[dc_id].append((c, g, store_count))
    
    # For each item and DC combination
    for i in opti_data.items_all:
        for dc_id, cluster_plano_list in dc_to_cluster_planos.items():
            # Filter to only cluster-planogram pairs where this item is eligible
            eligible_cg_for_dc = [
                (c, g, store_count) for (c, g, store_count) in cluster_plano_list 
                if (i, c, g) in opti_data.eligible_icg
            ]
            
            if not eligible_cg_for_dc:
                continue
                
            # Create binary variable for item assignment in this DC
            constraint_key = (i, dc_id)
            assignment_var = LpVariable(
                f"dc_assignment_{i}_{dc_id}",
                cat="Binary"
            )
            dc_assignment_vars[constraint_key] = assignment_var
            
            # Calculate proper Big-M: max possible non-zero facing assignments
            max_facings_per_cg = max(len(opti_data.facings_per_item[i]) - 1, 1)  # Exclude 0 facings
            M = len(eligible_cg_for_dc) * max_facings_per_cg
            
            non_zero_facing_vars = lpSum(
                opti_data.x_vars[(i, f, c, g)]
                for (c, g, _) in eligible_cg_for_dc
                for f in opti_data.facings_per_item[i][1:]  # Exclude 0 facings
                if (i, f, c, g) in opti_data.x_vars
            )

            # Link assignment_var to facings: if any non-zero facings assigned, assignment_var = 1
            opti_model.addConstraint(
                non_zero_facing_vars <= M * assignment_var,
                f"{opti_data.problem_id}_dc_assignment_link_upper_{i}_{dc_id}"
            )
            
            opti_model.addConstraint(
                non_zero_facing_vars >= assignment_var,
                f"{opti_data.problem_id}_dc_assignment_link_lower_{i}_{dc_id}"
            )
            
            # Create slack variable for violations
            slack_var = LpVariable(
                f"slack_dc_min_stores_{i}_{dc_id}", 
                lowBound=0, 
                cat="Continuous"
            )
            slack_dc_min_stores[constraint_key] = slack_var
            
            actual_stores_in_dc = lpSum(
                (1 - opti_data.x_vars[(i, 0, c, g)]) * store_count
                for (c, g, store_count) in eligible_cg_for_dc
                if (i, 0, c, g) in opti_data.x_vars
            )
            
            constraint = LpConstraint(
                e=actual_stores_in_dc + slack_var - (opti_data.min_stores_per_dc * assignment_var),
                sense=LpConstraintGE,
                rhs=0,
                name=f"{opti_data.problem_id}_dc_min_stores_{i}_{dc_id}"
            )
            
            dict_dc_min_stores_constraint[constraint_key] = constraint
            opti_model.addConstraint(constraint)
            constraint_count += 1
    
    # Store in opti_data for objective function
    setattr(opti_data, "slack_dc_min_stores", slack_dc_min_stores)
    setattr(opti_data, "dict_dc_min_stores_constraint", dict_dc_min_stores_constraint)
    setattr(opti_data, "dc_assignment_vars", dc_assignment_vars)
    
    log.info(f"Added {constraint_count} DC minimum store constraints")
    
    return opti_model, opti_data
