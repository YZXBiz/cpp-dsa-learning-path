import os
from typing import Tuple

from core.modules.optimization.model_constraints_v2 import (
    add_all_constraints_to_model,
    add_objective_function_to_model,
)
from core.modules.optimization.model_data_wrapper_v2 import OptimizationModelData
from core.modules.optimization.model_presolve_feasibility_check import (
    check_need_state_space_required_for_one_facing,
)
from core.utils.storage import write_object, write_text
from core.utils.space_context.run_versioning import complete_file_path
from oxygen.conf.context import context
from oxygen.conf.settings import settings

from pulp import PULP_CBC_CMD, SCIP_CMD, LpBinary, LpMaximize, LpProblem, LpVariable, GUROBI_CMD, GUROBI
import pulp
import gurobipy as gp
from collections import defaultdict

import ipdb
import time
import operator

import logging

log = logging.getLogger(__name__)


def solve_model_cluster_plano_cat_dept_fixture_v2(
    opti_model: LpProblem,
    opti_data: OptimizationModelData,
    model_name: str,
    dependent_var: str,
    category_level_dept_nbr: int,
    plano_cat_desc: str,
    department: int,
) -> Tuple[LpProblem, bool]:
    """
    This function will solve the `opti_model` fed into it, and will save the `.mps` file as well as a `.log` file to
    GCS for debugging purposes.
    Args:
        opti_model: Optimization problem to be solved using config-driven parameters
        opti_data: `OptimizationModelData` object which has updated constraints and objective function
        model_name: Name of the optimization problem to be solved
        dependent_var: Dependent variable on which we're optimizing (can either be sales or dnp)
        category_level_dept_nbr: Category_leveltudy selected by CM
        plano_cat_desc: POG Category on which we want to run optimization
        department: Department on which we're currently looping for optimization problems
        stores for a given department) rounded to the closest integer

    Returns:
    A solved optimization model
    """
    solver_name = context.optimization.solver_parameters.solver_name
    model_id = model_name
    local_temp_path_model = f"./model_solved_{solver_name}_{model_id}.mps"
    local_temp_path_model_ilp = f"./iis_results_{model_id}.ilp"
    local_temp_path_logs = f"./solver_logs_{solver_name}_{model_id}.log"

    if solver_name in ["CBC",  "GUROBI_CMD", "GUROBI_API", "SCIP"]:
        is_problem_infeasible = (
            False  # Will be updated to True if the model is indeed infeasible
        )
        try:
            start_time = time.time()
            if solver_name == "CBC":
                opti_model.solve(
                    PULP_CBC_CMD(
                        msg=True,
                        timeLimit=context.optimization.solver_parameters.time_limit_seconds,
                        gapRel=context.optimization.solver_parameters.relative_gap,
                        presolve=True,
                        keepFiles=context.optimization.solver_parameters.keep_files,
                        threads=context.optimization.solver_parameters.threads,
                        logPath=local_temp_path_logs,
                        # warmStart=True,
                    )
                )
            elif solver_name == "SCIP":
                opti_model.solve(
                    SCIP_CMD(
                        msg=True,
                        timeLimit=context.optimization.solver_parameters.time_limit_seconds,
                        gapRel=context.optimization.solver_parameters.relative_gap,
                        keepFiles=context.optimization.solver_parameters.keep_files,
                        threads=context.optimization.solver_parameters.threads,
                        logPath=local_temp_path_logs,
                        # warmStart=True,
                    )
                )
            elif solver_name == "GUROBI_CMD":
                opti_model.solve(
                    GUROBI_CMD(
                        msg=True,
                        options=[
                            (
                                "MIPGap",
                                context.optimization.solver_parameters.relative_gap,
                            ),
                            (
                                "TimeLimit",
                                context.optimization.solver_parameters.time_limit_seconds,
                            ),
                            ("Threads", context.optimization.solver_parameters.threads),
                        ],
                        keepFiles=context.optimization.solver_parameters.keep_files,
                        logPath=local_temp_path_logs,  # Path to log file
                        # warmStart=True  # Use warm start (optional, if you have initial values)
                    )
                )
            elif solver_name == "GUROBI_API":
                params = {
                    "OutputFlag": 0,
                    "GURO_PAR_ISVNAME": settings.GURO_PAR_ISVNAME,
                    "GURO_PAR_ISVAPPNAME": settings.GURO_PAR_ISVAPPNAME,
                    "GURO_PAR_ISVEXPIRATION": int(settings.GURO_PAR_ISVEXPIRATION),
                    "GURO_PAR_ISVKEY": settings.GURO_PAR_ISVKEY
                }
                with gp.Env(params=params) as env:
                    opti_model.solve(
                        GUROBI(
                            msg=True,
                            timeLimit=context.optimization.solver_parameters.time_limit_seconds,
                            env=env,
                            logPath=local_temp_path_logs,  # Path to log file
                        )
                    )
            
            end_time = time.time()
            run_time = end_time - start_time
            
            print(f"{end_time - start_time:.4f} seconds")
            solver_status = pulp.LpStatus[opti_model.status]
            log.info(f"Solver Status: {solver_status}")
            if solver_status == "Optimal":
                log.info(f"Objective value = {pulp.value(opti_model.objective):.2f}")
                if (
                    context.optimization_config.model_formulation.enable_enforce_as_many_need_states_as_possible_constraint
                    == True
                ):
                    cnt_slack_min_ns = 0
                    cnt_positive_slack_min_ns = 0
                    sum_positive_slack_min_ns = 0
                    positive_slack_min_ns_log = ""
                    for variable in opti_model.variables():
                        var_name = variable.name
                        var_value = variable.varValue
                        if "_slack_min_ns_" in var_name:
                            cnt_slack_min_ns += 1
                            if var_value > 0:
                                cnt_positive_slack_min_ns += 1
                                sum_positive_slack_min_ns += var_value
                                positive_slack_min_ns_log += (
                                    f"\n{var_name} = {var_value}"
                                )
                    log.info(
                        f"Checking slack variables for relaxing enable_enforce_as_many_need_states_as_possible_constraint constraint..."
                    )
                    log.info(f"Total slack variables: {cnt_slack_min_ns:,}")
                    log.info(f"Positive slack variables: {cnt_positive_slack_min_ns:,}")
                    log.info(
                        f"Ratio of positive slack variables out of total: {cnt_positive_slack_min_ns/cnt_slack_min_ns*100:.1f}%"
                    )
                    log.info(
                        "List of positive slack variables at cluster-plano-fixture level, index in the variable name represents a (c, g) pair"
                    )
                    log.info(positive_slack_min_ns_log)
                    log.info(
                        f"Total positive slack variables value {sum_positive_slack_min_ns:,}"
                    )
                    log.info(
                        f"Penalty coefficient for slack variables {opti_data.penalty_coefficient_for_slack_vars:.2f}"
                    )
                    log.info(
                        f"Objective value without slack penalty term = {(pulp.value(opti_model.objective) + opti_data.penalty_coefficient_for_slack_vars * sum_positive_slack_min_ns):.2f}"
                    )
                if (
                        context.optimization_config.model_formulation.enable_global_linear_space_change_constraints
                        == True
                ):
                    min_slack_global_space = 0
                    max_slack_global_space = 0
                    global_linear_space_change_penalty_coefficient = (
                        context.optimization_config.model_formulation.global_linear_space_change_penalty_coefficient
                    )

                    for dimension in (
                        context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys()
                    ):
                        if f"slack_{dimension}_space_min" in dir(opti_data):
                            slack_min_var = getattr(opti_data, f"slack_{dimension}_space_min")
                            slack_max_var = getattr(opti_data, f"slack_{dimension}_space_max")

                            min_slack_global_space += sum([v.varValue for k, v in slack_min_var.items()])
                            max_slack_global_space += sum([v.varValue for k, v in slack_max_var.items()])

                    min_slack_global_space = min_slack_global_space * global_linear_space_change_penalty_coefficient
                    max_slack_global_space = max_slack_global_space * global_linear_space_change_penalty_coefficient

                    log.info(
                        f"Total slack variable for min global linear space change constraint {min_slack_global_space}"
                    )

                    log.info(
                        f"Total slack variable for max global linear space change constraint {max_slack_global_space}"
                    )
            else:
                opti_model.writeMPS(local_temp_path_model)
                log.warning(
                    f"-------- Model {model_id} did not find an optimal solution, please check outputs & logs --------"
                )
                is_problem_infeasible = True

                if context.optimization.solver_parameters.save_opti_IIS:
                    IIS_success = False
                    if solver_name == "GUROBI":
                        gurobi_exe_path = GUROBI_CMD().path
                    command = f'"{gurobi_exe_path}" ResultFile="{local_temp_path_model_ilp}" "{local_temp_path_model}"'
                    try:
                        exit_code = os.system(command)
                        if exit_code != 0:
                            log.warning(
                                f"Error: Gurobi command failed with exit code {exit_code}"
                            )
                        else:
                            log.info("IIS generated successfully.")
                            IIS_success = True
                    except Exception as e:
                        log.warning(f"An error occurred: {e}")

                    if IIS_success:
                        iis_log = ""
                        with open(local_temp_path_model_ilp, "r") as f:
                            for line in f:
                                iis_log += line

                        write_text(
                            path=complete_file_path(
                                context.data_stores.optimization.root_path,
                                context.data_stores.optimization.modeling.optimization_iis_ilp,
                                at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                                dependent_var=dependent_var,
                                category_level_dept_nbr=category_level_dept_nbr,
                                plano_cat_desc=plano_cat_desc,
                                department=department,
                                solver_name=solver_name,
                            ),
                            text=iis_log,
                            root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        )

            if context.optimization.solver_parameters.save_opti_models:
                if not is_problem_infeasible:
                    write_object(
                        path=complete_file_path(
                            context.data_stores.optimization.root_path,
                            context.data_stores.optimization.modeling.optimization_model_mps,
                            at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                            dependent_var=dependent_var,
                            category_level_dept_nbr=category_level_dept_nbr,
                            plano_cat_desc=plano_cat_desc,
                            department=department,
                            solver_name=solver_name,
                        ),
                        obj=local_temp_path_model,
                        root=context.data_stores.optimization.save_to_datastores_root.modeling,
                    )
            else:
                if os.path.exists(local_temp_path_model):
                    os.remove(local_temp_path_model)

            if solver_name != "GUROBI_API":
                full_log = ""
                with open(local_temp_path_logs, "r") as f:
                    for line in f:
                        full_log += line

                write_text(
                    text=full_log,
                    path=complete_file_path(
                        context.data_stores.optimization.root_path,
                        context.data_stores.optimization.modeling.optimization_solver_logs,
                        at_datastores_root=context.data_stores.optimization.save_to_datastores_root.modeling,
                        dependent_var=dependent_var,
                        category_level_dept_nbr=category_level_dept_nbr,
                        plano_cat_desc=plano_cat_desc,
                        department=department,
                        solver_name=solver_name,
                    ),
                    root=context.data_stores.optimization.save_to_datastores_root.modeling,
                )

            return opti_model, is_problem_infeasible

        except Exception as e:
            log.error(
                f"-------- Model {model_id} did not solve successfully, please check outputs & logs. Error: {e} --------"
            )
            is_problem_infeasible = True
            return opti_model, is_problem_infeasible

    else:
        raise NotImplementedError(
            f"Expected solver_name='CBC' or 'GUROBI', got {solver_name}"
        )


def define_optimization_model_v2(
    opti_data: OptimizationModelData,
) -> Tuple[LpProblem, OptimizationModelData]:
    """
    Defines the optimization problem for that specific `plano_cat_desc` and `cluster_id` through creation of decision
    variables, constraints and objective function
    Args:
        opti_data: `OptimizationModelData` object containing all the information about optimization model, and will be
        updated in this function with decision variables, constraints and objective function

    Returns:
    A tuple of 2 objects:
    - A `pulp` `LpProblem` object which contains the defined optimization model to be solved
    - An `OptimizationModelData` object which contains all the data related to this optimization model (which will be
    pickled and saved in the end)
    """
    # Initialization MIP model
    opti_model = LpProblem(
        name=opti_data.problem_id,
        sense=LpMaximize,
    )
    # Decision Variables
    opti_data = create_decision_variables(opti_data=opti_data)
    
    # presolve feasibility check and update the eligible set accordingly
    opti_data = check_need_state_space_required_for_one_facing(opti_data)

    # Constraints
    opti_model, opti_data = add_all_constraints_to_model(
        opti_model=opti_model,
        opti_data=opti_data,
    )
    # Objective Function
    opti_model, opti_data = add_objective_function_to_model(
        opti_model=opti_model,
        opti_data=opti_data,
    )
    return opti_model, opti_data


def create_decision_variables(
    opti_data: OptimizationModelData,
) -> OptimizationModelData:
    """
    Creates the a set of decision variables used in the optimization model for micro space
    Args:
        opti_data: `OptimizationModelData` object containing all the information about optimization model, and will be
        updated in this function with decision variables

    Returns:
    OptimizationModelData object with 1 updated attributes:
    x_vars: Binary variable x[i, f, c, g] which is equal to 1 if item i is assigned f facings within cluster c ang plano g, 0 otherwise
    """
    x_vars = {
        (i, f, c, g): LpVariable(cat=LpBinary, lowBound=0, name=f"x_{i}_{f}_{c}_{g}")
        for c in opti_data.clusters
        for g in opti_data.plano_fixture_by_cluster[c]
        for i in opti_data.items_per_c_g[(c, g)]
        for f in opti_data.facings_per_item[i]
    }
    opti_data.x_vars = x_vars

    # create binary variable y[i] which is equal to 1 if item i has >0 facings in dept; 0 otherwise.
    # this is used in the POD count constraint
    y_vars = {
        i: LpVariable(cat=LpBinary, lowBound=0, name=f"y_{i}")
        for i in opti_data.items_all
    }
    opti_data.y_vars = y_vars

    opti_data.eligible_icg = {(i, c, g) for (i, f, c, g) in opti_data.x_vars}
    opti_data.eligible_if_for_cg = defaultdict(set)

    for i, f, c, g in opti_data.x_vars:
        opti_data.eligible_if_for_cg[(c, g)].add((i, f))

    opti_data.eligible_cg = set(opti_data.eligible_if_for_cg.keys())
    opti_data.eligible_ncg = [
        (n, c, g)
        for (c, g) in opti_data.eligible_cg
        for n in opti_data.ns_per_c_g[(c, g)]
    ]
    return opti_data


def run_optimization_qc(opti_data):
    """
    Task to perform post-optimization QC on constraints.
    Logs warnings for any hard constraint violations and logs soft constraint violations.
    Provides aggregate summary of violations.
    """
    import pandas as pd
    from pulp import value
    # Map sense to operator and description
    sense_map = {
        0: ("==", "equality"),      # LpConstraintEQ
        1: (">=", "greater_equal"), # LpConstraintGE  
        -1: ("<=", "less_equal")    # LpConstraintLE
    }

    hard_constraint_attrs = [
        "total_used_space_constraint",
        "dict_items_forced_facings_guardrails_constraint",
        "min_inventory_constraint",
        "max_inventory_constraint",
        "dict_at_most_one_facing_value_assigned_constraint",
        "dict_max_incremental_facings_constraint",
        "dict_max_decremental_facings_constraint",
        "dict_max_facings_in_plano_cat_constraint",
        "dict_min_need_state_facings_constraint",
        "dict_max_need_state_facings_constraint",
        "max_pct_drop_own_brand_space_constraint",
        "min_pct_allocated_own_brands_from_total_space_constraint",
        "max_pct_allocated_own_brands_from_total_space_constraint",
        "dict_pct_allocated_linear_space_supplier_guardrail_lower_constraint",
        "dict_pct_allocated_linear_space_supplier_guardrail_upper_constraint",
        "dict_pct_allocated_linear_space_brand_guardrail_lower_constraint",
        "dict_pct_allocated_linear_space_brand_guardrail_upper_constraint",
        "dict_facings_allowed_supplier_guardrail_lower_constraint",
        "dict_facings_allowed_supplier_guardrail_upper_constraint",
        "dict_facings_allowed_brand_guardrail_lower_constraint",
        "dict_facings_allowed_brand_guardrail_upper_constraint",
        "dict_pivot_linked_sku_pairs_constraint",
        "dict_pivot_linked_sku_pairs_pivot_has_0_facings_constraint",
    ]

    soft_constraint_attrs = [
        "constraints_min_number_ns",
        "dict_min_reduce_constraint",
        "dict_max_expand_constraint",
        "dict_brand_global_linear_space_change_constraints",
        "dict_supplier_global_linear_space_change_constraints",
        "dict_need_states_global_linear_space_change_constraints",
        "dict_cdt_global_linear_space_change_constraints",
        "dict_subcat_global_linear_space_change_constraints",
        "dict_segment_global_linear_space_change_constraints",
        "dict_item_POD_min_store_constraint",
        "dict_item_POD_max_store_constraint",
        "dict_item_store_count_min_change_constraint",
        "dict_dc_min_stores_constraint",
    ]

    soft_constraint_slack_map = {
        "constraints_min_number_ns": "slack_min_ns_vars",
        "dict_min_reduce_constraint": "slack_reduce",
        "dict_max_expand_constraint": "slack_expand",
        "dict_brand_global_linear_space_change_constraints": ("slack_brand_space_min", "slack_brand_space_max"),
        "dict_supplier_global_linear_space_change_constraints": ("slack_supplier_space_min", "slack_supplier_space_max"),
        "dict_need_states_global_linear_space_change_constraints": ("slack_need_states_space_min", "slack_need_states_space_max"),
        "dict_cdt_global_linear_space_change_constraints": ("slack_choice_map_space_min", "slack_choice_map_space_max"),
        "dict_subcat_global_linear_space_change_constraints": ("slack_subcat_space_min", "slack_subcat_space_max"),
        "dict_segment_global_linear_space_change_constraints": ("slack_segment_space_min", "slack_segment_space_max"),
        "dict_item_POD_min_store_constraint": "slack_pod_lb",
        "dict_item_POD_max_store_constraint": "slack_pod_ub",
        "dict_item_store_count_min_change_constraint": "slack_store_count_min_change",
        "dict_dc_min_stores_constraint": "slack_dc_min_stores",
    }
    # Initialize violation counters and slack tracking
    hard_violations = []
    hard_violations_df = pd.DataFrame()
    soft_violations = []
    soft_violations_df = pd.DataFrame()
    hard_slack = []  # Non-binding hard constraints
    soft_slack = []  # Non-binding soft constraints
    total_hard_constraints = 0
    total_soft_constraints = 0
    
    # Check hard constraints
    for attr in hard_constraint_attrs:
        constraints = getattr(opti_data, attr, None)
        if constraints is None:
            continue
        
        for key, constr in constraints.items():
            total_hard_constraints += 1
            try:
                # PuLP normalizes ALL constraints to form: (lhs - rhs) sense 0
                # So constr.value() always returns (lhs - rhs), regardless of original constraint
                # Examples:
                #   Original: sum(x) == 1    → PuLP: sum(x) - 1 == 0    → constr.value() = sum(x) - 1
                #   Original: sum(x) >= 5    → PuLP: sum(x) - 5 >= 0    → constr.value() = sum(x) - 5  
                #   Original: sum(x) <= 10   → PuLP: sum(x) - 10 <= 0   → constr.value() = sum(x) - 10
                
                constraint_value = constr.value()  # This is always (original_lhs - original_rhs)
                sense = constr.sense
                tolerance = 1e-6
                
                # Check satisfaction based on PuLP's normalized form
                if sense == 0:  # == : constraint_value should be ≈ 0
                    violation_amount = abs(constraint_value)
                    satisfied = violation_amount <= tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                elif sense == 1:  # >= : constraint_value should be >= 0  
                    violation_amount = max(0, -constraint_value)  # How much below 0
                    satisfied = constraint_value >= -tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                elif sense == -1:  # <= : constraint_value should be <= 0
                    violation_amount = max(0, constraint_value)   # How much above 0
                    satisfied = constraint_value <= tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                else:
                    log.warning(f"Unknown constraint sense {sense} for {constr.name}")
                    continue
                
                if not satisfied:
                    violation_info = {
                        'name': constr.name,
                        'type': attr,
                        'key': key,
                        'constraint_value': constraint_value,
                        'sense': sense,
                        'sense_str': sense_str,
                        'violation_amount': violation_amount
                    }
                    hard_violations.append(violation_info)
                    log.warning(f"[HARD] Constraint {constr.name} violated: "
                              f"(lhs-rhs)={constraint_value:.6f} {sense_str} 0, "
                              f"violation={violation_amount:.6f}")
                else:
                    # Calculate slack/surplus for non-binding constraints
                    if sense == 0:  # equality - no slack concept, just show how close to binding
                        slack_amount = violation_amount  # Same as violation calc but it's satisfied
                        slack_type = "tolerance"
                    elif sense == 1:  # >= : surplus is how much above the minimum
                        slack_amount = constraint_value  # How much above 0 (i.e., above minimum)
                        slack_type = "surplus"
                    elif sense == -1:  # <= : slack is how much below the maximum  
                        slack_amount = -constraint_value  # How much below 0 (i.e., below maximum)
                        slack_type = "slack"
                    
                    slack_info = {
                        'name': constr.name,
                        'type': attr,
                        'key': key,
                        'constraint_value': constraint_value,
                        'sense': sense,
                        'sense_str': sense_str,
                        'slack_amount': slack_amount,
                        'slack_type': slack_type
                    }
                    hard_slack.append(slack_info)
                    
            except Exception as e:
                log.error(f"Error evaluating constraint {getattr(constr, 'name', str(key))}: {e}")
    
    # Check soft constraints
    for attr in soft_constraint_attrs:
        constraints = getattr(opti_data, attr, None)
        if constraints is None:
            continue
            
        for key, constr in constraints.items():
            total_soft_constraints += 1
            try:
                # PuLP normalizes ALL constraints to form: (lhs - rhs) sense 0
                # So constr.value() always returns (lhs - rhs), regardless of original constraint
                
                constraint_value = constr.value()  # This is always (original_lhs - original_rhs)
                sense = constr.sense
                tolerance = 1e-6
                
                # Check satisfaction based on PuLP's normalized form
                if sense == 0:  # == : constraint_value should be ≈ 0
                    violation_amount = abs(constraint_value)
                    satisfied = violation_amount <= tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                elif sense == 1:  # >= : constraint_value should be >= 0  
                    violation_amount = max(0, -constraint_value)  # How much below 0
                    satisfied = constraint_value >= -tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                elif sense == -1:  # <= : constraint_value should be <= 0
                    violation_amount = max(0, constraint_value)   # How much above 0
                    satisfied = constraint_value <= tolerance
                    sense_str, sense_desc = sense_map[sense]
                    
                else:
                    log.warning(f"Unknown constraint sense {sense} for {constr.name}")
                    continue
                
                if not satisfied:
                    violation_info = {
                        'name': constr.name,
                        'type': attr,
                        'key': key,
                        'constraint_value': constraint_value,
                        'sense': sense,
                        'sense_str': sense_str,
                        'violation_amount': violation_amount
                    }
                    soft_violations.append(violation_info)
                    log.warning(f"[SOFT] Constraint {constr.name} violated: "
                              f"(lhs-rhs)={constraint_value:.6f} {sense_str} 0, "
                              f"violation={violation_amount:.6f}")
                    
                    # Log group info for SKU percent change constraints
                    if attr in ["dict_min_reduce_constraint", "dict_max_expand_constraint"]:
                        log.info(f"SKU percent change constraint violated for group {key}")
                else:
                    # Calculate slack/surplus for non-binding soft constraints
                    if sense == 0:  # equality - no slack concept, just show how close to binding
                        slack_amount = violation_amount  # Same as violation calc but it's satisfied
                        slack_type = "tolerance"
                    elif sense == 1:  # >= : surplus is how much above the minimum
                        slack_amount = constraint_value  # How much above 0 (i.e., above minimum)
                        slack_type = "surplus"
                    elif sense == -1:  # <= : slack is how much below the maximum  
                        slack_amount = -constraint_value  # How much below 0 (i.e., below maximum)
                        slack_type = "slack"
                    
                    slack_info = {
                        'name': constr.name,
                        'type': attr,
                        'key': key,
                        'constraint_value': constraint_value,
                        'sense': sense,
                        'sense_str': sense_str,
                        'slack_amount': slack_amount,
                        'slack_type': slack_type
                    }
                    soft_slack.append(slack_info)
                        
            # except Exception as e:
            #     log.error(f"Error evaluating constraint {getattr(constr, 'name', str(key))}: {e}")
            except Exception as e:
                constraint_details = {
                    "key": key,
                    "name": getattr(constr, "name", "Unknown"),
                    "type": type(constr).__name__,
                    "sense": getattr(constr, "sense", "Unknown"),
                    "rhs": getattr(constr, "rhs", "Unknown"),
                    "expression": getattr(constr, "e", "Unknown"),
                }
                log.error(
                    f"Error evaluating constraint {constraint_details['name']} (key: {constraint_details['key']}, "
                    f"type: {constraint_details['type']}, sense: {constraint_details['sense']}, "
                    f"rhs: {constraint_details['rhs']}, expression: {constraint_details['expression']}): {e}"
                )
    # Log aggregate summary
    log.info("=" * 60)
    log.info("OPTIMIZATION QC SUMMARY")
    log.info("=" * 60)
    
    # Hard constraints summary
    if hard_violations:
        total_hard_violation = sum(v['violation_amount'] for v in hard_violations)
        log.error(f"HARD CONSTRAINTS: {len(hard_violations)} of {total_hard_constraints} violated")
        
        # Group violations by constraint type
        violation_by_type = {}
        for v in hard_violations:
            if v['type'] not in violation_by_type:
                violation_by_type[v['type']] = []
            violation_by_type[v['type']].append(v)
        
        for constraint_type, violations in violation_by_type.items():
            log.error(f"  {constraint_type}: {len(violations)} violations")
            
    else:
        log.info(f"HARD CONSTRAINTS: All {total_hard_constraints} constraints satisfied ✓")
    
    # Soft constraints summary
    if soft_violations:
        total_soft_violation = sum(v['violation_amount'] for v in soft_violations)
        
        log.warning(f"SOFT CONSTRAINTS: {len(soft_violations)} of {total_soft_constraints} violated")
        
        # Group violations by constraint type
        violation_by_type = {}
        for v in soft_violations:
            if v['type'] not in violation_by_type:
                violation_by_type[v['type']] = []
            violation_by_type[v['type']].append(v)
        
        for constraint_type, violations in violation_by_type.items():
            log.warning(f"  {constraint_type}: {len(violations)} violations")
            
    else:
        log.info(f"SOFT CONSTRAINTS: All {total_soft_constraints} constraints satisfied ✓")
    
    # Overall status
    if not hard_violations and not soft_violations:
        log.info("OPTIMIZATION QC PASSED: All constraints satisfied")
    elif hard_violations:
        log.warning("OPTIMIZATION QC FAILED: Hard constraint violations detected")
        hard_violations_df = pd.DataFrame(hard_violations)
    else:
        log.warning("OPTIMIZATION QC PASSED WITH WARNINGS: Soft constraint violations detected ✓")
        soft_violations_df = pd.DataFrame(soft_violations)
    
    log.info("=" * 60)

    # --- Business Rule QC for Soft Constraints ---
    log.info("BUSINESS RULE QC (SOFT CONSTRAINTS)")
    log.info("=" * 60)
    log.info("Checking for soft constraints where the business rule was violated (indicated by positive slack variables)...")
    
    solved_vars = {v.name: v for v in opti_data.model.variables()}

    business_rule_violations = 0
    tolerance = 1e-6
    for constr_attr, slack_attrs in soft_constraint_slack_map.items():
        # Normalize to a list to handle both strings and tuples
        if isinstance(slack_attrs, str):
            slack_attrs = [slack_attrs]

        violation_count_for_type = 0
        for slack_attr in slack_attrs:
            slack_vars_dict = getattr(opti_data, slack_attr, None)
            if not slack_vars_dict:
                continue

            for key, original_slack_var in slack_vars_dict.items():
                # Look up the SOLVED variable by its name
                solved_slack_var = solved_vars.get(original_slack_var.name)
                
                if solved_slack_var is None:
                    # This case should be rare but is good for debugging
                    log.debug(f"Could not find solved variable for {original_slack_var.name}")
                    continue

                slack_value = value(solved_slack_var)
                if slack_value > tolerance:
                    business_rule_violations += 1
                    violation_count_for_type += 1
                    log.warning(
                        f"[BUSINESS RULE] Violation in '{constr_attr}' for key {key}. "
                        f"Rule was not met by an amount of {slack_value:.4f} (slack variable '{solved_slack_var.name}' was used)."
                    )
        if violation_count_for_type > 0:
            log.warning(f"  └─ Found {violation_count_for_type} business rule violations for constraint type: {constr_attr}")

    if business_rule_violations == 0:
        log.info("All soft constraint business rules were satisfied without using slack variables. ✓")
    else:
        log.error(f"Total business rule violations found: {business_rule_violations}")
    log.info("=" * 60)

    # SLACK ANALYSIS - Show how much room non-binding constraints have
    log.info("CONSTRAINT SLACK ANALYSIS")
    log.info("=" * 60)
    
    # Hard constraints slack analysis

    if hard_slack:
        log.info(f"HARD CONSTRAINTS SLACK ({len(hard_slack)} non-binding constraints):")
        hard_slack_df = pd.DataFrame(hard_slack)
        hard_slack_df = hard_slack_df.drop(['constraint_value', 'sense'], axis=1)
        
    else:
        log.info("HARD CONSTRAINTS SLACK: No non-binding hard constraints (all are tight or violated)")
        hard_slack_df = pd.DataFrame(columns=["name", "type", "key", "sense_str", "slack_amount", "slack_type", "violated"])
    
    # Soft constraints slack analysis  
    if soft_slack:
        log.info(f"SOFT CONSTRAINTS SLACK ({len(soft_slack)} non-binding constraints):")
        soft_slack_df = pd.DataFrame(soft_slack)
        soft_slack_df = soft_slack_df.drop(['constraint_value', 'sense'], axis=1)
    
    else:
        soft_slack_df = pd.DataFrame(columns=["name", "type", "key", "sense_str", "slack_amount", "slack_type", "violated"])
        log.info("SOFT CONSTRAINTS SLACK: No non-binding soft constraints (all are tight or violated)")
    

    # Add 'violated' column to hard_slack_df
    if not hard_slack_df.empty:
        hard_slack_df['violated'] = 'No'
        if not hard_violations_df.empty:
            hard_slack_df['violated'] = hard_slack_df['name'].isin(hard_violations_df['name']).map({True: 'Yes', False: 'No'})

    # Add 'violated' column to soft_slack_df
    if not soft_slack_df.empty:
        soft_slack_df['violated'] = 'No'
        if not soft_violations_df.empty:
            soft_slack_df['violated'] = soft_slack_df['name'].isin(soft_violations_df['name']).map({True: 'Yes', False: 'No'})
            
    unmapped_clusters_planos_df = pd.DataFrame({"labels_not_found": opti_data.unmapped_clusters_planos["labels_not_found"]})

    log.info("=" * 60)


    return hard_slack_df, soft_slack_df, unmapped_clusters_planos_df, opti_data

