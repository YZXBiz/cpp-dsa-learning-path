import pandas as pd
from oxygen.conf.context import context
import re
import numpy as np
import logging

log = logging.getLogger(__name__)


def adjust_macro_space_then_report_store_count_before_and_after(
    df_linear_space_plano_dept_fixture: pd.DataFrame,
    df_macro_space_move: pd.DataFrame,
) -> pd.DataFrame:
    """
    Adjusts linear space based on macro space changes and reports the difference in store counts
    before and after the adjustment.

    Args:
        df_linear_space_plano_dept_fixture (pd.DataFrame): The original linear space data at the store and department level.
        df_macro_space_move (pd.DataFrame): Macro space move data containing adjustments to `plano_ft` and fixture size.

    Returns:
        pd.DataFrame: The adjusted `df_linear_space_plano_dept_fixture` DataFrame after applying macro space changes.
    """
    optimizer_cols = context.groupby_granularity.optimizer + [
        "plano_ft",
        "fixture_size",
        "plano_id"
    ]

    df_store_count_before = (
        df_linear_space_plano_dept_fixture.groupby(optimizer_cols)
        .agg(n_stores_before=("store_nbr", "nunique"))
        .reset_index()
    )

    df_linear_space_plano_dept_fixture = adjust_linear_space_with_macro_space(
        df_linear_space_plano_dept_fixture_original=df_linear_space_plano_dept_fixture,
        df_macro_space_move=df_macro_space_move,
    )

    df_store_count_after = (
        df_linear_space_plano_dept_fixture.groupby(optimizer_cols)
        .agg(n_stores_after=("store_nbr", "nunique"))
        .reset_index()
    )

    df_merged = df_store_count_before.merge(
        df_store_count_after,
        on=optimizer_cols,
        how="outer",
    )

    df_merged["n_stores_before"].fillna(0, inplace=True)
    df_merged["n_stores_after"].fillna(0, inplace=True)
    df_merged["n_stores_delta"] = (
        df_merged["n_stores_after"] - df_merged["n_stores_before"]
    )
    df_changed = df_merged[df_merged["n_stores_delta"] != 0]
    if len(df_changed) > 0:
        log.info(f"{df_changed.shape[0]} rows have changes in n_stores.")
        log.info(
            df_changed[
                optimizer_cols + ["n_stores_before", "n_stores_after", "n_stores_delta"]
            ]
        )

    # report for each dept how many stores have changed
    df_dept_store_changed = (
        df_linear_space_plano_dept_fixture.groupby("dept_id")
        .agg(
            n_stores_changed=("addtl_linear_ft_gained", lambda x: (x > 0).sum()),
        )
        .reset_index()
    )

    log.info("Number of stores changed per dept:")
    log.info(df_dept_store_changed)

    return df_linear_space_plano_dept_fixture


def adjust_linear_space_with_macro_space(
    df_linear_space_plano_dept_fixture_original: pd.DataFrame,
    df_macro_space_move: pd.DataFrame,
) -> pd.DataFrame:
    """
    Merges linear space data with macro space move data, applies adjustments to `plano_ft` and linear space,
    calculates differences, and logs unmatched or significantly different rows.

    Args:
        df_linear_space_plano_dept_fixture_original (pd.DataFrame): Original linear space data at the store and department level.
        df_macro_space_move (pd.DataFrame): Macro space move data with adjustments for `plano_ft` and linear space.

    Returns:
        pd.DataFrame: Updated DataFrame with adjusted plano and linear space values, including calculated differences.

    Steps:
        - Merges `df_macro_space_move` with the original data based on `store_nbr`, `dept_id`, and `plano_ft`.
        - Fills missing values in `plano_ft_change` and `addtl_linear_ft_gained` with `0`.
        - Updates `plano_ft` and `n_total_linear_space_dept_fixture_ft` with macro space adjustments.
        - Calculates and logs rows with significant differences in linear space (`linear_space_diff` > 1e-5).
    """

    # Merges `df_macro_space_move` with the original data based on `store_nbr`, `dept_id`, and `plano_ft`.
    # TODO: macro spaces moves for combo dept splits need to merge on NEW plano_ft values (post split)
    df_linear_space_plano_dept_fixture = (
        df_linear_space_plano_dept_fixture_original.merge(
            df_macro_space_move,
            left_on=["store_nbr", "dept_id", "plano_ft"],
            right_on=["store_nbr", "dept_id", "current_plano_ft"],
            how="left",
        )
    )

    # TODO: the plano_ft_change will have to reflect the change from the NEW plano_ft values
    matched_macro_space = df_linear_space_plano_dept_fixture[
        (df_linear_space_plano_dept_fixture["plano_ft_change"].notna())
        & (df_linear_space_plano_dept_fixture["addtl_linear_ft_gained"].notna())
    ]

    # Identify and log unmatched rows from df_macro_space_move
    df_unmatched_macro_space = df_macro_space_move[
        ~(
            (df_macro_space_move["store_nbr"].isin(matched_macro_space["store_nbr"]))
            & (df_macro_space_move["dept_id"].isin(matched_macro_space["dept_id"]))
            & (
                df_macro_space_move["current_plano_ft"].isin(
                    matched_macro_space["plano_ft"]
                )
            )
        )
    ]

    unmatched_count = df_unmatched_macro_space.shape[0]  # Number of unmatched rows
    total_count = df_macro_space_move.shape[
        0
    ]  # Total number of rows in df_macro_space_move
    if unmatched_count > 0:
        log.info(
            f"{unmatched_count} rows were not merged out of {total_count} total rows in df_macro_space_move."
        )
        log.info(
            df_unmatched_macro_space[
                [
                    "store_nbr",
                    "dept_id",
                    "dept_id_replaced",
                    "current_plano_ft",
                    "current_fixture_desc",
                    "current_plano_ft_replaced",
                    "current_fixture_desc_replaced",
                    "plano_ft_change",
                    "addtl_linear_ft_gained",
                ]
            ]
        )

    # Apply adjustments and calculate differences
    # Fills missing values in `plano_ft_change` and `addtl_linear_ft_gained` with `0`.
    df_linear_space_plano_dept_fixture["plano_ft_change"].fillna(0, inplace=True)
    df_linear_space_plano_dept_fixture["addtl_linear_ft_gained"].fillna(0, inplace=True)

    # Updates `plano_ft` and `n_total_linear_space_dept_fixture_ft` with macro space adjustments.
    df_linear_space_plano_dept_fixture["plano_ft"] = (
        df_linear_space_plano_dept_fixture["post_split_plano_ft"]
        + df_linear_space_plano_dept_fixture["plano_ft_change"]
    )
    df_linear_space_plano_dept_fixture["n_total_linear_space_dept_fixture_ft"] = (
        df_linear_space_plano_dept_fixture[
            "override_n_total_linear_space_dept_fixture_ft"
        ]
        + df_linear_space_plano_dept_fixture["addtl_linear_ft_gained"]
    )

    # Calculates and logs rows with significant differences in linear space (`linear_space_diff` > 1e-5).
    df_linear_space_plano_dept_fixture["linear_space_diff"] = np.where(
        df_linear_space_plano_dept_fixture["current_total_linear_ft"].notna(),
        df_linear_space_plano_dept_fixture[
            "override_n_total_linear_space_dept_fixture_ft"
        ]
        - df_linear_space_plano_dept_fixture["current_total_linear_ft"],
        0,
    )
    threshold = 1e-5
    df_large_diff = df_linear_space_plano_dept_fixture[
        np.abs(df_linear_space_plano_dept_fixture["linear_space_diff"]) > threshold
    ]

    if len(df_large_diff) > 0:
        log.info(
            f"{df_large_diff.shape[0]} rows have a linear_space_diff greater than {threshold}."
        )
        log.info(
            df_large_diff[
                [
                    "store_nbr",
                    "dept_id",
                    "current_total_linear_ft",
                    "override_n_total_linear_space_dept_fixture_ft",
                    "pre_split_n_total_linear_space_dept_fixture_ft",
                    "linear_space_diff",
                ]
            ]
        )

    return df_linear_space_plano_dept_fixture


def get_store_representative_with_median_total_space(
    df_linear_space_plano_dept_fixture: pd.DataFrame,
    df_abs_difference_with_median_store: pd.DataFrame,
) -> pd.DataFrame:
    """
    Calculating the median sum of linear space per `[plano_cat_desc, dept_id, final_cluster_labels, plano_ft,
    fixture_size]` across stores and only keeping the store closest to that median, which will be our store
    representative. If there is a tie, we'll take the store with the lowest difference in facings to the "artificial
    median store", see docstrings of function `tie_break_with_distance_to_artificial_median_store()` for more details
    Args:
        df_linear_space_plano_dept_fixture: DataFrame containing the total linear space available for the
        prioritized (for optimization) dept_id, plano_ft, fixture sizes
        df_abs_difference_with_median_store (pd.DataFrame): DataFrame containing the score differences between each
        store and the artificial median store.

    Returns:
    DataFrame with `PrioritizedStoreRepresentativeSchema` schema, containing a mapping between one unique `store_nbr`
    and one unique group of `[plano_cat_id, plano_cat_desc, dept_id, final_cluster_labels, plano_ft, fixture_size]`
    """
    # Creating the quantile_linear_space_available
    df_median_linear_space = (
        df_linear_space_plano_dept_fixture.groupby(
            (
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_store_representative
            )
        )["n_total_linear_space_dept_fixture_ft"]
        .quantile(context.optimization.data_prep.representative_store_quantile)
        .reset_index()
        .rename(
            columns={
                "n_total_linear_space_dept_fixture_ft": "quantile_linear_space_available"
            }
        )
    )

    # Joining it back and creating a ratio of how close the true space value is from the median, and getting the min
    df_linear_space_plano_dept_fixture = df_linear_space_plano_dept_fixture.merge(
        df_median_linear_space,
        on=(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_store_representative
        ),
        how="inner",
    )
    df_linear_space_plano_dept_fixture["proximity_to_median_linear_space"] = np.abs(
        df_linear_space_plano_dept_fixture["quantile_linear_space_available"]
        / df_linear_space_plano_dept_fixture["n_total_linear_space_dept_fixture_ft"]
        - 1
    )

    df_closest_store_to_median = (
        df_linear_space_plano_dept_fixture.groupby(
            (
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_store_representative
            )
        )["proximity_to_median_linear_space"]
        .min()
        .reset_index()
    )

    # Keeping only the store closest to the median linear space for a given
    # [plano_cat_desc, dept_id, final_cluster_labels, plano_ft, fixture_size]
    df_store_representative = df_linear_space_plano_dept_fixture.merge(
        df_closest_store_to_median,
        on=(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_store_representative
            + ["proximity_to_median_linear_space"]
        ),
        how="inner",
    ).drop(
        columns=["proximity_to_median_linear_space", "quantile_linear_space_available"]
    )

    df_store_representative = tie_break_with_distance_to_artificial_median_store(
        df_store_representative=df_store_representative,
        df_abs_difference_with_median_store=df_abs_difference_with_median_store,
    )
    return df_store_representative


def calculate_abs_difference_with_median_store(
    df_latest_space_data: pd.DataFrame,
    df_final_clusters: pd.DataFrame,
) -> pd.DataFrame:
    """
    Calculates the absolute difference between the current facings in each store and the median facings
    for each SKU at the (POG Category, dept, plano_ft, cluster, SKU) level, and generates a score based
    on these differences.

    Args:
        df_latest_space_data: DataFrame containing space data for the most recent week of each `plano_cat_id, dept_id`
        df_final_clusters: DataFrame containing the final cluster labels used for space elasticity and optimization

    Returns:
        pd.DataFrame: DataFrame with the absolute difference score for each store.
    """
    df_latest_space_data_x_clusters = df_latest_space_data.merge(
        df_final_clusters,
        on=context.groupby_granularity.clustering,
        how="inner",
    )
    df_median_facings_in_cluster = (
        df_latest_space_data_x_clusters.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_cluster_planoft_level
            + ["item_no_nbr"]
        )["hfacings"]
        .median()
        .reset_index()
        .rename(columns={"hfacings": "n_median_current_facings_sku"})
    )

    df_latest_space_data_x_clusters = df_latest_space_data_x_clusters.merge(
        df_median_facings_in_cluster,
        on=(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_cluster_planoft_level
            + ["item_no_nbr"]
        ),
        how="inner",
    )

    df_latest_space_data_x_clusters[
        "n_abs_difference_with_median_store_facings_sku"
    ] = np.abs(
        df_latest_space_data_x_clusters["hfacings"]
        - df_latest_space_data_x_clusters["n_median_current_facings_sku"]
    )

    # Aggregating to get the total difference (which will be a score)
    df_abs_difference_with_median_store = (
        df_latest_space_data_x_clusters.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_cluster_planoft_level
            + ["store_nbr"]
        )["n_abs_difference_with_median_store_facings_sku"]
        .sum()
        .reset_index()
        .rename(
            columns={
                "n_abs_difference_with_median_store_facings_sku": "n_score_difference_with_median_store"
            }
        )
    )

    return df_abs_difference_with_median_store


def tie_break_with_distance_to_artificial_median_store(
    df_store_representative: pd.DataFrame,
    df_abs_difference_with_median_store: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function calculates the median number of facings at the (POG Category, dept, plano_ft, cluster, SKU) level &
    artificially creates a "median store", and then we calculate the absolute difference for each store between the
    actual facings a SKU has and that median number of facings; the sum of these absolute differences will correspond to
    a score, where within a (cluster, plano_ft), the store with the lowest score will be the one closest to the median
    store, and therefore the one that we will be choosing to represent the cluster, plano_ft
    Args:
        df_store_representative: DataFrame with `PrioritizedStoreRepresentativeSchema` schema, containing a mapping
        between multiple `store_nbr` and one unique group of `[plano_cat_id, plano_cat_desc, plano_ft_in_dept,
        final_cluster_labels]`, where this function is meant to make it a one-to-one mapping
        df_abs_difference_with_median_store (pd.DataFrame): DataFrame containing the score differences between each
        store and the artificial median store.

    Returns:
    DataFrame with `PrioritizedStoreRepresentativeSchema` schema, containing a mapping between one unique `store_nbr`
    and one unique group of `[plano_cat_id, plano_cat_desc, dept_id, plano_ft, final_cluster_labels]`
    """

    # Joining back with store representative dataset
    df_store_representative = df_store_representative.merge(
        df_abs_difference_with_median_store,
        on=(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_cluster_planoft_level
            + ["store_nbr"]
        ),
        how="left",
    )

    # Keeping only the store with the lowest score difference with median store (i.e. the closest one)
    df_store_representative = (
        df_store_representative.sort_values(
            by=["n_score_difference_with_median_store", "store_nbr"]
        )
        .drop_duplicates(
            subset=(
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_store_representative
            ),
            keep="first",
        )
        .drop(columns=["n_score_difference_with_median_store"])
    )

    return df_store_representative


def extract_fixture_size_from_string_col(
    df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Extracts the fixture size which is assumed to be either of the format 'xxUNIT' or 'xx.yyUNIT' using regular
    expressions
    Args:
        df: DataFrame containing a column named fixture_desc which will be processed to get fixture size and unit


    Returns:
    Same dataframe with 2 new features `fixture_size` and `fixture_unit`
    """

    def extract_size(fixture_desc):
        size_decimal = re.search(r"\d+\.\d+", fixture_desc)
        size_int = re.search(r"\d+", fixture_desc)
        if size_decimal:
            return float(size_decimal.group())
        elif size_int:
            return float(size_int.group())
        else:
            return None

    def extract_unit(fixture_desc):
        unit = re.search(r"[A-Z]+", fixture_desc)
        return unit.group() if unit else None

    df["fixture_size"] = df["fixture_desc"].apply(extract_size).astype(float)
    df["fixture_unit"] = df["fixture_desc"].apply(extract_unit).astype(str)
    df["fixture_size"].fillna(0, inplace=True)
    df["fixture_unit"].fillna("NA", inplace=True)

    return df
