import gc
from typing import Dict, List, Tuple, Union, Literal, Optional
import numpy as np
import warnings
import pandas as pd
from core.modules.optimization.model_data_wrapper_v2 import OptimizationModelData
from core.utils.optimizer_helpers import check_duplicates
from oxygen.conf.context import context
import logging
import ipdb

log = logging.getLogger(__name__)


def create_optimization_model_sets_and_params_v2(
        df_optimization_master_data_filt: pd.DataFrame,
        dependent_var: str,
        category_level_dept_nbr: int,
        plano_cat_desc: str,
        department: int,
) -> Tuple[OptimizationModelData, pd.DataFrame]:
    # TODO this need refactor
    """
    This function creates all the sets of indices used for optimization model formulation, as well as all the
    parameters used for the constraints formulation (or objective function).
    It will also instantiate a `OptimizationModelData` object that will be updated later on with constraints, decision
    variables and objective function.
    Notice that we have to filter at the very beginning to `df_optimization_master_data_filt_optimizer_only` because
    we want the optimizer to only see SKUs that were modeled on; the other ones (with `include_in_optimizer_choices = 0`
    ) are only here so that the space comparison is apple to apple between current and optimized assortment
    Args:
        df_optimization_master_data_filt: Optimization master data containing all the data we need for formulating
        and solving the optimization model for that specific [plano_cat_id, cluster_id]
        dependent_var: Dependent variable on which we're optimizing (can either be sales or dnp)
        category_level_dept_nbr: Category_level selected by CM
        plano_cat_desc: POG Category on which we want to run optimization
        department: Department on which we're currently looping for optimization problems
        fixture_size: Fixture size on which we're currently looping for optimization problems
        cluster_id: Store Cluster on which we want to run optimization
        plano_ft: Plano ft in POG Category (typically could have 2-3 different values possible across all
        stores for a given POG Category) rounded to closest integer

    Returns:
    A tuple of an instantiated `OptimizationModelData` object and the master optimization dataframe with 3 new fields
    """

    for dimension, col_name in context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.items():
        df_optimization_master_data_filt[f"{dimension}_global_linear_space"] = (df_optimization_master_data_filt
                                                                                .groupby(col_name)["n_current_linear_space_used_sku"].transform("sum")
                                                                                )

    df_optimization_master_data_filt["total_facings_space_in_dept"] = df_optimization_master_data_filt.groupby(["plano_id", "final_cluster_labels", "plano_ft", "fixture_size"])["n_current_facings_sku"].transform("sum")

    # Creating main sets
    df_optimization_master_data_filt_optimizer_only = df_optimization_master_data_filt[
        df_optimization_master_data_filt["include_in_optimizer_choices"] == 1
        ].copy()

    if df_optimization_master_data_filt_optimizer_only.empty:
        log.info(
            f"Filtered optimization input is empty, # of SKUs went from {df_optimization_master_data_filt.item_no_nbr.nunique()} to "
            f"{df_optimization_master_data_filt_optimizer_only.item_no_nbr.nunique()}"
        )
        return (None, pd.DataFrame())

    log.info(
        "Filtered optimization input to contain only SKUs that the optimizer can choose from, "
        f"# of SKUs went from {df_optimization_master_data_filt.item_no_nbr.nunique()} to "
        f"{df_optimization_master_data_filt_optimizer_only.item_no_nbr.nunique()}"
    )
    log.info(
        f"# of brands went from {df_optimization_master_data_filt.brand_name.nunique()} to "
        f"{df_optimization_master_data_filt_optimizer_only.brand_name.nunique()}"
    )
    # excluded_brands = np.setdiff1d(
    #     df_optimization_master_data_filt["brand_name"].unique(),
    #     df_optimization_master_data_filt_optimizer_only["brand_name"].unique(),
    # )
    # log.info(f"Filtered out brands: {excluded_brands}")
    brands_all = df_optimization_master_data_filt["brand_name"]
    brands_all = brands_all[brands_all.notna() & (brands_all != None)].unique()
    
    brands_optimizer_only = df_optimization_master_data_filt_optimizer_only["brand_name"]
    brands_optimizer_only = brands_optimizer_only[brands_optimizer_only.notna() & (brands_optimizer_only != None)].unique()
    
    excluded_brands = np.setdiff1d(brands_all, brands_optimizer_only)
    log.info(f"Filtered out brands: {excluded_brands}")

    df_optimization_master_data_filt_optimizer_only["brand_name"].fillna("NEW SKU", inplace=True)

    cols_to_confirm_no_na = [
        "item_no_nbr",
        "brand_name",
        "need_state_unique_id",
        "final_cluster_labels",
        "plano_ft",
        "fixture_size",
        "plano_id",
        "n_stores_item_no_forced_exist",
        "n_stores_item_no_exist_after_forced_drop",
        "min_POD",
        "max_POD",
        "min_POD_active",
        "max_POD_active",
        "n_stores",
        "is_regional_cluster",
        "is_regional_item",
        "n_current_linear_space_per_facing_sku",
        "n_transference_sku",
    ]

    na_counts = df_optimization_master_data_filt_optimizer_only.isna().sum()
    na_cols = na_counts[na_counts > 0]
    log.info(na_cols)

    for col in cols_to_confirm_no_na:
        if col in na_cols:
            log.error(f"Column {col} has NA values")
            raise ValueError(f"Column {col} has NA values")

    df_optimization_master_data_filt_optimizer_only, items_all = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["item_no_nbr"],
        index_name="items_all_idx",
    )
    (
        df_optimization_master_data_filt_optimizer_only,
        need_states,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["need_state_unique_id"],
        index_name="need_states_idx",
    )
    (
        df_optimization_master_data_filt_optimizer_only,
        cdts,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["cdt"],
        index_name="choice_map_idx",
    )

    (
        df_optimization_master_data_filt_optimizer_only,
        suppliers,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["supplier_name"],
        index_name="supplier_idx",
    )
    (
        df_optimization_master_data_filt_optimizer_only,
        brands,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["brand_name"],
        index_name="brand_idx",
    )
    (
        df_optimization_master_data_filt_optimizer_only,
        subcats,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["subcat_dsc"],
        index_name="subcat_idx",
    )
    (
        df_optimization_master_data_filt_optimizer_only,
        segments,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["seg_dsc"],
        index_name="segment_idx",
    )

    (
        df_optimization_master_data_filt_optimizer_only,
        clusters,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["final_cluster_labels"],
        index_name="cluster_idx",
    )

    (
        df_optimization_master_data_filt_optimizer_only,
        original_clusters,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["original_cluster_labels"],
        index_name="original_cluster_idx",
    )

    (
        df_optimization_master_data_filt_optimizer_only,
        all_plano_fixture,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["plano_ft", "fixture_size", "plano_id"],
        index_name="plano_fixture_idx",
    )

    # Temporary solution for getting the risk and volume flags
    split_labels = df_optimization_master_data_filt_optimizer_only["final_cluster_labels"].str.rsplit("-", n=1, expand=True)
    df_optimization_master_data_filt_optimizer_only["lp_flags"] = split_labels[1]
    df_optimization_master_data_filt_optimizer_only[["volume_flag", "risk_flag"]] = df_optimization_master_data_filt_optimizer_only["lp_flags"].str.split("_", expand=True)
    df_optimization_master_data_filt_optimizer_only = df_optimization_master_data_filt_optimizer_only.drop(columns="lp_flags")

    (
        df_optimization_master_data_filt_optimizer_only,
        risk_flag,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["risk_flag"],
        index_name="risk_flag_idx",
    )

    (
        df_optimization_master_data_filt_optimizer_only,
        volume_flag,
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["volume_flag"],
        index_name="volume_flag_idx",
    )

    # Create planogram index mapping
    (
        df_optimization_master_data_filt_optimizer_only,
        plano_idx
    ) = create_index_set_in_df(
        df=df_optimization_master_data_filt_optimizer_only,
        index_cols=["plano_id"],
        index_name="plano_idx",
    )
    eligible_tuples = df_optimization_master_data_filt_optimizer_only[
        ["brand_idx", "cluster_idx", "plano_fixture_idx"]
    ].drop_duplicates()
    eligible_brand_cg = [tuple(x) for x in eligible_tuples.to_numpy()]

    # confirm each cluster_idx, plano_fixture_idx pair store_count is unique
    check_duplicates(
        df=df_optimization_master_data_filt_optimizer_only[
            ["cluster_idx", "plano_fixture_idx", "n_stores"]
        ].drop_duplicates(),
        df_name="df_optimization_master_data_store_count",
        subset=["cluster_idx", "plano_fixture_idx"],
    )

    # Get the cluster, plano specific store count
    store_count_by_cluster_plano = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["n_stores"]
        .first()
        .to_dict()
    )

    # add list of cluster_idx that are not regional cluster. (we only create binary for those)
    regional_indicator_by_cluster = (
        df_optimization_master_data_filt_optimizer_only.groupby("cluster_idx")[
            "is_regional_cluster"
        ]
        .first()
        .to_dict()
    )

    # get the g_c set (set of g pairs for each cluster)
    plano_fixture_by_cluster = (
        df_optimization_master_data_filt_optimizer_only.groupby("cluster_idx")[
            "plano_fixture_idx"
        ]
        .unique()  # Get unique plano_fixture indices for each cluster
        .apply(list)  # Convert to a list
        .to_dict()  # Convert the Series to a dictionary
    )

    # mapping for ("plano_ft", "fixture_size") to plano_fixture_idx
    plano_fixture_mapping = pd.Series(
        df_optimization_master_data_filt_optimizer_only["plano_fixture_idx"].values,
        index=list(
            zip(
                df_optimization_master_data_filt_optimizer_only["plano_ft"],
                df_optimization_master_data_filt_optimizer_only["fixture_size"],
                df_optimization_master_data_filt_optimizer_only["plano_id"],
            )
        ),
    ).to_dict()

    items_per_c_g = {
        (c, g): np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    (
                            df_optimization_master_data_filt_optimizer_only["cluster_idx"]
                            == c
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "plano_fixture_idx"
                            ]
                            == g
                    )
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for c in clusters
        for g in plano_fixture_by_cluster[c]
    }

    items_own_brand_only_per_c_g = {
        (c, g): np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    (
                            df_optimization_master_data_filt_optimizer_only["cluster_idx"]
                            == c
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "plano_fixture_idx"
                            ]
                            == g
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "private_label_ind"
                            ]
                            == 1
                    )
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for c in clusters
        for g in plano_fixture_by_cluster[c]
    }

    # Get list of planograms to constraint on linear space only
    linear_space_plano_substring = (
        '|'
        .join(context.optimization.data_prep.facing_count_planograms
             + context.optimization.data_prep.linear_space_facing_count_planograms
             )
    )
    linear_space_only_constrained_planos = (
        df_optimization_master_data_filt_optimizer_only[
            ~df_optimization_master_data_filt_optimizer_only["plano_id"].str.contains(linear_space_plano_substring, case=False, na=False)
        ]
        ["plano_fixture_idx"]
        .unique()
        .tolist()
    )

    # Get list of planograms to constraint on facing count only
    facing_plano_substring = '|'.join(context.optimization.data_prep.facing_count_planograms)
    facing_only_constrained_planos = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["plano_id"].str.contains(facing_plano_substring, case=False, na=False)
        ]
        ["plano_fixture_idx"]
        .unique()
        .tolist()
    )

    # Get the regional items and non-regional items index
    regional_items = df_optimization_master_data_filt_optimizer_only[
        df_optimization_master_data_filt_optimizer_only["is_regional_item"] == 1
        ]["items_all_idx"].unique()
    non_regional_items = np.setdiff1d(items_all, regional_items)

    item_POD_enforce_type = (
        df_optimization_master_data_filt_optimizer_only[
            (df_optimization_master_data_filt_optimizer_only["min_POD_active"] == 1)
            | (df_optimization_master_data_filt_optimizer_only["max_POD_active"] == 1)
            ]
        .groupby("items_all_idx")["POD_enforce"]
        .first()
        .to_dict()
    )

    item_POD_threshold_LB = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["min_POD_active"] == 1
            ]
        .groupby("items_all_idx")["min_POD"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    item_POD_threshold_UB = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["max_POD_active"] == 1
            ]
        .groupby("items_all_idx")["max_POD"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    brand_POD_threshold_LB = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["min_brand_POD_active"] == 1
            ]
        .groupby("brand_idx")["min_brand_POD"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    brand_POD_threshold_UB = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["max_brand_POD_active"] == 1
            ]
        .groupby("brand_idx")["max_brand_POD"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    smallest_non_regional_item_per_need_state_dict = (
        get_smallest_non_regional_item_per_need_state(
            df_optimization_master_data_filt_optimizer_only
        )
    )

    # update available need state due to forced 0 facings
    (
        available_need_states_num_update,
        df_optimization_master_data_filt_optimizer_only,
    ) = update_available_need_state_number(
        df_optimization_master_data_filt_optimizer_only
    )

    ns_per_c_g = {
        (c, g): np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    (
                            df_optimization_master_data_filt_optimizer_only["cluster_idx"]
                            == c
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "plano_fixture_idx"
                            ]
                            == g
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "need_state_unavailable"
                            ]
                            == 0
                    )
                    ]["need_states_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for c in clusters
        for g in plano_fixture_by_cluster[c]
    }

    # Mapping for item_no_nbr to item index in optimization
    item_idx_to_item_no = (
        df_optimization_master_data_filt_optimizer_only.groupby(["items_all_idx"])[
            "item_no_nbr"
        ]
        .first()
        .dropna()
        .to_dict()
    )

    brand_idx_to_brand = (
        df_optimization_master_data_filt_optimizer_only.groupby(["brand_idx"])[
            "brand_name"
        ]
        .first()
        .dropna()
        .to_dict()
    )

    # Create mapping from index to plano_id
    plano_idx_to_plano = (
    df_optimization_master_data_filt_optimizer_only.groupby(["plano_idx"])["plano_id"]
        .first()
        .to_dict()
    )

    items_per_need_state_c_g = {
        (n, c, g): np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    (
                            df_optimization_master_data_filt_optimizer_only[
                                "need_states_idx"
                            ]
                            == n
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only["cluster_idx"]
                            == c
                    )
                    & (
                            df_optimization_master_data_filt_optimizer_only[
                                "plano_fixture_idx"
                            ]
                            == g
                    )
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for c in clusters
        for g in plano_fixture_by_cluster[c]
        for n in ns_per_c_g[(c, g)]
    }

    # Creating sets of items per need states
    items_per_need_states = {
        need_state: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["need_states_idx"]
                    == need_state
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for need_state in need_states
    }

    # Creating sets of items per choice maps
    items_per_cdt = {
        cdt: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["choice_map_idx"]
                    == cdt
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for cdt in cdts
    }

    # Creating subsets
    facings_per_item = np.array(
        [
            [
                f
                for f in range(
                0, context.optimization.model_formulation.max_facings_opti
            )
            ]
            for i in items_all
        ]
    )

    # Create subsets for (Cluster, Plano fixture, Risk Flag, Volume Flag)
    items_per_c_g_r_v = (
        df_optimization_master_data_filt_optimizer_only[df_optimization_master_data_filt_optimizer_only["n_current_facings_sku"]>0]
        .groupby(["cluster_idx", "plano_fixture_idx", "risk_flag_idx", "volume_flag_idx"])["items_all_idx"]
        .apply(list)
        .to_dict()
    )


    # Ignoring the warning, these arrays of arrays are meant not to have the same inner lengths
    warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)

    # Initialize an empty dictionary to store the results
    # Nested for loops to iterate through items_all, clusters, and plano_fixture_idx
    facings_per_item_ineligible_max_incremental = get_list_facings_ineligible_for_constraints_vectorized(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
        col_reference="n_current_facings_sku",
        output_col="facings_per_item_ineligible_max_incremental",
        facings_param=context.optimization.model_formulation.max_incremental_facings_sku,
        max_facings_opti=context.optimization.model_formulation.max_facings_opti,
        mode="incremental"
    )

    facings_per_item_ineligible_max_decremental = get_list_facings_ineligible_for_constraints_vectorized(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
        col_reference="n_current_facings_sku",
        output_col="facings_per_item_ineligible_max_decremental",
        facings_param=context.optimization.model_formulation.max_decremental_facings_sku,
        max_facings_opti=context.optimization.model_formulation.max_facings_opti,
        mode="decremental"
    )

    facings_per_item_above_max_authorized_in_dept = get_list_facings_ineligible_for_constraints_vectorized(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
        col_reference="n_facings_config_percentile_dept",
        output_col="facings_per_item_above_max_authorized_in_dept",
        facings_param=context.optimization.model_formulation.max_incremental_facings_from_dept_percentile,
        max_facings_opti=context.optimization.model_formulation.max_facings_opti,
        mode="incremental"
    )

    log.info(f"Finished facings_per_item_above_max_authorized_in_dept...")

    # Getting the max facings per need state based on config
    (
        df_optimization_master_data_filt_optimizer_only,
        min_facings_per_need_state,
        max_facings_per_need_state,
    ) = get_min_and_max_facings_per_need_state(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
    )

    # Forced facings guardrail constraint & items array
    facings_per_item_forced_guardrail = get_facings_forced_facings_guardrails_constraint(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only
    )

    # Own brand / Private label items
    items_own_brand_only = np.array(
        sorted(
            df_optimization_master_data_filt_optimizer_only[
                df_optimization_master_data_filt_optimizer_only["private_label_ind"]
                == 1
                ]["items_all_idx"]
            .drop_duplicates()
            .tolist()
        )
    )
    items_per_supplier = {
        supplier: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["supplier_idx"]
                    == supplier
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for supplier in suppliers
    }
    items_per_brand = {
        brand: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["brand_idx"]
                    == brand
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for brand in brands
    }

    items_per_subcat = {
        subcat: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["subcat_idx"]
                    == subcat
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for subcat in subcats
    }

    items_per_segment = {
        segment: np.array(
            sorted(
                df_optimization_master_data_filt_optimizer_only[
                    df_optimization_master_data_filt_optimizer_only["segment_idx"]
                    == segment
                    ]["items_all_idx"]
                .drop_duplicates()
                .tolist()
            )
        )
        for segment in segments
    }

    # Model Parameters
    item_width_x_facings = get_item_width_x_facings(
        df_optimization_master_data_filt_optimizer_only
    )

    for f in range(context.optimization.model_formulation.max_facings_opti):
        column_name = f"n_space_prod_fit_facings_{f}"
        df_optimization_master_data_filt_optimizer_only[
            column_name
        ] = df_optimization_master_data_filt_optimizer_only[column_name].fillna(0)

    item_productivity_per_facing = get_item_productivity_per_facing(
        df_optimization_master_data_filt_optimizer_only
    )

    (
        final_cluster_by_original_cluster,
        original_idx_to_original_cluster,
        # original_cluster_labels_ioh_constrained,
        # cluster_ioh_full_budget,
        # min_pct_ioh_constraint,
        # max_pct_ioh_constraint,
    ) = get_working_capital_constraints_sets_and_params(
        df_optimization_master_data_filt_optimizer_only
    )

    # TODO: Re-add when IOD constraints are implemented
    # ioh_cost_per_facing = get_ioh_cost_per_facing(
    #     df_optimization_master_data_filt_optimizer_only
    # )

    # Adding current productivity for the penalty in objective function
    df_optimization_master_data_filt_optimizer_only[
        "n_current_space_prod_at_current_facings"
    ] = df_optimization_master_data_filt_optimizer_only.apply(
        lambda row: row[
            f"n_space_prod_fit_facings_{int(row['n_current_facings_sku'])}"
        ],
        axis=1,
    )

    item_productivity_current_facings = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
        )["n_current_space_prod_at_current_facings"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    # Add top item current facing productivity per need states
    need_states_top1_item_productivity_current_facing = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["need_states_idx", "items_all_idx"]
        )
        .apply(lambda x: x.nlargest(1, ["n_current_space_prod_at_current_facings"]))
        .reset_index(drop=True)
        .groupby(["need_states_idx"])
        .agg(
            sum_top_item_productivity=("n_current_space_prod_at_current_facings", "sum")
        )["sum_top_item_productivity"]
        .round(4)
        .to_dict()
    )
    log.info(
        f"sum_need_states_top1_item_productivity_current_facing = {sum(need_states_top1_item_productivity_current_facing.values()):.2f}"
    )

    df_optimization_master_data_filt_optimizer_only.drop(
        columns=["n_current_space_prod_at_current_facings"], inplace=True
    )

    current_facings_per_item = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
        )["n_current_facings_sku"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )

    # Other Constants and Parameters
    item_height = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
        )["prod_unit_height_ft"]
        .max()
        .dropna()
        .to_dict()
    )

    item_depth = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
        )["prod_unit_depth_ft"]
        .max()
        .dropna()
        .to_dict()
    )

    total_linear_space_in_dept = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["n_total_linear_space_dept_fixture_ft"]
        .first()
        # .dropna()
        .fillna(0)
        .to_dict()
    )

    total_linear_space_in_dept_for_own_brand = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["n_total_linear_space_dept_fixture_ft_for_own_brand"]
        .first()
        .dropna()
        .to_dict()
    )

    total_facings_space_in_dept = ( 
        df_optimization_master_data_filt_optimizer_only.groupby( 
            ["cluster_idx", "plano_fixture_idx"] 
        )["total_facings_space_in_dept"]
        .first()
        .dropna()
        .to_dict()
    ) 

    height_space_in_dept = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["height_space_dept_fixture_ft"]
        .min()
        .dropna()
        .to_dict()
    )

    depth_space_in_dept = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["depth_space_dept_fixture_ft"]
        .min()
        .dropna()
        .to_dict()
    )

    max_pct_drop_own_brand_space = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["max_pct_drop_own_brand_space"]
        .first()
        .dropna()
        .to_dict()
    )

    min_pct_allocated_from_total_space_to_own_brands = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["min_pct_allocated_from_total_space_to_own_brands"]
        .first()
        .dropna()
        .to_dict()
    )

    max_pct_allocated_from_total_space_to_own_brands = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["max_pct_allocated_from_total_space_to_own_brands"]
        .first()
        .dropna()
        .to_dict()
    )

    # Adding item transference
    item_transference = np.array(
        [
            df_optimization_master_data_filt_optimizer_only[
                df_optimization_master_data_filt_optimizer_only["items_all_idx"] == i
                ]["n_transference_sku"]
            .drop_duplicates()
            .round(4)
            .unique()[0]
            for i in items_all
        ]
    )

    # Supplier / Brand Constraints
    dict_dimension_indices = {
        "brand": brands,
        "supplier": suppliers,
    }
    list_constraint_types = sorted(
        list(
            set(
                [
                    "_".join(
                        constraint_type_raw.split("_")[1:]
                    )  # removes "supplier_" or "brand_"
                    for constraint_type_raw in (
                    context.optimization.manual_constraints.authorized_supplier_brand_constraint_types.keys()
                )
                ]
            )
        )
    )

    dict_supplier_brand_constraints = {}
    for dimension in dict_dimension_indices.keys():
        for constraint_type in list_constraint_types:
            # Dynamically creates the dictionaries for the right dimension an constraint type, and will be
            # added as **kwargs to the OptimizationModelData
            dict_supplier_brand_constraints[f"{dimension}_{constraint_type}"] = vars()[
                f"{dimension}_{constraint_type}"
            ] = get_supplier_or_brand_space_constraint_bound(
                constraint_type=constraint_type,
                dimension=dimension,
                dimension_indices=dict_dimension_indices[dimension],
                df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
            )

    # Global Supplier / Brand Constraints
    dict_global_linear_space_change_constraints = {}
    for dimension in context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions.keys():
        dict_global_linear_space_change_constraints[dimension] = get_global_linear_space_constraint_bound(
            dimension=dimension,
            df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
        )

    # Pivot/Linked SKU pairs
    dict_cluster_plano_pivot_to_linked_skus = get_pivot_and_linked_sku_pairs_constraints(
        df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
    )
    # Local Items reserved space
    df_optimization_master_data_filt_optimizer_only["pct_space_for_local_items"] = (
        df_optimization_master_data_filt_optimizer_only["pct_space_for_local_items"]
        .fillna(method="pad")
        .fillna(context.optimization.model_formulation.local_items_reserved_space_pct)
    )  # The second fillna will fill with a default value, but should only happen when there is no value in the col

    local_items_reserved_space_pct = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["cluster_idx", "plano_fixture_idx"]
        )["pct_space_for_local_items"]
        .first()
        .dropna()
        .to_dict()
    )

    dict_assortment_expansion_reduction_idx, unmapped_clusters_planos = map_assortment_constraints_to_indices(
                context.optimization.model_formulation.dict_assortment_expansion_reduction,
                df_optimization_master_data_filt_optimizer_only)

    plano_sku_mapping = create_plano_id_to_sku_mapping(df_optimization_master_data_filt_optimizer_only)

    dict_item_POD_min_store_idx = map_item_no_nbr_to_items_all_idx(
        context.optimization.model_formulation.dict_item_POD_min_store,
        item_idx_to_item_no,
        plano_sku_mapping
    )

    dict_item_POD_max_store_idx = map_item_no_nbr_to_items_all_idx(
        context.optimization.model_formulation.dict_item_POD_max_store,
        item_idx_to_item_no,
        plano_sku_mapping
    )

    dict_item_pod_min_change_idx = map_item_no_nbr_to_items_all_idx(
        context.optimization.model_formulation.dict_item_pod_min_change,
        item_idx_to_item_no,
        plano_sku_mapping
    )

    dict_item_pod_max_change_idx = map_item_no_nbr_to_items_all_idx(
        context.optimization.model_formulation.dict_item_pod_max_change,
        item_idx_to_item_no,
        plano_sku_mapping
    )

    # Merge dict_item_pod_min_change and dict_item_pod_max_change
    merged_dict_item_pod_change = {
        plano_id: {**context.optimization.model_formulation.dict_item_pod_min_change.get(plano_id, {}),
                **context.optimization.model_formulation.dict_item_pod_max_change.get(plano_id, {})}
        for plano_id in set(context.optimization.model_formulation.dict_item_pod_min_change.keys())
        | set(context.optimization.model_formulation.dict_item_pod_max_change.keys())
    }

    # Get current store count per items_all_idx
    current_store_count_per_items_all_idx = get_current_store_count_per_items_all_idx(
        df_optimization_master_data_filt_optimizer_only,
        merged_dict_item_pod_change,
        item_idx_to_item_no,
        plano_sku_mapping
    )

    dc_constraint_params = create_dc_constraint_parameters(
        df_optimization_master_data_filt_optimizer_only
    )

    removal_penalty_per_item = get_removal_penalty_per_item(
        df_optimization_master_data_filt_optimizer_only
    )  

    # Initializing sets and parameters data object
    opti_data = OptimizationModelData(
        dependent_var=dependent_var,
        category_level_dept_nbr=category_level_dept_nbr,
        plano_cat_desc=plano_cat_desc,
        department=department,
        item_idx_to_item_no=item_idx_to_item_no,
        brand_idx_to_brand=brand_idx_to_brand,
        plano_idx_to_plano=plano_idx_to_plano,
        eligible_brand_cg=eligible_brand_cg,
        facings_per_item=facings_per_item,
        facings_per_item_ineligible_max_incremental=facings_per_item_ineligible_max_incremental,
        facings_per_item_ineligible_max_decremental=facings_per_item_ineligible_max_decremental,
        facings_per_item_above_max_authorized_in_dept=facings_per_item_above_max_authorized_in_dept,
        facings_per_item_forced_guardrail=facings_per_item_forced_guardrail,
        dict_cluster_plano_pivot_to_linked_skus=dict_cluster_plano_pivot_to_linked_skus,
        min_facings_per_need_state=min_facings_per_need_state,
        max_facings_per_need_state=max_facings_per_need_state,
        need_states=need_states,
        suppliers=suppliers,
        brands=brands,
        clusters=clusters,
        all_plano_fixture=all_plano_fixture,
        linear_space_only_constrained_planos = linear_space_only_constrained_planos,
        facing_only_constrained_planos = facing_only_constrained_planos,   
        plano_fixture_by_cluster=plano_fixture_by_cluster,
        plano_fixture_mapping=plano_fixture_mapping,
        store_count_by_cluster_plano=store_count_by_cluster_plano,
        regional_indicator_by_cluster=regional_indicator_by_cluster,
        risk_flag=risk_flag,
        volume_flag=volume_flag,
        items_all=items_all,
        items_per_c_g=items_per_c_g,
        items_per_c_g_r_v=items_per_c_g_r_v,
        item_POD_enforce_type=item_POD_enforce_type,
        item_POD_threshold_LB=item_POD_threshold_LB,
        item_POD_threshold_UB=item_POD_threshold_UB,
        brand_POD_threshold_LB=brand_POD_threshold_LB,
        brand_POD_threshold_UB=brand_POD_threshold_UB,
        smallest_non_regional_item_per_need_state_dict=smallest_non_regional_item_per_need_state_dict,
        ns_per_c_g=ns_per_c_g,
        items_per_need_state_c_g=items_per_need_state_c_g,
        items_own_brand_only=items_own_brand_only,
        items_own_brand_only_per_c_g=items_own_brand_only_per_c_g,
        items_per_supplier=items_per_supplier,
        items_per_brand=items_per_brand,
        items_per_need_states=items_per_need_states,
        items_per_cdt=items_per_cdt,
        items_per_segment=items_per_segment,
        items_per_subcat=items_per_subcat,
        item_width_x_facings=item_width_x_facings,
        item_height=item_height,
        item_depth=item_depth,
        current_facings_per_item=current_facings_per_item,
        item_productivity_per_facing=item_productivity_per_facing,
        item_productivity_current_facings=item_productivity_current_facings,
        item_transference=item_transference,
        local_items_reserved_space_pct=local_items_reserved_space_pct,
        total_linear_space_in_dept=total_linear_space_in_dept,
        total_linear_space_in_dept_for_own_brand=total_linear_space_in_dept_for_own_brand,
        total_facings_space_in_dept=total_facings_space_in_dept,
        height_space_in_dept=height_space_in_dept,
        depth_space_in_dept=depth_space_in_dept,
        max_pct_drop_own_brand_space=max_pct_drop_own_brand_space,
        min_pct_allocated_from_total_space_to_own_brands=min_pct_allocated_from_total_space_to_own_brands,
        max_pct_allocated_from_total_space_to_own_brands=max_pct_allocated_from_total_space_to_own_brands,
        dict_item_POD_min_store_idx = dict_item_POD_min_store_idx,
        dict_item_POD_max_store_idx = dict_item_POD_max_store_idx,
        dict_item_pod_min_change_idx = dict_item_pod_min_change_idx,
        dict_item_pod_max_change_idx = dict_item_pod_max_change_idx,
        current_store_count_per_items_all_idx = current_store_count_per_items_all_idx,
        dict_assortment_expansion_reduction_idx=dict_assortment_expansion_reduction_idx,
        unmapped_clusters_planos = unmapped_clusters_planos,
        sku_increase_reduction_priority_order=context.optimization.model_formulation.sku_increase_reduction_priority_order,
        dict_supplier_brand_constraints=dict_supplier_brand_constraints,
        dict_global_linear_space_change_constraints=dict_global_linear_space_change_constraints,
        original_idx_to_original_cluster=original_idx_to_original_cluster,
        final_cluster_by_original_cluster=final_cluster_by_original_cluster,
        # original_cluster_labels_ioh_constrained=original_cluster_labels_ioh_constrained,
        # ioh_cost_per_facing=ioh_cost_per_facing,
        # cluster_ioh_full_budget=cluster_ioh_full_budget,
        # min_pct_ioh_constraint=min_pct_ioh_constraint,
        # max_pct_ioh_constraint=max_pct_ioh_constraint,
        need_state_space_presolve_calculation_method=context.optimization.model_formulation.need_state_space_presolve_calculation_method,
        need_states_top1_item_productivity_current_facing=need_states_top1_item_productivity_current_facing,
        **dc_constraint_params,
        removal_penalty_per_item=removal_penalty_per_item,
        x_vars=None,
    )

    # Joining set indices back to the original with all SKUs (the ones that were excluded will have a null for the 3
    # additional columns)
    df_optimization_master_data_filt = df_optimization_master_data_filt.merge(
        df_optimization_master_data_filt_optimizer_only[
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_cols_merge_model_sets
            + context.optimization.data_prep.index_columns
            + [
                "n_min_facings_need_state",
                "n_max_facings_need_state_before_guardrails",
                "n_max_facings_need_state",
            ]
            ].drop_duplicates(),
        on=(
                context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_cols_merge_model_sets
        ),
        how="left",
    )
    for col in context.optimization.data_prep.index_columns:
        nulls_in_col = df_optimization_master_data_filt[col].isnull().sum()
        if nulls_in_col > 0:
            log.debug(
                f"Filling {col} with -1 (currently {nulls_in_col}nulls) "
                f"so that we don't keep nulls in index columns"
            )
            df_optimization_master_data_filt[col] = df_optimization_master_data_filt[
                col
            ].fillna(-1)

    del df_optimization_master_data_filt_optimizer_only
    gc.collect()

    return opti_data, df_optimization_master_data_filt


def get_smallest_non_regional_item_per_need_state(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[int, int]:
    """
    Retrieves the smallest non-regional item per need state based on the mean
    linear space per facing SKU.

    This function filters the input DataFrame to include only non-regional items
    (where "is_regional_cluster" equals 0) and then groups the data by
    "items_all_idx" and "need_states_idx". For each need state, it calculates
    the mean of the current linear space per facing SKU for each item and selects
    the item with the smallest mean value. The result is returned as a dictionary
    where the keys are need state indices and the values are the smallest item
    indices.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame):
            The input DataFrame containing optimization master data filtered
            for the optimizer. It must contain at least the following columns:
            - "items_all_idx": Item index.
            - "need_states_idx": Need state index.
            - "n_current_linear_space_per_facing_sku": Linear space per facing SKU.
            - "is_regional_cluster": A flag indicating whether the item belongs
              to a regional cluster.

    Returns:
        Dict[int, int]: A dictionary mapping each need state index
        (as `need_states_idx`) to the smallest non-regional item index
        (as `items_all_idx`).
    """
    # get the smallest non-regional item per need state
    df_optimization_master_data_filt_optimizer_only_non_regional = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["is_regional_cluster"] == 0
            ]
    )
    smallest_non_regional_item_per_need_state = (
        df_optimization_master_data_filt_optimizer_only_non_regional[
            [
                "items_all_idx",
                "need_states_idx",
                "n_current_linear_space_per_facing_sku",
            ]
        ]
        .groupby(["items_all_idx", "need_states_idx"])
        .agg({"n_current_linear_space_per_facing_sku": "mean"})
        .reset_index()
    )
    smallest_non_regional_item_per_need_state = (
        smallest_non_regional_item_per_need_state.groupby("need_states_idx")
        .apply(
            lambda group: group.loc[
                group["n_current_linear_space_per_facing_sku"].idxmin()
            ]["items_all_idx"]
        )
        .reset_index(name="smallest_items_all_idx")
    )
    smallest_non_regional_item_per_need_state_dict = dict(
        zip(
            smallest_non_regional_item_per_need_state["need_states_idx"],
            smallest_non_regional_item_per_need_state["smallest_items_all_idx"],
        )
    )
    return smallest_non_regional_item_per_need_state_dict


def update_available_need_state_number(
        df: pd.DataFrame,
) -> (Dict[Tuple[int, int], int], pd.DataFrame): # type: ignore
    """
    Updates and calculates the number of available need states for each cluster and fixture combination in the DataFrame.

    This function performs the following operations:
    1. Calculates the `total_available_need_states` for each group by summing the rows where `need_state_unavailable` equals 0.
    2. Returns a dictionary mapping each unique combination of `cluster_idx` and `plano_fixture_idx` to their corresponding `total_available_need_states`.
    3. Returns the modified DataFrame with the added `need_state_unavailable` and `total_available_need_states` columns.

    Args:
        df (pd.DataFrame): The input DataFrame containing the necessary columns, including
                           other grouping columns defined by
                           `context.groupby_granularity.optimizer` and `context.optimization.data_prep.addtl_agg_optimizer_ns_level`.

    Returns:
        Tuple[Dict[Tuple[int, int], int], pd.DataFrame]:
            - A dictionary where the keys are tuples of (`cluster_idx`, `plano_fixture_idx`) and the values
              are the corresponding `total_available_need_states`.
            - The modified DataFrame with the `need_state_unavailable` and `total_available_need_states` columns added.
    """
    # TODO: adjust logic
    # df["need_state_unavailable"] = (
    #     df.groupby(
    #         context.groupby_granularity.optimizer
    #         + context.optimization.data_prep.addtl_agg_optimizer_ns_level
    #     )["new_column_for_cluster_level"]  # updated column name
    #     .transform("all")
    #     .astype(int)
    # )

    df.loc[:, "need_state_unavailable"] = 0

    # Invert 'need_state_unavailable' to calculate available need states
    # Step 2: Filter the DataFrame where need_state_unavailable is 0
    filtered_df = df[df["need_state_unavailable"] == 0]

    # Step 3: Calculate distinct need_states_idx count in the filtered DataFrame
    distinct_need_states = (
        filtered_df.groupby(
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_level
        )["need_states_idx"]
        .nunique()
        .reset_index()
    )

    # Rename the count column for clarity
    distinct_need_states.rename(
        columns={"need_states_idx": "total_available_need_states"}, inplace=True
    )

    # Step 4: Merge the result back to the original DataFrame
    df = df.merge(
        distinct_need_states,
        on=context.groupby_granularity.optimizer
           + context.optimization.data_prep.addtl_agg_optimizer_level,
        how="left",
    )

    available_need_states_num_update = (
        df.groupby(["cluster_idx", "plano_fixture_idx"])["total_available_need_states"]
        .first()
        .dropna()
        .to_dict()
    )
    return (available_need_states_num_update, df)


def get_item_productivity_per_facing(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[Tuple[int, int, int, int], float]:
    """
    Computes the productivity per facing for each combination of item, facing, cluster, and plano fixture.

    This function generates a dictionary where each key is a tuple of `(items_all_idx, f, cluster_idx, plano_fixture_idx)`
    representing a unique combination of an item, the number of facings, the cluster, and the plano fixture. The corresponding
    value is the calculated productivity per facing for that combination, rounded to four decimal places.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame):
            A DataFrame containing the optimization master data filtered to only include the relevant items
            and their associated clusters and plano fixtures. The DataFrame is expected to have the following columns:
            - `items_all_idx`: Unique identifier for each item.
            - `cluster_idx`: Cluster index.
            - `plano_fixture_idx`: Plano fixture index.
            - Columns named as `n_space_prod_fit_facings_{f}`, where `{f}` corresponds to the number of facings,
              containing productivity values.

    Returns:
        Dict[Tuple[int, int, int, int], float]:
            A dictionary where each key is a tuple `(items_all_idx, f, cluster_idx, plano_fixture_idx)`
            and the value is the productivity per facing for that combination.

    """
    # Get the unique combinations of items_all_idx, cluster_idx, and plano_fixture_idx from the DataFrame
    unique_combinations = df_optimization_master_data_filt_optimizer_only[
        ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
    ].drop_duplicates()

    # Generate all possible (items_all_idx, f, cluster_idx, plano_fixture_idx) combinations
    combination_df = pd.DataFrame(
        [
            (row["items_all_idx"], f, row["cluster_idx"], row["plano_fixture_idx"])
            for _, row in unique_combinations.iterrows()
            for f in range(context.optimization.model_formulation.max_facings_opti)
        ],
        columns=["items_all_idx", "f", "cluster_idx", "plano_fixture_idx"],
    )

    # Merge with the original DataFrame to get the relevant productivity data
    merged_df = combination_df.merge(
        df_optimization_master_data_filt_optimizer_only,
        on=["items_all_idx", "cluster_idx", "plano_fixture_idx"],
        how="left",
    )

    # Calculate the productivity per facing and round it
    merged_df["item_productivity_per_facing"] = merged_df.apply(
        lambda row: round(row[f"n_space_prod_fit_facings_{row['f']}"], 4), axis=1
    )

    # Convert back to a dictionary
    item_productivity_per_facing = merged_df.set_index(
        ["items_all_idx", "f", "cluster_idx", "plano_fixture_idx"]
    )["item_productivity_per_facing"].to_dict()
    return item_productivity_per_facing


def get_working_capital_constraints_sets_and_params(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Tuple[
    Dict[int, List[int]],
    Dict[int, str],
    List[int],
    Dict[int, float],
    Dict[int, float],
    Dict[int, float],
    Dict[int, float],
]:
    """
    Extracts and returns various working capital constraint parameters and sets from the provided optimization data.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame):
            Filtered optimization data containing working capital constraints.

    Returns:
        tuple: A tuple containing the following elements:
            - final_cluster_by_original_cluster (dict):
                A dictionary mapping each `original_cluster_idx` to a list of unique `cluster_idx` values.
            - original_idx_to_original_cluster (dict):
                A dictionary mapping each `original_cluster_idx` to its associated `original_cluster_labels`.
            - original_cluster_labels_ioh_constrained (list):
                A list of unique `original_cluster_idx` values that have a working capital constraint applied.
            - cluster_ioh_full_budget (dict):
                A dictionary mapping each constrained `original_cluster_idx` to its `cluster_ioh_full_budget` value.
            - min_pct_ioh_constraint (dict):
                A dictionary mapping each constrained `original_cluster_idx` to its minimum IOH percentage.
            - max_pct_ioh_constraint (dict):
                A dictionary mapping each constrained `original_cluster_idx` to its maximum IOH percentage.
    """
    # Mapping each original cluster to its associated clusters
    final_cluster_by_original_cluster = (
        df_optimization_master_data_filt_optimizer_only.groupby("original_cluster_idx")[
            "cluster_idx"
        ]
        .unique()  # Get unique cluster_idx for each original_cluster_idx
        .apply(list)  # Convert to a list
        .to_dict()
    )

    # Mapping original index to its respective original cluster label
    original_idx_to_original_cluster = (
        df_optimization_master_data_filt_optimizer_only.groupby(
            ["original_cluster_idx"]
        )["original_cluster_labels"]
        .first()
        .dropna()
        .to_dict()
    )

    # TODO: Re-add once working capital constraint flag is added
    df_original_cluster_labels_ioh_constrained = df_optimization_master_data_filt_optimizer_only
    # # Filtering for clusters with working capital constraints
    # df_original_cluster_labels_ioh_constrained = (
    #     df_optimization_master_data_filt_optimizer_only[
    #         (
    #             df_optimization_master_data_filt_optimizer_only[
    #                 "working_capital_constraint"
    #             ].notnull()
    #         )
    #         & (
    #             df_optimization_master_data_filt_optimizer_only[
    #                 "working_capital_constraint"
    #             ]
    #             == 1
    #         )
    #     ]
    # )

    # # List of unique constrained original clusters
    # original_cluster_labels_ioh_constrained = (
    #     df_original_cluster_labels_ioh_constrained["original_cluster_idx"]
    #     .drop_duplicates()
    #     .tolist()
    # )
    #
    # # Mapping constrained clusters to their IOH full budget values
    # cluster_ioh_full_budget = (
    #     df_original_cluster_labels_ioh_constrained.groupby("original_cluster_idx")[
    #         "cluster_ioh_full_budget"
    #     ]
    #     .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
    #     .to_dict()
    # )
    #
    # # Mapping constrained clusters to their minimum IOH percentage constraint
    # min_pct_ioh_constraint = (
    #     df_original_cluster_labels_ioh_constrained.groupby("original_cluster_idx")[
    #         "min_IOH_percent"
    #     ]
    #     .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
    #     .to_dict()
    # )
    #
    # # Mapping constrained clusters to their maximum IOH percentage constraint
    # max_pct_ioh_constraint = (
    #     df_original_cluster_labels_ioh_constrained.groupby("original_cluster_idx")[
    #         "max_IOH_percent"
    #     ]
    #     .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
    #     .to_dict()
    # )

    return (
        final_cluster_by_original_cluster,
        original_idx_to_original_cluster,
        # original_cluster_labels_ioh_constrained,
        # cluster_ioh_full_budget,
        # min_pct_ioh_constraint,
        # max_pct_ioh_constraint,
    )


def get_ioh_cost_per_facing(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[Tuple[int, int, int], float]:
    """
    Calculates the IOH cost per facing for each combination of item, facing, and cluster.

    This function filters the input DataFrame for rows with valid `min_IOH_percent`
    and `max_IOH_percent` values, generates all possible combinations of
    `(items_all_idx, f, original_cluster_idx)` where `f` represents the facings, and
    calculates the IOH cost per facing.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame): The input
        DataFrame containing optimization master data filtered to optimizer-only rows.

    Returns:
        Dict[Tuple[int, int, int], float]: A dictionary where the keys are tuples of
        `(items_all_idx, f, original_cluster_idx)` and the values are the IOH cost
        per facing.

    Workflow:
        1. Filter rows with non-null `min_IOH_percent` and `max_IOH_percent`.
        2. Extract unique combinations of `items_all_idx` and `original_cluster_idx`.
        3. Generate all possible `(items_all_idx, f, original_cluster_idx)` combinations
           for `f` ranging from 0 to the maximum number of facings.
        4. Merge the combinations with the input DataFrame to include relevant data.
        5. Calculate the IOH cost per facing using the appropriate columns.
        6. Convert the resulting DataFrame into a dictionary.

    Logs:
        - Information about the filtering and merging steps.

    Raises:
        KeyError: If the required column for a specific facing (`item_no_avg_ioh_facings_{f}`)
        is missing from the DataFrame.

    Example:
        >>> df_input = pd.DataFrame({
                "items_all_idx": [1, 2],
                "original_cluster_idx": [100, 200],
                "min_IOH_percent": [0.1, 0.2],
                "max_IOH_percent": [0.5, 0.6],
                "item_no_avg_ioh_facings_0": [1.0, 2.0],
                "item_no_avg_ioh_facings_1": [1.1, 2.2]
            })
        >>> get_ioh_cost_per_facing(df_input)
        {(1, 0, 100): 1.0, (1, 1, 100): 1.1, (2, 0, 200): 2.0, (2, 1, 200): 2.2}
    """
    # Get the unique combinations of items_all_idx, and original_cluster_idx from the DataFrame

    df_original_cluster_labels_ioh_constrained = (
        df_optimization_master_data_filt_optimizer_only[
            df_optimization_master_data_filt_optimizer_only["min_IOH_percent"].notnull()
            & df_optimization_master_data_filt_optimizer_only[
                "max_IOH_percent"
            ].notnull()
            ]
    )

    unique_combinations = df_original_cluster_labels_ioh_constrained[
        ["items_all_idx", "original_cluster_idx"]
    ].drop_duplicates()

    # Generate all possible (items_all_idx, f, original_cluster_idx) combinations
    combination_df = pd.DataFrame(
        [
            (row["items_all_idx"], f, row["original_cluster_idx"])
            for _, row in unique_combinations.iterrows()
            for f in range(context.optimization.model_formulation.max_facings_opti + 1)
        ],
        columns=["items_all_idx", "f", "original_cluster_idx"],
    )

    # Merge with the original DataFrame to get the relevant productivity data
    merged_df = combination_df.merge(
        df_original_cluster_labels_ioh_constrained,
        on=["items_all_idx", "original_cluster_idx"],
        how="left",
    )

    # Calculate the productivity per facing and round it
    merged_df["ioh_cost_per_facing"] = merged_df.apply(
        lambda row: round(row[f"item_no_avg_ioh_facings_{row['f']}"], 4)
        if f"item_no_avg_ioh_facings_{row['f']}" in merged_df.columns
        else None,
        axis=1,
    )

    # this should be thge s_ifc_
    # Convert back to a dictionary
    ioh_cost_per_facing = merged_df.set_index(
        [
            "items_all_idx",
            "f",
            "original_cluster_idx",
        ]
    )["ioh_cost_per_facing"].to_dict()

    return ioh_cost_per_facing


def get_item_width_x_facings(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[Tuple[int, int, int, int], float]:
    """
    Computes the item width per facing for each combination of item, facing, cluster, and plano fixture.

    This function generates a dictionary where each key is a tuple of `(items_all_idx, f, cluster_idx, plano_fixture_idx)`
    representing a unique combination of an item, the number of facings, the cluster, and the plano fixture. The corresponding
    value is the calculated item width per facing for that combination, rounded to four decimal places.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame):
            A DataFrame containing the optimization master data filtered to only include the relevant items
            and their associated clusters and plano fixtures. The DataFrame is expected to have the following columns:
            - `items_all_idx`: Unique identifier for each item.
            - `cluster_idx`: Cluster index.
            - `plano_fixture_idx`: Plano fixture index.
            - Columns named as `n_space_prod_fit_facings_{f}`, where `{f}` corresponds to the number of facings,
              containing item width values.

    Returns:
        Dict[Tuple[int, int, int, int], float]:
            A dictionary where each key is a tuple `(items_all_idx, f, cluster_idx, plano_fixture_idx)`
            and the value is the item width per facing for that combination.

    """
    # Get the unique combinations of items_all_idx, cluster_idx, and plano_fixture_idx from the DataFrame
    unique_combinations = df_optimization_master_data_filt_optimizer_only[
        ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
    ].drop_duplicates()

    # Generate all possible (items_all_idx, f, cluster_idx, plano_fixture_idx) combinations
    combination_df = pd.DataFrame(
        [
            (row["items_all_idx"], f, row["cluster_idx"], row["plano_fixture_idx"])
            for _, row in unique_combinations.iterrows()
            for f in range(context.optimization.model_formulation.max_facings_opti)
        ],
        columns=["items_all_idx", "f", "cluster_idx", "plano_fixture_idx"],
    )

    # Merge with the original DataFrame to get the relevant productivity data
    merged_df = combination_df.merge(
        df_optimization_master_data_filt_optimizer_only,
        on=["items_all_idx", "cluster_idx", "plano_fixture_idx"],
        how="left",
    )

    # Calculate the productivity per facing and round it
    merged_df["item_width_x_facings"] = merged_df.apply(
        lambda row: row["f"] * round(row[f"n_current_linear_space_per_facing_sku"], 4),
        axis=1,
    )

    # Convert back to a dictionary
    item_width_per_facing = merged_df.set_index(
        ["items_all_idx", "f", "cluster_idx", "plano_fixture_idx"]
    )["item_width_x_facings"].to_dict()
    return item_width_per_facing


def get_pivot_and_linked_sku_pairs_constraints(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[int, np.array]:
    """
    This function creates a mapping between a pivot SKU and some linked SKUs, for which we'll apply a constraint such
    that if the pivot SKU gets assigned at least 1 facing, then each linked SKU needs to be assigned at least 1 facing
    Args:
        df_optimization_master_data_filt_optimizer_only: Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer

    Returns:
    A mapping between a pivot SKU and some linked SKUs, for which we'll apply a constraint such that if the pivot SKU
    gets assigned at least 1 facing, then each linked SKU needs to be assigned at least 1 facing
    """
    df = (
        df_optimization_master_data_filt_optimizer_only[
            context.groupby_granularity.optimizer
            + [
                "item_no_nbr",
                "items_all_idx",
                "unique_linked_item_no_nbrs",
                "cluster_idx",
                "plano_fixture_idx",
            ]
            ]
        .drop_duplicates()
        .copy()
    )
    # Making the column a list of integers instead of a long string
    df["unique_linked_item_no_nbrs"] = (
        df["unique_linked_item_no_nbrs"]
        .fillna("")
        .apply(
            lambda string_item_nos: extract_item_nos_from_string_of_item_nos(
                string_item_nos=string_item_nos
            )
        )
    )
    # Exploding the list values into separate rows
    df = df.explode("unique_linked_item_no_nbrs")
    item_idx_cols = context.groupby_granularity.optimizer + [
        "item_no_nbr",
        "items_all_idx",
        "cluster_idx",
        "plano_fixture_idx",
    ]
    df_item_no_nbr_idx = (
        df[item_idx_cols]
        # rename item_no number to linked item_no number to grab the index for linked items when joining
        .rename(
            columns={
                "item_no_nbr": "unique_linked_item_no_nbrs",
                "items_all_idx": "items_all_idx_linked",
            }
        ).drop_duplicates()
    )
    df = df.merge(
        df_item_no_nbr_idx,
        on=context.groupby_granularity.optimizer
           + ["unique_linked_item_no_nbrs", "cluster_idx", "plano_fixture_idx"],
        how="left",
    )
    df = df[df["items_all_idx_linked"].notnull()]
    df["items_all_idx_linked"] = df["items_all_idx_linked"].astype(int)

    dict_cluster_plano_pivot_to_linked_skus = {}
    df_grouped = (
        df.groupby(["cluster_idx", "plano_fixture_idx", "items_all_idx"])[
            "items_all_idx_linked"
        ]
        .agg("unique")
        .apply(sorted)
        .reset_index()
    )
    for _, row in df_grouped.iterrows():
        cluster_idx = row["cluster_idx"]
        plano_fixture_idx = row["plano_fixture_idx"]
        pivot_sku_idx = row["items_all_idx"]
        linked_sku_indices = row["items_all_idx_linked"]
        if (len(linked_sku_indices) > 0) and (np.nan not in linked_sku_indices):
            if (
                    cluster_idx,
                    plano_fixture_idx,
            ) not in dict_cluster_plano_pivot_to_linked_skus.keys():
                dict_cluster_plano_pivot_to_linked_skus[
                    (cluster_idx, plano_fixture_idx)
                ] = {}
            dict_cluster_plano_pivot_to_linked_skus[(cluster_idx, plano_fixture_idx)][
                pivot_sku_idx
            ] = linked_sku_indices

    return dict_cluster_plano_pivot_to_linked_skus


def extract_item_nos_from_string_of_item_nos(
        string_item_nos: str,
) -> Union[List[int]]:
    """
    Extract a list of item_no_nbr from a string that can potentially contain none (which would just be an empty string).
    If there are none, it will return a list with -99999, which we then handle later in the processing to exclude them.
    Args:
        string_item_nos: String containing item_no_nbr separated by a comma; can potentially be an empty string

    Returns:
    A list of either item_no_nbrs or -99999
    """
    list_item_nos = []
    for str_item_no in string_item_nos.split(","):
        try:
            list_item_nos.append(int(str_item_no))
        except ValueError:
            list_item_nos.append(-99999)

    return list(set(list_item_nos))


def get_facings_forced_facings_guardrails_constraint(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[Tuple[int, int, int], np.array]:
    """
    This function gets a list of "forced" facings from the guardrails in the UI for a given item, and creates the
    mapping of item_idx, cluster_idx, plano_fixture_idx to list of facings it should be able to take (could be a list of just one value).

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame): Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer.

    Returns:
        facings_per_item_forced_guardrail (Dict[Tuple[int, int, int], np.array]): Mapping of (items_all_idx, cluster_idx, plano_fixture_idx) to the
                                                                                  list of facings it should be able to take.
    """
    subset_columns = (
            context.groupby_granularity.optimizer
            + context.optimization.data_prep.addtl_agg_optimizer_level
            + [
                "items_all_idx",
                "cluster_idx",
                "plano_fixture_idx",
                "min_forced_facings_guardrails",
                "max_forced_facings_guardrails",
            ]
    )
    df_optimization_master_data_filter = (
        df_optimization_master_data_filt_optimizer_only[
            subset_columns
        ].drop_duplicates()
    )
    check_duplicates(
        df=df_optimization_master_data_filter,
        df_name="df_optimization_master_data_filter_get_facings_forced_facings_guardrails_constraint",
        subset=(context.groupby_granularity.optimizer
                + context.optimization.data_prep.addtl_agg_optimizer_level
                + ["items_all_idx", "cluster_idx", "plano_fixture_idx"]),
    )

    # Filter for rows where guardrails are not null
    filtered_df = df_optimization_master_data_filter[
        df_optimization_master_data_filter["min_forced_facings_guardrails"].notnull()
        & df_optimization_master_data_filter["max_forced_facings_guardrails"].notnull()
        ]

    # Remove redundant rows where min_forced_facings_guardrails == 0 AND max_forced_facings_guardrails == context.optimization.model_formulation.max_facings_opti - 1
    filtered_df = filtered_df[
        ~(
                (filtered_df["min_forced_facings_guardrails"] == 0)
                & (
                        filtered_df["max_forced_facings_guardrails"]
                        == context.optimization.model_formulation.max_facings_opti - 1
                )
        )
    ]

    # Return an empty dictionary if the filtered DataFrame is empty
    if filtered_df.empty:
        return {}

    # Filling nulls with min and max opti value for facings, which essentially corresponds to no ineligible facings
    filtered_df["min_forced_facings_guardrails"] = (
        filtered_df["min_forced_facings_guardrails"].fillna(0).astype(int)
    )
    filtered_df["max_forced_facings_guardrails"] = (
        filtered_df["max_forced_facings_guardrails"]
        .fillna(context.optimization.model_formulation.max_facings_opti - 1)
        .astype(int)
    )

    # Group by the key fields and generate the facings array
    facings_per_item_forced_guardrail = (
        filtered_df.groupby(["items_all_idx", "cluster_idx", "plano_fixture_idx"])
        .apply(
            lambda x: np.arange(
                x["min_forced_facings_guardrails"].min(),
                x["max_forced_facings_guardrails"].max() + 1,
            )
        )
        .to_dict()
    )

    return facings_per_item_forced_guardrail


def get_supplier_or_brand_space_constraint_bound(
        constraint_type: str,
        dimension: str,
        dimension_indices: List[Union[str, int]],
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[Tuple[int, int, int], Union[Tuple[float, float], Tuple[int, int]]]:
    """
    This function extracts all lower and upper bound values for a certain dimension, constraint type and bound type
    Args:
        constraint_type: Type of constraint we want to create the bounds for, there is an assert to make sure
        only certain supported values are fed
        dimension: Dimension on which we want to get the constraint bounds, can only be supplier or brand
        dimension_indices: List of relevant indices for the `dimension` fed as parameter
        df_optimization_master_data_filt_optimizer_only: Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer

    Returns:
    A dictionary with the key being an index relevant to the `dimension` (e.g. `supplier_idx`) and the values being a
    list of lower and upper bounds based on the `constraint_type`
    """
    assert (
            dimension
            in context.optimization.manual_constraints.authorized_supplier_brand_dimensions
    ), f"Expected 'brand' or 'supplier', got {dimension}"

    # Create an empty dict
    dict_bounds_constraint_dimension_space_constraint_type = {}

    for dimension_idx in dimension_indices:
        # Lower Bound
        lb_constraint = get_constraint_value_from_df(
            df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
            dimension_idx=dimension_idx,
            constraint_type=constraint_type,
            bound_type="lower",
            dimension=dimension,
        )

        # Upper bound
        ub_constraint = get_constraint_value_from_df(
            df_optimization_master_data_filt_optimizer_only=df_optimization_master_data_filt_optimizer_only,
            dimension_idx=dimension_idx,
            constraint_type=constraint_type,
            bound_type="upper",
            dimension=dimension,
        )

        if lb_constraint is not None and ub_constraint is not None:
            dict_bounds_constraint_dimension_space_constraint_type = {key:
                                                                          (lb_constraint[key], ub_constraint[key])
                                                                          for key in lb_constraint
                                                                      }

    return dict_bounds_constraint_dimension_space_constraint_type


def get_global_linear_space_constraint_bound(
        dimension: str,
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[int, Union[Tuple[float, float], Tuple[int, int]]]:
    """
    This function determines the lower & upper bound linear space a brand, supplier, need_state, etc
    can have on a global level
    (across all versions)
    Args:
        dimension: Dimension on which we want to get the constraint bounds, can only be supplier or brand
        df_optimization_master_data_filt_optimizer_only: Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer

    Returns:
    A dictionary with the key being an index relevant to the `dimension` (e.g. `supplier_idx`) and the values being a
    list of lower and upper bounds based on the `constraint_type`
    """
    dimension_grouper = f"{dimension}_idx"

    # Verify the dimension is within the accepted values
    assert (
            dimension
            in context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions
    ), (f"Expected {context.optimization.manual_constraints.authorized_global_linear_space_change_dimensions}, "
        f"got {dimension}")

    # Get total linear space occupied by dimension
    df_dimension_lin_space = (
        df_optimization_master_data_filt_optimizer_only
        .groupby([dimension_grouper, f"{dimension}_change_type"])
        .agg(
            dimension_linear_space=(f"{dimension}_global_linear_space", "first"),
            min_bound=(f"{dimension}_min_bound", "first"),
            max_bound=(f"{dimension}_max_bound", "first"),
        )
        .reset_index()
    )

    # Get total linear space occupied across all versions
    total_linear_space = (
        df_optimization_master_data_filt_optimizer_only[[
            "final_cluster_labels", "plano_id", "plano_ft", "fixture_size", "n_total_linear_space_dept_fixture_ft"]]
        .drop_duplicates()
        ["n_total_linear_space_dept_fixture_ft"]
        .sum()
    )
    df_dimension_lin_space["total_linear_space"] = total_linear_space

    # Compute decrease/increase in linear space range relative to current.
    # Since min/max bound hold the change sign (-/+), all changes are treated the same
    df_dimension_lin_space.loc[
        (df_dimension_lin_space[f"{dimension}_change_type"] == "dimension_current") & 
        (df_dimension_lin_space["min_bound"].notna()), "change_min_bound"] = (
        df_dimension_lin_space["dimension_linear_space"] * (1 + df_dimension_lin_space["min_bound"])
    )
    df_dimension_lin_space.loc[
        (df_dimension_lin_space[f"{dimension}_change_type"] == "dimension_current") & 
        (df_dimension_lin_space["max_bound"].notna()), "change_max_bound"] = (
            df_dimension_lin_space["dimension_linear_space"] * (1 + df_dimension_lin_space["max_bound"])
    )

    # Compute share of linear space dimension value will occupy relative to the overall linear space available
    df_dimension_lin_space.loc[
        (df_dimension_lin_space[f"{dimension}_change_type"] == "overall_share") & 
        (df_dimension_lin_space["min_bound"].notna()), "change_min_bound"] = (
        df_dimension_lin_space["total_linear_space"] * (df_dimension_lin_space["min_bound"])
    )
    df_dimension_lin_space.loc[
        (df_dimension_lin_space[f"{dimension}_change_type"] == "overall_share") & 
        (df_dimension_lin_space["max_bound"].notna()), "change_max_bound"] = (
            df_dimension_lin_space["total_linear_space"] * (df_dimension_lin_space["max_bound"])
    )

    # Handle missing bounds - set reasonable defaults
    # For missing min_bound, use 0 (no decrease allowed)
    df_dimension_lin_space.loc[
        df_dimension_lin_space["change_min_bound"].isna(), "change_min_bound"] = 0

    # For missing max_bound, use a large value or current dimension space
    df_dimension_lin_space.loc[
        (df_dimension_lin_space["change_max_bound"].isna()) & 
        (df_dimension_lin_space[f"{dimension}_change_type"] == "dimension_current"), "change_max_bound"] = (
            df_dimension_lin_space["total_linear_space"]  # Allow up to total space
    )
    df_dimension_lin_space.loc[
        (df_dimension_lin_space["change_max_bound"].isna()) & 
        (df_dimension_lin_space[f"{dimension}_change_type"] == "overall_share"), "change_max_bound"] = (
            df_dimension_lin_space["total_linear_space"]  # Allow up to 100% of space
    )

    # If any value is negative, set it to 0
    df_dimension_lin_space.loc[df_dimension_lin_space["change_max_bound"] < 0, "change_max_bound"] = 0
    df_dimension_lin_space.loc[df_dimension_lin_space["change_min_bound"] < 0, "change_min_bound"] = 0

    # Remove rows without entries & keep relevant columns
    df_dimension_lin_space = df_dimension_lin_space[df_dimension_lin_space[f"change_min_bound"].notna()]

    # Get back the dimension idx

    return dict(zip(df_dimension_lin_space[dimension_grouper],
                    zip(df_dimension_lin_space["change_min_bound"], df_dimension_lin_space["change_max_bound"])))



def get_constraint_value_from_df(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
        dimension_idx: int,
        constraint_type: str,
        bound_type: str,
        dimension: str,
) -> dict[Tuple[int, int, int], Union[int, float]]:
    """
    This function extracts one single bound value for a certain dimension, constraint type and bound type for a specific
    index within the `dimension`; if the given combination doesn't exist it will return `NaN`
    Args:
        df_optimization_master_data_filt_optimizer_only: Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer
        dimension_idx: Index of the relevant object (supplier or brand) for the `dimension` that's been fed as parameter
        constraint_type: Type of constraint we want to create the bounds for, there is an assert to make sure
        only certain supported values are fed
        bound_type: Bound type (lower or upper) that we want to extract
        dimension: Dimension on which we want to get the constraint bounds, can only be supplier or brand

    Returns:
    Bound for a constraint given the cmombination of dimension, constraint type, bound type and specific index
    """
    df_filt = (
        df_optimization_master_data_filt_optimizer_only[
            (
                    df_optimization_master_data_filt_optimizer_only[f"{dimension}_idx"]
                    == dimension_idx
            )
            & (
                    df_optimization_master_data_filt_optimizer_only[
                        "constraint_type_supplier_or_brand"
                    ]
                    == f"{dimension}_{constraint_type}"
            )
            ][["cluster_idx", "plano_fixture_idx", f"{bound_type}_bound_constraint_supplier_or_brand"]]
        .drop_duplicates()
        .round(2)
    )
    if len(df_filt) == 0:
        return None
    else:
        # Only need one singular value as the lower/upper bound, assuming all clusters share the same thresholds
        return dict(
            zip(
                zip(
                    [dimension_idx] * len(df_filt),  # repeat the constant int
                    df_filt["cluster_idx"],
                    df_filt["plano_fixture_idx"]
                ),
                df_filt[f"{bound_type}_bound_constraint_supplier_or_brand"]
            )
        )


def get_min_and_max_facings_per_need_state(
        df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Tuple[
    pd.DataFrame, Dict[Tuple[int, int, int], int], Dict[Tuple[int, int, int], int]
]:
    """
    This function creates the maximum number of facings a need state can be assigned based on config-driven rules and
    saturation facings coming from need state level curves
    Args:
        df_optimization_master_data_filt_optimizer_only: Optimization master data containing all the data we need for
        formulating and solving the optimization model for that specific [plano_cat_id, dept_id, cluster_id, plano_ft,
        fixture_size]; this one is filtered to have only the SKUs that will be considered by the optimizer

    Returns:
    A tuple containing:
    - The original `df_optimization_master_data_filt_optimizer_only` input with a new column `n_max_facings_need_state`
    - An array with the length of the number of need states, where each value is the max no. of facings that need state
    can get assigned from the optimizer (will be used for a constraint)
    """

    # Getting need state level stats from opti input
    df_facings_need_state = df_optimization_master_data_filt_optimizer_only[
        [
            "need_states_idx",
            "cluster_idx",
            "plano_fixture_idx",
            "saturation_facings",
            "n_current_facings_need_state",
            "n_forced_facings_need_state_not_in_current",
            "n_forced_facings_all_need_state",
            "n_current_and_forced_facings_unique_need_state",
            "n_manually_adjusted_saturation_facings_need_state",
            "n_facings_middle_current_and_saturation_need_state",
            "min_facings_in_need_state_forced_guardrail",
            "max_facings_in_need_state_forced_guardrail",
        ]
    ].drop_duplicates(subset=["need_states_idx", "cluster_idx", "plano_fixture_idx"])

    # Making sure no nulls
    df_facings_need_state["min_facings_in_need_state_forced_guardrail"] = (
        df_facings_need_state["min_facings_in_need_state_forced_guardrail"]
        .fillna(0)
        .astype(int)
    )
    df_facings_need_state["max_facings_in_need_state_forced_guardrail"] = (
        df_facings_need_state["max_facings_in_need_state_forced_guardrail"]
        .fillna(9999)
        .astype(int)
    )

    # Group by need_states_idx, cluster_idx, and plano_fixture_idx
    grouped = df_facings_need_state.groupby(
        ["need_states_idx", "cluster_idx", "plano_fixture_idx"]
    )

    # Initialize lists to store results
    results = []

    for name, group in grouped:
        # Process each group separately

        # Now comparing these manual bounds to current & saturation NS facings
        # Calculate the max facings before applying guardrails
        conditions = [
            group["n_current_facings_need_state"] >= group["saturation_facings"],
            group["n_current_facings_need_state"] < group["saturation_facings"],
        ]

        # If current >= saturation_facings: max((saturation+current)/2, all forced facings)
        # If current < saturation_facings: max(current, set(current + forced), adjusted saturation)
        choices = [
            group[
                [
                    "n_facings_middle_current_and_saturation_need_state",
                    "n_forced_facings_all_need_state",
                ]
            ].max(axis=1),
            group[
                [
                    "n_current_facings_need_state",
                    "n_current_and_forced_facings_unique_need_state",
                    "n_manually_adjusted_saturation_facings_need_state",
                ]
            ].max(axis=1),
        ]

        # Apply the conditions and choices to update the column
        group["n_max_facings_need_state_before_guardrails"] = np.select(
            conditions, choices, default=9999
        )

        # Now that we have these values, we need to compare and potentially override using the manual constraint guardrails
        # if there are any; we also create the min facings for need state, filled with 1 if it's null since every need state
        # has to be represented
        group["n_min_facings_need_state"] = group[
            "min_facings_in_need_state_forced_guardrail"
        ]
        # The final max facings in NS is the min(saturation_based_max, guardrail_max) or guardrail_min
        # if guardrail_min > saturation_based_max
        group["n_max_facings_need_state"] = group[
            [
                "n_max_facings_need_state_before_guardrails",
                "max_facings_in_need_state_forced_guardrail",
            ]
        ].min(axis=1)
        # the max facings is the guardrail minimum if it is greater than the saturation facings-based max
        group.loc[
            (
                    group["min_facings_in_need_state_forced_guardrail"]
                    > group["n_max_facings_need_state_before_guardrails"]
            ),
            "n_max_facings_need_state",
        ] = group["min_facings_in_need_state_forced_guardrail"]

        results.append(group)

    # Concatenate results into a single DataFrame
    df_result = (
        pd.concat(results)
        .sort_values(["need_states_idx", "cluster_idx", "plano_fixture_idx"])
        .reset_index(drop=True)
    )

    # Create dictionaries for min and max facings
    min_facings_per_need_state = (
        df_result.groupby(["need_states_idx", "cluster_idx", "plano_fixture_idx"])[
            "n_min_facings_need_state"
        ]
        .apply(lambda x: int(x.drop_duplicates().unique()[0]))
        .to_dict()
    )

    max_facings_per_need_state = (
        df_result.groupby(["need_states_idx", "cluster_idx", "plano_fixture_idx"])[
            "n_max_facings_need_state"
        ]
        .apply(lambda x: int(x.drop_duplicates().unique()[0]))
        .to_dict()
    )

    # Merge the results back into df_optimization_master_data_filt_optimizer_only
    df_optimization_master_data_filt_optimizer_only = (
        df_optimization_master_data_filt_optimizer_only.merge(
            df_result[
                [
                    "need_states_idx",
                    "cluster_idx",
                    "plano_fixture_idx",
                    "n_max_facings_need_state_before_guardrails",
                    "n_min_facings_need_state",
                    "n_max_facings_need_state",
                ]
            ].drop_duplicates(
                subset=["need_states_idx", "cluster_idx", "plano_fixture_idx"]
            ),
            on=["need_states_idx", "cluster_idx", "plano_fixture_idx"],
            how="left",
        )
    )

    df_optimization_master_data_filt_optimizer_only["n_max_facings_need_state"].fillna(
        9999, inplace=True
    )

    return (
        df_optimization_master_data_filt_optimizer_only,
        min_facings_per_need_state,
        max_facings_per_need_state,
    )


def create_index_set_in_df(
        df: pd.DataFrame, index_cols: List[str], index_name: str
) -> Tuple[pd.DataFrame, np.array]:
    """
    This function allows to create indices based on `index_cols` which will have the name `index_name`
    Args:
        df: DataFrame for which we want to create the indices
        index_cols: Columns on which we want the unique indices to be based
        index_name: Name of the index column we want to create

    Returns:
    A tuple of:
    - Input `df` dataframe with an extra column named `index_name`
    - A np.array that contains the same value as that column
    """
    df_temp = (
        df[index_cols]
        .drop_duplicates(subset=index_cols)
        .sort_values(index_cols)
        .reset_index(drop=True)
    )
    df_temp[index_name] = df_temp.index
    df = df.merge(
        df_temp,
        on=index_cols,
        how="inner",
    )
    return df, np.array(df_temp[index_name].tolist())


def get_list_facings_ineligible_for_constraints_item(
    i: int,
    c: int,
    g: int,
    col_reference: str,
    facings_param: int,
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
    mode: Literal["incremental", "decremental"] = "incremental",
) -> np.array:
    """
    Returns a list of facings that are ineligible for a given SKU (item, cluster, fixture) based on either
    incremental or decremental constraints.

    - In "incremental" mode: returns facings greater than (current facings + facings_param)
    - In "decremental" mode: returns facings less than (current facings - facings_param)

    Args:
        i (int): Index of the item (SKU).
        c (int): Index of the cluster.
        g (int): Index of the plano fixture.
        col_reference (str): Column name for current facings.
        facings_param (int): Max allowed change in facings (increment or decrement).
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame): Filtered optimizer input data.
        mode (str): Either "incremental" or "decremental".

    Returns:
        np.array: Array of ineligible facings for the given SKU and constraint mode.
     """

    # Get max facings per SKU in department
    max_facings_per_sku_in_dept = (
        df_optimization_master_data_filt_optimizer_only["max_facings_per_sku"].unique()[0] + 1
    )
    if np.isnan(max_facings_per_sku_in_dept):
        max_facings_per_sku_in_dept = context.optimization.model_formulation.max_facings_opti - 1

    # Filter for the specific item-cluster-fixture combination
    row = df_optimization_master_data_filt_optimizer_only[
        (df_optimization_master_data_filt_optimizer_only["items_all_idx"] == i) &
        (df_optimization_master_data_filt_optimizer_only["cluster_idx"] == c) &
        (df_optimization_master_data_filt_optimizer_only["plano_fixture_idx"] == g)
    ]

    if row.empty:
        return np.array([])

    current_facings = row[col_reference].drop_duplicates().round(4).unique()[0]

    if mode == "incremental":
        range_min = int(min(current_facings + facings_param + 1, max_facings_per_sku_in_dept))
        range_max = int(context.optimization.model_formulation.max_facings_opti)
        return np.arange(range_min, range_max) if range_min < range_max else np.array([])

    elif mode == "decremental":
        range_max = int(max(current_facings - facings_param, 0))
        return np.arange(0, range_max) if range_max > 0 else np.array([])

    else:
        raise ValueError(f"Invalid mode '{mode}'. Must be 'incremental' or 'decremental'.")


# Function to calculate ineligible facings in a vectorized manner
def get_list_facings_ineligible_for_constraints_vectorized(
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
    col_reference: str,
    output_col: str,
    facings_param: int,
    max_facings_opti: int,
    mode: Literal["incremental", "decremental"] = "incremental",
) -> Dict[Tuple[int, int, int], np.array]:
    """
    Generates a dictionary mapping a combination of (`items_all_idx`, `cluster_idx`, `plano_fixture_idx`)
    to an array of ineligible facings based on either incremental or decremental constraints.

    This function processes the input DataFrame, grouping by SKU, cluster, and fixture. For each group,
    it calculates a range of ineligible facings:
    - In "incremental" mode: facings that exceed the allowed increase from the current facings.
    - In "decremental" mode: facings that fall below the allowed decrease from the current facings.

    Args:
        df_optimization_master_data_filt_optimizer_only (pd.DataFrame):
            The filtered optimization master data containing necessary columns.
        col_reference (str):
            The column name used as a reference for calculating the ineligible facings range.
        output_col (str):
            The name of the output column where the ineligible facings arrays will be stored.
        facings_param (int):
            The max allowed change (increment or decrement) in facings.
        max_facings_opti (int):
            The maximum allowed facings, used as the upper bound in incremental mode.
        mode (str):
            Either "incremental" or "decremental", indicating which constraint to apply.

    Returns:
        Dict[Tuple[int, int, int], np.array]:
             A dictionary where the keys are tuples of (`items_all_idx`, `cluster_idx`, `plano_fixture_idx`)
            and the values are numpy arrays containing the ineligible facings for those combinations.

    Raises:
        ValueError: If any group in the DataFrame contains more than one row.

    Example:
        >>> df = pd.DataFrame({
                "items_all_idx": [1, 2, 3],
                "cluster_idx": [10, 10, 20],
                "plano_fixture_idx": [100, 100, 200],
                "max_facings_per_sku": [5, 8, 4],
                "some_reference_column": [2.0, 3.5, 1.0]
            })

        >>> # Incremental mode: disallow facings more than current + 1
        >>> get_list_facings_ineligible_for_constraints_vectorized(
                df,
                col_reference="some_reference_column",
                output_col="ineligible_facings_incremental",
                facings_param=1,
                max_facings_opti=10,
                mode="incremental"
            )
        {
            (1, 10, 100): np.array([4, 5, 6, 7, 8, 9]),
            (2, 10, 100): np.array([6, 7, 8, 9]),
            (3, 20, 200): np.array([3, 4, 5, 6, 7, 8, 9])
        }

        >>> # Decremental mode: disallow facings less than current - 1
        >>> get_list_facings_ineligible_for_constraints_vectorized(
                df,
                col_reference="some_reference_column",
                output_col="ineligible_facings_decremental",
                facings_param=1,
                max_facings_opti=10,
                mode="decremental"
            )
        {
            (1, 10, 100): np.array([0]),
            (2, 10, 100): np.array([0, 1]),
            (3, 20, 200): np.array([])
        }
    """
    # For items which are replacing old items, filter to clusters where old item do not exist
    # For clusters where the old items exist, there is a forced facing constraint which would conflict this
    df_new_replacement_idx = (
        (df_optimization_master_data_filt_optimizer_only["item_no_nbr"]
        !=df_optimization_master_data_filt_optimizer_only["clone_item_item_no_nbr"])
        & (df_optimization_master_data_filt_optimizer_only["facing_type"]=="new_replacement")
    )
    df_optimization_master_data_filt_optimizer_only = df_optimization_master_data_filt_optimizer_only.loc[~df_new_replacement_idx]
    
    df_facings_sku = df_optimization_master_data_filt_optimizer_only[
        [
            "items_all_idx",
            "cluster_idx",
            "plano_fixture_idx",
            "max_facings_per_sku",
            col_reference,
        ]
    ].drop_duplicates(subset=["items_all_idx", "cluster_idx", "plano_fixture_idx"])

    # Group by items_all_idx, cluster_idx, and plano_fixture_idx
    grouped = df_facings_sku.groupby(
        ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
    )

    
    results = []

    for name, group in grouped:
        if len(group) > 1:
            raise ValueError(
                f"Group {name} has more than one row. This function expects exactly one row per group."
            )

        current_facings = group[col_reference].fillna(0).round(4).iloc[0]
        max_facings_per_sku_in_dept = (
            group["max_facings_per_sku"].fillna(max_facings_opti - 2).iloc[0] + 1
        )

        if mode == "incremental":
            range_min = int(min(current_facings + facings_param + 1, max_facings_per_sku_in_dept))
            range_max = max_facings_opti
            ineligible_array = np.arange(range_min, range_max) if range_min < range_max else np.array([])

        elif mode == "decremental":
            range_max = int(max(current_facings - facings_param, 0))
            ineligible_array = np.arange(0, range_max) if range_max > 0 else np.array([])

        else:
            raise ValueError(f"Invalid mode '{mode}'. Must be 'incremental' or 'decremental'.")

        group[output_col] = [ineligible_array]
        results.append(group)

    df_result = pd.concat(results).reset_index(drop=True)
    df_result_filtered = df_result[df_result[output_col].apply(lambda x: x.size > 0)]

    return df_result_filtered.set_index(
        ["items_all_idx", "cluster_idx", "plano_fixture_idx"]
    )[output_col].to_dict()


def map_assortment_constraints_to_indices(
    dict_assortment_expansion_reduction: List[Dict[str, Union[str, float]]],
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Tuple[List[Dict[str, Union[int, float]]], Dict[str, List[str]]]:
    """
    Maps the values in dict_assortment_expansion_reduction to their corresponding index values.
    Returns:
        - mapped_constraints: List of constraints with indices mapped.
        - unmapped_clusters_planos: Dictionary containing labels not found in mapping.
    """
    # Create mapping for plano_fixture_idx (plano_ft, fixture_size, plano_id)
    plano_fixture_mapping = pd.Series(
        df_optimization_master_data_filt_optimizer_only["plano_fixture_idx"].values,
        index=list(
            zip(
                df_optimization_master_data_filt_optimizer_only["plano_ft"],
                df_optimization_master_data_filt_optimizer_only["fixture_size"],
                df_optimization_master_data_filt_optimizer_only["plano_id"],
            )
        ),
    ).to_dict()
    
    # Create mapping for cluster_idx using the final_cluster_labels
    cluster_mapping = pd.Series(
        df_optimization_master_data_filt_optimizer_only["cluster_idx"].values,
        index=df_optimization_master_data_filt_optimizer_only["final_cluster_labels"],
    ).drop_duplicates().to_dict()

    # Map dict_assortment_expansion_reduction values to indices
    mapped_constraints = []
    labels_not_found = []
    for constraint in dict_assortment_expansion_reduction:
        mapped_constraint = constraint.copy()
        
        # Convert constraint values to match DataFrame types
        try:
            plano_ft = int(float(constraint["plano_ft"]))
            fixture_size = float(constraint["fixture_size"])
            plano_id = str(constraint["plano_id"])
            
            plano_key = (plano_ft, fixture_size, plano_id)
            
            if plano_key in plano_fixture_mapping:
                mapped_constraint["plano_fixture_idx"] = plano_fixture_mapping[plano_key]
            else:
                labels_not_found.append(plano_key)
                continue
                
        except (ValueError, KeyError) as e:
            log.info(f"Error converting constraint values: {e}")
            continue

        # Create final_cluster_label from store_cluster, volume_flag, and risk_flag
        final_cluster_label = f"{constraint['store_cluster']}-{constraint['volume_flag']}_{constraint['risk_flag']}"
        
        # Map final_cluster_label to cluster_idx
        if final_cluster_label in cluster_mapping:
            mapped_constraint["cluster_idx"] = cluster_mapping[final_cluster_label]
        else:
            labels_not_found.append(final_cluster_label)
            continue

        # Remove original keys that were mapped to indices
        for key in ["plano_ft", "fixture_size", "plano_id", "store_cluster", "risk_flag", "volume_flag"]:
            mapped_constraint.pop(key, None)

        mapped_constraints.append(mapped_constraint)

    unmapped_clusters_planos = {"labels_not_found": list(set(labels_not_found))}

    log.info(f"\nSuccessfully mapped {len(mapped_constraints)} out of {len(dict_assortment_expansion_reduction)} constraints.")
    return mapped_constraints, unmapped_clusters_planos


def create_plano_id_to_sku_mapping(
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame
) -> Dict[str, List[int]]:
    """
    Creates a mapping of plano_id to list of item_no_nbr (SKUs) from the optimization data.
    
    Args:
        df_optimization_master_data_filt_optimizer_only: DataFrame containing optimization data
        
    Returns:
        Dictionary mapping plano_id to list of item_no_nbr values
    """
    plano_sku_mapping = (
        df_optimization_master_data_filt_optimizer_only
        .groupby('plano_id')['item_no_nbr']
        .apply(list)
        .to_dict()
    )
    
    log.info(f"Created plano_id to SKU mapping for {len(plano_sku_mapping)} plano_ids")
    return plano_sku_mapping


def map_item_no_nbr_to_items_all_idx(
    nested_dict: Dict[Union[str, float], Dict[int, float]],
    item_idx_to_item_no: Dict[int, int],
    plano_sku_mapping: Optional[Dict[str, List[int]]] = None
) -> Dict[Union[str, float], Dict[int, float]]:
    """
    Maps a nested dictionary keyed by plano_id and item_no_nbr to one keyed by plano_id and items_all_idx.

    Args:
        nested_dict: {plano_id: {item_no_nbr: value}} where plano_id can be string or float
        item_idx_to_item_no: {item_idx: item_no_nbr}

    Returns:
        {plano_id: {items_all_idx: value}} where plano_id can be string or float
    """
    
    # Build reverse mapping: item_no_nbr -> items_all_idx
    item_no_nbr_to_item_idx = {v: k for k, v in item_idx_to_item_no.items()}

    # If plano_sku_mapping is provided, resolve plano_id variations
    resolved_nested_dict = nested_dict.copy()
    if plano_sku_mapping:
        resolved_nested_dict = _resolve_plano_id_variations(nested_dict, plano_sku_mapping)

    # Track mapping statistics
    total_items_processed = 0
    total_items_mapped = 0
    total_items_skipped = 0
    planos_with_mappings = 0
    planos_without_mappings = 0

    # Map keys in the nested dictionary
    mapped_dict = {}
    for plano_id, inner_dict in resolved_nested_dict.items():
        
        mapped_inner_dict = {}
        items_mapped_for_plano = 0
        items_skipped_for_plano = 0
        
        for item_no_nbr, value in inner_dict.items():
            total_items_processed += 1
            
            if item_no_nbr in item_no_nbr_to_item_idx:
                item_idx = item_no_nbr_to_item_idx[item_no_nbr]
                mapped_inner_dict[item_idx] = value
                items_mapped_for_plano += 1
                total_items_mapped += 1
            else:
                items_skipped_for_plano += 1
                total_items_skipped += 1
                log.warning(f"item_no_nbr {item_no_nbr} not found in mapping, skipping (plano_id: {plano_id})")
        
        if mapped_inner_dict:
            mapped_dict[plano_id] = mapped_inner_dict
            planos_with_mappings += 1
            log.info(f"Plano {plano_id}: {items_mapped_for_plano} items mapped, {items_skipped_for_plano} items skipped")
        else:
            planos_without_mappings += 1
            log.warning(f"Plano {plano_id}: No items could be mapped ({items_skipped_for_plano} items skipped)")
    
    if total_items_skipped > 0:
        log.warning(f"{total_items_skipped} items could not be mapped - check if these item_no_nbr values exist in the optimization dataset")
    
    return mapped_dict


def _resolve_plano_id_variations(
    nested_dict: Dict[Union[str, float], Dict[int, float]],
    plano_sku_mapping: Dict[str, List[int]]
) -> Dict[Union[str, float], Dict[int, float]]:
    """
    Helper function to resolve plano_id variations by finding the correct plano_id 
    that contains the SKUs specified in the nested_dict.
    
    Args:
        nested_dict: Original nested dictionary with potentially outdated plano_ids
        plano_sku_mapping: Mapping of current plano_ids to their SKU lists
        
    Returns:
        Resolved nested dictionary with updated plano_ids
    """
    resolved_dict = {}
    
    for original_plano_id, sku_dict in nested_dict.items():
        original_plano_str = str(original_plano_id)
        
        # Try exact match first
        if original_plano_str in plano_sku_mapping:
            resolved_dict[original_plano_id] = sku_dict
            continue
        
        # Find all plano_ids that start with the original plano_id
        candidate_planos = [
            plano_id for plano_id in plano_sku_mapping.keys() 
            if plano_id.startswith(original_plano_str)
        ]
        
        if not candidate_planos:
            # No matches found - keep original and log warning
            resolved_dict[original_plano_id] = sku_dict
            log.warning(f"No matching plano_id found for {original_plano_id}")
            continue
        
        # Distribute SKUs across matching sub-planos
        unmatched_skus = {}
        matched_any = False
        
        for target_sku, value in sku_dict.items():
            sku_matched = False
            
            for candidate_plano in candidate_planos:
                if target_sku in plano_sku_mapping[candidate_plano]:
                    # Add SKU to this sub-plano
                    if candidate_plano not in resolved_dict:
                        resolved_dict[candidate_plano] = {}
                    resolved_dict[candidate_plano][target_sku] = value
                    sku_matched = True
                    matched_any = True
                    log.info(f"Mapped SKU {target_sku} from {original_plano_id} -> {candidate_plano}")
                    break
            
            if not sku_matched:
                unmatched_skus[target_sku] = value
        
        # Handle unmatched SKUs
        if unmatched_skus:
            if matched_any:
                # Some SKUs were matched, but these weren't - log warning
                log.warning(f"SKUs {list(unmatched_skus.keys())} from {original_plano_id} could not be matched to any sub-plano")
            else:
                # No SKUs were matched - keep original
                resolved_dict[original_plano_id] = sku_dict
                log.warning(f"No SKUs from {original_plano_id} could be matched to sub-planos {candidate_planos}")
    
    return resolved_dict


def get_current_store_count_per_items_all_idx(
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
    nested_dict: Dict[int, Dict[int, float]],
    item_idx_to_item_no: Dict[int, int],
    plano_sku_mapping: Dict[str, List[int]]
) -> Dict[int, Dict[int, float]]:
    """
    For SKUs in nested_dict, returns {plano_id: {items_all_idx: current_store_count}}.

    Args:
        df_optimization_master_data_filt_optimizer_only: DataFrame containing optimization data.
        nested_dict: {plano_id: {item_no_nbr: value}}
        item_idx_to_item_no: {item_idx: item_no_nbr}

    Returns:
        {plano_id: {items_all_idx: current_store_count}}
    """
    # Build reverse mapping: item_no_nbr -> items_all_idx
    item_no_nbrs = {item_no_nbr for inner_dict in nested_dict.values() for item_no_nbr in inner_dict.keys()}

    # Filter and group in one pass, then map to items_all_idx
    current_store_count_per_items_all = (
        df_optimization_master_data_filt_optimizer_only.loc[
            (df_optimization_master_data_filt_optimizer_only["item_no_nbr"].isin(item_no_nbrs)) &
            (df_optimization_master_data_filt_optimizer_only["n_current_facings_sku"] > 0)
        ]
        .groupby(["plano_id", "item_no_nbr"])["n_stores_item_no_exist_total"]
        .max()
        .to_dict()
    )

    # Convert the flat dictionary to nested format
    nested_store_count = {}
    for (plano_id, item_no_nbr), count in current_store_count_per_items_all.items():
        if plano_id not in nested_store_count:
            nested_store_count[plano_id] = {}
        nested_store_count[plano_id][item_no_nbr] = count

    # Map item_no_nbr to items_all_idx in the nested dictionary
    current_store_count_per_items_all_idx = map_item_no_nbr_to_items_all_idx(
        nested_store_count,
        item_idx_to_item_no,
        plano_sku_mapping
    )
    return current_store_count_per_items_all_idx


def create_dc_constraint_parameters(
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame
) -> Dict:
    """
    Create DC-specific parameters for constraints using pre-calculated DC data.
    """
    
    log.info("Creating DC constraint parameters...")
    
    # Check if DC data is available
    required_dc_cols = ['dc_id', 'total_stores_in_dc', 'stores_in_dc_per_cluster_plano']
    missing_cols = [col for col in required_dc_cols if col not in df_optimization_master_data_filt_optimizer_only.columns]
    
    if missing_cols:
        log.warning(f"Missing DC columns: {missing_cols} - DC constraints will be skipped")
        return {}
    
    # Get unique DC information per cluster-planogram with actual store counts
    dc_cluster_store_mapping = {}
    
    # Group by cluster-planogram and DC to get store counts
    dc_data = (
        df_optimization_master_data_filt_optimizer_only[
            ["cluster_idx", "plano_fixture_idx", "dc_id", "stores_in_dc_per_cluster_plano"]
        ]
        .drop_duplicates()
    )
    
    for _, row in dc_data.iterrows():
        cluster_plano_key = (row["cluster_idx"], row["plano_fixture_idx"])
        dc_id = row["dc_id"]
        store_count = row["stores_in_dc_per_cluster_plano"]
        
        if cluster_plano_key not in dc_cluster_store_mapping:
            dc_cluster_store_mapping[cluster_plano_key] = {}
        
        dc_cluster_store_mapping[cluster_plano_key][dc_id] = store_count
    
    min_stores_per_dc = context.optimization_config.model_formulation.get("min_stores_per_dc", 50)
    
    log.info(f"Created DC mapping for {len(dc_cluster_store_mapping)} cluster-planogram combinations")
    log.info(f"Minimum stores per DC threshold: {min_stores_per_dc}")
    
    return {
        "dc_cluster_store_mapping": dc_cluster_store_mapping,
        "min_stores_per_dc": min_stores_per_dc
    }


def get_removal_penalty_per_item(
    df_optimization_master_data_filt_optimizer_only: pd.DataFrame,
) -> Dict[int, float]:
    """
    Extracts removal penalty per item.
    
    Args:
        df_optimization_master_data_filt_optimizer_only: Filtered optimization master data
        
    Returns:
        Dictionary mapping item_idx to removal penalty value
    """
    removal_penalty_per_item = (
        df_optimization_master_data_filt_optimizer_only.groupby("items_all_idx")["removal_penalty"]
        .apply(lambda x: round(x.drop_duplicates().unique()[0], 4))
        .to_dict()
    )
    
    log.info(f"Extracted removal penalties for {len(removal_penalty_per_item)} items")
    
    return removal_penalty_per_item
