"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import (
    BoolColumn,
    FloatColumn,
    IntegerColumn,
    Schema,
    StringColumn,
)


# class OptimizationMasterModelingOutputClientOutput(Schema):
#     # Identifiers
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     dept_id = IntegerColumn()
#     final_cluster_labels = StringColumn()
#     plano_ft = IntegerColumn()
#     fixture_size = FloatColumn()
#     item_no_nbr = IntegerColumn()
#     need_state_unique_id = StringColumn()
#     representative_store_nbr = IntegerColumn()
#     brand_name = StringColumn()
#     supplier_name = StringColumn()
#
#     # SKU or POG Data
#     item_no_desc = StringColumn()
#     n_current_linear_space_used_sku = FloatColumn()
#     n_current_facings_sku = IntegerColumn()
#     n_current_linear_space_per_facing_sku = FloatColumn()
#
#     # Sets or Constraints Data
#     private_label_ind = IntegerColumn()
#     is_net_new_sku = IntegerColumn()
#     is_discontinued_sku = IntegerColumn()
#
#     # Optimal Results Data
#     n_optimal_facings_sku = IntegerColumn()
#     n_optimal_linear_space_used_sku = FloatColumn()


# class NewItemItemCodeSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     new_item_item_code_nbr = IntegerColumn(source="item_code_nbr")
