"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import FloatColumn, IntegerColumn, Schema, StringColumn


class LatestSkuFacingsPogCategoryDept(Schema):
    store_nbr = IntegerColumn()
    # ad_wk_per_id = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    plano_id = StringColumn()
    fixture_desc = StringColumn()
    item_no_nbr = IntegerColumn()
    n_current_facings_sku = IntegerColumn()
    n_current_linear_space_used_sku = FloatColumn()
    # n_weeks_in_dept = IntegerColumn()
    prod_unit_width_ft = FloatColumn()
    prod_unit_height_ft = FloatColumn()
    prod_unit_depth_ft = FloatColumn()
    orientation = StringColumn()


class LatestSkuFacingsPogCategoryDeptWithCategoryLevel(LatestSkuFacingsPogCategoryDept):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class SpaceProductivityPerFacing(Schema):
    # Original information
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()
    need_state_unique_id = StringColumn()
    final_cluster_labels = StringColumn()
    is_zero_sales = IntegerColumn()
    # Outputs from elasticity model
    param_max_target = FloatColumn()
    param_exp_scaling = FloatColumn()
    n_space_prod_fit_facings_0 = FloatColumn()
    n_space_prod_fit_facings_1 = FloatColumn()
    n_space_prod_fit_facings_2 = FloatColumn()
    n_space_prod_fit_facings_3 = FloatColumn()
    n_space_prod_fit_facings_4 = FloatColumn()
    n_space_prod_fit_facings_5 = FloatColumn()
    n_space_prod_fit_facings_6 = FloatColumn()
    n_space_prod_fit_facings_7 = FloatColumn()
    n_space_prod_fit_facings_8 = FloatColumn()
    n_space_prod_fit_facings_9 = FloatColumn()
    n_space_prod_fit_facings_10 = FloatColumn()
    n_space_prod_fit_facings_11 = FloatColumn()
    n_space_prod_fit_facings_12 = FloatColumn()
    n_space_prod_fit_facings_13 = FloatColumn()
    n_space_prod_fit_facings_14 = FloatColumn()
    n_space_prod_fit_facings_15 = FloatColumn()
    n_space_prod_fit_facings_16 = FloatColumn()
    n_space_prod_fit_facings_17 = FloatColumn()


class SkuSpecificSpaceProductivityPerFacing(Schema):
    # Original information
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()
    brand_name = StringColumn()
    vendor_name = StringColumn()
    vendor_number = StringColumn()
    need_state_unique_id = StringColumn()
    final_cluster_labels = StringColumn()
    plano_id = StringColumn()    
    fixture_desc = StringColumn()
    
    # Outputs from elasticity model
    # param_max_target = FloatColumn()
    # param_exp_scaling = FloatColumn()
    n_space_prod_fit_facings_0 = FloatColumn()
    n_space_prod_fit_facings_1 = FloatColumn()
    n_space_prod_fit_facings_2 = FloatColumn()
    n_space_prod_fit_facings_3 = FloatColumn()
    n_space_prod_fit_facings_4 = FloatColumn()
    n_space_prod_fit_facings_5 = FloatColumn()
    n_space_prod_fit_facings_6 = FloatColumn()
    n_space_prod_fit_facings_7 = FloatColumn()
    n_space_prod_fit_facings_8 = FloatColumn()
    n_space_prod_fit_facings_9 = FloatColumn()
    n_space_prod_fit_facings_10 = FloatColumn()
    n_space_prod_fit_facings_11 = FloatColumn()
    n_space_prod_fit_facings_12 = FloatColumn()
    n_space_prod_fit_facings_13 = FloatColumn()
    n_space_prod_fit_facings_14 = FloatColumn()
    n_space_prod_fit_facings_15 = FloatColumn()
    n_space_prod_fit_facings_16 = FloatColumn()
    n_space_prod_fit_facings_17 = FloatColumn()
    is_elasticity_overridden = IntegerColumn()
    elasticity_override_granularity = StringColumn()
    boh_param_a = FloatColumn()
    boh_param_b = FloatColumn()
    unit_price = FloatColumn()

    # dnp components
    dnp_component_fixed = FloatColumn()
    dnp_component_cost = FloatColumn()
    dnp_component_allowance_coupon_co_op = FloatColumn()
    dnp_component_units_sold = FloatColumn()
    dnp_component_cost_purchases = FloatColumn()
    dnp_component_total_sales = FloatColumn()
    dnp_component_tot_dnp_amt = FloatColumn()
    sku_system_scan_spread = FloatColumn()
    sku_scan_final = FloatColumn()