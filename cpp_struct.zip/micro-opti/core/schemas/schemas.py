"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import (
    DateColumn,
    FloatColumn,
    IntegerColumn,
    Schema,
    StringColumn,
)


class SampleSchema(Schema):
    CUSTOMER_CARD_ID = StringColumn(source="CUSTOMER_CARD_ID")
    ITEM_A = StringColumn(source="ITEM_A")
    ITEM_B = StringColumn(source="ITEM_B")


class PogCategoryMappingSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()


class LatestSpaceDataSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    ad_wk_per_id = IntegerColumn()
    item_no_nbr = IntegerColumn()
    plano_id = StringColumn()
    plano_ft = IntegerColumn()
    pre_split_plano_ft = IntegerColumn()
    dept_id = IntegerColumn()
    pre_split_dept_id = IntegerColumn()
    fixture_desc = StringColumn()
    linear_ft = FloatColumn()
    linear_in = FloatColumn()
    hfacings = IntegerColumn()
    # vfacings = IntegerColumn()
    # prod_unit_width_in = FloatColumn()
    # prod_unit_height_in = FloatColumn()
    # prod_unit_depth_in = FloatColumn()
    orientation = StringColumn()
    # position_count = FloatColumn()


class LatestSpaceDataWithCategoryLevelSchema(LatestSpaceDataSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class LatestSpaceDataFtSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    item_no_nbr = IntegerColumn()
    plano_id = StringColumn()
    plano_ft = IntegerColumn()
    dept_id = IntegerColumn()
    fixture_desc = StringColumn()
    hfacings = IntegerColumn()
    orientation = StringColumn()


class LatestSpaceDataWithCategoryLevelFtSchema(LatestSpaceDataFtSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class LatestAdWkPerIdSchema(Schema):
    ad_wk_per_id = IntegerColumn()


class FilteredLatestSpaceDataSchema(Schema):
    store_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    plano_ft = IntegerColumn()
    dept_id = IntegerColumn()
    fixture_desc = StringColumn()
    linear_ft = FloatColumn()
    hfacings = IntegerColumn()


class FilteredLatestSpaceDataSchemaWithCategoryLevel(FilteredLatestSpaceDataSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class RawProductHierarchySchema(Schema):
    product_id = IntegerColumn()
    product_desc = StringColumn()
    item_code_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    item_no_desc = StringColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    prod_cat_nbr = IntegerColumn()
    prod_cat_name = StringColumn()
    creation_dt = DateColumn()


class PogOutlierSkuSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    item_no_nbr = IntegerColumn()
    product_id = StringColumn()
    product_desc = StringColumn()
    pct_store_coverage = FloatColumn()


class PogOutlierSkuItemNoNbrSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    item_no_nbr = IntegerColumn()


class PogOutlierSkuProductIdSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    product_id = StringColumn()


class DnpRatioSchema(Schema):
    store_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    sum_sales_dlrs = FloatColumn()
    sum_dnp = FloatColumn()


class UpcItemNoSkuMappingSchema(Schema):
    item_no_nbr = IntegerColumn()
    upc_nbr = IntegerColumn()


class MergedClustersAnalysisSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    cluster1_id = StringColumn()
    cluster2_id = StringColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    plano_size = IntegerColumn()
    n_optimal_facings_sku_cluster1 = IntegerColumn()
    n_optimal_facings_sku_cluster2 = IntegerColumn()
    n_optimal_facings_sku_total = IntegerColumn()
    n_optimal_facings_sku_percent_diff = FloatColumn()
    n_current_facings_sku_cluster1 = IntegerColumn()
    n_current_facings_sku_cluster2 = IntegerColumn()
    n_current_facings_sku_total = IntegerColumn()
    n_current_facings_sku_percent_diff = FloatColumn()


class SkuTransferenceSchema(Schema):
    item_no_nbr = IntegerColumn()
    n_transference_sku = FloatColumn()


class SkuAvgUnitPriceSchema(Schema):
    item_no_nbr = IntegerColumn()
    sales_sum = FloatColumn()
    units_sum = FloatColumn()
    avg_unit_price = FloatColumn()


class LatestItemCodeandUPCSchema(Schema):
    upc_nbr = IntegerColumn()
    item_code_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()


class ArticleXrefSchema(Schema):
    upc_nbr = StringColumn(source="ZUPCWOCHECK")
    item_code_nbr = StringColumn(source="ZItemCode")
    item_no_nbr = StringColumn(source="ZItemNo")


class RedistributedSmallClusterSchema(Schema):
    redistributed_cluster_labels = StringColumn()
    consolidated_cluster_labels = StringColumn()
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    internal_cluster_labels = IntegerColumn()
    internal_optimal_silhouette_score = FloatColumn()
    internal_optimal_n_clusters = IntegerColumn()
    city = StringColumn()
    state = StringColumn()
    zip = IntegerColumn()
    external_cluster_labels = StringColumn()
    external_optimal_silhouette_score = FloatColumn()
    external_optimal_n_clusters = IntegerColumn()
    final_cluster_labels = StringColumn()
    cluster_type = StringColumn()
    n_stores_in_cluster = IntegerColumn()


class StoreWeeklySales(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    ad_wk_per_id = IntegerColumn()
    min_dt = DateColumn()
    max_dt = DateColumn()
    sales = FloatColumn()
    gp = FloatColumn()
    units = FloatColumn()
    dnp_original = FloatColumn()
    dnp_based_on_ratio = FloatColumn()


class PilotStores(Schema):
    pilot_store = IntegerColumn()
    control_store = IntegerColumn()


class PilotPreparedMsmtData(Schema):
    pilot_store = IntegerColumn()
    control_store = IntegerColumn()
    cluster = StringColumn()
    ad_wk_per_id = IntegerColumn()
    min_dt = DateColumn()
    max_dt = DateColumn()
    pilot_sales = FloatColumn()
    control_sales = FloatColumn()
    avg_pilot_pre_sales = FloatColumn()
    avg_control_pre_sales = FloatColumn()
    avg_pilot_yoy_test_sales = FloatColumn()
    avg_control_yoy_test_sales = FloatColumn()
    avg_pilot_yoy_pre_sales = FloatColumn()
    avg_control_yoy_pre_sales = FloatColumn()
    pilot_test_pre_index_sales = FloatColumn()
    control_test_pre_index_sales = FloatColumn()
    pilot_yoy_test_pre_index_sales = FloatColumn()
    control_yoy_test_pre_index_sales = FloatColumn()
    test_pre_index_diff_sales = FloatColumn()
    yoy_test_pre_index_diff_sales = FloatColumn()
    total_index_diff_sales = FloatColumn()
    pilot_dnp_based_on_ratio = FloatColumn()
    control_dnp_based_on_ratio = FloatColumn()
    avg_pilot_pre_dnp_based_on_ratio = FloatColumn()
    avg_control_pre_dnp_based_on_ratio = FloatColumn()
    avg_pilot_yoy_test_dnp_based_on_ratio = FloatColumn()
    avg_control_yoy_test_dnp_based_on_ratio = FloatColumn()
    avg_pilot_yoy_pre_dnp_based_on_ratio = FloatColumn()
    avg_control_yoy_pre_dnp_based_on_ratio = FloatColumn()
    pilot_test_pre_index_dnp_based_on_ratio = FloatColumn()
    control_test_pre_index_dnp_based_on_ratio = FloatColumn()
    pilot_yoy_test_pre_index_dnp_based_on_ratio = FloatColumn()
    control_yoy_test_pre_index_dnp_based_on_ratio = FloatColumn()
    test_pre_index_diff_dnp_based_on_ratio = FloatColumn()
    yoy_test_pre_index_diff_dnp_based_on_ratio = FloatColumn()
    total_index_diff_dnp_based_on_ratio = FloatColumn()
    pilot_units = FloatColumn()
    control_units = FloatColumn()
    avg_pilot_pre_units = FloatColumn()
    avg_control_pre_units = FloatColumn()
    avg_pilot_yoy_test_units = FloatColumn()
    avg_control_yoy_test_units = FloatColumn()
    avg_pilot_yoy_pre_units = FloatColumn()
    avg_control_yoy_pre_units = FloatColumn()
    pilot_test_pre_index_units = FloatColumn()
    control_test_pre_index_units = FloatColumn()
    pilot_yoy_test_pre_index_units = FloatColumn()
    control_yoy_test_pre_index_units = FloatColumn()
    test_pre_index_diff_units = FloatColumn()
    yoy_test_pre_index_diff_units = FloatColumn()
    total_index_diff_units = FloatColumn()
    pilot_dnp_original = FloatColumn()
    control_dnp_original = FloatColumn()
    avg_pilot_pre_dnp_original = FloatColumn()
    avg_control_pre_dnp_original = FloatColumn()
    avg_pilot_yoy_test_dnp_original = FloatColumn()
    avg_control_yoy_test_dnp_original = FloatColumn()
    avg_pilot_yoy_pre_dnp_original = FloatColumn()
    avg_control_yoy_pre_dnp_original = FloatColumn()
    pilot_test_pre_index_dnp_original = FloatColumn()
    control_test_pre_index_dnp_original = FloatColumn()
    pilot_yoy_test_pre_index_dnp_original = FloatColumn()
    control_yoy_test_pre_index_dnp_original = FloatColumn()
    test_pre_index_diff_dnp_original = FloatColumn()
    yoy_test_pre_index_diff_dnp_original = FloatColumn()
    total_index_diff_dnp_original = FloatColumn()


class OutOfStockPctSchema(Schema):
    item_no_nbr = IntegerColumn()
    out_of_stock_pct = FloatColumn()


class ManuallyCleanedBrands(Schema):
    brand_name = StringColumn()
    private_label_ind = IntegerColumn()


class AggregateTransactionsSchema(Schema):
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    baseline_sales = FloatColumn()
    baseline_dnp = FloatColumn()
    baseline_units = FloatColumn()


class NeedStateItemNoInfoSchema(Schema):
    category_level_dept_name = StringColumn()
    category_level_dept_nbr = IntegerColumn()
    prod_cat_name = StringColumn()
    prod_cat_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()


class NeedStateInputSchema(NeedStateItemNoInfoSchema):
    need_state = StringColumn()


class RawItemNoInfoSchema(Schema):
    plano_cat_desc = StringColumn()
    plano_cat_id = IntegerColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()


class OwnBrandItemNoInfoSchema(Schema):
    item_no_nbr = IntegerColumn()
    private_label_ind = IntegerColumn()


class SpaceItemNoInfoSchema(Schema):
    item_no_nbr = IntegerColumn()
    plano_cat_desc = StringColumn()
    plano_cat_id = IntegerColumn()
    dept_id = IntegerColumn()


class SpaceStoreSalesSchema(SpaceItemNoInfoSchema):
    store_nbr = IntegerColumn()
    client_cluster_nbr = IntegerColumn()
    client_cluster_desc = StringColumn()
    prod_cat_nbr = IntegerColumn()
    prod_cat_name = StringColumn()
    last_12m_shrink_dlrs = FloatColumn()
    last_12m_claim_dlrs = FloatColumn()
    last_12m_sales_dlrs = FloatColumn()


class ShrinkWasteSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    last_12m_shrink_dlrs = FloatColumn()
    last_12m_claim_dlrs = FloatColumn()
    last_12m_sales_dlrs = (
        FloatColumn()
    )  # Need to match to config shrink_waste_denominator


class InternalProportionsSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    unique_id = StringColumn()
    sum_allocated_units_feature_lvl = FloatColumn()
    sum_allocated_sales_feature_lvl = FloatColumn()
    sum_allocated_gp_feature_lvl = FloatColumn()
    sum_allocated_dnp_feature_lvl = FloatColumn()
    sum_allocated_units_above_feature_lvl = FloatColumn()
    sum_allocated_sales_above_feature_lvl = FloatColumn()
    sum_allocated_gp_above_feature_lvl = FloatColumn()
    sum_allocated_dnp_above_feature_lvl = FloatColumn()
    n_allocated_sales_proportion = FloatColumn()
    n_allocated_units_proportion = FloatColumn()
    n_allocated_gp_proportion = FloatColumn()
    n_allocated_dnp_proportion = FloatColumn()
    proportion_of_waste = FloatColumn()
    ob_sales_pen = FloatColumn()


class InternalProportionsProdcatSchema(InternalProportionsSchema):
    prod_cat_nbr = IntegerColumn()
    prod_cat_name = StringColumn()


class InternalProportionsNeedstateSchema(InternalProportionsSchema):
    need_state = StringColumn()


class RampUpItemNoStoreSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()
    store_nbr = IntegerColumn()


class TotalYearlySalesItemNoStoreSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()
    store_nbr = IntegerColumn()
    sales_dlrs = FloatColumn()


class ForceFacingsItemNoClusterSchema(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    item_no_nbr = IntegerColumn()
    final_cluster_labels = StringColumn()
    is_forced_facings = IntegerColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()


class ForceFacingsItemNoClusterSchemaWithCategoryLevel(ForceFacingsItemNoClusterSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class PlanoMoveSchema(Schema):
    store_nbr = IntegerColumn()
    dept_id = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_id = StringColumn()
    plano_ft = IntegerColumn()
    fixture_desc = StringColumn()
