"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import (
    FloatColumn,
    IntegerColumn,
    Schema,
    StringColumn,
    DateTimeColumn,
)


class ClusteringCorrelationSchema(Schema):
    external_feature = StringColumn()
    corr_w_last_12m_normalized_sales_dlrs = FloatColumn()


class PlanoCorrelationSchema(ClusteringCorrelationSchema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()


class DeptCorrelationSchema(PlanoCorrelationSchema):
    dept_id = IntegerColumn()


class ShrinkWasteSalesSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    last_12m_shrink_dlrs = FloatColumn()
    last_12m_claim_dlrs = FloatColumn()
    last_12m_sales_dlrs = FloatColumn()


class TotalStoreSalesSchema(Schema):
    store_nbr = IntegerColumn()
    total_sales = FloatColumn()


class PogDnpProductSpaceDataSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    total_pog_sales = FloatColumn()


class ItemNoTrxDnpProductSpaceDataSchema(Schema):
    store_nbr = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    item_no_nbr = IntegerColumn()
    allocated_sales_store_plano_dept_category_level_prod_item_no = FloatColumn()
    allocated_units_store_plano_dept_category_level_prod_item_no = FloatColumn()
    allocated_gp_store_plano_dept_category_level_prod_item_no = FloatColumn()
    allocated_dnp_store_plano_dept_category_level_prod_item_no = FloatColumn()
    hfacings_store_plano_dept_category_level_prod_item_no = IntegerColumn()
    linear_ft_store_plano_dept_category_level_prod_item_no = FloatColumn()


class ItemNoTrxDnpProductSpaceDataWithProdCatSchema(ItemNoTrxDnpProductSpaceDataSchema):
    prod_cat_nbr = IntegerColumn()
    prod_cat_name = StringColumn()


class ClusteringTrxDnpProductSpaceSchema(Schema):
    store_nbr = IntegerColumn()
    prod_cat_nbr = IntegerColumn()
    prod_cat_name = StringColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    unique_id = StringColumn()
    sum_allocated_sales = FloatColumn()
    sum_allocated_units = FloatColumn()
    sum_allocated_gp = FloatColumn()
    sum_allocated_dnp = FloatColumn()


class ClusteringNeedStateCategoryLevelProdCatItemNoSchema(Schema):
    category_level_dept_nbr = IntegerColumn()
    prod_cat_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    need_state = StringColumn()


class FilteredTrxDnpProductSpaceForFinancial(Schema):
    store_nbr = IntegerColumn()
    price_per_unit = FloatColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    item_no_nbr = IntegerColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_desc = StringColumn()
    allocated_sales = FloatColumn()
    allocated_units = FloatColumn()
    allocated_gp = FloatColumn()
    allocated_dnp = FloatColumn()


class FilteredTrxDnpProductSpaceForFinancialWithCategoryLevelSchema(
    FilteredTrxDnpProductSpaceForFinancial
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class InternalClusteringMetricsSchema(Schema):
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    n_clusters = IntegerColumn()
    silhouette_score = FloatColumn()
    inertia = FloatColumn()
    min_stores_per_cluster = IntegerColumn()
    total_stores_for_dept = IntegerColumn()


class DemandClusterLabelsSchema(Schema):
    store_nbr = IntegerColumn()
    city = StringColumn()
    state = StringColumn()
    tag = StringColumn()
    tag_previous = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    internal_cluster_labels = StringColumn()
    internal_optimal_silhouette_score = FloatColumn()
    internal_optimal_n_clusters = IntegerColumn()
    external_cluster_labels = StringColumn()
    external_optimal_silhouette_score = FloatColumn()
    external_optimal_n_clusters = IntegerColumn()
    demand_cluster_labels = StringColumn()
    cluster_type = StringColumn()
    n_stores_in_cluster = IntegerColumn()


class DemandClusterLabelsWithCategoryLevelSchema(DemandClusterLabelsSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class FilteredFinalClusterLabelsSchema(Schema):
    store_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    final_cluster_labels = StringColumn() # After user overrides


class FilteredFinalOriginalClusterLabelsSchema(FilteredFinalClusterLabelsSchema):
    original_cluster_labels = StringColumn() # original cluster value


class FilteredFinalOriginalDemandClusterLabelsSchema(
    FilteredFinalOriginalClusterLabelsSchema
):
    demand_cluster_labels = StringColumn() # Combination of external and internal cluster


class FilteredFinalClusterLabelsWithCategoryLevelSchema(FilteredFinalClusterLabelsSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class FilteredFinalOriginalClusterLabelsWithCategoryLevelSchema(
    FilteredFinalOriginalClusterLabelsSchema
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class FilteredFinalOriginalDemandClusterLabelsWithCategoryLevelSchema(
    FilteredFinalOriginalDemandClusterLabelsSchema
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class FilteredFinalOriginalSegmentClusterLabelsWithCategoryLevelSchema(
    FilteredFinalOriginalClusterLabelsWithCategoryLevelSchema
):
    segment_cluster_labels = StringColumn()

