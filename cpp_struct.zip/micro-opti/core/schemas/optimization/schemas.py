"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import (
    BoolColumn,
    FloatColumn,
    IntegerColumn,
    Schema,
    StringColumn,
)


class SuppliersAndBrandsSpaceConstraints(Schema):
    """
    Contains the requested space (either as a % change in facings, or a total number of facings) for a given Supplier or
    for a Brand within a (final_cluster_labels, plano_cat_desc, dept_id). /!\ Note that this shouldn't contain any
    Own Brands, since those are directly handled by the schema `OwnBrandSpaceConstraints`.
    Down the road, this will come from the Retail Catalyst App (through API call).
    """

    final_cluster_labels = StringColumn()
    dept_id = IntegerColumn()
    constraint_type_supplier_or_brand = StringColumn()
    # can only take values in context.optimization.manual_constraints.authorized_supplier_brand_constraint_types
    supplier_name = StringColumn()
    brand_name = StringColumn()
    lower_bound_constraint_supplier_or_brand = FloatColumn()
    upper_bound_constraint_supplier_or_brand = FloatColumn()


class SuppliersAndBrandsSpaceConstraintsWithCategoryLevel(SuppliersAndBrandsSpaceConstraints):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class LinearSpaceChangeGlobalConstraints(Schema):
    """
    Contains the requested a given Supplier or Brand should occupy on a global (across all versions) level.
    """
    plano_id = StringColumn()
    dimension = StringColumn()
    name = StringColumn()
    constraint_relative_to = StringColumn()
    min_bound = FloatColumn()
    max_bound = FloatColumn()


class LinearSpaceChangeGlobalConstraintsWithCategoryLevel(LinearSpaceChangeGlobalConstraints):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class SupplierAndOwnBrandItemMapping(Schema):
    """
    Contains a mapping between SKU and Supplier Name, as well as a flag to know whether or not this supplier is a
    Client Supplier (making it an Own Brand); comes from ETL.
    """

    item_no_nbr = IntegerColumn()
    brand_name = StringColumn()
    supplier_name = StringColumn()
    private_label_ind = IntegerColumn()


class LocalItemsSpaceConstraints(Schema):
    """
    Contains the requested space (as a %) for local items within a plano_cat_desc.
    Down the road, this will come from the Retail Catalyst App (through API call).
    """

    final_cluster_labels = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    pct_space_for_local_items = FloatColumn()


class LocalItemsSpaceConstraintsWithCategoryLevel(LocalItemsSpaceConstraints):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class LowerPerformerSkuStore(Schema):
    store_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    low_perform_label = IntegerColumn()


class ItemsForcedFacingsGuardrails(Schema):
    """
    Contains a list of items for which we want to force guardrails on the number of facings (min, max).
    Notice the biggest difference with `ItemsAddedNotInData` will be that these items CAN be found in the current
    pipeline's data, so we don't need extra info (e.g. brand, supplier, space prod, item width, etc.)
    Down the road, this will come from the Retail Catalyst App (through API call).
    """

    final_cluster_labels = StringColumn()
    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()


class ItemsForcedFacingsGuardrailsWithCategoryLevel(ItemsForcedFacingsGuardrails):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class ProtectedItems(Schema):
    """
    Contains a list of items for which we want to protect from removal the optimized number of facings in FP post-processing.
    """

    final_cluster_labels = StringColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    n_stores = IntegerColumn()
    n_stores_exceeding_space = IntegerColumn()
    item_no_nbr = IntegerColumn()
    brand_name = StringColumn()
    n_optimal_facings_sku = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    is_protect_items = IntegerColumn()
    is_protect_items_conservative = IntegerColumn()
    is_protect_forced_pos_facings = IntegerColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()
    is_protect_user_input_min_POD = IntegerColumn()
    POD_enforce = StringColumn()
    min_POD = FloatColumn()
    max_POD = FloatColumn()
    is_protect_user_input_min_brand_POD = IntegerColumn()
    brand_POD_enforce = StringColumn()
    min_brand_POD = FloatColumn()
    max_brand_POD = FloatColumn()
    optimal_assortment_item_POD = IntegerColumn()
    max_item_POD_reduction_after_pp = IntegerColumn()
    item_POD_after_resolving_space_violations_pp = IntegerColumn()
    optimal_assortment_brand_POD = IntegerColumn()
    is_protect_user_input_min_POD_in_pp = IntegerColumn()
    max_brand_POD_reduction_after_pp = IntegerColumn()
    brand_POD_after_resolving_space_violations_pp = IntegerColumn()
    is_protect_user_input_min_brand_POD_in_pp = IntegerColumn()


class ItemsPODConstraints(Schema):
    """
    Contains a list of items for which we want to enforce POD constraints
    """

    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    min_POD = FloatColumn()
    max_POD = FloatColumn()


class ItemsPODExempt(Schema):
    """
    Contains a list of items for which we want to exempt from the item POD constraints
    """

    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OriginalClusterIOHMinMaxPercentConstraints(Schema):
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    original_cluster_labels = StringColumn()
    min_IOH_percent = FloatColumn()
    max_IOH_percent = FloatColumn()
    working_capital_constraint = IntegerColumn()


class OriginalClusterIOHMinMaxPercentConstraintsWCategoryLevel(
    OriginalClusterIOHMinMaxPercentConstraints
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class PlanoFtForcedFacingsConstraints(Schema):
    """ """

    item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()


class ForcedFacingsMostGranular(Schema):
    item_no_nbr = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    final_cluster_labels = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()
    facing_type = StringColumn()

    "plano_cat_id",
    "plano_cat_desc",
    "dept_id",
    "final_cluster_labels",
    "need_state_unique_id",
    "category_level_dept_nbr",
    "category_level_dept_name",


class BrandPODConstraints(Schema):
    """ """

    brand_name = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    min_brand_POD = FloatColumn()
    max_brand_POD = FloatColumn()


class ItemsAddedNotInData(Schema):
    """
    Contains a list of items for which we want to force guardrails on the number of facings, but these items are
    "net new" items which cannot be found in the current pipeline's data.
    Down the road, this will come from the Retail Catalyst App (through API call).
    """

    cluster = StringColumn()  # TODO change later
    item_no_nbr = IntegerColumn()
    old_item_item_no_nbr = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    n_current_linear_space_per_facing_sku = FloatColumn()  # item width
    clone_pct = FloatColumn()


class ItemsAddedNotInDataWithCategoryLevel(ItemsAddedNotInData):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OwnBrandSpaceConstraints(Schema):
    """
    Contains a max % drop of own brand space within a (POG Category, Department); e.g. if own brands have 100ft of
    total linear space, the minimum they can end up with post-optimizer is 90ft if that max percent drop is 10%.
    It also contains a min and max % from total linear space allocated to own brands.
    Finally, there's a field `constraint_type_own_brand` which supposedly can only take 2 values:
    "max_pct_drop_from_current_ob_space" or "min_max_pct_allocated_from_total_available_space"
    """

    final_cluster_labels = StringColumn()
    dept_id = IntegerColumn()
    constraint_type_own_brand = StringColumn()
    max_pct_drop_own_brand_space = FloatColumn()
    min_pct_allocated_from_total_space_to_own_brands = FloatColumn()
    max_pct_allocated_from_total_space_to_own_brands = FloatColumn()


class OwnBrandSpaceConstraintsWithCategoryLevel(OwnBrandSpaceConstraints):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class MaxFacingsPerSkuInDeptConstraint(Schema):
    """
    Contains a max number of facings that applies to all SKUs in a given `dept_id` if specified
    """

    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    max_facings_per_sku = IntegerColumn()


class MaxFacingsPerSkuInDeptConstraintWithCategoryLevel(MaxFacingsPerSkuInDeptConstraint):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class NeedStateMinMaxFacingsConstraint(Schema):
    """
    Contains a min/max number of facings assigned to a Need State at the `final_cluster_labels, dept_id,
    need_state_unique_id` level
    """

    final_cluster_labels = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_id = StringColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    need_state_unique_id = StringColumn()
    min_facings_in_need_state_forced_guardrail = IntegerColumn()
    max_facings_in_need_state_forced_guardrail = IntegerColumn()


class NeedStateMinMaxFacingsConstraintWithCategoryLevel(NeedStateMinMaxFacingsConstraint):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class PivotAndLinkedSkuPairsConstraint(Schema):
    """
    Contains a constraint dataframe containing pairs of pivot and linked SKUs, where if the pivot SKU gets assigned
    >= 1 facing by optimizer then the linked SKU also needs to be assigned >= 1 facing by optimizer
    """

    dept_id = IntegerColumn()
    pivot_item_no_nbr = IntegerColumn()
    linked_item_no_nbr = IntegerColumn()
    volume_flag = StringColumn()
    category_level_dept_nbr = StringColumn()
    risk_flag = StringColumn()
    category_level_dept_name = StringColumn()


class PivotAndLinkedSkuPairsConstraintWithCategoryLevel(PivotAndLinkedSkuPairsConstraint):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class StoreSpaceCharacteristicsSchema(Schema):
    """
    Contains a mapping from (plano_cat_id, plano_cat_desc, store_nbr) to (plano_ft, final_cluster_labels, fixture_size)
    for all the stores in-scope for clustering
    """

    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    # pre_split_dept_id = IntegerColumn()
    store_nbr = IntegerColumn()
    original_cluster_labels = StringColumn()
    final_cluster_labels = StringColumn()
    cluster_labels_based_on = StringColumn()
    plano_ft = IntegerColumn()  # The final plano ft after splits and macro moves
    post_split_plano_ft = IntegerColumn()  # Plano ft after dept splits
    plano_ft_change = (
        IntegerColumn()
    )  # Calculates the change in plano ft due to macro space moves
    pre_split_plano_ft = IntegerColumn()  # Plano ft before dept splits (original)
    plano_ft_override_ratio = FloatColumn()  # post_split / pre_split
    fixture_desc = StringColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    n_stores = IntegerColumn()
    n_total_linear_space_dept_fixture_ft = (
        FloatColumn()
    )  # Final linear ft after splits and macro moves
    # override_n_total_linear_space_dept_fixture_ft = (
    #     FloatColumn()
    # )  # Adjusted linear ft based on plano ratio
    # pre_split_n_total_linear_space_dept_fixture_ft = (
    #     FloatColumn()
    # )  # Unadjusted linear ft
    addtl_linear_ft_gained = (
        FloatColumn()
    )  # Calculates the change in linear ft due to macro space moves
    n_total_linear_space_dept_fixture_ft_for_own_brand = (
        FloatColumn()
    )  # Adjusted linear ft based on plano ratio
    # pre_split_n_total_linear_space_dept_fixture_ft_for_own_brand = (
    #     FloatColumn()
    # )  # Unadjusted linear ft
    height_space_dept_fixture_ft = FloatColumn()
    depth_space_dept_fixture_ft = FloatColumn()


class StoreSpaceCharacteristicsWithCategoryLevelSchema(StoreSpaceCharacteristicsSchema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class StoreSpaceCharacteristicsAfterCollapseSchema(StoreSpaceCharacteristicsSchema):
    """
    StoreSpaceCharacteristicsSchema after the assortment collapsing process
    """

    original_cluster_labels_before_collapsing = StringColumn()
    final_cluster_labels_before_collapsing = StringColumn()


class StoreSpaceCharacteristicsWithCategoryLevelAfterCollapseSchema(
    StoreSpaceCharacteristicsWithCategoryLevelSchema
):
    original_cluster_labels_before_collapsing = StringColumn()
    final_cluster_labels_before_collapsing = StringColumn()


class PrioritizedStoreRepresentativeSchema(Schema):
    """
    Contains a mapping from (plano_cat_id, plano_cat_desc, plano_ft, final_cluster_labels) to
    store_nbr, which will correspond to the representative store of that grouping for the optimization module. It also
    contains the total linear space in that plano_cat for that plano_ft size and that store, as well as the sum of
    fixture sizes (e.g. if for that store there were 2 fixtures, one of 36in and one of 30in, the value will be 66)
    """

    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    original_cluster_labels = StringColumn()
    final_cluster_labels = StringColumn()
    cluster_labels_based_on = StringColumn()
    store_nbr = IntegerColumn()
    n_stores = IntegerColumn()
    n_total_linear_space_dept_fixture_ft = FloatColumn()
    n_total_linear_space_dept_fixture_ft_for_own_brand = FloatColumn()
    height_space_dept_fixture_ft = FloatColumn()
    depth_space_dept_fixture_ft = FloatColumn()


class PrioritizedStoreRepresentativeWithCategoryLevelSchema(
    PrioritizedStoreRepresentativeSchema
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationMasterModelingInput(Schema):
    """
    Contains the optimization master dataset after pre-processing, which will be used all throughout the modeling
    to create, formulate, solve and post-process the model.
    """

    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    original_cluster_labels = StringColumn()
    opti_item_scope_cluster = StringColumn()
    final_cluster_labels = StringColumn()
    n_stores = IntegerColumn()
    cluster_labels_based_on = StringColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    fixture_desc = StringColumn()
    representative_store_nbr = IntegerColumn()
    item_no_nbr = IntegerColumn()
    need_state_unique_id = StringColumn()
    cdt = StringColumn()
    clone_pct = FloatColumn()
    seg_dsc = StringColumn()
    subcat_dsc = StringColumn()

    # SKU or POG Data
    is_net_new_sku = IntegerColumn()
    disc_item = IntegerColumn()
    is_fake_new_sku = IntegerColumn()
    item_no_desc = StringColumn()
    n_space_prod_fit_facings_0 = FloatColumn()
    n_space_prod_fit_facings_1 = FloatColumn()
    n_space_prod_fit_facings_2 = FloatColumn()
    n_space_prod_fit_facings_3 = FloatColumn()
    n_space_prod_fit_facings_4 = FloatColumn()
    n_space_prod_fit_facings_5 = FloatColumn()
    n_space_prod_fit_facings_6 = FloatColumn()
    n_space_prod_fit_facings_7 = FloatColumn()
    n_space_prod_fit_facings_8 = FloatColumn()
    n_space_prod_fit_facings_9 = FloatColumn()
    n_space_prod_fit_facings_10 = FloatColumn()
    n_space_prod_fit_facings_11 = FloatColumn()
    n_space_prod_fit_facings_12 = FloatColumn()
    n_space_prod_fit_facings_13 = FloatColumn()
    n_space_prod_fit_facings_14 = FloatColumn()
    n_space_prod_fit_facings_15 = FloatColumn()
    n_space_prod_fit_facings_16 = FloatColumn()
    n_space_prod_fit_facings_17 = FloatColumn()
    dnp_mltp = FloatColumn()
    sales_mltp = FloatColumn()
    dnp_ratio = FloatColumn()
    
    # BOH penalty metric metric
    n_boh_facings_0 = FloatColumn()
    n_boh_facings_1 = FloatColumn()
    n_boh_facings_2 = FloatColumn()
    n_boh_facings_3 = FloatColumn()
    n_boh_facings_4 = FloatColumn()
    n_boh_facings_5 = FloatColumn()
    n_boh_facings_6 = FloatColumn()
    n_boh_facings_7 = FloatColumn()
    n_boh_facings_8 = FloatColumn()
    n_boh_facings_9 = FloatColumn()
    n_boh_facings_10 = FloatColumn()
    n_boh_facings_11 = FloatColumn()
    n_boh_facings_12 = FloatColumn()
    n_boh_facings_13 = FloatColumn()
    n_boh_facings_14 = FloatColumn()
    n_boh_facings_15 = FloatColumn()
    n_boh_facings_16 = FloatColumn()
    n_boh_facings_17 = FloatColumn()
    
    n_total_linear_space_dept_fixture_ft = FloatColumn()
    height_space_dept_fixture_ft = FloatColumn()
    depth_space_dept_fixture_ft = FloatColumn()
    n_total_linear_space_dept_fixture_ft_for_own_brand = FloatColumn()
    n_current_linear_space_used_sku = FloatColumn()
    n_current_facings_sku = IntegerColumn()
    n_transference_sku = FloatColumn()
    n_facings_config_percentile_dept = IntegerColumn()
    n_current_linear_space_per_facing_sku = FloatColumn()
    prod_unit_height_ft = FloatColumn()
    prod_unit_depth_ft = FloatColumn()
    orientation = StringColumn()

    # Sets or Constraints Data
    brand_name = StringColumn()
    supplier_name = StringColumn()
    private_label_ind = IntegerColumn()
    include_in_optimizer_choices = IntegerColumn()
    saturation_facings = IntegerColumn()

    # temp
    boh_param_a = FloatColumn()
    boh_param_b = FloatColumn()
    clone_item_item_no_nbr = FloatColumn()
    dnp_component_allowance_coupon_co_op = FloatColumn()
    dnp_component_cost = FloatColumn()
    dnp_component_cost_purchases = FloatColumn()
    dnp_component_fixed = FloatColumn()
    dnp_component_tot_dnp_amt = FloatColumn()
    dnp_component_total_sales = FloatColumn()
    dnp_component_units_sold = FloatColumn()
    elasticity_override_granularity = StringColumn()
    is_elasticity_overridden = IntegerColumn()
    n_dnp_facing_0 = FloatColumn()
    n_dnp_facing_1 = FloatColumn()
    n_dnp_facing_10 = FloatColumn()
    n_dnp_facing_11 = FloatColumn()
    n_dnp_facing_12 = FloatColumn()
    n_dnp_facing_13 = FloatColumn()
    n_dnp_facing_14 = FloatColumn()
    n_dnp_facing_15 = FloatColumn()
    n_dnp_facing_16 = FloatColumn()
    n_dnp_facing_17 = FloatColumn()
    n_dnp_facing_2 = FloatColumn()
    n_dnp_facing_3 = FloatColumn()
    n_dnp_facing_4 = FloatColumn()
    n_dnp_facing_5 = FloatColumn()
    n_dnp_facing_6 = FloatColumn()
    n_dnp_facing_7 = FloatColumn()
    n_dnp_facing_8 = FloatColumn()
    n_dnp_facing_9 = FloatColumn()
    n_sales_facing_0 = FloatColumn()
    n_sales_facing_1 = FloatColumn()
    n_sales_facing_10 = FloatColumn()
    n_sales_facing_11 = FloatColumn()
    n_sales_facing_12 = FloatColumn()
    n_sales_facing_13 = FloatColumn()
    n_sales_facing_14 = FloatColumn()
    n_sales_facing_15 = FloatColumn()
    n_sales_facing_16 = FloatColumn()
    n_sales_facing_17 = FloatColumn()
    n_sales_facing_2 = FloatColumn()
    n_sales_facing_3 = FloatColumn()
    n_sales_facing_4 = FloatColumn()
    n_sales_facing_5 = FloatColumn()
    n_sales_facing_6 = FloatColumn()
    n_sales_facing_7 = FloatColumn()
    n_sales_facing_8 = FloatColumn()
    n_sales_facing_9 = FloatColumn()
    original_dnp_ratio = FloatColumn()
    prod_unit_width_ft = FloatColumn()
    source = StringColumn()
    unit_price = FloatColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    # DC data
    dc_id = StringColumn()
    total_stores_in_dc = IntegerColumn()
    stores_in_dc_per_cluster_plano = IntegerColumn()
    # Penalty for removal
    removal_penalty = FloatColumn()



class OptimizationMasterModelingInputWCategoryLevel(OptimizationMasterModelingInput):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OriginalClusterItemNoIOHCurves(Schema):
    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    original_cluster_labels = StringColumn()
    item_no_nbr = IntegerColumn()

    # working capital constraint columns
    item_no_avg_ioh_facings_0 = FloatColumn()
    item_no_avg_ioh_facings_1 = FloatColumn()
    item_no_avg_ioh_facings_2 = FloatColumn()
    item_no_avg_ioh_facings_3 = FloatColumn()
    item_no_avg_ioh_facings_4 = FloatColumn()
    item_no_avg_ioh_facings_5 = FloatColumn()
    item_no_avg_ioh_facings_6 = FloatColumn()
    item_no_avg_ioh_facings_7 = FloatColumn()
    item_no_avg_ioh_facings_8 = FloatColumn()
    item_no_avg_ioh_facings_9 = FloatColumn()
    item_no_avg_ioh_facings_10 = FloatColumn()
    item_no_avg_ioh_facings_11 = FloatColumn()
    item_no_avg_ioh_facings_12 = FloatColumn()


class OriginalClusterItemNoIOHCurvesWCategoryLevel(OriginalClusterItemNoIOHCurves):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationMasterModelingOutput(OptimizationMasterModelingInput):
    # Identifiers
    is_regional_cluster = IntegerColumn()
    is_regional_item = IntegerColumn()

    # Optimal Results Data
    n_optimal_facings_sku = IntegerColumn()
    n_optimal_linear_space_used_sku = FloatColumn()
    n_optimal_space_productivity = FloatColumn()
    n_current_space_productivity = FloatColumn()
    is_problem_infeasible = BoolColumn()

    # item POD specific
    n_stores_item_no_forced_exist = IntegerColumn()
    n_stores_item_no_exist_after_forced_drop = IntegerColumn()
    n_stores_cluster_total = IntegerColumn()
    n_stores_item_no_exist_total = IntegerColumn()
    POD_enforce = StringColumn()
    POD_feasible = IntegerColumn()
    min_POD = FloatColumn()
    max_POD = FloatColumn()
    min_POD_active = IntegerColumn()
    max_POD_active = IntegerColumn()

    # SKU or POG Data
    is_discontinued_sku = IntegerColumn()

    # Sets or Constraints Data
    n_stores_brand_forced_exist = IntegerColumn()
    n_stores_brand_exist_after_forced_drop = IntegerColumn()
    brand_POD_enforce = StringColumn()
    brand_POD_feasible = IntegerColumn()
    min_brand_POD = FloatColumn()
    max_brand_POD = FloatColumn()
    min_brand_POD_active = IntegerColumn()
    max_brand_POD_active = IntegerColumn()
    max_facings_per_sku = IntegerColumn()
    pct_space_for_local_items = FloatColumn()
    min_forced_facings_guardrails = IntegerColumn()
    max_forced_facings_guardrails = IntegerColumn()
    n_current_facings_need_state = IntegerColumn()
    n_forced_facings_need_state_not_in_current = IntegerColumn()
    n_forced_facings_all_need_state = IntegerColumn()
    n_current_and_forced_facings_unique_need_state = IntegerColumn()
    n_manually_adjusted_saturation_facings_need_state = IntegerColumn()
    n_facings_middle_current_and_saturation_need_state = IntegerColumn()
    n_min_facings_need_state = IntegerColumn()
    n_max_facings_need_state_before_guardrails = IntegerColumn()
    n_max_facings_need_state = IntegerColumn()
    min_facings_in_need_state_forced_guardrail = IntegerColumn()
    max_facings_in_need_state_forced_guardrail = IntegerColumn()
    max_pct_drop_own_brand_space = FloatColumn()
    min_pct_allocated_from_total_space_to_own_brands = FloatColumn()
    max_pct_allocated_from_total_space_to_own_brands = FloatColumn()
    constraint_type_supplier_or_brand = StringColumn()
    lower_bound_constraint_supplier_or_brand = FloatColumn()
    upper_bound_constraint_supplier_or_brand = FloatColumn()
    unique_linked_item_no_nbrs = StringColumn()

    # Variable Indices
    items_all_idx = IntegerColumn()
    need_states_idx = IntegerColumn()
    supplier_idx = IntegerColumn()
    brand_idx = IntegerColumn()

    x_ifcg = StringColumn()
    x_ifcg_optimal_value = FloatColumn()
    optimal_objective_value = FloatColumn()
    optimal_objective_value_contribution = FloatColumn()


class OptimizationMasterModelingOutputWithSlackVariables(
    OptimizationMasterModelingOutput
):
    # Label for slack variables for minimum need states constraint
    slack_min_ns_vars = StringColumn()
    # Optimal value for slack variables for minimum need states constraint
    # TODO: Debug where this value comes from
    # slack_min_ns_vars_optimal_value = FloatColumn()


class OptimizationMasterModelingOutputWithCategoryLevel(OptimizationMasterModelingOutput):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationFinancialProjectionsClusterNeedState(Schema):
    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    final_cluster_labels = StringColumn()
    store_nbr = IntegerColumn()
    representative_store_nbr = IntegerColumn()
    need_state_unique_id = StringColumn()

    # Aggregated Financial Projections
    n_current_facings_cluster_ns = IntegerColumn()
    n_optimal_facings_cluster_ns = IntegerColumn()
    n_current_linear_space_used_cluster_ns = FloatColumn()
    n_optimal_linear_space_used_cluster_ns = FloatColumn()
    n_current_space_productivity_sales_cluster_ns = FloatColumn()
    n_optimal_space_productivity_sales_cluster_ns = FloatColumn()
    n_incremental_pct_space_productivity_sales_cluster_ns = FloatColumn()
    n_adjusted_current_space_productivity_sales_cluster_ns = FloatColumn()
    n_adjusted_optimal_space_productivity_sales_cluster_ns = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_sales_cluster_ns = FloatColumn()
    n_current_space_productivity_units_cluster_ns = FloatColumn()
    n_optimal_space_productivity_units_cluster_ns = FloatColumn()
    n_incremental_pct_space_productivity_units_cluster_ns = FloatColumn()
    n_adjusted_current_space_productivity_units_cluster_ns = FloatColumn()
    n_adjusted_optimal_space_productivity_units_cluster_ns = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_units_cluster_ns = FloatColumn()
    n_current_space_productivity_dnp_cluster_ns = FloatColumn()
    n_optimal_space_productivity_dnp_cluster_ns = FloatColumn()
    n_incremental_pct_space_productivity_dnp_cluster_ns = FloatColumn()
    n_adjusted_current_space_productivity_dnp_cluster_ns = FloatColumn()
    n_adjusted_optimal_space_productivity_dnp_cluster_ns = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_dnp_cluster_ns = FloatColumn()
    n_unique_skus_with_current_facings_cluster_ns = IntegerColumn()
    n_unique_brands_with_current_facings_cluster_ns = IntegerColumn()
    n_unique_suppliers_with_current_facings_cluster_ns = IntegerColumn()
    n_own_brand_share_with_current_facings_cluster_ns = FloatColumn()
    n_unique_skus_with_optimal_facings_cluster_ns = IntegerColumn()
    n_unique_brands_with_optimal_facings_cluster_ns = IntegerColumn()
    n_unique_suppliers_with_optimal_facings_cluster_ns = IntegerColumn()
    n_own_brand_share_with_optimal_facings_cluster_ns = FloatColumn()


class OptimizationFinancialProjectionsClusterNeedStateWithCategoryLevel(
    OptimizationFinancialProjectionsClusterNeedState
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationFinancialProjectionsClusterOnly(Schema):
    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    final_cluster_labels = StringColumn()
    store_nbr = IntegerColumn()
    representative_store_nbr = IntegerColumn()

    # Aggregated Financial Projections
    n_current_facings_cluster_only = IntegerColumn()
    n_optimal_facings_cluster_only = IntegerColumn()
    n_current_linear_space_used_cluster_only = FloatColumn()
    n_optimal_linear_space_used_cluster_only = FloatColumn()
    n_current_space_productivity_sales_cluster_only = FloatColumn()
    n_optimal_space_productivity_sales_cluster_only = FloatColumn()
    n_incremental_pct_space_productivity_sales_cluster_only = FloatColumn()
    n_adjusted_current_space_productivity_sales_cluster_only = FloatColumn()
    n_adjusted_optimal_space_productivity_sales_cluster_only = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_sales_cluster_only = FloatColumn()
    n_current_space_productivity_units_cluster_only = FloatColumn()
    n_optimal_space_productivity_units_cluster_only = FloatColumn()
    n_incremental_pct_space_productivity_units_cluster_only = FloatColumn()
    n_adjusted_current_space_productivity_units_cluster_only = FloatColumn()
    n_adjusted_optimal_space_productivity_units_cluster_only = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_units_cluster_only = FloatColumn()
    n_current_space_productivity_dnp_cluster_only = FloatColumn()
    n_optimal_space_productivity_dnp_cluster_only = FloatColumn()
    n_incremental_pct_space_productivity_dnp_cluster_only = FloatColumn()
    n_adjusted_current_space_productivity_dnp_cluster_only = FloatColumn()
    n_adjusted_optimal_space_productivity_dnp_cluster_only = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_dnp_cluster_only = FloatColumn()
    n_unique_skus_with_current_facings_cluster_only = IntegerColumn()
    n_unique_brands_with_current_facings_cluster_only = IntegerColumn()
    n_unique_suppliers_with_current_facings_cluster_only = IntegerColumn()
    n_own_brand_share_with_current_facings_cluster_only = FloatColumn()
    n_unique_skus_with_optimal_facings_cluster_only = IntegerColumn()
    n_unique_brands_with_optimal_facings_cluster_only = IntegerColumn()
    n_unique_suppliers_with_optimal_facings_cluster_only = IntegerColumn()
    n_own_brand_share_with_optimal_facings_cluster_only = FloatColumn()


class OptimizationFinancialProjectionsClusterOnlyWithCategoryLevel(
    OptimizationFinancialProjectionsClusterOnly
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationFinancialImpactPerStore(Schema):
    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    final_cluster_labels = StringColumn()
    representative_store_nbr = IntegerColumn()
    store_nbr = IntegerColumn()

    # Aggregated Financial Projections
    n_incremental_pct_space_productivity_sales_store = FloatColumn()
    n_incremental_pct_space_productivity_units_store = FloatColumn()
    n_incremental_pct_space_productivity_dnp_store = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_sales_store = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_units_store = FloatColumn()
    n_adjusted_incremental_pct_space_productivity_dnp_store = FloatColumn()

    # Real financial impact
    sum_allocated_sales = FloatColumn()
    sum_allocated_units = FloatColumn()
    sum_allocated_dnp = FloatColumn()
    n_incremental_sales_generated = FloatColumn()
    n_incremental_units_generated = FloatColumn()
    n_incremental_dnp_generated = FloatColumn()
    n_adjusted_incremental_sales_generated = FloatColumn()
    n_adjusted_incremental_units_generated = FloatColumn()
    n_adjusted_incremental_dnp_generated = FloatColumn()


class OptimizationFinancialImpactPerStoreWithCategoryLevel(
    OptimizationFinancialImpactPerStore
):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()


class OptimizationMasterModelingCollapsingInput(Schema):
    # Identifiers
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    final_cluster_labels = StringColumn()
    plano_ft = IntegerColumn()
    fixture_size = FloatColumn()
    plano_id = StringColumn()
    item_no_nbr = IntegerColumn()
    need_state_unique_id = StringColumn()
    representative_store_nbr = IntegerColumn()
    brand_name = StringColumn()
    supplier_name = StringColumn()

    # SKU or POG Data
    item_no_desc = StringColumn()
    n_current_linear_space_used_sku = FloatColumn()
    n_current_facings_sku = IntegerColumn()
    n_current_linear_space_per_facing_sku = FloatColumn()

    # Sets or Constraints Data
    private_label_ind = IntegerColumn()
    is_net_new_sku = IntegerColumn()
    is_discontinued_sku = IntegerColumn()
    is_fake_new_sku = IntegerColumn()

    # Optimal Results Data
    n_optimal_facings_sku = IntegerColumn()
    n_optimal_linear_space_used_sku = FloatColumn()


class OptimizationMasterModelingCollapsingOutput(
    OptimizationMasterModelingCollapsingInput
):
    # Collapsing Info
    is_collapsed = IntegerColumn()
    is_collapsed_target = IntegerColumn()
    final_cluster_labels_before_collapsing = StringColumn()
    collapsed_overlap_ratio = FloatColumn()
    operational_cluster_labels = StringColumn()


class OrientationMapping(Schema):
    """
    Contains the mapping of the orientation with equivalent item dimensions (width, height, depth) mapping
    """

    orientation = StringColumn()
    equivalent_width_dimension = StringColumn()
    equivalent_height_dimension = StringColumn()
    equivalent_depth_dimension = StringColumn()


class DCStoreMapping(Schema):
    """
    Contains mapping between distribution centers and stores
    """
    dc_id = StringColumn()
    store_nbr = IntegerColumn()


class RemovalPenalty(Schema):
    """
    Contains removal penalty at SKU level
    """
    item_no_nbr = IntegerColumn()
    removal_penalty = FloatColumn()
