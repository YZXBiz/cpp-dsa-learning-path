"""
Schemas are the interfaces that define how a file or data is expected to look like.

You can use a schema as `SampleSchema.load("path/to/file.csv")` to read in
a DataFrame and automatically validate that it matches the schema defined.
"""
from oxygen.files.schemas import (
    BoolColumn,
    FloatColumn,
    IntegerColumn,
    Schema,
    StringColumn,
)


# class NewItemRawInput(Schema):
#     cluster = StringColumn()
#     item_no_nbr = IntegerColumn()
#     old_item_item_no_nbr = IntegerColumn()
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     old_item_item_code_nbr = IntegerColumn()
#     item_code_nbr = IntegerColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     dept_id = IntegerColumn()
#     item_no_desc = StringColumn()
#     prod_cat_id = IntegerColumn()
#     prod_cat_name = StringColumn()
#     brand_name = StringColumn()
#     supplier_name = StringColumn()
#     item_cost = FloatColumn()
#     item_price = FloatColumn()
#     clone_pct = FloatColumn()
#     original_clone_pct = FloatColumn()
#     private_label_ind = IntegerColumn()
#     n_current_linear_space_per_facing_sku = FloatColumn()
#     prod_unit_width_ft = FloatColumn()
#     prod_unit_height_ft = FloatColumn()
#     prod_unit_depth_ft = FloatColumn()
#     clone_type = StringColumn()


# class DropItemRawInput(Schema):
#     cluster = StringColumn()
#     item_code_nbr = IntegerColumn()
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     chainwide_or_deptwide = StringColumn()
#     item_no_nbr = IntegerColumn()
#     private_label_ind = IntegerColumn()
#     dept_id = IntegerColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     min_forced_facings_guardrails = IntegerColumn()
#     max_forced_facings_guardrails = IntegerColumn()


class NewItemNeedStateOverride(Schema):
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    item_no_nbr = IntegerColumn()
    need_state_override = StringColumn()


# class MacroSpaceInput(Schema):
#     store_nbr = IntegerColumn()  # this is needed
#     dept_id = IntegerColumn()  # this is needed
#     dept_id_replaced = IntegerColumn()
#     plano_id = StringColumn()
#     plano_id_replaced = StringColumn()
#     current_plano_ft = IntegerColumn()
#     current_fixture_desc = StringColumn()
#     optimal_plano_ft = IntegerColumn()  # this is needed
#     plano_ft_change = IntegerColumn()
#     current_total_linear_ft = FloatColumn()
#     current_plano_ft_replaced = IntegerColumn()
#     current_fixture_desc_replaced = StringColumn()
#     optimal_plano_ft_replaced = IntegerColumn()
#     plano_ft_change_replaced = IntegerColumn()
#     current_total_linear_ft_replaced = FloatColumn()
#     addtl_linear_ft_gained = FloatColumn()  # this is needed


# class PlanoLinearSpaceFromSpaceData(Schema):
#     store_nbr = IntegerColumn()
#     dept_id = IntegerColumn()
#     plano_id = StringColumn()
#     plano_ft = IntegerColumn()
#     fixture_desc = StringColumn()
#     current_total_linear_ft = FloatColumn()


# class MacroSpaceMoveSchema(Schema):
#     store_nbr = IntegerColumn(source="STORES")
#     dept_id = IntegerColumn(source="DEPARTMENT")
#     current_plano_ft = IntegerColumn(source="CURRENT_FOOTAGE")
#     current_productivity = FloatColumn(source="CURRENT_BENEFIT")
#     optimal_plano_ft = IntegerColumn(source="OPTIMAL_FOOTAGE")
#     optimal_productivity = FloatColumn(source="OPTIMAL_BENEFIT")
#     plano_ft_change = IntegerColumn(source="FOOTAGE_CHANGE")
#     productivity_change = FloatColumn(source="BENEFIT_CHANGE")
#     plano_id = StringColumn(source="Planogram ID#")


# class CaetgoryLevelPlanoDeptInSchema(Schema):
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     dept_id = IntegerColumn()


# class ItemRawPODInputSchema(Schema):
#     dept_id = IntegerColumn(source="dept_id")
#     item_no_nbr = IntegerColumn(source="item_no_nbr")
#     min_POD = FloatColumn(source="min_forced_POD")
#     max_POD = FloatColumn(source="max_forced_POD")


# class ItemPlanoFtForcedFacingsRawSchema(Schema):
#     dept_id = IntegerColumn()
#     item_no_nbr = IntegerColumn()
#     plano_ft = IntegerColumn()
#     min_forced_facings_guardrails = IntegerColumn()
#     max_forced_facings_guardrails = IntegerColumn()


# class BrandRawPODInputSchema(Schema):
#     dept_id = IntegerColumn(source="dept_id")
#     brand_name = StringColumn(source="brand_name")
#     min_brand_POD = FloatColumn(source="min_forced_POD")
#     max_brand_POD = FloatColumn(source="max_forced_POD")


# class OriginalClusterIOHInputSchema(Schema):
#     dept_id = IntegerColumn(source="dept_id")
#     cluster_granularity = StringColumn(source="cluster_granularity")
#     cluster_labels = StringColumn(source="cluster_labels")
#     min_IOH_percent = FloatColumn(source="min_IOH_percent")
#     max_IOH_percent = FloatColumn(source="max_IOH_percent")


# class ItemExcludeFromPODConstraintsSchema(Schema):
#     category_level_dept_nbr = IntegerColumn(source="category_level_dept_nbr")
#     category_level_dept_name = StringColumn(source="category_level_dept_name")
#     cluster = StringColumn(source="cluster_labels")
#     plano_cat_id = IntegerColumn(source="plano_cat_id")
#     plano_cat_desc = StringColumn(source="plano_cat_desc")
#     dept_id = IntegerColumn(source="dept_id")
#     item_no_nbr = IntegerColumn(source="item_no_nbr")


# class BrandPODConstraintsSchema(Schema):
#     category_level_dept_nbr = IntegerColumn(source="category_level_dept_nbr")
#     category_level_dept_name = StringColumn(source="category_level_dept_name")
#     cluster = StringColumn(source="cluster_labels")
#     plano_cat_id = IntegerColumn(source="plano_cat_id")
#     plano_cat_desc = StringColumn(source="plano_cat_desc")
#     dept_id = IntegerColumn(source="dept_id")
#     constraint_type_brand = StringColumn(source="constraint_type_brand")
#     brand_name = StringColumn(source="brand_name")
#     lower_bound_constraint_brand = FloatColumn(source="lower_bound_constraint_brand")
#     upper_bound_constraint_brand = FloatColumn(source="upper_bound_constraint_brand")


class ItemPODConstraintsAdded(Schema):
    dept_id = IntegerColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    item_no_nbr = IntegerColumn()
    POD_enforce = StringColumn()
    is_regional_item = IntegerColumn()
    min_POD = FloatColumn()
    max_POD = FloatColumn()
    n_stores_item_no_exist_total = IntegerColumn()
    n_stores_item_no_forced_exist = IntegerColumn()
    n_stores_item_no_exist_after_forced_drop = IntegerColumn()
    POD_feasible = IntegerColumn()
    min_POD_active = IntegerColumn()
    max_POD_active = IntegerColumn()


# class ItemInScopeSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     dept_id = IntegerColumn()


# class ItemInScopeWithCloneSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     dept_id = IntegerColumn()
#     clone_item_item_no_nbr = IntegerColumn(source="old_item_item_no_nbr")


class ItemInScopeWithHierarchySchema(Schema):
    item_no_nbr = IntegerColumn()
    item_no_desc = StringColumn()
    source = StringColumn()
    clone_item_item_no_nbr = IntegerColumn()
    # clone_item_item_no_nbr_source = StringColumn()
    clone_type = StringColumn()
    clone_pct = FloatColumn()
    need_state = StringColumn()
    need_state_unique_id = StringColumn()
    need_state_override = StringColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    brand_name = StringColumn()
    vendor_name = StringColumn()
    vendor_number = StringColumn()
    prod_cat_name = StringColumn()
    private_label_ind = IntegerColumn()
    n_current_linear_space_per_facing_sku = FloatColumn()
    prod_unit_width_ft = FloatColumn()
    prod_unit_height_ft = FloatColumn()
    prod_unit_depth_ft = FloatColumn()


# class ItemInScopePerClusterSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     item_no_desc = StringColumn()
#     brand_name = StringColumn()
#     vendor_name = StringColumn()
#     private_label_ind = IntegerColumn()
#     source = StringColumn()
#     clone_item_item_no_nbr = IntegerColumn()
#     clone_type = StringColumn()
#     clone_pct = FloatColumn()
#     need_state = StringColumn()
#     need_state_unique_id = StringColumn()
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     dept_id = IntegerColumn()
#     opti_item_scope_cluster = StringColumn()
#     final_cluster_labels = StringColumn()


# class OptInputSkeletonSchema(Schema):
#     """
#     This schema is used to create the skeleton for the optimization input.
#     """
#
#     item_no_nbr = IntegerColumn()
#     item_no_desc = StringColumn()  # only for display
#     brand_name = StringColumn()  # brand_idx
#     vendor_name = StringColumn()  # supplier_idx
#     source = StringColumn()
#     clone_item_item_no_nbr = IntegerColumn()
#     clone_type = StringColumn()
#     need_state_unique_id = StringColumn()  # need_states_idx
#     category_level_dept_nbr = IntegerColumn()
#     category_level_dept_name = StringColumn()
#     plano_cat_id = IntegerColumn()
#     plano_cat_desc = StringColumn()
#     dept_id = IntegerColumn()
#     opti_item_scope_cluster = StringColumn()
#     final_cluster_labels = StringColumn()  # cluster_idx
#     plano_ft = IntegerColumn()  # plano_fixture_idx
#     fixture_size = StringColumn()  # plano_fixture_idx
#     median_total_linear_space_dept_fixture_ft = FloatColumn()


class ItemInScopePerClusterFilteredSchema(Schema):
    item_no_nbr = IntegerColumn()
    item_no_desc = StringColumn()
    brand_name = StringColumn()
    vendor_name = StringColumn()
    vendor_number = StringColumn()
    seg_dsc = StringColumn()
    subcat_dsc = StringColumn()
    private_label_ind = IntegerColumn()
    source = StringColumn()
    disc_item = IntegerColumn()
    clone_item_item_no_nbr = IntegerColumn()
    clone_pct = FloatColumn()
    need_state_unique_id = StringColumn()
    cdt = StringColumn()
    fixture_desc = StringColumn()
    category_level_dept_nbr = IntegerColumn()
    category_level_dept_name = StringColumn()
    plano_id = StringColumn()
    plano_cat_id = IntegerColumn()
    plano_cat_desc = StringColumn()
    dept_id = IntegerColumn()
    opti_item_scope_cluster = StringColumn()
    final_cluster_labels = StringColumn()


# class NewItemInfoSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     clone_item_item_no_nbr = IntegerColumn(source="old_item_item_no_nbr")
#     dept_id = IntegerColumn()
#     clone_pct = FloatColumn()
#     n_current_linear_space_per_facing_sku = FloatColumn()  # item width
#     prod_unit_width_ft = FloatColumn()
#     prod_unit_height_ft = FloatColumn()
#     prod_unit_depth_ft = FloatColumn()
#
#
# class DnpRatioAdjustmentSchema(Schema):
#     item_no_nbr = IntegerColumn()
#     dnp_ratio_adjustment = FloatColumn()  # Required adjustment of DNP ratio
#     # Add it to raw DNP ratio or multiply it with sales to calculate the adjustment amount of DNP
