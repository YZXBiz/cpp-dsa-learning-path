set week_nbr_start = 202431;
set week_nbr_end = 202530;

CREATE OR REPLACE TABLE DL_FSCA_SLFSRV.TWA07.C835645_SALES_L52W AS (
    select
    a.sku_nbr,
    a.store_nbr,
    a.cat_dsc,
    a.subcat_dsc,
    a.seg_dsc,
    a.state_cd,
    a.str_actv_flg,
    a.sku_status,
    b.facility_typ_dsc,
    c.sku_dsc,
    b.retail_sq_ft,
    sum(units_sold) as total_units_sold,
    sum(tot_scan_sales) as total_sales,
    sum(units_sold * unit_cost_price) as total_cost,
    sum(tot_scan_sales) - sum(units_sold * unit_cost_price) as total_margin
    from
    app_merch.prod_promo.wkly_sku_str_features a
    left join CORE_FSSC.CURATED_LOCATION.STORE_MASTER b on a.store_nbr = b.str_nbr
    left join CORE_FSSC.CURATED_PRODUCT.SKU c using (sku_nbr)
    where
    coalesce(ad_rgn_cd, 'NA') NOT IN ('F', 'W', '999')
    and fiscal_week_nbr >= 202431
    and fiscal_week_nbr <= 202530
    group by
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11
    );