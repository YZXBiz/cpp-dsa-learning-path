CREATE OR REPLACE TABLE DL_FSCA_SLFSRV.TWA07.C835645_LOCALIZATION_POG_MASTER_TABLE_8000_0829_FULL_SCOPE AS
with plano_max_load as (
    SELECT
        PLANOGRAM_NBR,
        MAX(LOAD_DT) AS LOAD_DT
    FROM
        CORE_FSSC.CURATED_VISUAL.PLANOGRAM_VERSION_HISTORY
    WHERE
        LOAD_DT <= '2025-08-29'
    GROUP BY
        PLANOGRAM_NBR
),
store_scope as (
    SELECT 
        planogram_nbr,
        planogram_version_id
    FROM 
        DL_FSCA_SLFSRV.TWA07.C872080_template_in_scope
    WHERE 
        optimized_version = 'Yes'
),
pog_data as (
    select
        planogram_nbr,
        planogram_version_id,
        planogram_version_dsc,
        fixture_width_nbr,
        fixture_height_nbr,
        planogram_dsc,
        planogram_type_cd,
        max (
            case
                when version_characteristics_1_dsc = 'INC' then 1
                when version_characteristics_2_dsc = 'INC' then 1
                when version_characteristics_3_dsc = 'INC' then 1
                when version_characteristics_4_dsc = 'INC' then 1
                when version_characteristics_5_dsc = 'INC' then 1
                else 0
            end
        ) as inches_indicator
        from CORE_FSSC.CURATED_VISUAL.PLANOGRAM_VERSION_HISTORY
        inner join plano_max_load using (planogram_nbr, load_dt)
        inner join store_scope using (planogram_nbr, planogram_version_id)
    where
        1 = 1 
        and store_cnt_nbr > 0
        and planogram_type_cd not in ('P', 'Q', 'L', 'N', 'O', 'M', 'S', 'T')
        and fixture_width_nbr > 0
    group by
        1,
        2,
        3,
        4,
        5,
        6,
        7
    order by
        inches_indicator desc
),
pog_clean as (
    select
        a.planogram_nbr,
        a.planogram_version_id,
        planogram_dsc,
        planogram_version_dsc,
        planogram_type_cd,
        case
            when inches_indicator = 1 then fixture_width_nbr * 0.0833
            else fixture_width_nbr
        end as fixture_width_nbr,
        case
            when inches_indicator = 1 then fixture_height_nbr * 0.0833
            else fixture_height_nbr
        end as fixture_height_nbr,
        plano_cat_dsc,
        plano_mdse_grp_dsc
    from
        pog_data a
        left join DL_FSCA_SLFSRV.TWA07.c830557_POG_CAT_DSC b
        on a.planogram_nbr = b.planogram_nbr - 1000
),
pog_clean_adj as (
    select
        planogram_nbr,
        planogram_version_id,
        planogram_dsc,
        planogram_version_dsc,
        planogram_type_cd,
        plano_cat_dsc,
        plano_mdse_grp_dsc,
        fixture_height_nbr,
        fixture_width_nbr
    from
        pog_clean
),
plano_cat_map as (
    select distinct
        planogram_nbr,
        cat_nbr
        from DL_FSCA_SLFSRV.TWA07.C835645_LOCALIZATION_POG_MASTER_TABLE_8000_0829_FULL_SCOPE
    union
    select 7123 as planogram_nbr, 80 as cat_nbr
    union
    select 9033 as planogram_nbr, 10 as cat_nbr
),
store_sales as (
    select *
    FROM DL_FSCA_SLFSRV.TWA07.C835645_SALES_L52W
),
pog_items as (
    select
        planogram_nbr,
        planogram_version_id,
        sku_nbr,
        sum(horizontal_facings_nbr) as horizontal_facings_nbr,
        sum(vertical_facings_nbr) as vertical_facings_nbr
        from CORE_FSSC.CURATED_VISUAL.PLANOGRAM_SKU_HISTORY
        inner join plano_max_load using (planogram_nbr, load_dt)
        inner join store_scope using (planogram_nbr, planogram_version_id)
    group by
        1,
        2,
        3
),
master_data as (
    select
        distinct a.planogram_nbr,
        a.planogram_version_id,
        plano_cat_dsc,
        plano_mdse_grp_dsc,
        planogram_type_cd,
        STORE_NBR,
        SKU_NBR,
        STORE_AISLE_NBR,
        STORE_AISLE_SEQ_NBR,
        PLANOGRAM_VERSION_DSC,
        planogram_dsc,
        FIXTURE_WIDTH_NBR,
        FIXTURE_HEIGHT_NBR,
        HORIZONTAL_FACINGS_NBR,
        VERTICAL_FACINGS_NBR,
        CAT_NBR
    from
        CORE_FSSC.CURATED_VISUAL.PLANOGRAM_STORE_HISTORY a
        inner join pog_clean_adj b using (planogram_nbr, planogram_version_id)
        inner join pog_items c using (planogram_nbr, planogram_version_id)
        inner join plano_max_load using (planogram_nbr, load_dt)
        left join plano_cat_map pm using(planogram_nbr)
),
double_homed_items as (
    select
        store_nbr,
        sku_nbr,
        count(distinct planogram_nbr, planogram_version_id) as pog_counts,
        sum(HORIZONTAL_FACINGS_NBR * VERTICAL_FACINGS_NBR) as total_facings
    from
        master_data
    group by
        1,
        2
    having
        pog_counts > 1
),
master_data2 as (
    select
        a.*,
        s.cat_dsc,
        s.subcat_dsc,
        s.seg_dsc,
        s.sku_status,
        case
            when pog_counts is null then total_sales
            else total_sales *(
                (HORIZONTAL_FACINGS_NBR * VERTICAL_FACINGS_NBR) / total_facings
            )
        end as total_sales
    from
        master_data a
        left join store_sales b using (store_nbr, sku_nbr)
        left join double_homed_items c using (store_nbr, sku_nbr)
        left join CORE_FS.CURATED_PRODUCT.SKU s using(sku_nbr)
)
select
    *
from
    master_data2
where
    planogram_nbr > 8000
    AND planogram_nbr < 9000;
;