from oxygen.commands.cli import cli


@cli.command()
def core_sample():
    """Example of how you can add a command to the CLI"""
