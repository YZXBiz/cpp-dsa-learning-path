#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Test main functions in acquire data module.
    1. Create dummy parquet file
    2. Test different functions in the module
    3. Delete data after success / failed run
"""

import os

import pandas as pd
import pytest

# from core.tasks.data_acquisition.acquire_data import AcquireDataTask
from oxygen.files.readers import reader
from oxygen.files.storages import storage
import logging

_logger = logging.getLogger(__name__)


@pytest.fixture(scope="function")
def setup_io(request):
    """Environment Prep
        function: Run once per test, class: Run once per class of tests
        module: Run once per module, session: Run once per session
        The default is 'function'.
    Ref:
    https://pythontesting.net/framework/pytest/pytest-fixtures-nuts-bolts/#finalizer

    Args:
     request: You need the request parameter to a fixture to add a finaliser.
    """

    # Names of different input files for different test cases
    # Add as many test cases

    # Set-up Environment Variables
    path_test_raw = "tmp/promo_test"

    def create_inputs():
        """Creates main promo input"""

        # Delete test input directory if it exists
        if storage.exists(path_test_raw):
            _logger.info("Input Path Exists, Deleting existing files")
            all_files = storage._list_all(path_test_raw)
            all_files = sorted(
                all_files,
                key=lambda file: (os.path.dirname(file), os.path.basename(file)),
                reverse=True,
            )

            for file in all_files:
                storage.rm(file, recursive=True)

        promo_input = {
            "SPOT_SEQ_NUMBER": [
                22518667,
                22518667,
                22518667,
                22518667,
                22518667,
                22518667,
            ],
            "item_no": [100, 100, 101, 101, 102, 102],
            "week_dt": [
                "2000-01-01",
                "2000-01-02",
                "2000-01-01",
                "2000-01-02",
                "2000-01-02",
                "2000-01-03",
            ],
            "decision_zone": ["zone1", "zone1", "zone1", "zone1", "zone1", "zone1"],
            "number_stores": [1000, 1000, 1000, 1000, 1000, 1000],
            "units": [1, 2, 1, 2, 1, 2],
            "sales": [0.99, 1.98, 0.75, 1.50, 2.99, 5.98],
            "base_price": [0.99, 0.99, 1.49, 1.49, 2.99, 2.99],
            "receipt_price": [0.99, 0.99, 0.75, 0.75, 2.99, 2.99],
            "mech_bogolep": [0, 0, 0, 0, 0, 0],
            "mech_per_or_am_off": [0, 0, 0, 0, 0, 0],
            "mech_multi": [0, 0, 0, 0, 0, 0],
            "mech_other": [0, 0, 0, 0, 0, 0],
            "prod_cat_name": ["cat1", "cat1", "cat2", "cat2", "cat3", "cat3"],
            "private_label_ind": ["p1", "p1", "p1", "p1", "p1", "p1"],
            "prod_cat_code": ["1", "1", "2", "2", "3", "3"],
            "category_level_name": ["category_level1", "category_level1", "category_level2", "category_level2", "category_level3", "category_level3"],
            "category_level_code": ["1", "1", "2", "2", "3", "3"],
            "mkt_DSP": [0, 0, 1, 1, 0, 0],
            "mkt_IVC": [0, 0, 1, 1, 0, 0],
            "mkt_ROT": [0, 0, 1, 1, 0, 0],
            "mkt_TLC": [0, 0, 1, 1, 0, 0],
            "mkt_TOC": [0, 0, 1, 1, 0, 0],
            "mkt_XPO": [0, 0, 1, 1, 0, 0],
            "mkt_other": [0, 0, 1, 1, 0, 0],
            "discount": [0, 0, 0.5, 0.5, 0, 0],
            "discount_cann": [0, 0, 0.5, 0.5, 0, 0],
            "discount_pf": [0, 0, 0.5, 0.5, 0, 0],
            "is_page_front": [1, 0, 1, 0, 1, 0],
            "page_percentile_rank": [0, 0, 0, 0, 0, 0],
            "layout_percentile_rank": [0, 0, 0, 0, 0, 0],
            "is_promo": [1, 0, 1, 0, 1, 0],
        }

        promo_input = pd.DataFrame(promo_input)

        reader.write(
            os.path.join(path_test_raw, "test_input.parquet"), promo_input, root=True
        )
        reader.write(
            os.path.join(path_test_raw, "test_input_mult.parquet"),
            promo_input,
            root=True,
            partition_col="week_dt",
        )

        # Make empty test input directory
        _logger.info(f"Input files created in folder: {path_test_raw}")

    def teardown():
        """Acts as a teardown for the fixture to remove artefacts from the test"""
        _logger.info(
            3 * "-" + "Tearing Down Assets: Deleting test generated files" + 3 * "-"
        )
        all_files = storage._list_all(path_test_raw)
        all_files = sorted(
            all_files,
            key=lambda file: (os.path.dirname(file), os.path.basename(file)),
            reverse=True,
        )

        for file in all_files:
            storage.rm(file, recursive=True)

    _logger.info(10 * "-" + " Setting Up Environment " + 10 * "-")
    create_inputs()

    # To run after the tests in this module was finished
    request.addfinalizer(teardown)


@pytest.fixture(scope="function")
def abd_vars():
    """Main parameters in acquire data test"""

    vars = {
        "data_path_single": "tmp/promo_test/test_input.parquet",
        "data_path_multiple": "tmp/promo_test/test_input_mult.parquet",
        "start_date": "2000-01-01",
        "end_date": "2000-01-02",
        "fmt": "parquet",
    }

    return vars


# def test_acquire_boost_data_single_parquet(setup_io, abd_vars):
#     """Test that the inputs are read and filtered as defined in the ingestion step"""

#     input_data = AcquireDataTask().acquire_boost_data(mode='train')

#     # Assert that data shape is correct
#     assert len(input_data.columns) == 32


# def test_acquire_boost_data_multiple_parquet(setup_io, abd_vars):
#     """
#     Test that the inputs are read and filtered as defined in the ingestion step
#     for a partitioned dataset
#     """
#
#     input_data = AcquireDataTask.acquire_boost_data(
#         data_path=abd_vars["data_path_multiple"],
#         fmt=abd_vars["fmt"],
#     )
#
#     # Assert that data shape is correct
#     assert input_data.shape == (6, 31)
