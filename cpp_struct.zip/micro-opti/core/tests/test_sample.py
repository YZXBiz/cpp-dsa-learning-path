import pandas as pd
import pytest


@pytest.fixture
def df_sample():
    df_sample = pd.DataFrame({"item": ["x", "y", "z"], "price": [1, 2, 3]})
    return df_sample


def test_sample(df_sample):
    """
    Sample test case to be used as a reference
    """
    df_expected = pd.DataFrame({"item": ["x", "y", "z"], "price": [1, 2, 3]})
    assert df_expected.equals(df_sample)
