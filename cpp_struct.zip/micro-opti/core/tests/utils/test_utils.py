import pandas as pd
import pytest
from oxygen.files.schemas import (
    Schema,
    StringColumn,
)
from pandas.testing import assert_frame_equal, assert_series_equal

from core.utils.calculations import calculate_discount_pct, calculate_price_change_pct
from core.utils.curves import (
    linear_curve,
    exponential_curve,
    logarithmic_curve,
    negative_exponential_curve,
    reverse_sigmoid_curve,
)
from core.utils.df import (
    cross_join,
    left_anti_join,
    make_list_if_not_list,
    subset_df_from_date_range_list,
    make_date_dense,
    check_matching_key_rows,
)
from core.utils.metrics import (
    bias_score,
    symmetric_mean_absolute_error as smape,
    balanced_mean_absolute_percentage_error as bmape,
)
from core.utils.misc import (
    merge_schema_fields, is_even_number
)


def test_cross_join():
    # Test normal case
    df1 = pd.DataFrame({"a": list("ABC")})
    df2 = pd.DataFrame({"b": list("EF")})
    expected = pd.DataFrame({"a": list("AABBCC"), "b": list("EF") * 3})
    assert_frame_equal(
        expected.sort_values(["a", "b"]).reset_index(drop=True),
        cross_join(df1, df2).sort_values(["a", "b"]).reset_index(drop=True),
    )

    # Test dupe key name
    with pytest.raises(ValueError):
        cross_join(df1, df2, key="a")

    # Test dupe col names
    df2 = pd.DataFrame({"a": list("EF")})
    with pytest.raises(ValueError):
        cross_join(df1, df2)

    # Test zero length
    df1 = pd.DataFrame({"a": []})
    with pytest.raises(ValueError):
        cross_join(df1, df2)

    # Test multiple columns
    df1 = pd.DataFrame({"a": list("AB"), "b": list("XY")})
    df2 = pd.DataFrame({"c": list("EF")})
    expected = pd.DataFrame({"a": list("AABB"), "b": list("XXYY"), "c": list("EFEF")})
    assert_frame_equal(
        expected.sort_values(["a", "b", "c"]).reset_index(drop=True),
        cross_join(df1, df2).sort_values(["a", "b", "c"]).reset_index(drop=True),
    )


def test_left_anti_join():
    # Test normal case
    df1 = pd.DataFrame({"a": [1, 2, 3], "b": [3, 2, 1]})
    df2 = pd.DataFrame(
        {
            "a": [2, 4],
        }
    )

    actual = left_anti_join(df1, df2, "a")
    expected = pd.DataFrame({"a": [1, 3], "b": [3, 1]}, index=[0, 2])

    assert_frame_equal(actual, expected)

    # Test missing key
    with pytest.raises(ValueError):
        left_anti_join(df1, df2, "c")

    # Test same join (should be empty)
    expected = pd.DataFrame(columns=["a", "b_x", "b_y"])
    actual = left_anti_join(df1, df1, "a")
    assert_frame_equal(actual, expected, check_index_type=False, check_dtype=False)


def test_subset_df_from_date_range_list():
    test_df = pd.DataFrame(
        {
            "date": pd.to_datetime(
                ["2020-01-01", "2020-01-02", "2020-01-03", "2020-01-04"]
            ),
        }
    )

    actual_df = subset_df_from_date_range_list(
        df=test_df, date_ranges=[["2020-01-01", "2020-01-02"]], date_var="date"
    )

    expected_rows = 2

    assert actual_df.shape[0] == expected_rows


def test_make_data_dense():
    test_df = pd.DataFrame(
        {
            "sku_id": ["item_1", "item_1", "item_1", "item_1"],
            "date": pd.to_datetime(
                ["2020-01-01", "2020-01-02", "2020-01-03", "2020-01-05"]
            ),
            "volume": [1.0, 1.0, 1.0, 1.0],
        }
    )

    actual_df = make_date_dense(
        df=test_df,
        date_col="date",
        granularity_col=["sku_id"],
        volume_col="volume",
        fill_method="zero",
    )

    expected_df = pd.DataFrame(
        {
            "sku_id": ["item_1", "item_1", "item_1", "item_1", "item_1"],
            "date": pd.to_datetime(
                ["2020-01-01", "2020-01-02", "2020-01-03", "2020-01-04", "2020-01-05"]
            ),
            "volume": [1.0, 1.0, 1.0, 0.0, 1.0],
        }
    )

    assert_frame_equal(
        actual_df.reset_index(drop=True), expected_df.reset_index(drop=True)
    )


def test_calculate_discount_pct():
    # Test base behaviour
    assert calculate_discount_pct(base_price=20, receipt_price=10) == 0.5

    # Tested vectorized behaviour
    df = pd.DataFrame({"a": [20, 40, 40], "b": [15, 20, 10]})

    expected = pd.Series([0.25, 0.50, 0.75])

    actual = df.apply(lambda x: calculate_discount_pct(x["a"], x["b"]), axis=1)

    assert_series_equal(actual, expected, check_dtype=False)


def test_calculate_price_change_pct():
    # Test base behaviour
    assert calculate_price_change_pct(base_price=20, new_price=10) == -0.5

    # Tested vectorized behaviour
    df = pd.DataFrame({"a": [20, 40, 40], "b": [15, 20, 100]})

    expected = pd.Series([-0.25, -0.50, 1.50])

    actual = df.apply(lambda x: calculate_price_change_pct(x["a"], x["b"]), axis=1)

    assert_series_equal(actual, expected, check_dtype=False)

    obj = [1, 2, 3]
    actual = make_list_if_not_list(obj)

    assert obj == actual

    obj = "abc"
    actual = make_list_if_not_list(obj)
    expected = ["abc"]

    assert actual == expected

    obj = pd.DataFrame({"a": [0]})
    actual = make_list_if_not_list(obj)

    assert_frame_equal(obj, actual)


def test_check_matching_key_rows():
    df1 = pd.DataFrame({"a": [1, 2, 3], "b": [3, 2, 1]})
    df2 = pd.DataFrame({"a": [1, 2, 3], "b": [3, 2, 1], "c": [1, 1, 1]})

    # Test basic cases
    check_matching_key_rows(df1, df2, key=["a", "b"])
    check_matching_key_rows(df1, df2.assign(b=["a", "b", "c"]), key="a")

    # Test case when key col is missing
    with pytest.raises(ValueError):
        check_matching_key_rows(df1, df2, key=["a", "c"])

    # Test case when rows are dropped
    with pytest.raises(pd.errors.InvalidIndexError):
        check_matching_key_rows(df1, df2.drop(index=[0]), key=["a", "b"])

    # Test case when key col is modified
    with pytest.raises(pd.errors.InvalidIndexError):
        check_matching_key_rows(df1, df2.assign(a=[1, 2, 2]), key=["a", "b"])

    # Test case when duplicated rows
    with pytest.raises(pd.errors.InvalidIndexError):
        check_matching_key_rows(df1, pd.concat([df2, df2]), key=["a", "b"])

    # Test case where dtype of key columns changes
    with pytest.raises(ValueError):
        check_matching_key_rows(df1, df2.astype(str), key=["a", "b"])


def test_make_list_if_not_list():
    # Test non-transform when list is passed
    obj = [1, 2, 3]
    actual = make_list_if_not_list(obj)

    assert obj == actual

    # Test wrapping when string is passed
    obj = "abc"
    actual = make_list_if_not_list(obj)
    expected = ["abc"]

    assert actual == expected

    # Test no wrapping when df is passed
    obj = pd.DataFrame()
    actual = make_list_if_not_list(obj)
    expected = pd.DataFrame()

    assert_frame_equal(actual, expected)


def test_metrics_bias_score():
    # test bias
    test_y_true = pd.Series([1, 1, 1])
    test_y_pred = pd.Series([2, 2, 2])

    actual_bias = bias_score(test_y_true, test_y_pred)

    expected_bias = 1

    assert actual_bias == expected_bias


def test_smape():
    # test smape
    test_y_true = pd.Series([1, 1, 1])
    test_y_pred = pd.Series([2, 2, 2])

    actual_smape = smape(test_y_true, test_y_pred)

    expected_smape = 0.33

    assert round(actual_smape, 2) == round(expected_smape, 2)


def test_bmape():
    # test bmape
    test_y_true = pd.Series([1, 1, 1])
    test_y_pred = pd.Series([2, 2, 2])

    actual_bmape = bmape(test_y_true, test_y_pred)

    expected_bmape = 0.5

    assert round(actual_bmape, 2) == round(expected_bmape, 2)


def test_get_class_by_name():
    class TestSchemaA(Schema):
        col_a = StringColumn()
        col_b = StringColumn()

    class TestSchemaB(Schema):
        col_c = StringColumn()
        cold_d = StringColumn()

    actual_merge_schemas = merge_schema_fields(TestSchemaA, TestSchemaB)
    expected_len = 4

    # check schemas are merged
    assert len(actual_merge_schemas) == expected_len


# def test_check_is_string():
#     test_string = "test_string"
#     actual_result = check_is_string(test_string)
#
#     expected_result = test_string
#
#     assert actual_result == expected_result
#
#     # failing test case
#     with pytest.raises(AssertionError):
#         check_is_string(1)


# def test_check_is_number():
#     test_number = 5
#     actual_result = check_is_number(test_number)
#
#     expected_result = test_number
#
#     assert actual_result == expected_result
#     # failing test case
#     with pytest.raises(AssertionError):
#         check_is_number("x")


# def test_check_is_dict():
#     test_dict = {"test": "dict"}
#     actual_result = check_is_dict(test_dict)
#
#     expected_result = test_dict
#
#     assert actual_result == expected_result
#     # failing test case
#     with pytest.raises(AssertionError):
#         check_is_dict("x")


# def test_check_is_list():
#     test_list = [1, 2]
#     actual_result = check_is_list(test_list)
#
#     expected_result = test_list
#
#     assert actual_result == expected_result
#
#     # failing test case
#     with pytest.raises(AssertionError):
#         check_is_list("x")


# def test_check_is_df():
#     test_df = pd.DataFrame({"a": list("ABC"), "b": list("ABC")})
#     actual_result = check_is_df(test_df)
#
#     expected_result = test_df
#
#     assert_frame_equal(actual_result, expected_result)
#
#     # failing test case
#     with pytest.raises(AssertionError):
#         check_is_df("x")


def test_is_even_number():
    actual_result = is_even_number(1)

    assert not actual_result
    actual_result = is_even_number(2)

    assert actual_result


def test_curves():
    # test linear cuver
    test_x = 1
    test_a = 1
    test_b = 1

    actual_linear_curve = linear_curve(test_x, test_a, test_b)

    assert actual_linear_curve == 2

    # test exponential curve
    actual_exponential_curve = exponential_curve(test_x, test_a, test_b)

    assert round(actual_exponential_curve, 1) == 7.4

    # test exponential curve
    actual_logarithmic_curve = logarithmic_curve(test_x, test_a, test_b)
    assert round(actual_logarithmic_curve, 1) == 1.1

    # test exponential curve
    actual_negative_exponential_curve = negative_exponential_curve(
        test_x, test_a, test_b
    )
    assert round(actual_negative_exponential_curve, 1) == 1.0

    # test reverse_sigmoid_curve
    actual_reverse_sigmoid_curve = reverse_sigmoid_curve(test_x, test_a, test_b)
    assert round(actual_reverse_sigmoid_curve, 1) == 1.0


# def test_build_nested_dict_dotted_keys():
#     # test compare dict function
#     actual_output = compare_dicts({"a": 1, "b": 2}, {"b": 2, "c": 3})
#
#     assert actual_output[0] == {"a"}
#     assert actual_output[1] == {"c"}
