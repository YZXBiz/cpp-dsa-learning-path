[TOC]
# Model Setup
This documents models the micro optimization problem as is currently formulated in the code.
## Objective Function
 Let
  - $( x_{i,f,c,g} )$: binary variable, 1 if item ( $i$ ) is assigned ( $f$ ) facings in cluster ( $c$ ), plano ( g ), 0 otherwise.
  - $( p_{i,f,c,g} )$: productivity per facing for item ( $i$ ), facing ( $f$ ), cluster ( $c$ ), plano ( $g$ ).
  - $( p^{\text{curr}}_{i,c,g} )$: current productivity for item ( $i$ ), cluster ( $c$ ), plano ( $g$ ).
  - $( t_i )$: transference for item ( $i$ ).
  - $( \mathcal{X} )$: set of all eligible (($i, f, c, g$)).
  - $( \mathcal{Y} )$: set of all eligible (($i, c, g$)).
  - $( \mathcal{F}_i )$: set of possible facings for item ( $i$ ).
  - $( \mathcal{F}_i^+ )$: set of possible facings for item ( $i$ ) excluding 0 (i.e., $(\mathcal{F}_i^+ = \mathcal{F}_i \setminus {0})$).
  - $( S )$: set of all slack variables and their penalties (if enabled).

  Then the objective function can be formulated as:

$$
\begin{aligned}
\max \quad & 
\underbrace{
  \sum_{(i,f,c,g) \in \mathcal{X}} x_{i,f,c,g} \cdot p_{i,f,c,g}
}_{\text{Total productivity of assigned facings}} \\
& - 
\underbrace{
  \sum_{(i,c,g) \in \mathcal{Y}} p^{\text{curr}}_{i,c,g} \cdot (1 - t_i) \cdot 
  \left(1 - \sum_{f \in \mathcal{F}_i^+} x_{i,f,c,g}\right)
}_{\text{Penalty for removing items (lost productivity)}} \\
& - 
\underbrace{
  \text{(Slack penalties, if enabled)}
}_{\text{Penalty for constraint violations}}
\end{aligned}
$$

  If slack penalties are enabled (for need states, brands, suppliers, etc.), the objective becomes:
  $$
 \max \quad \text{[above terms]} - \sum_{s \in S} \lambda_s \cdot s
  $$
 
Or, 
- Maximize the total productivity of all assigned facings
- Minus the productivity lost from items that are removed (not assigned any nonzero facings, weighted by their transference)
- Minus penalties for violating soft constraints (if those features are enabled in the config).

## Constaraints:
With the constraints being:

### Total Used Space Constraint

Let:

- $x_{i,f,c,g}$: binary variable, 1 if item $i$ is assigned $f$ facings in cluster $c$, plano $g$, 0 otherwise.
- $w_{i,f,c,g}$: width of item $i$ for $f$ facings in cluster $c$, plano $g$.
- $S_{c,g}$: total linear space available in cluster $c$, plano $g$.
- $R_{c,g}$: reserved space for local items in cluster $c$, plano $g$.

$$\sum_{(i,f) \in \mathcal{E}_{c,g}} x_{i,f,c,g} \cdot w_{i,f,c,g} \leq S_{c,g} - R_{c,g}$$


- Ensures that the total space allocated to items does not exceed the available space minus the reserved space for local items.

### Items Forced Facings Guardrails Constraint

Let:
- $\mathcal{F}_{i,c,g}$: possible set facings for item $i$ in cluster $c$, plano $g$.

$$\sum_{f \in \mathcal{F}_{i,c,g}} x_{i,f,c,g} = 1$$


- Ensures that items with forced guardrails are assigned exactly one facing from the specified set of facings.

### At Most One Facing Value Assigned Constraint

Let:

- $\mathcal{F}_i$: set of possible facings for item $i$.

$$\sum_{f \in \mathcal{F}_i} x_{i,f,c,g} = 1$$


- Ensures that exactly one facing value is assigned to each item.


<span style="color:red">Check this constraint and the one above it.</span>

### Max Incremental/Decremental Facings Constraint


Let:

- $\mathcal{F}_{i,c,g}^{\text{ineligible}}$: set of facings exceeding the maximum incremental facings or below the minimum decremental facings for item $i$ in cluster $c$, plano $g$.

$$x_{i,f,c,g} = 0 \quad \forall f \in \mathcal{F}_{i,c,g}^{\text{ineligible}}$$


- Ensures that items cannot receive more than a specified number of incremental facings or cannot lose more than a specified number of facings.

### Max Facings in Plano Category Constraint

Let:

- $\mathcal{F}_{i,c,g}^{\text{above max}}$: set of facings exceeding the maximum allowed facings for item $i$ in cluster $c$, plano $g$.

$$x_{i,f,c,g} = 0 \quad \forall f \in \mathcal{F}_{i,c,g}^{\text{above max}}$$

- Ensures that items cannot receive more than the maximum allowed facings in a plano category.

### Min/Max Need State Facings Constraint

- $\mathcal{I}_{n,c,g}$: set of items in need state $n$ for cluster $c$, plano $g$.
- $\text{MinFacings}_{n,c,g}$: minimum facings required for need state $n$ in cluster $c$, plano $g$.
- $\text{MaxFacings}_{n,c,g}$: maximum facings allowed for need state $n$ in cluster $c$, plano $g$.

$$\text{MinFacings}_{n,c,g} \leq \sum_{i \in \mathcal{I}_{n,c,g}} \sum_{f} f \cdot x_{i,f,c,g} \leq \text{MaxFacings}_{n,c,g}$$


- Ensures that the total facings assigned to items in a need state are within the specified minimum and maximum bounds.

### Max % Drop in Own Brand Space Constraint

Let:
- $w_{i,f,c,g}$: width of item $i$ for $f$ facings in cluster $c$, plano $g$.
- $\mathcal{I}_{\text{own},c,g}$: set of own brand items in cluster $c$, plano $g$.
- $S_{\text{own},c,g}$: total linear space allocated to own brands in cluster $c$, plano $g$.
- $\text{MaxDrop}_{c,g}$: maximum percentage drop allowed for own brand space.

$$\sum_{i \in \mathcal{I}_{\text{own},c,g}} \sum_{f} w_{i,f,c,g} \cdot x_{i,f,c,g} \geq (1 - \text{MaxDrop}_{c,g}) \cdot S_{\text{own},c,g}$$

- Ensures that the space allocated to own brands does not drop below a specified percentage.

### Pivot/Linked SKU Pairs Constraint

Let:

- $\mathcal{F}_i^+$: set of facings excluding 0 for item $i$.

$$\sum_{f \in \mathcal{F}_{i_l}^+} x_{i_l,f,c,g} \geq \sum_{f \in \mathcal{F}_{i_p}^+} x_{i_p,f,c,g}$$

$$x_{i_l,0,c,g} = x_{i_p,0,c,g}$$

- Ensures that linked SKUs are assigned facings in tandem with their pivot SKUs.
