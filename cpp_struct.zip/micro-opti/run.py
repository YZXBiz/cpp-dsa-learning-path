#!/usr/bin/env python
"""This is the entrypoint of your application"""
import os

from oxygen.boot import bootstrap
from oxygen.commands import *  # noqa


if __name__ == "__main__":
    os.environ.setdefault("SETTINGS_MODULE", "configs.settings")
    bootstrap()
    # Standalone mode must be disabled to enable Databricks execution
    cli.cli(standalone_mode=False)  # noqa
